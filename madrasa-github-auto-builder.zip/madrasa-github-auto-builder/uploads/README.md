# অ্যাপ জিপ আপলোড ফোল্ডার

ভবিষ্যতে যেকোনো নতুন আপডেটের জিপ ফাইল (যেমন `madrasa-management-phase4-final.zip` বা `madrasa-android-studio-ready.zip`)
এই `uploads/` ফোল্ডারে GitHub থেকে **Add file > Upload files** করে Commit করলেই
GitHub Actions স্বয়ংক্রিয়ভাবে ৩টি ভার্সনের APK বিল্ড করে ডাউনলোডযোগ্য জিপ তৈরি করে দেবে।
