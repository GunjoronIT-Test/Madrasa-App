# গিটহাব (GitHub) দিয়ে অটোমেটিক ৩ ভার্সনের Android APK বিল্ড গাইড

অ্যান্ড্রয়েড স্টুডিও ছাড়াই গিটহাব থেকে ৩টি আলাদা ভার্সনের APK বানানোর সম্পূর্ণ নিয়ম:

## ৩টি বিল্ড ভার্সন কী কী?
1. **`1-madrasa-debug.apk` (ডিবাগ ভার্সন):** ডেভেলপমেন্ট ও ব্রাউজার/USB ডিবাগিংয়ের জন্য (`com.madrasa.darululum.app.debug`)।
2. **`2-madrasa-release-standard.apk` (রিলিজ — ডিবাগের কাছাকাছি):** সাধারণ রিলিজ ভার্সন, কোড মিনিফাই ছাড়া, দ্রুত টেস্টের জন্য (`com.madrasa.darululum.app.std`)।
3. **`3-madrasa-release-hardened.apk` (রিলিজ — হালকা ও সুরক্ষিত):** সবচেয়ে ছোট সাইজের প্রোডাকশন ভার্সন — এতে R8 কোড শ্রিংকিং, রিসোর্স শ্রিংকিং, জাভা অবফাসকেশন, JS/CSS/HTML মিনিফিকেশন ও অবফাসকেশন এবং `allowBackup="false"` ও WebView ডিবাগিং বন্ধ করা আছে (`com.madrasa.darululum.app`)।

## কীভাবে ব্যবহার করবেন (৫ মিনিটে সম্পন্ন)
1. গিটহাবে (`https://github.com`) একটি নতুন প্রাইভেট বা পাবলিক রিপোজিটরি তৈরি করুন (যেমন `madrasa-app-builder`)।
2. এই জিপটি আনজিপ করে ভেতরের সব ফাইল (`.github/`, `android/`, `uploads/`, `GITHUB_BUILD_GUIDE.md`, `.gitignore`) আপনার রিপোতে আপলোড/পুশ করুন।
   - *গুরুত্বপূর্ণ:* ওয়েব UI দিয়ে আপলোড করলে `.github/workflows/build-android-apk.yml` ফাইলটি যেন অবশ্যই আপলোড হয় (অথবা Git CLI দিয়ে পুশ করুন)।
3. পুশ করার সাথে সাথেই আপনার রিপোর **Actions** ট্যাবে `Build Madrasa Android APKs (3 Variants)` অটো চালু হয়ে যাবে (প্রায় ৩–৫ মিনিট লাগবে)।
4. বিল্ড সবুজ টিক দেখালে ওই রান-এ ক্লিক করে নিচে **Artifacts** সেকশন থেকে **`madrasa-android-apks-3-variants`** ক্লিক করলেই ৩টি APK-সহ একটি জিপ ফাইল ডাউনলোড হয়ে যাবে।

## ভবিষ্যতে নতুন জিপ আপলোড করে আবার বিল্ড করবেন কীভাবে?
- আপনার রিপোর `uploads/` ফোল্ডারে ঢুকে **Add file > Upload files** ক্লিক করে নতুন অ্যাপের `.zip` ফাইলটি আপলোড করে **Commit changes** দিন।
- সাথে সাথেই GitHub Actions নতুন জিপ থেকে কোড নিয়ে আবার ৩টি ভার্সনের APK বানিয়ে দেবে।

## স্থায়ী রিলিজ Keystore ব্যবহার করতে চাইলে (Play Store-এর জন্য)
গিটহাব রিপোর **Settings > Secrets and variables > Actions**-এ নিচের ৪টি Secret যোগ করলে আপনার নিজের স্থায়ী Keystore দিয়ে সাইন হবে (না দিলেও টেস্টের জন্য অটো সাইন হয়ে ফোনে ইনস্টল করা যাবে):
- `ANDROID_KEYSTORE_BASE64`
- `KEYSTORE_PASSWORD`
- `KEY_ALIAS`
- `KEY_PASSWORD`
