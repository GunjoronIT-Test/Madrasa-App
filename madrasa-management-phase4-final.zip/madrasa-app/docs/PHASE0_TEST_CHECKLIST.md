# ফেজ ০ — টেস্ট ও যাচাই চেকলিস্ট

ফেজ ১ শুরু করার আগে নিচের ধাপগুলো মিলিয়ে নিন:

1. **জিপ এক্সট্র্যাক্ট ও ফোল্ডার যাচাই:**
   - `madrasa-management-phase0.zip` আনজিপ করে দেখুন `firebase.json`, `firestore.rules`, `storage.rules`, `firestore.indexes.json`, `docs/`, `scripts/`, এবং `public/` ফোল্ডার সঠিকভাবে আছে কি না।
2. **অটোমেটেড ভেরিফিকেশন স্ক্রিপ্ট চালানো:**
   - টার্মিনালে `madrasa-app` ফোল্ডারের ভেতর ঢুকে চালান:
     `bash scripts/verify-phase0.sh`
   - সবগুলো চেক সবুজ রঙে **PASS** দেখাতে হবে (JSON ফরম্যাট, সিকিউরিটি রুলস কাঠামো, লোকাল ফন্ট ফাইল, SVG ভেক্টর আইকন এবং শূন্য-ইমোজি অডিট)।
3. **Firebase প্রজেক্ট ও কনফিগ সেটআপ:**
   - `docs/FIREBASE_SETUP_GUIDE.md` অনুসরণ করে Firebase প্রজেক্ট খুলুন।
   - `public/config/firebase-config.example.js` কপি করে `public/config/firebase-config.js` বানান এবং আপনার কনফিগ বসান।
   - `.firebaserc.example` কপি করে `.firebaserc` বানান এবং প্রজেক্ট আইডি বসান।
4. **রুলস ও ইনডেক্স ডিপ্লয় যাচাই:**
   - `firebase deploy --only firestore:rules,firestore:indexes,storage` চালিয়ে কোনো সিনট্যাক্স এরর ছাড়াই ডিপ্লয় হচ্ছে কি না নিশ্চিত করুন।
5. **স্কিমা ও ঘাটতি পর্যালোচনা:**
   - `docs/DATABASE_SCHEMA.md` এবং `docs/PHASE1_FILE_PLAN.md` পড়ে কোনো মডিউল বা ফিল্ড বদলাতে চাইলে জানান।
