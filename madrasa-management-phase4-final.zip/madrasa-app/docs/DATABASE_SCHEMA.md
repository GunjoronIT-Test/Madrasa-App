# ডেটাবেস স্কিমা (Firestore + Storage) — ফেজ ০

এই ডকুমেন্টে পুরো মাদ্রাসা ম্যানেজমেন্ট অ্যাপের পূর্ণ Firestore কালেকশন, ফিল্ড, সম্পর্ক, স্টোরেজ পাথ এবং নিরাপত্তা নীতিমালা নির্ধারণ করা হয়েছে।

## ১. মূল স্থাপত্য নীতি (Core Architecture Rules)

1. **সর্বজনীন ব্র্যান্ডিং (White-Label):** কোথাও মাদ্রাসার নাম, লোগো, ঠিকানা বা রঙ হার্ডকোড করা হবে না। সবকিছু `settings/institution` থেকে লোড হবে।
2. **মাল্টি-শাখা প্রস্তুতি (`branchId`):** প্রতিটি ব্যবসায়িক ডকুমেন্টে `branchId` (ডিফল্ট: `"main"`) থাকবে, যাতে ভবিষ্যতে একাধিক শাখা যুক্ত করলে ডেটাবেস বদলাতে না হয়।
3. **অপরিবর্তনীয় আর্থিক লেজার (Immutable Financial Ledger):** `transactions` ও `payroll` ডকুমেন্ট কখনো মুছে ফেলা (`delete`) যাবে না এবং মূল `amount` বদলানো যাবে না। ভুল এন্ট্রি হলে `type: "reversal"` ও `reversalOfTxId` দিয়ে নতুন রিভার্সাল এন্ট্রি তৈরি হবে।
4. **সফট ডিলিট (Soft Delete & Recycle Bin):** ছাত্র, স্টাফ, দাতা, ভর্তি বা সম্পদ সরাসরি মুছবে না; `isDeleted: true`, `deletedAt`, `deletedBy` সেট হয়ে রিসাইকেল বিনে যাবে।
5. **শরিয়াহ তহবিল পৃথকীকরণ (Shariah Fund Guardrail):** প্রতিটি তহবিল (`funds`) আলাদা থাকবে এবং `zakatEligible` ফ্ল্যাগ থাকবে, যাতে যাকাত/ফিতরা তহবিল থেকে ভুলবশত অযোগ্য খাতে (যেমন ভবন নির্মাণ বা সাধারণ বেতন) খরচ করা হলে সিস্টেম সতর্কতা দেয়।
6. **শিশুদের গোপনীয়তা (Child Privacy):** অভিভাবক (`guardian`) শুধু নিজের `linkedStudentIds`-এর ছাত্রদের তথ্য দেখতে পারবে। পাবলিক QR যাচাই (`public_verifications`) শুধু রিসিট/সনদের বৈধতা দেখাবে, ছাত্রের ঠিকানা বা ফোন নম্বর নয়।

---

## ২. Firestore কালেকশন তালিকা

### ২.১ সেটিংস ও শাখা
- **`settings/institution`** (একক ডকুমেন্ট)
  - `nameBn` (string), `nameEn` (string), `slogan` (string)
  - `logoUrl` (string), `sealUrl` (string), `signatureUrl` (string)
  - `address` (string), `phone` (string), `email` (string), `website` (string)
  - `establishedYear` (number), `registrationNo` (string), `muhtamimName` (string)
  - `primaryColor` (string, যেমন `#0F6E56`), `accentColor` (string, যেমন `#B47B2B`)
  - `currencySymbol` (string, ডিফল্ট `"৳"`), `academicStartMonth` (number, ১–১২)
  - `defaultLanguage` (`"bn"` | `"en"`), `numberFormat` (`"bn"` | `"en"`)
  - `expenseApprovalLimit` (number — এর বেশি খরচে মুহতামিমের অনুমোদন লাগবে)
  - `setupCompleted` (boolean), `demoMode` (boolean), `updatedAt` (timestamp)

- **`branches/{branchId}`**
  - `branchId`, `nameBn`, `address`, `phone`, `isDefault` (boolean), `status` (`"active"` | `"inactive"`)

### ২.২ ইউজার ও নিরাপত্তা
- **`users/{uid}`**
  - `uid`, `name`, `phone`, `email`
  - `role`: `"muhtamim"` | `"nayeb_muhtamim"` | `"accountant"` | `"education_secretary"` | `"ustad"` | `"office_staff"` | `"guardian"`
  - `branchId` (`"main"` বা `"all"`), `linkedStudentIds` (array — শুধু অভিভাবকের জন্য)
  - `status` (`"active"` | `"suspended"`), `isDeleted` (boolean), `createdAt`, `updatedAt`
- **`users/{uid}/security/pin`** (প্রাইভেট সাব-কালেকশন)
  - `pinHash` (string — সল্টেড SHA-256 হ্যাশ), `salt` (string), `updatedAt` (timestamp)

### ২.৩ একাডেমিক কাঠামো
- **`academic_years/{yearId}`**: `branchId`, `nameBn` (যেমন `"১৪৪৭-৪৮ হি. / ২০২৬-২৭"`), `startDate`, `endDate`, `isCurrent` (boolean)
- **`departments/{deptId}`**: `branchId`, `nameBn` (যেমন মক্তব, নাজেরা, হিফজ, কিতাব, ইফতা), `order` (number), `isDeleted`
- **`jamats/{jamatId}`**: `branchId`, `departmentId`, `nameBn`, `monthlyFeeDefault` (number), `order` (number), `isDeleted`

### ২.৪ ভর্তি ও ছাত্র ব্যবস্থাপনা
- **`admissions/{admissionId}`**
  - `branchId`, `academicYearId`, `applicationNo`, `studentNameBn`, `studentNameEn`, `fatherName`, `motherName`, `guardianPhone`, `dob`, `address`, `photoUrl`, `documentUrls` (array)
  - `targetDepartmentId`, `targetJamatId`, `category` (`"residential"` | `"non_residential"` | `"lillah_boarding"` | `"orphan"`)
  - `examScore`, `status` (`"pending"` | `"approved"` | `"admitted"` | `"rejected"`), `admittedStudentId`, `isDeleted`, `createdAt`

- **`students/{studentId}`**
  - `branchId`, `studentCode` (অটো সিরিয়াল), `academicYearId`, `departmentId`, `jamatId`, `rollNumber`
  - `nameBn`, `nameEn`, `photoUrl`, `dob`, `bloodGroup`, `birthRegNo`
  - `fatherName`, `motherName`, `guardianName`, `guardianPhone`, `guardianRelation`, `guardianUserId`
  - `presentAddress`, `permanentAddress`
  - `category` (`"residential"` | `"non_residential"` | `"lillah_boarding"` | `"orphan"`)
  - `monthlyFee` (number), `feeWaiverAmount` (number), `feeWaiverReason` (string)
  - `hostelRoomId`, `status` (`"active"` | `"tc_issued"` | `"alumni"` | `"inactive"`)
  - `disciplineNotes` (array), `healthNotes` (string), `isDeleted` (boolean), `createdAt`, `updatedAt`

- **`student_enrollments/{enrollmentId}`** (নতুন সংযোজন — প্রতি শিক্ষাবর্ষে ছাত্রের প্রমোশন ইতিহাস)
  - `branchId`, `studentId`, `academicYearId`, `departmentId`, `jamatId`, `rollNumber`, `resultStatus` (`"promoted"` | `"repeated"` | `"graduated"` | `"ongoing"`)

### ২.৫ হাজিরা
- **`attendance/{attendanceId}`** (আইডি ফরম্যাট: `{branchId}_{type}_{date}_{targetId}`)
  - `branchId`, `type` (`"student"` | `"staff"`), `date` (`"YYYY-MM-DD"`), `hijriDate` (string)
  - `targetId` (`studentId` বা `staffId`), `jamatId` (ছাত্রের ক্ষেত্রে)
  - `status` (`"present"` | `"absent"` | `"leave"` | `"late"`), `note`, `markedBy`, `updatedAt`

### ২.৬ ওস্তাদ, স্টাফ ও বেতন
- **`staff/{staffId}`**
  - `branchId`, `userId`, `staffCode`, `nameBn`, `designation`, `phone`, `nidNo`, `photoUrl`
  - `joiningDate`, `baseSalary` (number), `allowances` (number), `status` (`"active"` | `"resigned"`), `isDeleted`
- **`payroll/{payrollId}`**
  - `branchId`, `staffId`, `userId`, `month` (`"YYYY-MM"`), `baseSalary`, `bonus`, `advanceDeduction`, `otherDeduction`, `netAmount`, `paidAmount`
  - `status` (`"unpaid"` | `"partial"` | `"paid"` | `"reversed"`), `transactionId`, `receiptNo`, `paidAt`, `createdBy`

### ২.৭ ছাত্র ফি ও বকেয়া (নতুন সংযোজন: ইনভয়েস বনাম পেমেন্ট লেজার)
- **`fee_structures/{structureId}`**: `branchId`, `academicYearId`, `jamatId`, `feeType` (`"admission"` | `"monthly"` | `"exam"` | `"meal"` | `"hostel"`), `amount`, `isActive`
- **`fee_invoices/{invoiceId}`**
  - `branchId`, `studentId`, `academicYearId`, `jamatId`, `billingMonth` (`"YYYY-MM"`), `feeType`
  - `grossAmount`, `waiverAmount`, `waiverReason`, `netAmount`, `paidAmount`, `dueAmount`
  - `status` (`"unpaid"` | `"partial"` | `"paid"` | `"waived"`), `transactionIds` (array), `createdAt`, `updatedAt`

### ২.৮ আয়-ব্যয়, তহবিল ও হিসাব
- **`funds/{fundId}`** (আলাদা শরিয়াহ তহবিল)
  - `branchId`, `code` (`"general"` | `"zakat"` | `"sadaqah"` | `"fitra"` | `"qurbani_skin"` | `"lillah"` | `"construction"`)
  - `nameBn`, `zakatRestricted` (boolean — true হলে শুধু যাকাত-যোগ্য খাতে ব্যয় অনুমোদিত), `currentBalance` (number)
- **`accounts/{accountId}`** (ক্যাশ/ব্যাংক/মোবাইল ব্যাংকিং)
  - `branchId`, `type` (`"cash"` | `"bank"` | `"bkash"` | `"nagad"`), `nameBn`, `accountNo`, `currentBalance` (number)
- **`transactions/{txId}`** (অপরিবর্তনীয় লেজার)
  - `branchId`, `receiptNo` (অটো সিরিয়াল), `date` (`"YYYY-MM-DD"`), `hijriDate`
  - `type` (`"income"` | `"expense"` | `"reversal"`), `category` (যেমন `student_fee`, `general_donation`, `zakat`, `salary`, `food`, `electricity`, `event`)
  - `fundId`, `accountId`, `amount` (number > 0), `description`, `voucherUrl`
  - `studentId` (ঐচ্ছিক), `donorId` (ঐচ্ছিক), `campaignId` (ঐচ্ছিক), `eventId` (ঐচ্ছিক), `loanId` (ঐচ্ছিক)
  - `status` (`"posted"` | `"reversed"`), `reversalOfTxId`, `reversalTxId`, `reversalReason`
  - `approvalStatus` (`"auto_approved"` | `"pending_approval"` | `"approved"` | `"rejected"`), `approvedBy`, `approvedAt`
  - `verifyCode` (QR যাচাই কোড), `createdBy`, `createdAt`

### ২.৯ দান, দাতা ও ঋণ
- **`donors/{donorId}`**: `branchId`, `nameBn`, `phone`, `address`, `donorType` (`"regular"` | `"one_time"`), `pledgedAmount`, `pledgeFrequency`, `collectorId`, `isDeleted`
- **`donation_campaigns/{campaignId}`**: `branchId`, `titleBn`, `fundId`, `targetAmount`, `collectedAmount`, `startDate`, `endDate`, `status`
- **`loans/{loanId}`**: `branchId`, `direction` (`"payable"` | `"receivable"`), `partyName`, `partyPhone`, `principalAmount`, `paidAmount`, `remainingAmount`, `dueDate`, `installments` (array), `status`, `createdBy`

### ২.১০ পরীক্ষা, হিফজ, অনুষ্ঠান, আবাসিক ও যোগাযোগ (ফেজ ২ ও ৩)
- **`exams/{examId}`**, **`exam_results/{resultId}`** (কওমি/বেফাক গ্রেডিং সেটিং সহ)
- **`hifz_logs/{logId}`** (`studentId`, `date`, `paraNo`, `sabaq`, `sabqi`, `amokhta`, `ustadNote`)
- **`routines/{routineId}`**, **`holidays/{holidayId}`**, **`events/{eventId}`** (বাজেট, কমিটি, টাস্ক, বক্তা)
- **`hostel_rooms/{roomId}`**, **`meal_logs/{mealId}`**, **`inventory/{itemId}`**, **`assets/{assetId}`**, **`library_books/{bookId}`**, **`library_issues/{issueId}`**
- **`notices/{noticeId}`**, **`leave_requests/{reqId}`**

### ২.১১ সিস্টেম ও নিরাপত্তা (নতুন সংযোজন)
- **`counters/{counterId}`**: `branchId`, `prefix` (যেমন `"RCP-2026-"`), `lastNumber` (atomic increment)
- **`audit_logs/{logId}`**: `branchId`, `actorId`, `actorName`, `actorRole`, `action`, `collection`, `docId`, `summary`, `createdAt`
- **`public_verifications/{verifyCode}`**: `docType` (`"receipt"` | `"admit_card"` | `"certificate"` | `"tc"`), `serialNo`, `holderName`, `amount` (ঐচ্ছিক), `issuedDate`, `status` (`"valid"` | `"revoked"`)

---

## ৩. Firebase Storage পাথ কাঠামো

| পাথ | ব্যবহার | সর্বোচ্চ সাইজ |
| --- | --- | --- |
| `institution/{fileName}` | মাদ্রাসার লোগো, সিলমোহর ও মুহতামিমের স্বাক্ষর | ২ মেগাবাইট |
| `students/{studentId}/{fileName}` | ছাত্রের ছবি, জন্মনিবন্ধন ও অভিভাবকের NID | ৩ মেগাবাইট |
| `staff/{staffId}/{fileName}` | ওস্তাদ/স্টাফের ছবি ও NID | ৩ মেগাবাইট |
| `vouchers/{txId}/{fileName}` | খরচের ভাউচার ও বিলের ছবি/PDF | ৫ মেগাবাইট |
| `events/{eventId}/{fileName}` | মাহফিল/অনুষ্ঠানের ছবি ও ব্যানার | ৫ মেগাবাইট |
| `posters/{posterId}/{fileName}` | জেনারেট করা পোস্টার (PNG/PDF) | ৫ মেগাবাইট |
