# ফায়ারবেজ (Firebase) সেটআপ গাইড — ফেজ ০

এই অ্যাপটি **Firebase** (Authentication, Firestore, Storage, Hosting) ব্যবহার করে তৈরি করা হচ্ছে।
ফেজ ০ থেকে ফেজ ৩ পর্যন্ত সম্পূর্ণ কাজ Firebase-এর **ফ্রি (Spark) প্ল্যানেই** চালানো ও টেস্ট করা যাবে।

## ধাপ ১: নতুন Firebase প্রজেক্ট তৈরি
1. ব্রাউজারে `https://console.firebase.google.com` খুলুন এবং আপনার Google অ্যাকাউন্ট দিয়ে লগইন করুন।
2. **Add project** ক্লিক করুন এবং মাদ্রাসার নামে একটি প্রজেক্ট তৈরি করুন (যেমন `madrasa-demo-app`)।
3. Google Analytics চাইলে বন্ধ রেখে **Create project** ক্লিক করুন।

## ধাপ ২: প্রয়োজনীয় ৪টি সার্ভিস চালু করা
বাম পাশের মেনু (**Build**) থেকে নিচের সার্ভিসগুলো চালু করুন:

1. **Authentication:**
   - **Get started** ক্লিক করুন।
   - **Sign-in method** ট্যাব থেকে **Email/Password** চালু (Enable) করে Save করুন।
2. **Firestore Database:**
   - **Create database** ক্লিক করুন।
   - লোকেশন হিসেবে `asia-south1` (Mumbai) বা `asia-southeast1` (Singapore) বেছে নিন (বাংলাদেশ থেকে দ্রুত কাজ করবে)।
   - **Start in production mode** নির্বাচন করে তৈরি করুন (আমাদের `firestore.rules` ফাইল পরে ডিপ্লয় হবে)।
3. **Storage:**
   - **Get started** ক্লিক করুন এবং একই লোকেশনে তৈরি করুন।
4. **Hosting:**
   - **Get started** ক্লিক করুন (ডিপ্লয়মেন্টের জন্য তৈরি থাকবে)।

## ধাপ ৩: Web App রেজিস্টার ও কনফিগ সংগ্রহ
1. প্রজেক্ট ওভারভিউ থেকে **Web (`</>`)** আইকনে ক্লিক করুন।
2. অ্যাপের নাম দিন (যেমন `Madrasa Web PWA`), **Also set up Firebase Hosting** টিক দিয়ে **Register app** ক্লিক করুন।
3. স্ক্রিনে দেখানো `firebaseConfig` অবজেক্টটি কপি করুন।
4. এই জিপের `public/config/firebase-config.example.js` ফাইলটি কপি করে `public/config/firebase-config.js` নামে সেভ করুন এবং আপনার মানগুলো বসিয়ে দিন।
5. `.firebaserc.example` ফাইলটি কপি করে `.firebaserc` নামে সেভ করুন এবং `YOUR_MADRASA_FIREBASE_PROJECT_ID`-এর জায়গায় আপনার প্রজেক্ট আইডি বসান।

## ধাপ ৪: সিকিউরিটি রুলস ও ইনডেক্স ডিপ্লয় (টার্মিনাল কমান্ড)
আপনার কম্পিউটারে Node.js ইনস্টল থাকলে টার্মিনালে নিচের কমান্ডগুলো চালান:

```bash
npm install -g firebase-tools
firebase login
firebase deploy --only firestore:rules,firestore:indexes,storage
```

## কখন Blaze (পে-অ্যাজ-ইউ-গো) প্ল্যান লাগবে?
- **ফেজ ০ থেকে ফেজ ৩:** ফ্রি (Spark) প্ল্যানেই চলবে।
- **ফেজ ৪ (SMS, bKash/Nagad ওয়েবহুক, স্বয়ংক্রিয় ডেইলি ব্যাকআপ):** তখন Cloud Functions চালানোর জন্য Blaze প্ল্যান প্রয়োজন হবে।
