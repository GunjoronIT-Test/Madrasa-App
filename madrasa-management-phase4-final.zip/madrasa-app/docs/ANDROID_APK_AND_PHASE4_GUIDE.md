# ফেজ ৪ — Cloud Functions, SMS/bKash/Nagad এবং Android APK বিল্ড গাইড

## ১. Cloud Functions ডিপ্লয় (SMS ও bKash/Nagad ওয়েবহুক)
*(এর জন্য Firebase প্রজেক্টটি Blaze পে-অ্যাজ-ইউ-গো প্ল্যানে থাকতে হবে)*

```bash
cd functions
npm install
cd ..
firebase deploy --only functions
```

ডিপ্লয় করার আগে `functions/.env` ফাইলে আপনার গোপন চাবিগুলো রাখুন (এটি কখনো Git বা `public/`-এ রাখবেন না):
```
SMS_API_KEY=আপনার_SMS_API_KEY
SMS_SENDER_ID=আপনার_SENDER_ID
SMS_ENDPOINT_URL=https://bulksmsbd.net/api/smsapi
WEBHOOK_SECRET=একটি_শক্তিশালী_র্যান্ডম_সিক্রেট
```

## ২. একই কোড থেকে Android APK তৈরি (Capacitor)
আপনার কম্পিউটারে **Node.js** ও **Android Studio** ইনস্টল থাকলে নিচের কমান্ডগুলো চালান:

```bash
npm install
npx cap add android
npx cap sync android
npx cap open android
```

Android Studio খোলার পর:
1. মেনু থেকে **Build > Generate Signed Bundle / APK > APK** বেছে নিন।
2. নতুন Keystore তৈরি করে **release** বিল্ড করুন—আপনার সাইন করা Android APK তৈরি হয়ে যাবে।
3. যেকোনো নতুন মাদ্রাসার জন্য শুধু `capacitor.config.json`-এ `appId`, `appName` এবং `public/config/firebase-config.js` বদলে `npx cap sync android` চালালেই নতুন মাদ্রাসার নিজস্ব APK তৈরি হয়ে যাবে।

## ৩. একাধিক মাদ্রাসায় মাসিক হোস্টিং ডিপ্লয় (Model B)
নতুন কোনো মাদ্রাসার জন্য প্রজেক্ট ডিপ্লয় করতে:
```bash
bash scripts/deploy-madrasa.sh <madrasa-firebase-project-id>
```
