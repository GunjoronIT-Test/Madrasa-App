const { onCall, onRequest, HttpsError } = require('firebase-functions/v2/https');
const { onSchedule } = require('firebase-functions/v2/scheduler');
const admin = require('firebase-admin');

admin.initializeApp();
const db = admin.firestore();

/**
 * ১. নিরাপদ SMS প্রেরণ (শুধুমাত্র অনুমোদিত রোল কল করতে পারবে)
 * এনভায়রনমেন্ট ভ্যারিয়েবল: SMS_API_KEY, SMS_SENDER_ID, SMS_ENDPOINT_URL
 */
exports.sendMadrasaSms = onCall({ region: 'asia-south1' }, async (request) => {
  if (!request.auth) {
    throw new HttpsError('unauthenticated', 'লগইন আবশ্যক।');
  }
  const userSnap = await db.doc(`users/${request.auth.uid}`).get();
  const role = userSnap.exists ? userSnap.data().role : 'none';
  if (!['muhtamim', 'nayeb_muhtamim', 'accountant', 'office_staff'].includes(role)) {
    throw new HttpsError('permission-denied', 'SMS পাঠানোর অনুমতি নেই।');
  }

  const { phone, message } = request.data || {};
  if (!phone || !message) {
    throw new HttpsError('invalid-argument', 'ফোন নম্বর ও বার্তা আবশ্যক।');
  }

  const apiKey = process.env.SMS_API_KEY;
  const senderId = process.env.SMS_SENDER_ID;
  const endpoint = process.env.SMS_ENDPOINT_URL || 'https://bulksmsbd.net/api/smsapi';

  if (!apiKey || !senderId) {
    throw new HttpsError('failed-precondition', 'সার্ভারে SMS_API_KEY ও SMS_SENDER_ID সেট করা হয়নি।');
  }

  const url = `${endpoint}?api_key=${encodeURIComponent(apiKey)}&type=text&number=${encodeURIComponent(phone)}&senderid=${encodeURIComponent(senderId)}&message=${encodeURIComponent(message)}`;
  const res = await fetch(url);
  const bodyText = await res.text();

  await db.collection('audit_logs').add({
    branchId: 'main',
    actorId: request.auth.uid,
    actorRole: role,
    action: 'SEND_SMS',
    collection: 'sms_gateway',
    docId: phone,
    summary: `SMS প্রেরণ: ${phone}`,
    createdAt: new Date().toISOString()
  });

  return { ok: res.ok, gatewayResponse: bodyText };
});

/**
 * ২. bKash / Nagad পেমেন্ট ওয়েবহুক হ্যান্ডলার
 * পেমেন্ট নিশ্চিত হলে স্বয়ংক্রিয়ভাবে transactions ও fee_invoices আপডেট করে।
 */
async function processOnlinePayment(provider, payload) {
  const { invoiceId, trxID, amount, payerPhone } = payload || {};
  if (!invoiceId || !trxID || !amount) return { ok: false, reason: 'missing_fields' };

  const txId = `${provider}_${trxID}`;
  const txRef = db.doc(`transactions/${txId}`);
  const existing = await txRef.get();
  if (existing.exists) return { ok: true, duplicate: true };

  const amt = Number(amount);
  const today = new Date().toISOString().slice(0, 10);
  const receiptNo = `${provider.toUpperCase()}-${trxID}`;
  const verifyCode = `VRF-${trxID}`;

  await db.runTransaction(async (t) => {
    const invRef = db.doc(`fee_invoices/${invoiceId}`);
    const invSnap = await t.get(invRef);
    const inv = invSnap.exists ? invSnap.data() : null;

    t.set(txRef, {
      branchId: inv?.branchId || 'main',
      receiptNo,
      date: today,
      type: 'income',
      category: 'student_fee',
      fundId: 'fund_general',
      accountId: provider === 'bkash' ? 'acc_bkash' : 'acc_nagad',
      amount: amt,
      description: `অনলাইন ফি (${provider.toUpperCase()}) — ${payerPhone || ''}`,
      studentId: inv?.studentId || null,
      status: 'posted',
      approvalStatus: 'auto_approved',
      verifyCode,
      createdBy: `${provider}_webhook`,
      createdAt: new Date().toISOString()
    });

    if (inv) {
      const newPaid = Number(inv.paidAmount || 0) + amt;
      const newDue = Math.max(0, Number(inv.netAmount || 0) - newPaid);
      t.update(invRef, {
        paidAmount: newPaid,
        dueAmount: newDue,
        status: newDue === 0 ? 'paid' : 'partial',
        transactionIds: admin.firestore.FieldValue.arrayUnion(txId),
        updatedAt: new Date().toISOString()
      });
    }

    t.set(db.doc(`public_verifications/${verifyCode}`), {
      docType: 'receipt',
      serialNo: receiptNo,
      holderName: payerPhone || 'অনলাইন পেমেন্ট',
      amount: amt,
      issuedDate: today,
      status: 'valid'
    });
  });

  return { ok: true, txId };
}

exports.bkashWebhook = onRequest({ region: 'asia-south1' }, async (req, res) => {
  const secret = process.env.WEBHOOK_SECRET;
  if (secret && req.headers['x-webhook-secret'] !== secret) {
    return res.status(403).json({ error: 'Invalid signature' });
  }
  const result = await processOnlinePayment('bkash', req.body);
  return res.status(result.ok ? 200 : 400).json(result);
});

exports.nagadWebhook = onRequest({ region: 'asia-south1' }, async (req, res) => {
  const secret = process.env.WEBHOOK_SECRET;
  if (secret && req.headers['x-webhook-secret'] !== secret) {
    return res.status(403).json({ error: 'Invalid signature' });
  }
  const result = await processOnlinePayment('nagad', req.body);
  return res.status(result.ok ? 200 : 400).json(result);
});

/**
 * ৩. সাপ্তাহিক স্বয়ংক্রিয় ব্যাকআপ লগ (Blaze প্ল্যান)
 */
exports.scheduledWeeklyBackup = onSchedule(
  { schedule: 'every sunday 03:00', timeZone: 'Asia/Dhaka', region: 'asia-south1' },
  async () => {
    await db.collection('audit_logs').add({
      branchId: 'main',
      actorId: 'system_scheduler',
      actorName: 'অটো ব্যাকআপ সার্ভিস',
      actorRole: 'system',
      action: 'SCHEDULED_BACKUP_PING',
      collection: 'system',
      docId: new Date().toISOString().slice(0, 10),
      summary: 'সাপ্তাহিক স্বয়ংক্রিয় ব্যাকআপ রিমাইন্ডার সম্পন্ন',
      createdAt: new Date().toISOString()
    });
  }
);
