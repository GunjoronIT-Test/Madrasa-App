#!/usr/bin/env bash
set -u

GREEN='\033[0;32m'
RED='\033[0;31m'
NC='\033[0m'

PASS_COUNT=0
FAIL_COUNT=0

pass() {
  echo -e "${GREEN}[PASS]${NC} $1"
  PASS_COUNT=$((PASS_COUNT + 1))
}

fail() {
  echo -e "${RED}[FAIL]${NC} $1"
  FAIL_COUNT=$((FAIL_COUNT + 1))
}

echo "=================================================="
echo "  মাদ্রাসা ম্যানেজমেন্ট অ্যাপ — ফেজ ০ যাচাইকরণ"
echo "=================================================="

REQUIRED_FILES=(
  "firebase.json"
  ".firebaserc.example"
  "firestore.rules"
  "firestore.indexes.json"
  "storage.rules"
  "public/manifest.json"
  "public/config/firebase-config.example.js"
  "public/css/tokens.css"
  "public/assets/icons/icons.svg"
  "public/assets/fonts/NotoSerifByGunjoron-Regular.ttf"
  "public/assets/fonts/NotoSerifByGunjoron-Medium.ttf"
  "public/assets/fonts/NotoSerifByGunjoron-SemiBold.ttf"
  "public/assets/fonts/NotoSerifByGunjoron-Bold.ttf"
  "public/assets/fonts/OFL.txt"
  "docs/DATABASE_SCHEMA.md"
  "docs/FIREBASE_SETUP_GUIDE.md"
  "docs/PHASE1_FILE_PLAN.md"
  "docs/PHASE0_TEST_CHECKLIST.md"
)

for f in "${REQUIRED_FILES[@]}"; do
  if [ -f "$f" ]; then
    pass "ফাইল পাওয়া গেছে: $f"
  else
    fail "ফাইল অনুপস্থিত: $f"
  fi
done

for jf in "firebase.json" ".firebaserc.example" "firestore.indexes.json" "public/manifest.json"; do
  if python3 -c "import json; json.load(open('$jf', encoding='utf-8'))" 2>/dev/null; then
    pass "বৈধ JSON ফরম্যাট: $jf"
  else
    fail "অবৈধ JSON ফরম্যাট: $jf"
  fi
done

if grep -q "rules_version = '2';" firestore.rules && grep -q "match /transactions/{txId}" firestore.rules && grep -q "allow delete: if false;" firestore.rules; then
  pass "Firestore সিকিউরিটি রুলস ও আর্থিক অপরিবর্তনীয়তা নীতি যাচাই হয়েছে"
else
  fail "Firestore সিকিউরিটি রুলস অসম্পূর্ণ"
fi

if grep -q "service firebase.storage" storage.rules && grep -q "underSizeMB" storage.rules; then
  pass "Storage সিকিউরিটি রুলস যাচাই হয়েছে"
else
  fail "Storage সিকিউরিটি রুলস অসম্পূর্ণ"
fi

if grep -q "Noto Serif by Gunjoron" public/css/tokens.css; then
  pass "Noto Serif by Gunjoron ফন্ট টোকেন কনফিগারেশন যাচাই হয়েছে"
else
  fail "ফন্ট কনফিগারেশন অনুপস্থিত"
fi

if python3 -c "import xml.etree.ElementTree as ET; tree=ET.parse('public/assets/icons/icons.svg'); syms=tree.findall('.//{http://www.w3.org/2000/svg}symbol'); assert len(syms) >= 25, len(syms)" 2>/dev/null; then
  pass "ভেক্টর SVG আইকন স্প্রাইট বৈধ (২৫+ আইকন)"
else
  fail "ভেক্টর SVG আইকন স্প্রাইটে ত্রুটি"
fi

if python3 -c "
import pathlib, re, sys
emoji_re = re.compile(r'[\U0001F300-\U0001FAFF\u2600-\u27BF]')
bad = []
for p in pathlib.Path('.').rglob('*'):
    if p.is_file() and p.suffix in {'.json', '.rules', '.js', '.css', '.svg', '.md', '.txt', '.sh', '.html'}:
        txt = p.read_text(encoding='utf-8', errors='ignore')
        if emoji_re.search(txt):
            bad.append(str(p))
if bad:
    print('Emoji found in:', bad)
    sys.exit(1)
" 2>/dev/null; then
  pass "শূন্য-ইমোজি অডিট সফল (কোনো ফাইলে ইমোজি নেই)"
else
  fail "ইমোজি পাওয়া গেছে — অনুগ্রহ করে পরিষ্কার করুন"
fi

echo "--------------------------------------------------"
if [ "$FAIL_COUNT" -eq 0 ]; then
  echo -e "${GREEN}সকল যাচাই সফল হয়েছে! (PASS: ${PASS_COUNT}, FAIL: ${FAIL_COUNT})${NC}"
  exit 0
else
  echo -e "${RED}কিছু যাচাই ব্যর্থ হয়েছে! (PASS: ${PASS_COUNT}, FAIL: ${FAIL_COUNT})${NC}"
  exit 1
fi
