#!/usr/bin/env bash
set -u

GREEN='\033[0;32m'
RED='\033[0;31m'
NC='\033[0m'

PASS_COUNT=0
FAIL_COUNT=0

pass() {
  echo -e "${GREEN}[PASS]${NC} $1"
  PASS_COUNT=$((PASS_COUNT + 1))
}

fail() {
  echo -e "${RED}[FAIL]${NC} $1"
  FAIL_COUNT=$((FAIL_COUNT + 1))
}

echo "========================================================"
echo "  মাদ্রাসা ম্যানেজমেন্ট অ্যাপ — ফেজ ০ + ফেজ ১ (MVP) যাচাইকরণ"
echo "========================================================"

REQUIRED_FILES=(
  "firebase.json"
  "firestore.rules"
  "firestore.indexes.json"
  "storage.rules"
  "public/index.html"
  "public/manifest.json"
  "public/sw.js"
  "public/css/tokens.css"
  "public/css/base.css"
  "public/css/print.css"
  "public/assets/icons/icons.svg"
  "public/assets/fonts/NotoSerifByGunjoron-Regular.ttf"
  "public/assets/fonts/NotoSerifByGunjoron-Medium.ttf"
  "public/assets/fonts/NotoSerifByGunjoron-SemiBold.ttf"
  "public/assets/fonts/NotoSerifByGunjoron-Bold.ttf"
  "public/js/app.js"
  "public/js/core/firebase.js"
  "public/js/core/store.js"
  "public/js/core/brand.js"
  "public/js/core/icons.js"
  "public/js/core/auth.js"
  "public/js/core/router.js"
  "public/js/core/utils.js"
  "public/js/core/qr.js"
  "public/js/core/audit.js"
  "public/js/core/demo-data.js"
  "public/js/pages/setup-wizard.js"
  "public/js/pages/login.js"
  "public/js/pages/dashboard.js"
  "public/js/pages/students.js"
  "public/js/pages/admission.js"
  "public/js/pages/attendance.js"
  "public/js/pages/fees.js"
  "public/js/pages/finance.js"
  "public/js/pages/donations.js"
  "public/js/pages/receipt.js"
  "public/js/pages/verify.js"
  "public/js/pages/settings.js"
  "docs/PHASE1_TEST_CHECKLIST.md"
)

for f in "${REQUIRED_FILES[@]}"; do
  if [ -f "$f" ]; then
    pass "ফাইল বিদ্যমান: $f"
  else
    fail "ফাইল অনুপস্থিত: $f"
  fi
done

# JSON ফাইল চেক
for jf in "firebase.json" ".firebaserc.example" "firestore.indexes.json" "public/manifest.json"; do
  if python3 -c "import json; json.load(open('$jf', encoding='utf-8'))" 2>/dev/null; then
    pass "বৈধ JSON: $jf"
  else
    fail "অবৈধ JSON: $jf"
  fi
done

# শূন্য-ইমোজি অডিট
if python3 -c "
import pathlib, re, sys
emoji_re = re.compile(r'[\U0001F300-\U0001FAFF\u2600-\u27BF]')
bad = []
for p in pathlib.Path('.').rglob('*'):
    if p.is_file() and p.suffix in {'.json', '.rules', '.js', '.css', '.svg', '.md', '.txt', '.sh', '.html'}:
        txt = p.read_text(encoding='utf-8', errors='ignore')
        if emoji_re.search(txt):
            bad.append(str(p))
if bad:
    print('Emoji found in:', bad)
    sys.exit(1)
" 2>/dev/null; then
  pass "শূন্য-ইমোজি অডিট সফল"
else
  fail "ইমোজি পাওয়া গেছে"
fi

echo "--------------------------------------------------------"
if [ "$FAIL_COUNT" -eq 0 ]; then
  echo -e "${GREEN}ফেজ ১ সকল যাচাই সফল! (PASS: ${PASS_COUNT}, FAIL: ${FAIL_COUNT})${NC}"
  exit 0
else
  echo -e "${RED}কিছু যাচাই ব্যর্থ! (PASS: ${PASS_COUNT}, FAIL: ${FAIL_COUNT})${NC}"
  exit 1
fi
