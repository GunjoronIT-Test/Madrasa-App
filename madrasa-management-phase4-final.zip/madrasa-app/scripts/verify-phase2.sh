#!/usr/bin/env bash
set -u

GREEN='\033[0;32m'
RED='\033[0;31m'
NC='\033[0m'

PASS_COUNT=0
FAIL_COUNT=0

pass() { echo -e "${GREEN}[PASS]${NC} $1"; PASS_COUNT=$((PASS_COUNT + 1)); }
fail() { echo -e "${RED}[FAIL]${NC} $1"; FAIL_COUNT=$((FAIL_COUNT + 1)); }

echo "============================================================"
echo "  মাদ্রাসা ম্যানেজমেন্ট অ্যাপ — ফেজ ০ + ১ + ২ যাচাইকরণ"
echo "============================================================"

PHASE2_FILES=(
  "public/js/pages/staff.js"
  "public/js/pages/loans.js"
  "public/js/pages/exams.js"
  "public/js/pages/notices.js"
  "public/js/pages/posters.js"
  "public/js/pages/reports.js"
  "docs/PHASE2_TEST_CHECKLIST.md"
)

for f in "${PHASE2_FILES[@]}"; do
  if [ -f "$f" ]; then pass "ফেজ ২ ফাইল বিদ্যমান: $f"; else fail "ফাইল অনুপস্থিত: $f"; fi
done

if grep -q "renderPosters" public/js/app.js && grep -q "renderReports" public/js/app.js && grep -q "renderExams" public/js/app.js; then
  pass "app.js-এ ফেজ ২-এর সকল রুট সংযুক্ত"
else
  fail "app.js-এ ফেজ ২ রুট অনুপস্থিত"
fi

if python3 -c "
import pathlib, re, sys
emoji_re = re.compile(r'[\U0001F300-\U0001FAFF\u2600-\u27BF]')
bad = [str(p) for p in pathlib.Path('.').rglob('*') if p.is_file() and p.suffix in {'.json','.rules','.js','.css','.svg','.md','.txt','.sh','.html'} and emoji_re.search(p.read_text(encoding='utf-8', errors='ignore'))]
if bad: print('Emoji:', bad); sys.exit(1)
" 2>/dev/null; then
  pass "শূন্য-ইমোজি অডিট সফল (ফেজ ০+১+২)"
else
  fail "ইমোজি পাওয়া গেছে"
fi

echo "------------------------------------------------------------"
if [ "$FAIL_COUNT" -eq 0 ]; then
  echo -e "${GREEN}ফেজ ২ সকল যাচাই সফল! (PASS: ${PASS_COUNT}, FAIL: ${FAIL_COUNT})${NC}"
  exit 0
else
  echo -e "${RED}কিছু যাচাই ব্যর্থ! (PASS: ${PASS_COUNT}, FAIL: ${FAIL_COUNT})${NC}"
  exit 1
fi
