#!/usr/bin/env bash
# এক কোডবেস থেকে যেকোনো মাদ্রাসার আলাদা Firebase প্রজেক্টে ডিপ্লয় স্ক্রিপ্ট (Model B)
# ব্যবহার: bash scripts/deploy-madrasa.sh <firebase-project-id>

set -euo pipefail

GREEN='\033[0;32m'
RED='\033[0;31m'
NC='\033[0m'

if [ $# -lt 1 ]; then
  echo -e "${RED}ব্যবহার বিধি: bash scripts/deploy-madrasa.sh <firebase-project-id>${NC}"
  exit 1
fi

PROJECT_ID="$1"

if [ ! -f "public/config/firebase-config.js" ]; then
  echo -e "${RED}ত্রুটি: public/config/firebase-config.js ফাইলটি পাওয়া যায়নি।${NC}"
  echo "আগে public/config/firebase-config.example.js কপি করে কনফিগ বসান।"
  exit 1
fi

echo "ডিপ্লয় শুরু হচ্ছে প্রজেক্টে: $PROJECT_ID"
firebase use "$PROJECT_ID"
firebase deploy --only firestore:rules,firestore:indexes,storage,hosting

echo -e "${GREEN}সফলভাবে ডিপ্লয় সম্পন্ন হয়েছে: https://${PROJECT_ID}.web.app${NC}"
