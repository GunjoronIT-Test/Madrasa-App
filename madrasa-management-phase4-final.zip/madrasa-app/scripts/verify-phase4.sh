#!/usr/bin/env bash
set -u

GREEN='\033[0;32m'
RED='\033[0;31m'
NC='\033[0m'

PASS_COUNT=0
FAIL_COUNT=0

pass() { echo -e "${GREEN}[PASS]${NC} $1"; PASS_COUNT=$((PASS_COUNT + 1)); }
fail() { echo -e "${RED}[FAIL]${NC} $1"; FAIL_COUNT=$((FAIL_COUNT + 1)); }

echo "======================================================================"
echo "  মাদ্রাসা ম্যানেজমেন্ট অ্যাপ — চূড়ান্ত যাচাইকরণ (ফেজ ০ + ১ + ২ + ৩ + ৪)"
echo "======================================================================"

PHASE4_FILES=(
  "public/js/pages/qr-attendance.js"
  "public/js/pages/analytics.js"
  "public/js/pages/integrations.js"
  "functions/index.js"
  "functions/package.json"
  "package.json"
  "capacitor.config.json"
  "docs/ANDROID_APK_AND_PHASE4_GUIDE.md"
  "docs/PHASE4_TEST_CHECKLIST.md"
)

for f in "${PHASE4_FILES[@]}"; do
  if [ -f "$f" ]; then pass "ফেজ ৪ ফাইল বিদ্যমান: $f"; else fail "ফাইল অনুপস্থিত: $f"; fi
done

for jf in "firebase.json" "package.json" "capacitor.config.json" "functions/package.json" "firestore.indexes.json" "public/manifest.json"; do
  if python3 -c "import json; json.load(open('$jf', encoding='utf-8'))" 2>/dev/null; then
    pass "বৈধ JSON: $jf"
  else
    fail "অবৈধ JSON: $jf"
  fi
done

if grep -q "renderQrAttendance" public/js/app.js && grep -q "renderAnalytics" public/js/app.js && grep -q "renderIntegrations" public/js/app.js; then
  pass "app.js-এ ফেজ ৪-এর সকল রুট সংযুক্ত"
else
  fail "app.js-এ ফেজ ৪ রুট অনুপস্থিত"
fi

if python3 -c "
import pathlib, re, sys
emoji_re = re.compile(r'[\U0001F300-\U0001FAFF\u2600-\u27BF]')
bad = [str(p) for p in pathlib.Path('.').rglob('*') if p.is_file() and p.suffix in {'.json','.rules','.js','.css','.svg','.md','.txt','.sh','.html'} and emoji_re.search(p.read_text(encoding='utf-8', errors='ignore'))]
if bad: print('Emoji:', bad); sys.exit(1)
" 2>/dev/null; then
  pass "চূড়ান্ত শূন্য-ইমোজি অডিট সফল (সম্পূর্ণ প্রজেক্ট)"
else
  fail "ইমোজি পাওয়া গেছে"
fi

echo "----------------------------------------------------------------------"
if [ "$FAIL_COUNT" -eq 0 ]; then
  echo -e "${GREEN}চূড়ান্ত সকল যাচাই সফল! (PASS: ${PASS_COUNT}, FAIL: ${FAIL_COUNT})${NC}"
  exit 0
else
  echo -e "${RED}কিছু যাচাই ব্যর্থ! (PASS: ${PASS_COUNT}, FAIL: ${FAIL_COUNT})${NC}"
  exit 1
fi
