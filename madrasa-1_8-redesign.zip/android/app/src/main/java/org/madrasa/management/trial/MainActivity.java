package org.madrasa.management.trial;

import android.net.Uri;
import android.os.Bundle;
import android.webkit.WebView;
import androidx.activity.OnBackPressedCallback;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                WebView view = getBridge().getWebView();
                String address = view.getUrl();
                if (address == null) return;
                Uri url = Uri.parse(address);
                if (!"localhost".equals(url.getHost())) {
                    if (view.canGoBack()) view.goBack();
                    else view.loadUrl(getBridge().getAppUrl());
                    return;
                }
                view.evaluateJavascript("typeof window.madrasaBack === 'function' ? window.madrasaBack() : null",
                    handled -> { if ("false".equals(handled)) finish(); });
            }
        });
    }
}
