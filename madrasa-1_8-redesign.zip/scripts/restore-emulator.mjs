// Restore a cloud MVP backup into a new emulator project for a recovery rehearsal.
import {readFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {createRequire} from 'node:module';
const require=createRequire(new URL('../functions/package.json',import.meta.url));
const {initializeApp}=require('firebase-admin/app'),{getFirestore}=require('firebase-admin/firestore');
const projectId='demo-madrasa-restore',host=process.env.FIRESTORE_EMULATOR_HOST;
if(!/^127\.0\.0\.1:\d+$/.test(host||''))throw Error('লোকাল Firestore Emulator-এর ঠিকানা প্রয়োজন।');
const app=initializeApp({projectId,storageBucket:projectId+'.appspot.com'}),db=getFirestore(app);
const isMedia=(p,r)=>p.startsWith('branches/main/media/')&&r.storagePath;
let bucket;
try{
 const copy=JSON.parse(await readFile(process.argv[2],'utf8'));
 if(copy.format!=='madrasa-branch-backup'||copy.mode!=='cloud'||copy.version!==1||
    !copy.records?.['settings/institution']||copy.branchId!=='main'||copy.count!==Object.keys(copy.records).length||
    createHash('sha256').update(JSON.stringify(copy.records)).digest('hex')!==copy.checksum)throw Error('ব্যাকআপের অখণ্ডতা মেলেনি।');
 const entries=Object.entries(copy.records);
 for(const [p,r] of entries){
   if(p!=='settings/institution'&&!/^branches\/main\/[a-zA-Z]+\/[^/]+$/.test(p))throw Error('পথ সঠিক নয়।');
   if((p.startsWith('branches/main/studentFiles/')||(p.startsWith('branches/main/media/')&&r.storagePath))&&!r.bytes)throw Error('সংযুক্তির ডেটা নেই।');
 }
 if(entries.some(([p,r])=>isMedia(p,r))){
   if(!/^127\.0\.0\.1:\d+$/.test(process.env.FIREBASE_STORAGE_EMULATOR_HOST||''))throw Error('অনুষ্ঠানের মিডিয়া ফেরাতে লোকাল Storage Emulator চালু করুন।');
   bucket=require('firebase-admin/storage').getStorage(app).bucket();
 }
 // Stop at any previous import, including a partially completed one.
 if((await db.listCollections()).length)throw Error('পরীক্ষার গন্তব্য খালি থাকতে হবে।');
 await db.doc('rehearsal/state').create({complete:false,checksum:copy.checksum});
 for(let i=0;i<entries.length;i+=100){
   const batch=db.batch();
   for(const [p,r] of entries.slice(i,i+100)){
     if(isMedia(p,r)){
       if(!/^branches\/main\/eventMedia\/[\w-]+\/[a-f0-9]{64}$/.test(r.storagePath))throw Error('মিডিয়ার পথ সঠিক নয়।');
       const {bytes,...meta}=r;await bucket.file(meta.storagePath).save(Buffer.from(bytes,'base64'),{resumable:false,metadata:{contentType:meta.mime}});
       batch.create(db.doc(p),meta);
     }else batch.create(db.doc(p),r);
   }
   await batch.commit();
 }
 let balance=0,count=0;
 for(const [p,expected] of entries){
   const row=(await db.doc(p).get()).data();
   if(!row)throw Error('রেকর্ড অনুপস্থিত।');
   if(p.startsWith('branches/main/ledger/')){
     if(row.amountMinor!==expected.amountMinor||row.direction!==expected.direction)throw Error('হিসাব মেলেনি।');
     balance+=row.amountMinor*row.direction;
   }
   if(isMedia(p,expected))row.bytes=(await bucket.file(row.storagePath).download())[0].toString('base64');
   if((p.startsWith('branches/main/studentFiles/')||isMedia(p,expected))&&row.bytes!==expected.bytes)throw Error('সংযুক্তি মেলেনি।');
   count++;
 }
 await db.doc('rehearsal/state').update({complete:true,count,balance});
 console.log('পুনরুদ্ধার যাচাই সম্পন্ন।',count,'রেকর্ড। নিট পয়সা',balance);
}finally{await db.terminate()}
