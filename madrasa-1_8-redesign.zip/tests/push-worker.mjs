import test from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import {readFileSync} from 'node:fs';
const sw=readFileSync(new URL('../public/sw.js',import.meta.url),'utf8');
test('পুশে ব্যক্তিগত বিজ্ঞপ্তির লেখা লক স্ক্রিনে যায় না',async()=>{
 const events={},notifications=[],opened=[];
 const scope='https://example.test/app/';
 vm.runInNewContext(sw,{URL,self:{registration:{scope,showNotification:async(t,v)=>notifications.push([t,v])},addEventListener:(k,fn)=>events[k]=fn},clients:{openWindow:async u=>opened.push(u)}});
 let wait;
 events.push({data:{json:()=>({data:{type:'madrasa-notice',noticeId:'a1',institution:'প্রতিষ্ঠান',body:'ব্যক্তিগত তথ্য'}})},waitUntil:p=>{wait=p}});
 await wait;
 assert.equal(notifications[0][0],'প্রতিষ্ঠান');assert.equal(notifications[0][1].tag,'notice-a1');
 assert.ok(!JSON.stringify(notifications).includes('ব্যক্তিগত তথ্য'));
 events.notificationclick({notification:{data:{notice:true},close(){}},waitUntil:p=>{wait=p}});
 await wait;assert.equal(opened[0],scope+'#notices');
});
