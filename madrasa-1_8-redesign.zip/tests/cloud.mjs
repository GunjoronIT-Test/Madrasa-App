// This fixture can run only against the local emulator project.
import assert from 'node:assert/strict';
import {initializeApp} from 'firebase/app';
import {getAuth,connectAuthEmulator,signInWithEmailAndPassword} from 'firebase/auth';
import {getFirestore,connectFirestoreEmulator,doc,serverTimestamp,setDoc,getDoc,disableNetwork,enableNetwork,terminate} from 'firebase/firestore';
import {getFunctions,connectFunctionsEmulator,httpsCallable} from 'firebase/functions';
import {createRequire} from 'node:module';
const require=createRequire(new URL('../functions/package.json',import.meta.url));
const {initializeApp:adminApp}=require('firebase-admin/app');
const {getAuth:adminAuth}=require('firebase-admin/auth');
const {getFirestore:adminStore}=require('firebase-admin/firestore');
const projectId='demo-madrasa';
assert.equal(process.env.FIRESTORE_EMULATOR_HOST,'127.0.0.1:8080');
assert.equal(process.env.FIREBASE_AUTH_EMULATOR_HOST,'127.0.0.1:9099');
const admin=adminApp({projectId}),adb=adminStore(admin);
const app=initializeApp({projectId,apiKey:'demo-key',appId:'demo-app'});
const auth=getAuth(app),db=getFirestore(app),fn=getFunctions(app);
connectAuthEmulator(auth,'http://127.0.0.1:9099',{disableWarnings:true});
connectFirestoreEmulator(db,'127.0.0.1',8080);connectFunctionsEmulator(fn,'127.0.0.1',5001);
const email='phase1@example.test',password='local-emulator-2026';
const acc=await adminAuth(admin).getUserByEmail(email).catch(()=>adminAuth(admin).createUser({email,password}));
await adb.doc('branches/main/members/'+acc.uid).set({role:'principal',branchId:'main',active:true});
await signInWithEmailAndPassword(auth,email,password);
const b='branches/main/',sleep=ms=>new Promise(r=>setTimeout(r,ms));
async function submit(kind,payload,offline=false){
 const id=crypto.randomUUID(),ref=doc(db,b+'requests/'+id);
 if(['reversal','staffAdd','salaryPay','loanOpen','loanPay','familyLink','issueDoc','revokeDoc'].includes(kind))await httpsCallable(fn,'confirmAction')({kind,id,pin:'395827'});
 if(offline)await disableNetwork(db);
 const commit=setDoc(ref,{branchId:'main',actorUid:acc.uid,kind,payload,status:'queued',createdAt:serverTimestamp()});
 if(offline)await enableNetwork(db);await commit;
 for(let i=0;i<100;i++){
   const r=(await getDoc(ref)).data();
   if(r.status!=='queued'){assert.equal(r.status,'accepted',r.message);return r.result}
   await sleep(250);
 }
 throw Error('Processing timeout: '+kind);
}
try{
 if(!(await adb.doc('securityPins/'+acc.uid).get()).exists)await httpsCallable(fn,'setPin')({pin:'395827'});
 await assert.rejects(httpsCallable(fn,'confirmAction')({kind:'reversal',id:crypto.randomUUID(),pin:'000000'}));
 if(!(await adb.doc('settings/institution').get()).exists)await submit('setup',{nameBn:'এমুলেটর মাদ্রাসা',address:'ঢাকা',principalName:'প্রশাসক',classes:['হিফজ'],monthlyMinor:10000,admissionMinor:5000,academicYear:'২০২৬',startDate:'2026-01-01',primaryColor:'#185747',accentColor:'#ad8346'});
 const sid=await submit('admission',{displayName:'ছাত্র '+crypto.randomUUID().slice(0,8),guardian:'পরীক্ষা',phone:'01700000000',classId:'হিফজ',residentialStatus:'অনাবাসিক',date:'2026-11-01',files:[{kind:'document',name:'sample.pdf',mime:'application/pdf',bytes:Buffer.from('%PDF-1.4 fixture').toString('base64')}]});
 const file=await httpsCallable(fn,'readAttachment')({id:sid+'_0'});assert.equal(file.data.name,'sample.pdf');
 await submit('attendance',{studentId:sid,status:'present',date:'2026-11-04',revision:0},true);
 const id=await submit('fee',{invoiceId:'adm_'+sid,amountMinor:1000,date:'2026-11-04',account:'নগদ',fund:'সাধারণ'},true);
 assert.equal((await getDoc(doc(db,b+'invoices/adm_'+sid))).data().paidMinor,1000);
 await submit('reversal',{entryId:id,note:'সংশোধন',date:'2026-11-04'});
 assert.equal((await getDoc(doc(db,b+'invoices/adm_'+sid))).data().paidMinor,0);
 const staffId=await submit('staffAdd',{name:'এমুলেটর কর্মী',designation:'ওস্তাদ',baseMinor:12000,joinedOn:'2026-11-01'});
 await submit('salarySlip',{staffId,period:'2026-11'});
 const movement={fund:'সাধারণ',account:'নগদ',date:'2026-11-05'};
 const loanId=await submit('loanOpen',{...movement,side:'borrow',party:'নমুনা',amountMinor:9000,count:2,due:'2026-12-01'});
 await submit('salaryPay',{...movement,slipId:staffId+'_2026-11',advance:true,amountMinor:1000});
 await submit('loanPay',{...movement,loanId,installment:0,amountMinor:1500});
 const loan=(await getDoc(doc(db,b+'loans/'+loanId))).data();
 assert.equal(loan.paidMinor,1500);assert.equal(loan.installments[0].paid,1500);
 const eid=await submit('examCreate',{classId:'হিফজ',name:'পরীক্ষা',room:'১',subjects:[{name:'আরবি',date:'2026-11-12',time:'09:00',max:100,pass:40}],grades:[{min:40,label:'উত্তীর্ণ'},{min:0,label:'অনুত্তীর্ণ'}]});
 await submit('examMark',{examId:eid,studentId:sid,scores:[88],revision:0});
 await submit('noticePublish',{title:'নোটিশ',body:'এমুলেটর পরীক্ষা।',audience:'all',push:false});
 await httpsCallable(fn,'registerPush')({token:'local-test-token-not-for-delivery'});
 await httpsCallable(fn,'registerPush')({token:'local-test-token-not-for-delivery',remove:true});
 // Two separate Firebase Auth sessions exercise the family boundary, including revocation.
 const parents=[];
 for(const suffix of ['a','b']){
   const email='family-'+suffix+'@example.test';
   const acc=await adminAuth(admin).getUserByEmail(email).catch(()=>adminAuth(admin).createUser({email,password}));
   await adb.doc(b+'members/'+acc.uid).set({active:true,role:'guardian',branchId:'main'});
   const a=initializeApp({projectId,apiKey:'demo-key',appId:'demo-app'},'family-'+suffix);
   const au=getAuth(a);connectAuthEmulator(au,'http://127.0.0.1:9099',{disableWarnings:true});
   await signInWithEmailAndPassword(au,email,password);const f=getFunctions(a);connectFunctionsEmulator(f,'127.0.0.1',5001);
   parents.push({uid:acc.uid,summary:httpsCallable(f,'guardianSummary'),auth:au});
 }
 const second=await submit('admission',{displayName:'দ্বিতীয় '+crypto.randomUUID().slice(0,8),guardian:'অন্য',phone:'01800000000',classId:'হিফজ',residentialStatus:'অনাবাসিক',date:'2026-11-01'});
 await submit('familyLink',{uid:parents[0].uid,studentId:sid,link:true});await submit('familyLink',{uid:parents[1].uid,studentId:second,link:true});
 await submit('hifz',{studentId:sid,date:'2026-11-04',lesson:'সবক',juz:1,from:2,to:3,revision:0,comment:'পরীক্ষিত'});
 const summary=(await parents[0].summary({studentId:sid})).data;
 assert.equal(summary.progress[0].comment,'পরীক্ষিত');assert.equal(summary.results[0].total,88);
 assert.ok(summary.invoices.length>=1 && summary.receipts.length>=1);assert.equal(summary.student.phone,undefined);
 await assert.rejects(parents[1].summary({studentId:sid}),e=>e.code==='functions/permission-denied');
 await assert.rejects(parents[0].summary({studentId:second}),e=>e.code==='functions/permission-denied');
 await submit('familyLink',{uid:parents[0].uid,studentId:sid,link:false});
 await assert.rejects(parents[0].summary({studentId:sid}),e=>e.code==='functions/permission-denied');
 for(const p of parents)await p.auth.signOut();
 await submit('familyLink',{uid:parents[0].uid,studentId:sid,link:true});
 const eventId=await submit('eventAdd',{title:'মাহফিল',venue:'প্রাঙ্গণ',date:'2026-11-23',budgetMinor:10000});
 const jpeg='/9j/4AAQSkZJRgABAQAAAQABAAD/2Q==';
 const uploaded=await httpsCallable(fn,'uploadEventMedia')({eventId,title:'নমুনা',consent:true,file:{name:'test.jpg',mime:'image/jpeg',bytes:jpeg}});
 assert.equal((await httpsCallable(fn,'readEventMedia')({id:uploaded.data.id})).data.bytes,jpeg);
 await submit('eventMoney',{...movement,eventId,type:'donation',amountMinor:3000,note:'অনুদান'});
 const roomId=await submit('roomAdd',{name:'দক্ষিণ',capacity:2});
 await submit('bedAssign',{roomId,seat:1,studentId:sid,date:'2026-11-05'});
 const docId=await submit('issueDoc',{studentId:sid,type:'পরিচয়পত্র',body:'আবাসিক ছাত্র',date:'2026-11-05'});
 assert.equal((await getDoc(doc(db,b+'verification/'+docId))).data().active,true);
 await submit('revokeDoc',{docId,reason:'সংশোধন'});
 assert.equal((await getDoc(doc(db,b+'verification/'+docId))).data().active,false);
 console.log('PASS: two guardian sessions isolated, access revoked, private event media round trip, seat, ledger and QR status');
 const backup=await httpsCallable(fn,'exportBranch')({});
 if(process.env.REHEARSAL_FILE){
   const {pack}=await import('../src/backup.js');
   const {writeFile}=await import('node:fs/promises');
   await writeFile(process.env.REHEARSAL_FILE,JSON.stringify(await pack(backup.data.records,'cloud')));
 }
 assert.equal(backup.data.records[b+'students/'+sid].classId,'হিফজ');
 console.log('PASS: Auth, member, setup, admission, offline attendance and fee sync, reversal confirmation, export');
}finally{await terminate(db);await auth.signOut();await adb.terminate()}
