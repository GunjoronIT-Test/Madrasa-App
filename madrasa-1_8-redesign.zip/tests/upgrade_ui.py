"""Usage: python tests/upgrade_ui.py /path/to/unpacked-phase-1/madrasa/public"""
import sys, os, threading
from pathlib import Path
from http.server import ThreadingHTTPServer,SimpleHTTPRequestHandler
from playwright.sync_api import sync_playwright, expect
old=Path(sys.argv[1]).resolve()
new=Path(__file__).resolve().parents[1]/'public'
assert old!=new and (old/'sw.js').exists()
source=[old]
class Preview(SimpleHTTPRequestHandler):
    def __init__(self,*a,**kw):super().__init__(*a,directory=str(source[0]),**kw)
    def end_headers(self):self.send_header('Cache-Control','no-store');super().end_headers()
    def log_message(self,*args):pass
http=ThreadingHTTPServer(('127.0.0.1',0),Preview)
threading.Thread(target=http.serve_forever,daemon=True).start()
with sync_playwright() as p:
    browser=p.chromium.launch(executable_path=os.getenv('CHROMIUM','/usr/bin/chromium'),args=['--no-sandbox'])
    ctx=browser.new_context()
    page=ctx.new_page()
    url='http://127.0.0.1:'+str(http.server_port)
    page.goto(url);page.locator('[data-act=demo]').click()
    page.locator('aside [data-val=students]').click()
    before=page.locator('tbody tr').all_text_contents()
    assert len(before)>0
    page.locator('aside [data-val=finance]').click()
    ledger=page.locator('.panel').first.locator('tbody tr').all_text_contents()
    page.evaluate('navigator.serviceWorker.ready')
    page.wait_for_function('!!navigator.serviceWorker.controller')
    source[0]=new
    page.evaluate('(async()=>{const r=await navigator.serviceWorker.ready; await r.update()})()')
    page.wait_for_function('(async()=>!!(await navigator.serviceWorker.ready).waiting)()')
    page.close()
    page=ctx.new_page();page.goto(url);page.locator('[data-act=demo]').click()
    expect(page.locator('aside [data-val=scanning]')).to_be_visible()
    page.locator('aside [data-val=students]').click();assert page.locator('tbody tr').all_text_contents()==before
    page.locator('aside [data-val=finance]').click();assert page.locator('.panel').first.locator('tbody tr').all_text_contents()==ledger
    print('PASS: Prior release service-worker upgrade retained student roster and ledger on the same origin.')
    browser.close()
http.shutdown()
