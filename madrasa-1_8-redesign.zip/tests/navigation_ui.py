import os
from playwright.sync_api import sync_playwright,expect
with sync_playwright() as p:
 b=p.chromium.launch(executable_path=os.getenv('CHROMIUM','/usr/bin/chromium'),args=['--no-sandbox'])
 page=b.new_page(viewport={'width':1380,'height':900});page.goto(os.getenv('APP_URL','http://127.0.0.1:4173'))
 page.locator('[data-act=demo]').click();page.evaluate('document.fonts.ready')
 expect(page.locator(".overview-hero")).to_be_visible()
 keys=page.locator('aside [data-act=page]').evaluate_all('(els)=>els.map(el=>el.dataset.val)')
 assert len(keys)==len(set(keys))==24,keys
 for k in keys:
  page.locator('aside [data-val="'+k+'"]').click()
  assert page.locator('#content h1').count() or page.locator('#content h2').count(),k
 page.set_viewport_size({'width':375,'height':812});page.locator('.bottom [data-val=home]').click()
 page.locator('[data-act=admit]').click()
 assert page.locator('dialog:modal').count()==0
 expect(page.locator('#app')).not_to_be_visible()
 assert page.evaluate('document.documentElement.scrollWidth<=innerWidth')
 page.go_back()
 expect(page.locator('.overview-hero')).to_be_visible()
 page.locator('.bottom [data-act=more]').click()
 page.locator('[name=moduleQuery]').fill('হিফজ')
 expect(page.locator('.directory-list .navbtn')).to_have_count(1)
 page.locator('.directory-list .navbtn').click()
 expect(page.locator('#content h1')).to_contain_text('হিফজ')
 print('PASS all module routes, full-page forms, browser Back, phone directory and search.')
 page.locator('.bottom [data-act=more]').click()
 page.locator('dialog [data-act=customDock]').click()
 page.locator('[name=slot0]').select_option('library')
 page.locator('dialog form button.primary').click()
 page.reload()
 expect(page.locator('.bottom [data-val=library]')).to_be_visible()
 page.locator('.bottom [data-val=library]').click()
 expect(page.locator('.bottom [aria-current=location]')).to_have_attribute('data-val','library')
 page.keyboard.press('Control+k')
 expect(page.locator('[name=moduleQuery]')).to_be_focused()
 page.keyboard.press('Escape')
 page.locator('.mast-account').click()
 page.locator('dialog [data-act=sync]').click()
 expect(page.locator('#task-title')).to_have_text('সংরক্ষণ ও সিঙ্ক')
 page.locator('dialog [data-act=close]').click()
 expect(page.locator('#task-title')).to_have_text('আমার অ্যাকাউন্ট')
 page.locator('dialog [data-act=close]').click()
 for width in [320,375,430,768,1440]:
  page.set_viewport_size({'width':width,'height':820})
  assert page.evaluate('document.documentElement.scrollWidth<=innerWidth')
  if width<701:
   page.locator('.bottom [data-val=home]').click()
   assert page.locator('.mast-seal').is_visible()
   assert page.locator('.bottom').bounding_box()['y']<820
 print('PASS personalized dock survives reload, active location, keyboard search, account sync and five widths.')
