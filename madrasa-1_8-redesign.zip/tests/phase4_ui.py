"""Exercise the cumulative PWA using a real issued QR image and isolated local branches."""
import base64
import os
from datetime import datetime, timezone, timedelta
from playwright.sync_api import sync_playwright, expect

with sync_playwright() as p:
    browser = p.chromium.launch(executable_path=os.getenv('CHROMIUM', '/usr/bin/chromium'), args=['--no-sandbox'])
    page = browser.new_page(viewport={'width':1280,'height':850})
    errors = []
    page.on('pageerror', lambda err: errors.append(str(err)))
    page.goto(os.getenv('APP_URL','http://127.0.0.1:4173'))
    page.locator('[data-act=demo]').click()
    dialog = page.locator('dialog')
    def nav(key):
        page.locator('aside [data-val="'+key+'"]').click()
    def action(key):
        page.locator('[data-act="'+key+'"]:visible').first.click()
    def submit():
        dialog.locator('button.primary:not([type=button])').click()
    nav('sms')
    action('p4-message')
    dialog.locator('textarea').fill('আগামীকাল অভিভাবক সভা।')
    dialog.locator('[name=consent]').check()
    submit()
    expect(page.locator('#content')).to_contain_text('আগামীকাল অভিভাবক সভা।')
    nav('onlineFees')
    count=page.locator('[data-act=p4-pay]').count()
    action('p4-pay')
    submit()
    expect(page.locator('[data-act=p4-pay]')).to_have_count(count-1)
    nav('analytics')
    expect(page.locator('#content tbody').first.locator('tr')).to_have_count(6)
    nav('documents')
    page.clock.set_fixed_time(datetime.now(timezone.utc)+timedelta(days=1))
    page.locator('[name=p3-doc]').select_option('পরিচয়পত্র')
    action('p3-issueDoc')
    dialog.locator('[name=body]').fill('প্রশিক্ষণ')
    submit()
    action('p3-doc')
    qr=dialog.locator('img.qr').get_attribute('src')
    dialog.locator('[data-act=close]').click()
    nav('scanning')
    def upload():
        action('p4-photo')
        dialog.locator('[type=file]').set_input_files({'name':'card.png','mimeType':'image/png','buffer':base64.b64decode(qr.split(',')[1])})
        submit()
    upload()
    expect(dialog).not_to_be_visible()
    upload()
    expect(dialog.locator('.error')).to_contain_text('আগেই লেখা')
    dialog.locator('[data-act=close]').click()
    nav('campuses')
    action('p4-addCampus')
    dialog.locator('[name=name]').fill('উত্তর শাখা')
    submit()
    action('p4-switch')
    expect(page.locator('#setupform')).to_be_visible()
    page.go_back()
    nav('sms')
    expect(page.locator('#content')).to_contain_text('আগামীকাল অভিভাবক সভা।')
    page.set_viewport_size({'width':360,'height':780})
    assert page.evaluate('document.documentElement.scrollWidth <= innerWidth')
    assert not errors, errors
    print('PASS real QR decode, duplicate scan, training SMS, fee receipt, six-month report, isolated branch, mobile width.')
    browser.close()
