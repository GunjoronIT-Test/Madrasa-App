import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
assert.equal(process.env.FIRESTORE_EMULATOR_HOST,'127.0.0.1:8080');
assert.equal(process.env.GCLOUD_PROJECT,'demo-madrasa');
const {monthlyFees,monthlyPayroll}=await import('../functions/index.js');
const require=createRequire(new URL('../functions/package.json',import.meta.url));
const db=require('firebase-admin/firestore').getFirestore(),root=db.doc('branches/main');
try{
 const before=await root.collection('students').where('status','==','active').get();
 assert.ok(before.size>0);
 const input={scheduleTime:'2026-11-30T18:05:00.000Z'};
 await monthlyFees.run(input);
 const get=()=>root.collection('invoices').where('period','==','2026-12').get();
 const first=await get();assert.equal(first.size,before.size);
 await monthlyFees.run(input);assert.equal((await get()).size,first.size);
 const contracts=await root.collection('payContracts').where('active','==',true).get();
 assert.ok(contracts.size>0);
 await monthlyPayroll.run(input);await monthlyPayroll.run(input);
 const slips=await root.collection('payslips').where('period','==','2026-12').get();
 assert.equal(slips.size,contracts.size);
 console.log('PASS: monthly payroll created once per active contract.');
 console.log('PASS: Dhaka month rollover produced one invoice per active student after two runs.');
}finally{await db.terminate()}
