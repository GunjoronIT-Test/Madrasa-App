"""Exercise Phase 2 in a fresh training browser. APP_URL points to the prebuilt app."""
import os, tempfile
from pathlib import Path
from zipfile import ZipFile
from PIL import Image
from openpyxl import load_workbook
import subprocess
from playwright.sync_api import sync_playwright,expect

with sync_playwright() as p, tempfile.TemporaryDirectory() as tmp:
    browser=p.chromium.launch(executable_path=os.getenv('CHROMIUM','/usr/bin/chromium'),args=['--no-sandbox'])
    ctx=browser.new_context(viewport={'width':1280,'height':900})
    page=ctx.new_page()
    page.set_default_timeout(9000)
    errors=[]
    page.on('pageerror',lambda e:errors.append(str(e)))
    page.goto(os.getenv('APP_URL','http://127.0.0.1:4173'))
    def act(a): page.locator('[data-act="p2-'+a+'"]').first.click()
    def nav(a): page.locator('aside [data-val="'+a+'"]').click()
    def fill(n,v): page.locator('dialog [name="'+n+'"]').fill(v)
    def submit():
        page.locator('dialog form button.primary').last.click()
        expect(page.locator('dialog')).not_to_be_visible()
    def close(): page.locator('dialog [data-act=close]').click()
    page.locator('[data-act=demo]').click()
    nav('payroll');act('staff')
    fill('name','পরীক্ষার ওস্তাদ');fill('designation','শিক্ষক');fill('base','8000');submit()
    act('slips');submit();act('adjust');fill('bonus','250');fill('deduction','100');fill('note','পরীক্ষা');submit()
    act('salary');fill('amount','250');submit();act('slip')
    expect(page.locator('dialog .paper2')).to_contain_text('৭,৯০০');close()
    nav('loans');act('loan');fill('party','পরীক্ষার পক্ষ');fill('amount','1000');fill('count','2');submit()
    act('schedule');act('installment');fill('amount','200');submit()
    expect(page.locator('#content table')).to_contain_text('৮০০')
    nav('exams');act('exam');fill('name','বার্ষিক পরীক্ষা');fill('room','কক্ষ এক');submit()
    act('marks');fill('mark0','85');submit()
    act('marksheet');expect(page.locator('dialog .paper2')).to_contain_text('মুমতাজ')
    expect(page.locator('dialog footer img')).to_be_visible()
    pdf=Path(tmp)/'marksheet.pdf'
    page.evaluate('document.fonts.ready');page.pdf(path=str(pdf),format='A4')
    fonts=subprocess.check_output(['pdffonts',str(pdf)],text=True);assert 'Gunjoron' in fonts,fonts
    close();act('bulkcards');assert page.locator('dialog .paper2').count()>=2;close()
    nav('notices');act('notice');fill('title','পরীক্ষার বিজ্ঞপ্তি');fill('body','পরীক্ষা সকাল নয়টায় শুরু হবে।');submit()
    expect(page.locator('.notice-card')).to_contain_text('পরীক্ষার বিজ্ঞপ্তি')
    nav('posters');page.locator('[name=template]').select_option('ভর্তি বিজ্ঞপ্তি')
    expect(page.locator('#p2-poster [name=title]')).to_have_value('ভর্তি চলছে')
    page.locator('[name=size]').select_option('a4');act('preview')
    expect(page.locator('.posterpreview')).to_be_visible()
    with page.expect_download() as dl:act('png')
    assert Image.open(dl.value.path()).size==(1240,1754)
    close();nav('reports')
    with page.expect_download() as dl:act('xlsx')
    sheet=load_workbook(dl.value.path().open('rb'),read_only=True).active
    assert sheet['A2'].value=='তারিখ'
    assert any(isinstance(row[-1],(float,int)) for row in list(sheet.values)[2:])
    page.set_viewport_size({'width':360,'height':780})
    assert page.evaluate('document.documentElement.scrollWidth<=innerWidth')
    assert not errors,errors
    print('PASS salary, loan, installments, marks, branded Bengali PDF with embedded font, bulk admit cards, notices, A4 PNG, XLSX numbers, mobile')
    browser.close()
