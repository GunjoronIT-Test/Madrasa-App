"""Run after tests/cloud.mjs with the demo Auth/Firestore/Functions emulators still running."""
import os
import threading
from pathlib import Path
from http.server import SimpleHTTPRequestHandler,ThreadingHTTPServer
from playwright.sync_api import sync_playwright,expect

class Preview(SimpleHTTPRequestHandler):
    def __init__(self,*args,**kwargs):
        super().__init__(*args,directory=str(Path(__file__).resolve().parents[1]/'public'),**kwargs)
    def do_GET(self):
        if self.path!='/config.js':return super().do_GET()
        content=b'export const firebaseConfig={projectId:"demo-madrasa",apiKey:"demo-key",appId:"demo-app"};export const useEmulators=true;'
        self.send_response(200);self.send_header('Content-Type','application/javascript');self.end_headers();self.wfile.write(content)
    def log_message(self,*args):pass

http=ThreadingHTTPServer(('127.0.0.1',0),Preview)
threading.Thread(target=http.serve_forever,daemon=True).start()
with sync_playwright() as p:
    browser=p.chromium.launch(executable_path=os.getenv('CHROMIUM','/usr/bin/chromium'),args=['--no-sandbox'])
    ctx=browser.new_context()
    page=ctx.new_page()
    errors=[]
    page.on('pageerror',lambda e:errors.append(str(e)))
    page.goto('http://127.0.0.1:'+str(http.server_port))
    page.get_by_role('button',name='প্রবেশ করুন').click()
    page.get_by_label('ইমেইল').fill('phase1@example.test')
    page.get_by_label('পাসওয়ার্ড').fill('local-emulator-2026')
    page.locator('dialog input[type=checkbox]').check()
    page.locator('dialog .primary').click()
    expect(page.get_by_role('heading',name='প্রতিষ্ঠানের সারসংক্ষেপ')).to_be_visible(timeout=20000)
    page.locator('aside [data-val=finance]').click()
    ctx.set_offline(True)
    page.get_by_role('button',name='লেনদেন লিখুন').click()
    page.get_by_label('পরিমাণ (টাকা)').fill('77')
    from uuid import uuid4
    donor='পরীক্ষা '+uuid4().hex[:8]
    page.get_by_label('দাতা বা প্রাপকের নাম').fill(donor)
    page.locator('dialog .primary').click()
    expect(page.locator('dialog')).not_to_be_visible()
    page.locator('header [data-act=account]').click()
    page.locator('dialog [data-act=sync]').click()
    expect(page.get_by_role('button',name='প্রাপ্তিস্বীকার').first).to_be_visible(timeout=15000)
    page.locator('dialog [data-act=close]').click()
    expect(page.locator('#task-title')).to_have_text('আমার অ্যাকাউন্ট')
    page.locator('dialog [data-act=close]').click()
    ctx.set_offline(False)
    expect(page.get_by_text(donor,exact=True)).to_be_visible(timeout=45000)
    page.locator('tr').filter(has_text=donor).get_by_role('button',name='দেখুন').click()
    expect(page.locator('.receipt img')).to_be_visible()
    page.locator('dialog [data-act=close]').click()
    page.locator('header [data-act=account]').click()
    page.locator('dialog [data-act=logout]').click()
    expect(page.get_by_role('button',name='প্রশিক্ষণ খুলুন')).to_be_visible(timeout=20000)
    assert not errors,errors
    print('PASS: browser sign-in, trusted cache, offline donation acknowledgment, reconnect, accepted QR receipt, sign-out')
    for suffix in ['a','b']:
        page.get_by_role('button',name='প্রবেশ করুন').click()
        page.get_by_label('ইমেইল').fill('family-'+suffix+'@example.test')
        page.get_by_label('পাসওয়ার্ড').fill('local-emulator-2026')
        page.locator('dialog .primary').click()
        expect(page.locator('#content [data-act=p3-child]')).to_be_visible(timeout=20000)
        assert page.locator('#content [data-act=p3-child]').count()==1
        page.locator('#content [data-act=p3-child]').click()
        if suffix=='a':
            expect(page.locator('dialog')).to_contain_text('পরীক্ষিত')
            page.locator('[data-childreceipt]').first.click()
            with page.expect_download() as dl:page.locator('#family-download').click()
            assert dl.value.suggested_filename.endswith('.png')
        else:
            expect(page.locator('dialog')).not_to_contain_text('পরীক্ষিত')
        page.locator('dialog [data-act=close]').click()
        page.locator('header [data-act=account]').click()
        page.locator('dialog [data-act=logout]').click()
        expect(page.get_by_role('button',name='প্রশিক্ষণ খুলুন')).to_be_visible(timeout=20000)
    assert not errors,errors
    print('PASS: two guardian logins, separate children and private receipt download.')
    browser.close()
http.shutdown()
