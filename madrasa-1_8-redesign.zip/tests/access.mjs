import { after, before, test } from 'node:test';
import { initializeTestEnvironment, assertSucceeds, assertFails } from '@firebase/rules-unit-testing';
import { collection, query, where, getDocs, doc, setDoc, getDoc, deleteDoc, serverTimestamp } from 'firebase/firestore';
import { ref, getMetadata, uploadBytes } from 'firebase/storage';

const projectId = 'demo-madrasa';
const branch = 'branches/main';
let env;
const user = uid => uid ? env.authenticatedContext(uid) : env.unauthenticatedContext();
const db = uid => user(uid).firestore();
const read = (uid, path) => getDoc(doc(db(uid), path));
const write = (uid, path, data) => setDoc(doc(db(uid), path), data);
const queue = (uid, kind, overrides = {}) => ({
  actorUid: uid, branchId: 'main', kind, status: 'queued',
  createdAt: serverTimestamp(), payload: {}, ...overrides
});
const request = branch + '/requests/abcdefghijklmnop';
before(async () => {
  env = await initializeTestEnvironment({projectId});
  await env.withSecurityRulesDisabled(async admin => {
    const store = admin.firestore();
    for (const role of ['teacher','guardian','office','accountant','principal','deputy','academic','inactive']) {
      await setDoc(doc(store, branch + '/members/' + role), {
        branchId: 'main', classIds: role==='teacher'?['হিফজ']:[], active: role !== 'inactive', role: role === 'inactive' ? 'principal' : role
      });
    }
    for(const [name,data] of Object.entries({'exams/a':{classId:'হিফজ'},'results/b':{classId:'নাজেরা'},'notices/a':{audience:'guardian'},'notices/b':{audience:'teacher'}}))await setDoc(doc(store,branch+'/'+name),data);
    await uploadBytes(ref(admin.storage(), branch + '/private/sample/avatar'), new Uint8Array([1]));
  });
});
after(async () => { await env?.cleanup(); });
const cases = [
 ['অভিভাবকের ফিল্টার করা নোটিশ তালিকা',true,()=>getDocs(query(collection(db('guardian'),branch+'/notices'),where('audience','in',['all','guardian'])))],
 ['সম্পূর্ণ নোটিশ তালিকা অভিভাবকের জন্য সীমিত',false,()=>getDocs(collection(db('guardian'),branch+'/notices'))],
 ['ওস্তাদের নির্ধারিত জামাতের পরীক্ষা তালিকা',true,()=>getDocs(query(collection(db('teacher'),branch+'/exams'),where('classId','==','হিফজ')))],
 ['প্রকাশ্য নথি যাচাই',true,()=>read(null,branch+'/verification/sample')],
 ['প্রকাশ্য নথির তালিকা নিষিদ্ধ',false,()=>getDocs(collection(db(null),branch+'/verification'))],
 ['মুদ্রণযোগ্য নথির গোপনীয়তা',false,()=>read('guardian',branch+'/documents/sample')],
 ['অন্য পরিবারের সংযোগ গোপন',false,()=>read('guardian',branch+'/families/another')],
 ['নিজ পরিবারের সংযোগ পড়া',true,()=>read('guardian',branch+'/families/guardian')],
 ['নিজে অভিভাবক সংযোগ লেখা নিষিদ্ধ',false,()=>write('guardian',branch+'/families/guardian',{children:[]})],
 ['নিজের জামাতের পরীক্ষা',true,()=>read('teacher',branch+'/exams/a')],
 ['অন্য জামাতের ফল',false,()=>read('teacher',branch+'/results/b')],
 ['প্রাপকের নোটিশ পাঠ',true,()=>read('guardian',branch+'/notices/a')],
 ['অন্য রোলের নোটিশ পাঠ',false,()=>read('guardian',branch+'/notices/b')],
 ['অফিস কর্মীর ঋণ লেখা',false,()=>write('office',request+'loan',queue('office','loanOpen'))],
 ['প্রকাশ্য ব্র্যান্ড', true, () => read(null,'settings/institution')],
 ['লগইন ছাড়া ছাত্র তথ্য', false, () => read(null,branch+'/students/s')],
 ['অফিসে ছাত্র তথ্য', true, () => read('office',branch+'/students/s')],
 ['শিক্ষা বিভাগে নম্বর', true, () => read('academic',branch+'/marks/m')],
 ['নায়েবের আর্থিক পাঠাধিকার', true, () => read('deputy',branch+'/ledger/l')],
 ['নিজের প্রকাশিত ভিউ', true, () => read('guardian',branch+'/views/guardian/items/result')],
 ['অন্য অভিভাবকের ভিউ', false, () => read('guardian',branch+'/views/another/items/result')],
 ['অফিসের বেতন পাঠ', false, () => read('office',branch+'/payslips/p')],
 ['অন্য শাখা', false, () => read('principal','branches/other/students/s')],
 ['নিষ্ক্রিয় সদস্য', false, () => read('inactive',branch+'/ledger/l')],
 ['নিজের পদ পরিবর্তন', false, () => write('teacher',branch+'/members/teacher',{role:'principal'})],
 ['ওস্তাদের হাজিরা অনুরোধ', true, () => write('teacher',request,queue('teacher','attendance'))],
 ['একই অনুরোধ পুনর্লিখন', false, () => write('teacher',request,queue('teacher','attendance'))],
 ['হিসাবরক্ষকের ব্যয় অনুরোধ', true, () => write('accountant',request+'2',queue('accountant','expense'))],
 ['জাল প্রেরক', false, () => write('teacher',request+'3',queue('guardian','attendance'))],
 ['অভিভাবকের ব্যয় অনুরোধ', false, () => write('guardian',request+'4',queue('guardian','expense'))],
 ['সরাসরি জার্নাল লেখা', false, () => write('principal',branch+'/ledger/l',{amountMinor:5})],
 ['জার্নাল মোছা', false, () => deleteDoc(doc(db('principal'),branch+'/ledger/l'))],
 ['অডিট জাল করা', false, () => write('principal',branch+'/audit/a',{action:'change'})],
 ['অফিসের সংযুক্তি পাঠ', true, () => getMetadata(ref(user('office').storage(),branch+'/private/sample/avatar'))],
 ['অভিভাবকের ব্যক্তিগত ফাইল পাঠ', false, () => getMetadata(ref(user('guardian').storage(),branch+'/private/sample/avatar'))],
 ['প্রকাশ্য লোগো বদল', false, () => uploadBytes(ref(user('guardian').storage(),'branding/logo'),new Uint8Array([1]))]
];
for (const [title, allowed, operation] of cases) {
  test(title, async () => { await (allowed ? assertSucceeds : assertFails)(operation()); });
}
test('অভিভাবক অন্য পরিবারের বার্তা পড়তে পারেন না',async()=>{
 await env.withSecurityRulesDisabled(async admin=>setDoc(doc(admin.firestore(),branch+'/familyMessages/test'),{uid:'another'}));
 await assertFails(read('guardian',branch+'/familyMessages/test'));
});
test('separate Firebase branch permits its member and denies the other branch principal',async()=>{
 const {readFileSync}=await import('node:fs');
 const second=await initializeTestEnvironment({projectId:'demo-second-campus',firestore:{rules:readFileSync('firestore.rules','utf8')}});
 try{
   await second.withSecurityRulesDisabled(async ctx=>{
     await setDoc(doc(ctx.firestore(),branch+'/members/second-admin'),{role:'principal',active:true,branchId:'main'});
     await setDoc(doc(ctx.firestore(),branch+'/invoices/bill'),{amountMinor:10000});
   });
   const lookup=uid=>getDoc(doc(second.authenticatedContext(uid).firestore(),branch+'/invoices/bill'));
   await assertSucceeds(lookup('second-admin'));await assertFails(lookup('principal'));
   await assertFails(read('second-admin',branch+'/invoices/bill'));
 }finally{await second.cleanup()}
});
test('SMS contents and order writes are restricted',async()=>{
 await assertFails(read('teacher',branch+'/smsOutbox/a'));
 await assertFails(write('principal',branch+'/paymentOrders/a',{status:'credited'}));
 await assertFails(write('guardian',request,queue('guardian','smsQueue')));
});
