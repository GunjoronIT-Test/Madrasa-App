// Run with the Firestore emulator only. All external provider calls use in-process fixtures.
import test from 'node:test';
import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {startCheckout,paymentCallback,deliverSms} from '../functions/services.js';
const require=createRequire(new URL('../functions/package.json',import.meta.url));
const {initializeApp,deleteApp}=require('firebase-admin/app');
const {getFirestore}=require('firebase-admin/firestore');
test('gateway handlers: authorized checkout, simultaneous IPN/return, SMS acceptance, rejection and timeout',async()=>{
  assert.equal(process.env.FIRESTORE_EMULATOR_HOST,'127.0.0.1:8080');
  const app=initializeApp({projectId:'demo-phase4-gateways'}),db=getFirestore(app);
  const doc=path=>db.doc('branches/main/'+path);
  const original=globalThis.fetch;
  let orderId,smsMode=202,attempts=0,validation='VALID';
  Object.assign(process.env,{SSL_STORE_ID:'fixture',SSL_STORE_PASSWORD:'fixture',SSL_LIVE:'false',PAYMENT_CALLBACK_URL:'https://fixture.example/callback',SMS_API_KEY:'fixture',SMS_SENDER_ID:'fixture'});
  globalThis.fetch=async(url,opts)=>{
    if(url==='https://sandbox.sslcommerz.com/gwprocess/v4/api.php'){
      orderId=opts.body.get('tran_id');assert.equal(opts.body.get('total_amount'),'100.00');
      return Response.json({status:'SUCCESS',GatewayPageURL:'https://sandbox.sslcommerz.com/EasyCheckOut/test'});
    }
    if(String(url).startsWith('https://sandbox.sslcommerz.com/validator/'))return Response.json({status:validation,tran_id:orderId,val_id:'valid',currency:'BDT',amount:'100.00',risk_level:'0'});
    if(String(url).startsWith('https://bulksmsbd.net/')){
      attempts++;assert.equal(opts.body.get('number'),'8801700000000');
      if(smsMode==='timeout')throw Error('timeout');
      return Response.json({response_code:smsMode});
    }
    return original(url,opts);
  };
  try{
    await db.doc('settings/institution').set({nameBn:'পরীক্ষা',address:'ঢাকা',publicPhone:''});
    await doc('members/family').set({active:true,role:'guardian',branchId:'main'});
    await doc('students/s1').set({displayName:'ছাত্র'});
    await doc('studentPrivate/s1').set({guardian:'অভিভাবক',phone:'01700000000'});
    await doc('invoices/bill').set({studentId:'s1',amountMinor:10000,waivedMinor:0,paidMinor:0});
    const req={auth:{uid:'family',token:{email:'guardian@example.test'}},data:{invoiceId:'bill'}};
    await assert.rejects(startCheckout.run(req),/অনুমতি/);
    await doc('families/family').set({children:[{id:'s1'}]});
    assert.match((await startCheckout.run(req)).url,/sandbox\.sslcommerz\.com/);
    await assert.rejects(startCheckout.run(req),/চেকআউট চলছে/);
    function callback(){
      let status=200;
      const res={status(n){status=n;return this},send(){return status},sendStatus(n){return n}};
      return paymentCallback({method:'POST',body:{tran_id:orderId,val_id:'valid'},headers:{}},res);
    }
    validation='FAILED';await callback();
    assert.equal((await doc('invoices/bill').get()).get('paidMinor'),0);
    validation='VALID';await Promise.all([callback(),callback()]);
    assert.equal((await doc('invoices/bill').get()).get('paidMinor'),10000);
    assert.equal((await doc('paymentOrders/'+orderId).get()).get('status'),'credited');
    assert.equal((await db.collection('branches/main/receipts').get()).size,1);
    for(const [id,mode,status] of [['ok',202,'accepted'],['bad',1005,'rejected'],['slow','timeout','unknown']]){
      smsMode=mode;const ref=doc('smsOutbox/'+id);
      await ref.set({status:'queued',phone:'01700000000',body:'নমুনা'});
      const event={data:await ref.get()};
      await Promise.all([deliverSms.run(event),deliverSms.run(event)]);
      assert.equal((await ref.get()).get('status'),status);
    }
    assert.equal(attempts,3);
  }finally{globalThis.fetch=original;await deleteApp(app)}
});
