"""Verify the same Back handler invoked by the native Android activity."""
import os
from playwright.sync_api import sync_playwright, expect

with sync_playwright() as p:
    browser = p.chromium.launch(executable_path=os.getenv('CHROMIUM','/usr/bin/chromium'),args=['--no-sandbox'])
    page = browser.new_page(viewport={'width':375,'height':812})
    page.goto(os.getenv('APP_URL','http://127.0.0.1:4173'))
    page.locator('[data-act=demo]').click()
    expect(page.locator('.overview-hero')).to_be_visible()
    def back():
        assert page.evaluate('window.madrasaBack()') is True
    def module(key):
        expect(page.locator('#content')).to_have_attribute('data-module',key)
    def title(label):
        expect(page.locator('#task-title')).to_have_text(label)

    page.locator('.bottom [data-val=students]').click()
    page.locator('.bottom [data-val=fees]').click()
    page.locator('.bottom [data-act=more]').click()
    page.locator('[name=moduleQuery]').fill('হিফজ')
    page.locator('.directory-list [data-val=hifz]').click()
    module('hifz')
    back();title('সব বিভাগ')
    expect(page.locator('[name=moduleQuery]')).to_have_value('হিফজ')
    back();expect(page.locator('dialog')).not_to_be_visible();module('fees')
    back();module('students')
    back();module('home')
    assert not page.evaluate('window.madrasaBack()')
    page.locator('.mast-account').click()
    page.locator('dialog [data-act=sync]').click()
    title('সংরক্ষণ ও সিঙ্ক')
    page.go_back();title('আমার অ্যাকাউন্ট')
    page.locator('dialog [data-act=close]').click()
    expect(page.locator('dialog')).not_to_be_visible()
    assert not page.evaluate('window.madrasaBack()')
    # Force one existing table to overflow, then remove the constraint.
    box=page.locator('#content .scroll').first
    box.evaluate("b=>{b.style.maxWidth='180px';b.firstElementChild.style.minWidth='600px'}")
    guide=box.locator('xpath=preceding-sibling::*[1]')
    expect(guide).to_contain_text('ডানে আরও আছে')
    guide.locator('button').last.click()
    expect(guide).to_contain_text('দুই পাশেই আরও আছে')
    box.evaluate('b=>b.scrollLeft=b.scrollWidth')
    expect(guide).to_contain_text('বাঁয়ে আরও আছে')
    box.evaluate("b=>{b.style.maxWidth='';b.firstElementChild.style.minWidth='';b.style.width='1px';b.firstElementChild.style.display='none'}")
    expect(guide).to_be_hidden()
    print('PASS sequential native-handler Back, nested screens, browser and in-app Back, overflow direction and hiding.')
