import test from 'node:test';
import assert from 'node:assert/strict';
import {execute} from '../functions/domain.js';
const brand={nameBn:'প্রশিক্ষণ',address:'ঢাকা',principalName:'প্রধান',classes:['হিফজ'],monthlyMinor:10000,admissionMinor:5000,academicYear:'২০২৬',startDate:'2026-01-01',primaryColor:'#185747',accentColor:'#ad8346'};
async function fixture(){
 const records=new Map(),actor={uid:'test',branchId:'main',active:true,role:'principal'};
 const run=async(kind,payload,id=crypto.randomUUID(),user=actor)=>{
  const {writes,result}=await execute({get:p=>structuredClone(records.get(p))},user,{id,kind,payload});
  for(const [p,v] of writes)records.set(p,v);return result;
 };
 await run('setup',brand);
 const student={displayName:'হাসান',guardian:'আহমদ',phone:'01700000000',classId:'হিফজ',residentialStatus:'আবাসিক',date:'2026-10-01'};
 const sid=await run('admission',student);
 const money={amountMinor:3000,date:'2026-10-23',fund:'সাধারণ',account:'নগদ'};
 return {records,run,actor,student,sid,money,read:(c,k)=>records.get('branches/main/'+c+'/'+k)};
}
test('ভর্তি, ডুপ্লিকেট ও পুনর্বহাল',async()=>{
 const f=await fixture();assert.equal(f.read('students',f.sid).roll,1);
 await assert.rejects(f.run('admission',f.student));
 await f.run('archive',{studentId:f.sid});assert.equal(f.read('roster',f.sid).status,'archived');
 await f.run('restore',{studentId:f.sid});assert.equal(f.read('students',f.sid).status,'active');
});
test('এক মাসে একটি ফি দাবি',async()=>{
 const f=await fixture(),p={studentId:f.sid,period:'2026-11'};
 assert.equal(await f.run('invoice',p),await f.run('invoice',p));
 assert.equal(f.read('invoices',f.sid+'_2026-11').amountMinor,10000);
});
test('আংশিক ফি, retry, অতিরিক্ত আদায় ও reversal',async()=>{
 const f=await fixture(),p={...f.money,invoiceId:'adm_'+f.sid},id=await f.run('fee',p);
 await f.run('fee',p,id);assert.equal(f.read('invoices',p.invoiceId).paidMinor,3000);
 await assert.rejects(f.run('fee',p));assert.equal(f.read('balances','0_0').amountMinor,3000);
 await f.run('reversal',{entryId:id,note:'সংশোধন',date:p.date});
 assert.equal(f.read('invoices',p.invoiceId).paidMinor,0);
 assert.equal(f.read('ledger',id).amountMinor,3000);
 await assert.rejects(f.run('reversal',{entryId:id,note:'সংশোধন',date:p.date}));
});
test('মওকুফের কারণ ও নগদ স্থিতি',async()=>{
 const f=await fixture(),p={...f.money,invoiceId:'adm_'+f.sid};await assert.rejects(f.run('waiver',p));
 await f.run('waiver',{...p,note:'অনুমোদিত'});assert.equal(f.read('balances','0_0').amountMinor,0);
});
test('ভিন্ন তহবিল থেকে অতিরিক্ত ব্যয়',async()=>{
 const f=await fixture();await f.run('donation',f.money);await assert.rejects(f.run('expense',{...f.money,fund:'যাকাত'}));
 await f.run('expense',f.money);assert.equal(f.read('balances','0_0').amountMinor,0);
});
test('ওস্তাদের জামাত ও পুরনো হাজিরার সংস্করণ',async()=>{
 const f=await fixture(),p={studentId:f.sid,date:'2026-11-01',status:'present',revision:0};
 await assert.rejects(f.run('attendance',p,crypto.randomUUID(),{...f.actor,role:'teacher',classIds:['কিতাব']}));
 await f.run('attendance',p,crypto.randomUUID(),{...f.actor,role:'teacher',classIds:['হিফজ']});
 await assert.rejects(f.run('attendance',{...p,status:'absent'}));
});
test('ব্যয়ের সীমা অতিক্রমে অনুমোদন ও ঠিক একবার খরচ',async()=>{
 const f=await fixture();await f.run('brand',{...brand,expenseLimitMinor:500});
 await f.run('income',f.money);
 const id=await f.run('expense',f.money,crypto.randomUUID(),{...f.actor,role:'accountant'});
 assert.equal(f.read('approvals',id).status,'pending');assert.equal(f.read('balances','0_0').amountMinor,3000);
 await f.run('approveExpense',{approvalId:id});assert.equal(f.read('balances','0_0').amountMinor,0);
 await assert.rejects(f.run('approveExpense',{approvalId:id}));
});
test('প্রোফাইল পরিবর্তন, পুরোনো revision ও গোপনীয় নোট',async()=>{
 const f=await fixture(),prev=f.read('studentPrivate',f.sid);
 const p={...f.student,studentId:f.sid,revision:prev.updatedAt,healthNote:'পরীক্ষার নোট'};
 await new Promise(resolve=>setTimeout(resolve,3));await f.run('profile',p);
 assert.equal(f.read('studentPrivate',f.sid).healthNote,p.healthNote);
 assert.equal(f.read('roster',f.sid).healthNote,undefined);
 await assert.rejects(f.run('profile',p));
});
test('অন্য ফি খাতের একক মাসিক দাবি',async()=>{
 const f=await fixture(),p={studentId:f.sid,period:'2026-10',label:'পরীক্ষা ফি',amountMinor:30000};
 const id=await f.run('charge',p);assert.equal(f.read('invoices',id).amountMinor,30000);await assert.rejects(f.run('charge',p));
});
import {defaultGrades,monthAfter,ranking} from '../functions/phase2.js';
async function staffFixture(){
 const f=await fixture(),staffId=await f.run('staffAdd',{name:'নমুনা শিক্ষক',designation:'ওস্তাদ',joinedOn:'2026-10-01',baseMinor:10000});
 const period='2026-10',slipId=staffId+'_'+period;
 await f.run('salarySlip',{staffId,period});
 return {...f,staffId,slipId,period};
}
test('মাসিক স্লিপ পুনরায় তৈরি ও বোনাস-কর্তন',async()=>{
 const f=await staffFixture(),s=f.read('payslips',f.slipId);
 await f.run('salaryAdjust',{slipId:f.slipId,revision:s.updatedAt,bonusMinor:1000,deductionMinor:500,note:'সমন্বয়'});
 await f.run('salarySlip',{staffId:f.staffId,period:f.period});
 assert.equal(f.read('payslips',f.slipId).netMinor,10500);
});
test('অগ্রিম বেতন, লেনদেন retry ও বাতিল',async()=>{
 const f=await staffFixture();await f.run('income',f.money);
 const p={...f.money,slipId:f.slipId,advance:true};
 const pay=await f.run('salaryPay',p);await f.run('salaryPay',p,pay);
 assert.equal(f.read('payslips',f.slipId).advanceMinor,3000);
 assert.equal(f.read('balances','0_0').amountMinor,0);
 await f.run('reversal',{entryId:pay,note:'সংশোধন',date:p.date});
 assert.equal(f.read('payslips',f.slipId).paidMinor,0);assert.equal(f.read('payslips',f.slipId).advanceMinor,0);
 assert.equal(f.read('balances','0_0').amountMinor,3000);
});
test('অপর্যাপ্ত তহবিলে বেতন স্লিপ অক্ষত',async()=>{
 const f=await staffFixture();await assert.rejects(f.run('salaryPay',{...f.money,slipId:f.slipId}));
 assert.equal(f.read('payslips',f.slipId).paidMinor,0);
});
test('ঋণ গ্রহণ, কিস্তি ভাগ ও বিপরীত এন্ট্রির ক্রম',async()=>{
 const f=await fixture(),opening={...f.money,party:'দাতা',side:'borrow',date:'2026-01-10',due:'2026-01-31',count:3,amountMinor:10001};
 const loanId=await f.run('loanOpen',opening);
 let l=f.read('loans',loanId);
 assert.deepEqual(l.installments.map(i=>i.expected),[3334,3334,3333]);
 assert.deepEqual(l.installments.map(i=>i.due),['2026-01-31','2026-02-28','2026-03-31']);
 const pay=await f.run('loanPay',{...f.money,loanId,installment:0,amountMinor:3000});
 await assert.rejects(f.run('loanPay',{...f.money,loanId,installment:0}));
 const reverse=entryId=>f.run('reversal',{entryId,date:'2026-11-01',note:'সংশোধন'});
 await assert.rejects(reverse(loanId));await reverse(pay);await reverse(loanId);
 assert.equal(f.read('loans',loanId).status,'cancelled');assert.equal(f.read('balances','0_0').amountMinor,0);
 assert.equal(monthAfter('2028-01-31',1),'2028-02-29');
});
test('ঋণ প্রদান ও পাওনা আদায়ে বিপরীত নগদ প্রবাহ',async()=>{
 const f=await fixture();await f.run('income',f.money);
 const loanId=await f.run('loanOpen',{...f.money,party:'পক্ষ',side:'lend',due:'2026-12-01',count:1});
 assert.equal(f.read('balances','0_0').amountMinor,0);
 await f.run('loanPay',{...f.money,loanId,installment:0});assert.equal(f.read('balances','0_0').amountMinor,3000);
});
test('কর্মী ও বেতন রোল পৃথক',async()=>{
 const f=await staffFixture(),office={...f.actor,role:'office'};
 await f.run('staffDay',{staffId:f.staffId,date:'2026-10-10',status:'ছুটি'},crypto.randomUUID(),office);
 await assert.rejects(f.run('salaryPay',{...f.money,slipId:f.slipId},crypto.randomUUID(),office));
});
test('বিষয়ে পাস, অনুপস্থিতি, পূর্ণমান, সংশোধন ও জামাতের সীমা',async()=>{
 const f=await fixture(),subject={name:'কুরআন',max:100,pass:33,date:'2026-11-01',time:'09:00'};
 const examId=await f.run('examCreate',{classId:'হিফজ',name:'বার্ষিক',room:'১',subjects:[subject,{...subject,name:'আরবি',time:'11:00'}],grades:defaultGrades});
 const payload={examId,studentId:f.sid,scores:[90,90],revision:0};
 await assert.rejects(f.run('examMark',payload,crypto.randomUUID(),{...f.actor,role:'teacher',classIds:['নাজেরা']}));
 await assert.rejects(f.run('examMark',{...payload,scores:[101,10]}));
 await f.run('examMark',payload,crypto.randomUUID(),{...f.actor,role:'teacher',classIds:['হিফজ']});
 const read=()=>f.read('results',examId+'_'+f.sid);assert.equal(read().grade,'মুমতাজ');assert.equal(read().total,180);
 await assert.rejects(f.run('examMark',payload));await f.run('examMark',{...payload,revision:1,scores:[100,null]});
 assert.equal(read().passed,false);assert.equal(read().grade,'রাসিব');
});
test('সমান নম্বরে যৌথ মেধাস্থান',()=>{
 const list=[{total:90,passed:true,roll:3},{total:80,passed:true,roll:2},{total:90,passed:true,roll:1},{total:92,passed:false,roll:4}];
 assert.deepEqual(ranking(list).map(x=>[x.roll,x.rank]),[[1,1],[3,1],[2,3],[4,4]]);
});
test('নোটিশ প্রকাশের রোল ও প্রাপক',async()=>{
 const f=await fixture(),p={title:'ছুটি',body:'আগামীকাল ছুটি।',audience:'guardian',push:false};
 await assert.rejects(f.run('noticePublish',p,crypto.randomUUID(),{...f.actor,role:'teacher'}));
 const id=await f.run('noticePublish',p);assert.equal(f.read('notices',id).audience,'guardian');
});
test('চুক্তির কার্যকর মাস ও আগের স্লিপের মূল বেতন',async()=>{
 const f=await staffFixture(),c=f.read('payContracts',f.staffId);
 await f.run('staffEdit',{staffId:f.staffId,revision:c.updatedAt,name:c.name,designation:c.designation,baseMinor:12000,effective:'2026-12',status:'active'});
 for(const period of ['2026-11','2026-12'])await f.run('salarySlip',{staffId:f.staffId,period});
 assert.equal(f.read('payslips',f.staffId+'_2026-11').baseMinor,10000);
 assert.equal(f.read('payslips',f.staffId+'_2026-12').baseMinor,12000);
 assert.equal(f.read('payslips',f.slipId).baseMinor,10000);
});
test('অনুষ্ঠানের দান ও ব্যয় মূল হিসাব ও reversal-এ মেলে',async()=>{
 const f=await fixture(),eventId=await f.run('eventAdd',{title:'মাহফিল',date:'2026-11-23',venue:'প্রাঙ্গণ',budgetMinor:50000});
 const p={...f.money,eventId,note:'আয়োজন'};
 await f.run('eventMoney',{...p,type:'donation'});const expense=await f.run('eventMoney',{...p,type:'expense',amountMinor:1000});
 assert.equal(f.read('events',eventId).expenseMinor,1000);assert.equal(f.read('balances','0_0').amountMinor,2000);
 await f.run('reversal',{entryId:expense,date:p.date,note:'সংশোধন'});
 assert.equal(f.read('events',eventId).expenseMinor,0);assert.equal(f.read('balances','0_0').amountMinor,3000);
});
test('এক ছাত্র বা সিটে দ্বৈত বরাদ্দ বন্ধ ও পুরনো বরাদ্দ পুনরায় ছাড়তে বাধা',async()=>{
 const f=await fixture(),roomId=await f.run('roomAdd',{name:'উত্তর',capacity:2});
 const p={roomId,studentId:f.sid,seat:1,date:'2026-11-20'};
 const allocationId=await f.run('bedAssign',p),bedId=roomId+'_1';
 await assert.rejects(f.run('bedAssign',{...p,seat:2}));
 const other=await f.run('admission',{...f.student,displayName:'দ্বিতীয় ছাত্র'});await assert.rejects(f.run('bedAssign',{...p,studentId:other}));
 await f.run('bedRelease',{allocationId,bedId,date:'2026-11-22'});
 await f.run('bedAssign',{...p,studentId:other});await assert.rejects(f.run('bedRelease',{allocationId,bedId,date:'2026-11-23'}));
});
test('হিফজের জামাত, পৃষ্ঠা ও একই রেকর্ডে সংশোধনের সংস্করণ',async()=>{
 const f=await fixture(),p={studentId:f.sid,date:'2026-11-22',lesson:'সবক',from:2,to:3,juz:1,revision:0};
 await assert.rejects(f.run('hifz',p,crypto.randomUUID(),{...f.actor,role:'teacher',classIds:['কিতাব']}));
 await f.run('hifz',p);await assert.rejects(f.run('hifz',p));
 await assert.rejects(f.run('hifz',{...p,revision:1,to:1}));
 await f.run('hifz',{...p,revision:1,to:4});assert.equal(f.read('hifzLogs',f.sid+'_'+p.date+'_0').to,4);
});
test('মিল সংখ্যার সংশোধনে খরচ থাকে এবং বাতিলে মূল খাতা ফেরে',async()=>{
 const f=await fixture(),date=f.money.date,mealId=date+'_1';
 await f.run('mealCount',{date,type:'দুপুর',count:5,revision:0});
 await assert.rejects(f.run('mealCost',{...f.money,mealId}));
 await f.run('income',f.money);const id=await f.run('mealCost',{...f.money,mealId});
 await f.run('mealCount',{date,type:'দুপুর',count:6,revision:1});assert.equal(f.read('meals',mealId).costMinor,3000);
 await f.run('reversal',{date,entryId:id,note:'সংশোধন'});assert.equal(f.read('meals',mealId).costMinor,0);
});
test('ভগ্নাংশ স্টক ও অতিরিক্ত ব্যবহার প্রত্যাখ্যান',async()=>{
 const f=await fixture(),itemId=await f.run('stockAdd',{name:'চাল',unit:'কেজি',minimum:1000});
 const p={itemId,quantity:1250,date:f.money.date,note:'রান্নাঘর'};
 await f.run('stockMove',{...p,type:'in'});await f.run('stockMove',{...p,type:'out',quantity:500});
 await assert.rejects(f.run('stockMove',{...p,type:'out'}));assert.equal(f.read('stockItems',itemId).quantity,750);
});
test('কপি নম্বর, ইস্যু ও ফেরতে পুনরাবৃত্তি নিয়ন্ত্রণ',async()=>{
 const f=await fixture(),b={title:'কিতাব',code:'A-1'},bookId=await f.run('bookAdd',b);
 await assert.rejects(f.run('bookAdd',b));const p={bookId,studentId:f.sid,date:'2026-11-01',due:'2026-11-15'};
 const loanId=await f.run('bookIssue',p);await assert.rejects(f.run('bookIssue',p));
 await f.run('bookReturn',{loanId,date:p.due});await assert.rejects(f.run('bookReturn',{loanId,date:p.due}));
 assert.equal(f.read('books',bookId).loanId,'');
});
test('নথি বাতিলের সঙ্গে QR অবস্থা বদলায় ও প্রকাশ্য তথ্যে নাম থাকে না',async()=>{
 const f=await fixture(),docId=await f.run('issueDoc',{studentId:f.sid,type:'সনদ',date:f.money.date,body:'শিক্ষা সমাপ্ত করেছেন।'});
 assert.equal(f.read('verification',docId).active,true);assert.equal(f.read('verification',docId).name,undefined);
 await f.run('revokeDoc',{docId,reason:'পুনঃইস্যু'});assert.equal(f.read('verification',docId).active,false);
});
test('অভিভাবক নিজে সংযোগ তৈরি করতে পারেন না',async()=>{
 const f=await fixture(),p={studentId:f.sid,uid:'parentA',link:true};await assert.rejects(f.run('familyLink',p));
 f.records.set('branches/main/members/parentA',{active:true,branchId:'main',role:'guardian'});
 await assert.rejects(f.run('familyLink',p,crypto.randomUUID(),{...f.actor,role:'guardian'}));
 await f.run('familyLink',p);assert.equal(f.read('families','parentA').children[0].id,f.sid);
 await f.run('familyLink',{...p,link:false});assert.deepEqual(f.read('families','parentA').children,[]);
});
test('দাওয়াতপত্র, পরিবার থেকে ছুটির আবেদন ও প্রশাসনিক উত্তর',async()=>{
 const f=await fixture(),eventId=await f.run('eventAdd',{title:'দস্তারবন্দি',date:'2026-11-23',venue:'প্রাঙ্গণ',budgetMinor:0});
 const invite=await f.run('eventInvite',{eventId,guest:'নমুনা অতিথি',date:'2026-11-15',body:'আপনি আমন্ত্রিত।'});
 assert.equal(f.read('documents',invite).venue,'প্রাঙ্গণ');assert.equal(f.read('verification',invite).type,'দাওয়াতপত্র');
 const guardian={...f.actor,role:'guardian',uid:'parent'};
 const p={studentId:f.sid,type:'ছুটির আবেদন',body:'পারিবারিক প্রয়োজনে',from:'2026-11-23',to:'2026-11-24'};
 await assert.rejects(f.run('familyMessage',p,crypto.randomUUID(),guardian));
 f.records.set('branches/main/members/parent',guardian);await f.run('familyLink',{uid:'parent',link:true,studentId:f.sid});
 const id=await f.run('familyMessage',p,crypto.randomUUID(),guardian);
 await f.run('familyReply',{messageId:id,status:'অনুমোদিত',reply:'ছুটি মঞ্জুর।'});
 assert.equal(f.read('familyMessages',id).status,'অনুমোদিত');
});

import {validatePayment,settlePayment} from '../functions/gateway.js';
test('QR card checks class, document type, day, revocation and duplicate attendance',async()=>{
  const f=await fixture(),date=new Date(Date.now()+21600000).toISOString().slice(0,10);
  const issue=type=>f.run('issueDoc',{studentId:f.sid,type,date,body:'কার্ড'});
  const cardId=await issue('পরিচয়পত্র'),payload={cardId,date};
  await assert.rejects(f.run('qrAttendance',{...payload,cardId:await issue('সনদ')}));
  await assert.rejects(f.run('qrAttendance',{...payload,date:'2020-01-01'}));
  await assert.rejects(f.run('qrAttendance',payload,crypto.randomUUID(),{...f.actor,role:'teacher',classIds:[]}));
  await f.run('qrAttendance',payload);
  assert.equal(f.read('attendance',f.sid+'_'+date).status,'present');
  await assert.rejects(f.run('qrAttendance',payload));
  f.read('documents',cardId).active=false;
  await assert.rejects(f.run('qrAttendance',payload),/সক্রিয় পরিচয়পত্র/);
});
test('SMS recipient comes from the enrolled contact and requires consent and management role',async()=>{
  const f=await fixture(),payload={studentId:f.sid,confirmed:true,body:'পরীক্ষার সময়সূচি',phone:'01799999999'};
  await assert.rejects(f.run('smsQueue',{...payload,confirmed:false}));
  await assert.rejects(f.run('smsQueue',payload,crypto.randomUUID(),{...f.actor,role:'teacher'}));
  const id=await f.run('smsQueue',payload);
  assert.equal(f.read('smsOutbox',id).phone,f.student.phone);
  assert.equal(f.read('smsOutbox',id).status,'queued');
});
test('validated payment credits once, flags conflicting dues and high-risk confirmations',async()=>{
  const f=await fixture(),id='de0123',v={val_id:'ok',tran_id:id,currency:'BDT',amount:'50.00',risk_level:'0',status:'VALID'};
  const order={invoiceId:'adm_'+f.sid,studentId:f.sid,amountMinor:5000,status:'pending'};
  validatePayment(order,id,'ok',v);
  for(const altered of [{val_id:'other'},{amount:49},{currency:'USD'},{tran_id:'other'},{status:'FAILED'}])assert.throws(()=>validatePayment(order,id,'ok',{...v,...altered}));
  const store={get:path=>structuredClone(f.records.get(path))};
  assert.equal((await settlePayment(store,order,id,{...v,risk_level:'1'})).status,'review');
  const first=await settlePayment(store,order,id,v);assert.equal(first.status,'credited');
  for(const [k,r] of first.writes)f.records.set(k,r);
  assert.equal(f.read('invoices',order.invoiceId).paidMinor,5000);
  assert.equal(f.read('receipts',id).account,'ব্যাংক');
  assert.equal((await settlePayment(store,{...order,status:'credited'},id,v)).writes.size,0);
  assert.equal((await settlePayment(store,order,'other',v)).status,'review');
});
