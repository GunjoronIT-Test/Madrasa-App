import {icon} from './ui.js';

const guides=new Map();
function attach(box){
 const bar=document.createElement('div');
 bar.className='scroll-guide';
 bar.innerHTML='<span></span><button type="button" aria-label="বাঁয়ে স্ক্রল">'+icon('chevron-left',17)+'</button><input type="range" min="0" max="100" step="any" aria-label="আড়াআড়ি স্ক্রলের অবস্থান"><button type="button" aria-label="ডানে স্ক্রল">'+icon('chevron-right',17)+'</button>';
 box.before(bar);
 const [left,right]=bar.querySelectorAll('button'),range=bar.querySelector('input'),label=bar.firstElementChild;
 function update(){
   const limit=box.scrollWidth-box.clientWidth;
   bar.hidden=limit<=2||box.clientWidth===0;
   if(bar.hidden)return;
   left.disabled=box.scrollLeft<=1;right.disabled=box.scrollLeft>=limit-1;
   const hint=left.disabled?'ডানে আরও আছে':right.disabled?'বাঁয়ে আরও আছে':'দুই পাশেই আরও আছে';
   if(label.textContent!==hint)label.textContent=hint;
   range.value=100*box.scrollLeft/limit;
 }
 const slide=sign=>box.scrollBy({left:sign*Math.max(100,box.clientWidth*.75),behavior:matchMedia('(prefers-reduced-motion:reduce)').matches?'instant':'smooth'});
 left.onclick=()=>slide(-1);right.onclick=()=>slide(1);
 range.oninput=()=>{box.scrollLeft=(box.scrollWidth-box.clientWidth)*Number(range.value)/100};
 box.addEventListener('scroll',update,{passive:true});
 const size=new ResizeObserver(update);size.observe(box);if(box.firstElementChild)size.observe(box.firstElementChild);
 guides.set(box,{bar,size,update});update();
}
// Task pages can be detached and restored with their controls and listeners intact.
let queued=false;
function reconcile(){
 queued=false;
 for(const [box,entry] of guides){
   if(!box.isConnected){entry.size.disconnect();box.removeEventListener('scroll',entry.update);entry.bar.remove();guides.delete(box)}
 }
 for(const box of document.querySelectorAll('.scroll'))if(!guides.has(box))attach(box);
}
new MutationObserver(()=>{if(!queued){queued=true;requestAnimationFrame(reconcile)}}).observe(document.body,{childList:true,subtree:true});
reconcile();
