import {esc,bn,cash,icon,btn,section,titlebar,table,empty,input,select,modal,notify,dateLabel,fileData} from './ui.js';
import {today,localRead} from './local.js';
import {funds,accounts,statusNames} from '../functions/domain.js';
import {docTypes,lessonTypes} from '../functions/phase3.js';
import {familySummary} from '../functions/family.js';
import {saveBlob} from './exports.js';
import * as cloud from './cloud.js';
import QRCode from 'qrcode';

export const pages3={events:['অনুষ্ঠান','calendar-days'],hifz:['হিফজ ও নাজেরা','book-open'],boarding:['আবাসন ও খাবার','landmark'],inventory:['স্টক ও সম্পদ','layers'],library:['লাইব্রেরি','book-open'],family:['অভিভাবক পোর্টাল','users'],documents:['সনদ ও পরিচয়পত্র','file-text']};
export const labels3={eventInvite:'দাওয়াতপত্র',familyMessage:'অভিভাবকের আবেদন',familyReply:'আবেদনের সিদ্ধান্ত',eventAdd:'অনুষ্ঠান',eventTask:'কাজ বণ্টন',eventDone:'কাজ সম্পন্ন',eventMedia:'অনুষ্ঠানের মিডিয়া',eventMoney:'অনুষ্ঠানের হিসাব',hifz:'হিফজ অগ্রগতি',roomAdd:'কক্ষ',bedAssign:'সিট বরাদ্দ',bedRelease:'সিট ছাড়া',mealCount:'মিল সংখ্যা',mealCost:'মিল খরচ',stockAdd:'স্টক পণ্য',stockMove:'মজুত পরিবর্তন',assetAdd:'সম্পদ',repair:'মেরামত',bookAdd:'কিতাব',bookIssue:'কিতাব ইস্যু',bookReturn:'কিতাব ফেরত',familyLink:'অভিভাবক সংযোগ',issueDoc:'নথি ইস্যু',revokeDoc:'নথি বাতিল'};
const action=(k,title,id='',style='link',ico)=>btn('p3-'+k,title,ico,style,id);
const primary=(k,title,ico='plus')=>action(k,title,'','primary',ico);
const bar=(...xs)=>'<div class="toolbar">'+xs.join('')+'</div>';
const grid=(...xs)=>'<div class="grid2">'+xs.join('')+'</div>';
const text=(label,name,v='',extra='required')=>input(label,name,'text',v,extra);
const number=(label,name,v='',min=0,step='1')=>input(label,name,'number',v,'required min="'+min+'" step="'+step+'"');
const date=(label='তারিখ',name='date',value=today())=>input(label,name,'date',value,'required');
const area=(label,name,value='',required=false)=>'<label>'+label+'<textarea name="'+name+'" '+(required?'required':'')+'>'+esc(value)+'</textarea></label>';
const accountForm=()=>grid(select('তহবিল','fund',funds),select('হিসাব','account',accounts));
const notes=(pairs)=>'<dl class="summary">'+pairs.map(([key,v])=>'<div><dt>'+key+'</dt><dd>'+esc(v)+'</dd></div>').join('')+'</dl>';
const printButton=()=>btn('print','প্রিন্ট / PDF','printer','primary');
const fmtQty=n=>bn(n/1000);
const minor=v=>Math.round(Number(v)*100);
const monthly=today().slice(0,7);
export function createPhase3(ctx){
 const {rows,can,send,local,refresh,passwordField}=ctx;
 const brand=()=>ctx.data().brand;
 let eventId='',hMonth=monthly,hStudent='',familyUid='training-guardian',docKind=docTypes[0];
 const find=(col,id)=>rows(col).find(v=>v.id===id);
 const active=()=>rows('roster').filter(v=>v.status==='active');
 const opts=(list,label)=>list.map(v=>[v.id,label(v)]);
 const studentOpts=()=>opts(active(),s=>s.displayName+' · '+bn(s.roll)+' · '+s.classId);
 const studentSelect=()=>select('ছাত্র','studentId',studentOpts());
 const requireList=(list,msg)=>{if(!list.length)throw Error(msg)};
 const guard=(title,body,fn)=>modal(title,body+passwordField(),f=>fn(f,{password:f.password,pin:f.pin}));
 const withMoney=(p,f)=>({...p,amountMinor:minor(f.amount),fund:f.fund,account:f.account,date:f.date});
 function allowed(k){
   return ({events:can('eventAdd')||can('eventMoney'),hifz:can('hifz'),boarding:can('roomAdd')||can('mealCost'),inventory:can('stockAdd'),library:can('bookAdd'),family:can('familyLink')||ctx.actor().role==='guardian',documents:can('issueDoc')})[k];
 }
 const event=()=>find('events',eventId)||rows('events')[0];
 const eventRecords=(c,id)=>rows(c).filter(r=>r.eventId===id);
 function paper(title,subtitle,body){
   const b=brand();
   modal(title,'<article class="paper2"><div class="paperhead">'+(b.logo?'<img src="'+esc(b.logo)+'" alt="">':'')+'<div><strong>'+esc(b.nameBn)+'</strong><small>'+esc(b.address)+'</small></div></div><h2>'+esc(title)+'</h2><p>'+esc(subtitle)+'</p>'+body+'</article><div class="actions">'+printButton()+'</div>');
 }
 const summaryEvent=e=>notes([['তারিখ ও স্থান',dateLabel(e.date)+' · '+e.venue],['কমিটি',e.committee||'—'],['বক্তা ও অতিথি',e.guests||'—'],['বাজেট',cash(e.budgetMinor)],['সংগৃহীত দান',cash(e.incomeMinor)],['ব্যয়',cash(e.expenseMinor)],['অবশিষ্ট বাজেট',cash(e.budgetMinor-e.expenseMinor)]]);
 function events(){
   const e=event();
   let html=titlebar('অনুষ্ঠান ব্যবস্থাপনা','পরিকল্পনা, দায়িত্ব বণ্টন ও অনুষ্ঠানভিত্তিক হিসাব।',can('eventAdd')?primary('event','অনুষ্ঠান তৈরি'):'');
   if(!e)return html+section('অনুষ্ঠান',empty('এখনো কোনো অনুষ্ঠান তৈরি হয়নি।'));
   html+=section(esc(e.title),select('অনুষ্ঠান নির্বাচন','p3-event',opts(rows('events'),v=>v.title),e.id)+summaryEvent(e),bar(action('eventReport','রিপোর্ট',e.id,'btn','printer'),can('eventInvite')?action('invite','দাওয়াতপত্র',e.id,'btn','file-text'):'',can('eventAdd')?action('poster','পোস্টার',e.id,'btn','layers'):'',can('eventMoney')?action('eventMoney','দান / ব্যয়',e.id,'primary','wallet'):''));
   if(can('eventAdd')){
     html+=section('কাজের তালিকা',table(['কাজ','দায়িত্ব','মেয়াদ','অবস্থা'],eventRecords('eventTasks',e.id).map(t=>[esc(t.title),esc(t.owner),dateLabel(t.due),t.done?'সম্পন্ন':action('done','সম্পন্ন করুন',t.id)])),action('task','কাজ যোগ করুন',e.id,'btn','plus'));
     html+=section('ছবি ও ভিডিও',table(['ক্যাপশন','ধরন','ফাইল'],eventRecords('media',e.id).map(m=>[esc(m.title),esc(m.kind),m.url?'<a target="_blank" rel="noopener noreferrer" href="'+esc(m.url)+'">লিংক খুলুন</a>':action('mediaFile','খুলুন',m.id)])),action('media','মিডিয়া যোগ করুন',e.id,'btn','upload'));
   }
   return html;
 }
 const logs=()=>rows('hifzLogs').filter(r=>r.date.startsWith(hMonth)&&(!hStudent||r.studentId===hStudent)).sort((a,b)=>b.date.localeCompare(a.date));
 const progressTable=list=>table(['তারিখ','ধরন','পারা','পৃষ্ঠা','মন্তব্য'],list.map(r=>[dateLabel(r.date),esc(r.lesson),bn(r.juz),bn(r.from)+'–'+bn(r.to),esc(r.comment)]));
 function hifz(){
   const list=logs(),filters=bar(input('মাস','p3-month','month',hMonth),select('ছাত্র','p3-hstudent',[['','সকল ছাত্র'],...studentOpts()],hStudent));
   return titlebar('হিফজ ও নাজেরা','দৈনিক পাঠ ও মাসিক অগ্রগতি।',primary('lesson','পাঠ লিখুন'))+section('অগ্রগতি খাতা',filters+table(['তারিখ','ছাত্র','পাঠ','পারা / পৃষ্ঠা','মন্তব্য','সম্পাদনা'],list.map(r=>[dateLabel(r.date),esc(r.name),esc(r.lesson),bn(r.juz)+' / '+bn(r.from)+'–'+bn(r.to),esc(r.comment),action('lesson','সম্পাদনা',r.id)])),action('progressReport','মাসিক রিপোর্ট','','btn','printer'));
 }
 function boarding(){
   const beds=rows('beds').filter(b=>b.active),meals=[...rows('meals')].sort((a,b)=>b.date.localeCompare(a.date));
   let html=titlebar('আবাসন ও খাবার','কক্ষের সিট, দৈনিক মিল ও খাবারের খরচ।');
   if(can('roomAdd'))html+=section('কক্ষ ও সিট',table(['কক্ষ','মোট সিট','খালি','বরাদ্দ'],rows('rooms').map(r=>[esc(r.name),bn(r.capacity),bn(r.capacity-beds.filter(b=>b.roomId===r.id).length),action('assign','সিট বরাদ্দ',r.id)])),primary('room','কক্ষ যোগ করুন'))+section('সক্রিয় বরাদ্দ',table(['ছাত্র','কক্ষ / সিট','শুরুর তারিখ','করণীয়'],beds.map(b=>[esc(b.name),esc(b.room)+' / '+bn(b.seat),dateLabel(b.start),action('release','সিট ছাড়ুন',b.id)])));
   if(can('roomAdd'))html+=section('বরাদ্দের ইতিহাস',table(['ছাত্র','কক্ষ / সিট','শুরু','শেষ'],rows('allocationsHostel').map(b=>[esc(b.name),esc(b.room)+' / '+bn(b.seat),dateLabel(b.start),b.end?dateLabel(b.end):'চলমান'])));
   return html+section('খাবারের খাতা',table(['তারিখ','বেলা','মিল','ব্যয়','মিলপ্রতি','করণীয়'],meals.map(m=>[dateLabel(m.date),esc(m.type),bn(m.count),cash(m.costMinor),m.count?cash(Math.round(m.costMinor/m.count)):'—',bar(can('mealCost')?action('mealCost','খরচ',m.id):'',can('mealCount')?action('meal','সংশোধন',m.id):'')])),can('mealCount')?primary('meal','মিল লিখুন'):'');
 }
 function inventory(){
   return titlebar('স্টক ও স্থায়ী সম্পদ','মজুত, ব্যবহার ও মেরামতের ইতিহাস।')+section('পণ্যের মজুত',table(['পণ্য','বর্তমান','সতর্কতার সীমা','অবস্থা','পরিবর্তন'],rows('stockItems').map(r=>[esc(r.name),fmtQty(r.quantity)+' '+esc(r.unit),fmtQty(r.minimum),r.quantity<=r.minimum?'<span class="badge2">কম মজুত</span>':'পর্যাপ্ত',action('move','গ্রহণ / ব্যবহার',r.id)])),primary('stock','পণ্য যোগ করুন'))+section('স্টক চলাচল',table(['তারিখ','পণ্য','ধরন','পরিমাণ','কারণ'],rows('stockMoves').slice().sort((a,b)=>b.date.localeCompare(a.date)).map(r=>[dateLabel(r.date),esc(r.name),r.type==='in'?'গ্রহণ':'ব্যবহার',fmtQty(r.quantity)+' '+esc(r.unit),esc(r.note)])))+section('সম্পদের তালিকা',table(['সম্পদ','অবস্থান','ক্রয়ের তারিখ','মূল্য','রক্ষণাবেক্ষণ'],rows('assets').map(a=>[esc(a.name),esc(a.location),dateLabel(a.date),cash(a.valueMinor),action('repair','মেরামত লিখুন',a.id)])),primary('asset','সম্পদ যোগ করুন'))+section('মেরামত খাতা',table(['তারিখ','সম্পদ','কাজ'],rows('repairs').map(r=>[dateLabel(r.date),esc(r.name),esc(r.note)])));
 }
 function library(){
   return titlebar('লাইব্রেরি','কপি নম্বর ধরে কিতাব ইস্যু ও ফেরত নিন।',primary('book','কিতাব যোগ করুন','book-open'))+section('কিতাবের কপি',table(['কপি','কিতাব','লেখক','অবস্থা'],rows('books').map(b=>[esc(b.code),esc(b.title),esc(b.author),b.loanId?'ইস্যুকৃত':action('issueBook','ইস্যু করুন',b.id)])))+section('ধার ও ফেরতের খাতা',table(['কিতাব / কপি','ছাত্র','ইস্যু','মেয়াদ','ফেরত'],rows('bookLoans').map(l=>[esc(l.title)+' · '+esc(l.code),esc(l.name),dateLabel(l.date),dateLabel(l.due)+(l.due<today()&&!l.returned?' <span class="badge2">মেয়াদ পেরিয়েছে</span>':''),l.returned?dateLabel(l.returned):action('returnBook','ফেরত নিন',l.id)])));
 }
 function family(){
   const admin=can('familyLink'),families=rows('families'),children=admin?(find('families',familyUid)?.children||[]):rows('children');
   const title=admin?'অভিভাবক সংযোগ':'আমার সন্তান';
   let html=titlebar(title,admin?'যাচাইকৃত অভিভাবকের অ্যাকাউন্টে ছাত্র যুক্ত করুন।':'সন্তানের হাজিরা, পাঠ, ফলাফল ও ফি দেখুন।',admin?primary('link','ছাত্র যুক্ত করুন'):'');
   if(admin)html+=section('সংযুক্ত পরিবার',table(['অভিভাবকের UID','ছাত্র','করণীয়'],families.flatMap(f=>f.children.map(c=>[esc(f.id),esc(c.name),bar(local()?action('previewFamily','প্রশিক্ষণ প্রিভিউ',f.id):'',action('unlink','সংযোগ সরান',f.id+'|'+c.id))]))));
   if(!admin||local())html+=section('সন্তানের তালিকা',children.length?table(['নাম','বিবরণ'],children.map(c=>[esc(c.name),action('child','তথ্য দেখুন',c.id)])):empty('এখনো কোনো ছাত্র যুক্ত নেই।'));
   const messages=rows('familyMessages');
   html+=section('আবেদন ও পরামর্শ',admin?table(['ছাত্র','বিষয়','বিবরণ','অবস্থা','উত্তর'],messages.map(m=>[esc(m.name),esc(m.type),esc(m.body)+(m.from?'<small>'+dateLabel(m.from)+' — '+dateLabel(m.to)+'</small>':''),esc(m.status),admin&&m.status==='অপেক্ষমাণ'?action('reply','সিদ্ধান্ত দিন',m.id):esc(m.reply||'—')])):'<p>আবেদনের উত্তর দেখতে সন্তানের তথ্য খুলুন।</p>',!admin&&children.length?primary('message','আবেদন লিখুন'):'');
   return html+section('প্রাসঙ্গিক নোটিশ',rows('notices').filter(n=>['all','guardian'].includes(n.audience)).map(n=>'<article class="notice-card"><h2>'+esc(n.title)+'</h2><p>'+esc(n.body)+'</p></article>').join('')||empty('নতুন নোটিশ নেই।'));
 }
 function docs(){
   const list=rows('documents').filter(d=>d.type===docKind);
   return titlebar('সনদ ও পরিচয়পত্র','সিরিয়াল ও QR-সহ প্রতিষ্ঠান থেকে ইস্যু করা নথি।',primary('issueDoc','নথি ইস্যু','file-text'))+section('নথির নিবন্ধন',select('নথির ধরন','p3-doc',[...docTypes,'দাওয়াতপত্র'],docKind)+table(['তারিখ','ছাত্র','রোল','অবস্থা','করণীয়'],list.map(d=>[dateLabel(d.issued),esc(d.name),d.roll==null?'—':bn(d.roll),d.active?'বৈধ':'বাতিল',bar(action('doc','দেখুন',d.id),d.active?action('revoke','বাতিল',d.id):'')])),action('bulk','একসঙ্গে প্রিন্ট','','btn','printer'));
 }
 function page(k){return ({events,hifz,boarding,inventory,library,family,documents:docs})[k]()}
 function change(e){
   const n=e.target.name,v=e.target.value;
   if(n==='p3-month'&&v)hMonth=v;else if(n==='p3-event')eventId=v;else if(n==='p3-hstudent')hStudent=v;else if(n==='p3-doc')docKind=v;else return;
   refresh();
 }
 async function docHtml(d){
   const pv=d.printVersion?(local()?find('printBrands',d.printVersion):await cloud.printBrand(d.printVersion)):null;
   const url=new URL(location.href);url.hash=new URLSearchParams({verify:d.id,source:local()?'training':'cloud'});
   const qr=await QRCode.toDataURL(url.href,{width:120,margin:1});
   let photo='';
   if(d.photoId){
     const f=local()?find('studentFiles',d.photoId):await cloud.readFile(d.photoId);
     if(f?.bytes&&['image/png','image/jpeg'].includes(f.mime))photo='<img class="student-photo" alt="ছাত্রের ছবি" src="data:'+f.mime+';base64,'+esc(f.bytes)+'">';
   }
   return '<article class="issued '+(d.type==='পরিচয়পত্র'?'idcard':'certificate')+'"><header class="documenthead">'+(pv?.logo?'<img src="'+esc(pv.logo)+'" alt="">':icon('book-open',30))+'<div><strong>'+esc(d.institution)+'</strong><small>'+esc(d.address)+'</small></div></header><h2>'+esc(d.type)+(d.active?'':' · বাতিল')+'</h2>'+photo+'<strong>'+esc(d.name)+'</strong><p>'+esc(d.classId)+(d.type==='দাওয়াতপত্র'?' · '+dateLabel(d.eventDate)+' · '+esc(d.venue):' · রোল '+bn(d.roll))+' · '+esc(d.academicYear)+'</p><p class="documentbody">'+esc(d.body)+'</p><footer><img class="qr" src="'+qr+'" alt="নথি যাচাই"><div><small>'+dateLabel(d.issued)+'</small><small>'+esc(d.serial)+'</small></div><div class="signatures">'+['seal','signature'].filter(k=>pv?.[k]).map(k=>'<img src="'+esc(pv[k])+'" alt="'+(k==='seal'?'সিল':'স্বাক্ষর')+'">').join('')+'</div></footer></article>';
 }
 async function child(id,serial=''){
   let data;
   if(local()){
     if(!find('families',familyUid)?.children.some(c=>c.id===id))throw Error('ছাত্র সংযুক্ত নেই।');
     const records=Object.fromEntries(['attendance','hifzLogs','results','invoices'].map(k=>[k,rows(k).filter(r=>r.studentId===id)]));
     records.results=records.results.map(r=>({...r,examName:find('exams',r.examId)?.name}));
     records.messages=rows('familyMessages').filter(r=>r.studentId===id&&r.uid===familyUid);
     records.receipts=rows('receipts').filter(r=>records.invoices.some(i=>i.id===r.invoiceId));
     data=familySummary(find('roster',id),records);
   }else{
     data=await cloud.guardianData(id);
     if(!rows('children').some(c=>c.id===id))throw Error('সংযোগ পরিবর্তিত হয়েছে।');
   }
   const {student,attendance,results,progress,invoices,receipts}=data;
   const body='<p>'+esc(student.classId)+' · রোল '+bn(student.roll)+'</p>'+section('হাজিরা',table(['তারিখ','অবস্থা'],attendance.sort((a,b)=>b.date.localeCompare(a.date)).map(r=>[dateLabel(r.date),esc(statusNames[r.status])])))+section('পরীক্ষার ফল',table(['পরীক্ষা','মোট','গ্রেড'],results.map(r=>[esc(r.examName),bn(r.total)+' / '+bn(r.max),esc(r.grade)])))+section('হিফজ ও নাজেরা',progressTable(progress))+section('ফি ও বকেয়া',table(['খাত','মাস','বাকি'],invoices.map(i=>[esc(i.label),esc(i.period),cash(i.amountMinor-i.paidMinor-i.waivedMinor)+(i.amountMinor>i.paidMinor+i.waivedMinor ? btn('p4-pay','পরিশোধ','wallet','link',i.id):'')])))+section('রসিদ',table(['তারিখ','পরিমাণ','রসিদ'],receipts.map((r,i)=>[dateLabel(r.date),cash(r.amountMinor),'<button type="button" class="link" data-childreceipt="'+i+'">দেখুন</button>'])));
   async function showReceipt(r){
     const kind=({fee:'ফি আদায়',waiver:'মওকুফ',reversal:'বাতিল এন্ট্রি'})[r.kind]||r.kind;
     const pairs=[['প্রতিষ্ঠান',r.institution],['ছাত্র',r.party],['তারিখ',dateLabel(r.date)],['ধরন',kind],['পরিমাণ',cash(r.amountMinor,r.currency)]];
     const url=new URL(location.href);url.hash=new URLSearchParams({familyReceipt:id,serial:r.serial});
     const qr=await QRCode.toDataURL(url.href,{margin:1,width:150});
     if(!local()&&!rows('children').some(c=>c.id===id))throw Error('সংযোগ পরিবর্তিত হয়েছে।');
     modal('ফি রসিদ','<article class="paper2"><h2>'+esc(r.institution)+'</h2><p>'+esc(r.address)+'</p><h2>ফি রসিদ</h2><small>'+esc(r.serial)+'</small>'+notes(pairs.slice(1))+'<img width="96" src="'+qr+'" alt="রসিদ যাচাই"></article><div class="actions"><button type="button" class="btn" id="family-download">রসিদ ডাউনলোড</button>'+printButton()+'</div>');
     document.querySelector('#family-download').onclick=async()=>{
       await document.fonts.ready;
       const canvas=document.createElement('canvas');canvas.width=1100;canvas.height=950;const c=canvas.getContext('2d');
       c.fillStyle='white';c.fillRect(0,0,1100,950);c.fillStyle=brand().primaryColor;c.fillRect(0,0,1100,16);
       c.font='600 48px Gunjoron';c.fillText('ফি রসিদ',64,112);c.font='400 26px Gunjoron';c.fillText(r.serial,64,170,970);
       for(const [i,[k,v]] of pairs.entries()){const y=250+i*82;c.fillStyle='#536656';c.fillText(k,64,y);c.fillStyle='#163e2c';c.fillText(v,330,y,695)}
       const img=new Image();img.src=qr;await img.decode();c.drawImage(img,64,710,160,160);
       canvas.toBlob(blob=>{if(blob)saveBlob(blob,r.serial+'.png')},'image/png');
     };
   }
   if(serial){const receipt=receipts.find(r=>r.serial===serial);if(!receipt)throw Error('রসিদটি এই ছাত্রের খাতায় পাওয়া যায়নি।');return showReceipt(receipt)}
   modal(student.name,body+section('আবেদনের উত্তর',table(['বিষয়','বিবরণ','অবস্থা','উত্তর'],data.messages.map(m=>[esc(m.type),esc(m.body),esc(m.status),esc(m.reply||'—')]))));
   document.querySelectorAll('[data-childreceipt]').forEach(b=>b.onclick=()=>showReceipt(receipts[Number(b.dataset.childreceipt)]).catch(()=>notify('রসিদ খোলা যায়নি।')));

 }
 async function run(k,id){
   if(k==='event')return modal('অনুষ্ঠান তৈরি',text('অনুষ্ঠানের নাম','title')+grid(date(),text('স্থান','venue'))+number('বাজেট (টাকা)','budget',0,0,'.01')+area('কমিটি ও দায়িত্ব','committee')+area('বক্তা / অতিথি','guests'),f=>send('eventAdd',{...f,budgetMinor:minor(f.budget)}));
   if(k==='task')return modal('কাজ বণ্টন',text('কাজ','title')+text('দায়িত্বপ্রাপ্ত','owner')+date('মেয়াদ','due'),f=>send('eventTask',{...f,eventId:id}));
   if(k==='done')return send('eventDone',{taskId:id});
   if(k==='eventMoney')return modal('অনুষ্ঠানের লেনদেন',select('ধরন','type',[['donation','দান'],['expense','ব্যয়']])+grid(number('পরিমাণ (টাকা)','amount','',.01,'.01'),date())+accountForm()+text('দাতা / প্রাপক','party','','')+text('বিবরণ','note'),f=>send('eventMoney',withMoney({eventId:id,type:f.type,party:f.party,note:f.note},f)));
   if(k==='eventReport'){
     const e=find('events',id);return paper('অনুষ্ঠানের রিপোর্ট',e.title,summaryEvent(e)+(can('eventMoney')?table(['তারিখ','বিবরণ','নিট টাকা'],rows('ledger').filter(r=>r.eventId===id).map(r=>[dateLabel(r.date),esc(r.note),cash(r.amountMinor*r.direction)])):'')+(can('eventTask')?table(['কাজ','দায়িত্ব','অবস্থা'],eventRecords('eventTasks',id).map(t=>[esc(t.title),esc(t.owner),t.done?'সম্পন্ন':'চলমান'])):''));
   }
   if(k==='poster'){const e=find('events',id);return ctx.poster({template:'মাহফিল',size:'square',title:e.title,body:e.guests?'অতিথি · '+e.guests:'সকলকে সাদর আমন্ত্রণ।',when:dateLabel(e.date)+' · '+e.venue})}
   if(k==='media')return modal('ছবি বা ভিডিও সংরক্ষণ',text('ক্যাপশন','title')+input('ফাইল · সর্বোচ্চ ৪ মেগাবাইট','file','file','','accept="image/png,image/jpeg,video/mp4,video/webm"')+input('অথবা মূল ফাইলের HTTPS লিংক','url','url')+select('লিংকের ধরন','mediaKind',['ছবি','ভিডিও'])+'<label class="inline"><input type="checkbox" required>সংরক্ষণের অনুমতি আছে</label>',async f=>{
     const payload={eventId:id,title:f.title,consent:true};
     if(f.file?.size){
       if(f.file.size>4194304)throw Error('৪ মেগাবাইটের মধ্যে ফাইল দিন অথবা মূল ফাইলের লিংক দিন।');
       payload.file={name:f.file.name,mime:f.file.type,bytes:(await fileData(f.file)).split(',')[1]};
       if(local())await send('eventMedia',payload);else await cloud.uploadMedia(payload);
     }else await send('eventMedia',{...payload,url:f.url,mediaKind:f.mediaKind});
   });
   if(k==='mediaFile'){
     const f=local()?find('media',id).file:await cloud.readMedia(id);
     const blob=new Blob([Uint8Array.from(atob(f.bytes),c=>c.charCodeAt(0))],{type:f.mime});saveBlob(blob,f.name);return;
   }
   if(k==='lesson'){
     const r=find('hifzLogs',id);requireList(active(),'আগে ছাত্র ভর্তি করুন।');
     const fixed=!!r;
     return modal(fixed?'পাঠ সংশোধন':'দৈনিক পাঠ',select('ছাত্র','studentId',fixed?[[r.studentId,r.name]]:studentOpts(),r?.studentId)+grid(input('তারিখ','date','date',r?.date||today(),fixed?'readonly required':'required'),select('পাঠ','lesson',fixed?[r.lesson]:lessonTypes,r?.lesson))+number('পারা','juz',r?.juz||1,1)+grid(number('শুরুর পৃষ্ঠা','from',r?.from||1,1),number('শেষ পৃষ্ঠা','to',r?.to||1,1))+area('ওস্তাদের মন্তব্য','comment',r?.comment),f=>send('hifz',{...f,juz:Number(f.juz),from:Number(f.from),to:Number(f.to),revision:r?.revision||0}));
   }
   if(k==='progressReport'){
     const list=logs();return paper('মাসিক হিফজ ও নাজেরা রিপোর্ট',hMonth+' · '+(find('roster',hStudent)?.displayName||'সকল ছাত্র'),notes(lessonTypes.map(type=>[type,bn(list.filter(r=>r.lesson===type).length)+' পাঠ']))+table(['ছাত্র','তারিখ','পাঠ','পারা / পৃষ্ঠা','মন্তব্য'],list.map(r=>[esc(r.name),dateLabel(r.date),esc(r.lesson),bn(r.juz)+' / '+bn(r.from)+'–'+bn(r.to),esc(r.comment)])));
   }
   if(k==='room')return modal('নতুন কক্ষ',text('কক্ষের নাম','name')+number('সিট সংখ্যা','capacity',1,1),f=>send('roomAdd',{name:f.name,capacity:Number(f.capacity)}));
   if(k==='assign'){
     const room=find('rooms',id),beds=rows('beds').filter(b=>b.active);
     const seats=Array.from({length:room.capacity},(_,i)=>i+1).filter(n=>!beds.some(b=>b.roomId===id&&b.seat===n));
     const studs=studentOpts().filter(([sid])=>!beds.some(b=>b.studentId===sid));requireList(seats,'কক্ষে খালি সিট নেই।');requireList(studs,'বরাদ্দের উপযোগী ছাত্র নেই।');
     return modal('সিট বরাদ্দ · '+room.name,select('ছাত্র','studentId',studs)+select('সিট নম্বর','seat',seats.map(n=>[n,bn(n)]))+date(),f=>send('bedAssign',{...f,roomId:id,seat:Number(f.seat)}));
   }
   if(k==='release'){const b=find('beds',id);return modal('সিট ছাড়ুন · '+b.name,date('ছাড়ার তারিখ'),f=>send('bedRelease',{...f,bedId:id,allocationId:b.allocationId}))}
   if(k==='meal'){const m=find('meals',id);return modal('মিল সংখ্যা',input('তারিখ','date','date',m?.date||today(),m?'readonly required':'required')+select('বেলা','type',m?[m.type]:['সকাল','দুপুর','রাত'])+number('মিলের সংখ্যা','count',m?.count??1),f=>send('mealCount',{...f,count:Number(f.count),revision:m?.revision||0}))}
   if(k==='mealCost')return modal('খাবারের খরচ',number('পরিমাণ (টাকা)','amount','',.01,'.01')+date('ব্যয়ের তারিখ')+accountForm(),f=>send('mealCost',withMoney({mealId:id},f)));
   if(k==='stock')return modal('পণ্য যোগ করুন',text('পণ্যের নাম','name')+text('একক','unit','কেজি')+number('কম মজুতের সীমা','minimum',0,0,'.001'),f=>send('stockAdd',{name:f.name,unit:f.unit,minimum:Math.round(Number(f.minimum)*1000)}));
   if(k==='move')return modal('স্টক চলাচল',select('ধরন','type',[['in','গ্রহণ'],['out','ব্যবহার']])+number('পরিমাণ','quantity','',.001,'.001')+date()+text('কারণ','note'),f=>send('stockMove',{...f,itemId:id,quantity:Math.round(Number(f.quantity)*1000)}));
   if(k==='asset')return modal('স্থায়ী সম্পদ',text('সম্পদের নাম','name')+text('অবস্থান','location')+date('ক্রয়ের তারিখ')+number('ক্রয়মূল্য (টাকা)','value',0,0,'.01'),f=>send('assetAdd',{...f,valueMinor:minor(f.value)}));
   if(k==='repair')return modal('মেরামত রেকর্ড',date()+area('কাজের বিবরণ','note','',true),f=>send('repair',{...f,assetId:id}));
   if(k==='book')return modal('কিতাবের কপি',text('কিতাবের নাম','title')+text('লেখক','author','','')+text('কপি নম্বর','code'),f=>send('bookAdd',f));
   if(k==='issueBook'){requireList(active(),'আগে ছাত্র ভর্তি করুন।');return modal('কিতাব ইস্যু',studentSelect()+grid(date('ইস্যুর তারিখ'),date('ফেরতের মেয়াদ','due',today(14))),f=>send('bookIssue',{...f,bookId:id}))}
   if(k==='returnBook')return modal('কিতাব ফেরত',date('ফেরতের তারিখ'),f=>send('bookReturn',{...f,loanId:id}));
   if(k==='invite'){const e=find('events',id);return modal('দাওয়াতপত্র ইস্যু',text('আমন্ত্রিত অতিথি','guest')+date('ইস্যুর তারিখ')+area('বক্তব্য','body','আপনাকে '+e.title+' অনুষ্ঠানে সাদর আমন্ত্রণ জানাচ্ছি।',true),async f=>{await send('eventInvite',{...f,eventId:id});docKind='দাওয়াতপত্র';ctx.navigate('documents')})}
   if(k==='message')return modal('অভিভাবকের আবেদন',select('সন্তান','studentId',rows('children').map(c=>[c.id,c.name]))+select('বিষয়','type',['ছুটির আবেদন','অভিযোগ','পরামর্শ'])+grid(date('ছুটি শুরু','from'),date('ছুটি শেষ','to'))+area('বিবরণ','body','',true),f=>send('familyMessage',f));
   if(k==='reply'){const m=find('familyMessages',id);return modal('আবেদনের উত্তর',select('সিদ্ধান্ত','status',m.type==='ছুটির আবেদন'?['অনুমোদিত','প্রত্যাখ্যাত']:['নিষ্পত্তি'])+area('উত্তর','reply','',true),f=>send('familyReply',{...f,messageId:id}))}
   if(k==='link'){requireList(active(),'আগে ছাত্র ভর্তি করুন।');return guard('অভিভাবকের সঙ্গে সংযোগ',studentSelect()+text('যাচাইকৃত অভিভাবকের UID','uid',local()?'training-guardian':''),async(f,secret)=>{familyUid=f.uid;await send('familyLink',{studentId:f.studentId,uid:f.uid,link:true},secret)})}
   if(k==='unlink'){const [uid,studentId]=id.split('|');return guard('অভিভাবক সংযোগ সরান','<p>এই অ্যাকাউন্টে ছাত্রটির তথ্য পড়ার অনুমতি সরানো হবে।</p>',(f,secret)=>send('familyLink',{uid,studentId,link:false},secret))}
   if(k==='previewFamily'){familyUid=id;refresh();return}
   if(k==='child')return child(id);
   if(k==='issueDoc'){
     requireList(active(),'আগে ছাত্র ভর্তি করুন।');
     return guard('নথি ইস্যু',studentSelect()+select('নথির ধরন','type',docTypes,docKind)+date('ইস্যুর তারিখ')+area('নথির বক্তব্য','body','',true),async(f,secret)=>{docKind=f.type;await send('issueDoc',{studentId:f.studentId,type:f.type,date:f.date,body:f.body},secret)});
   }
   if(k==='doc'||k==='bulk'){
     let list=k==='doc'?[find('documents',id)]:rows('documents').filter(d=>d.type===docKind&&d.active);
     if(k==='bulk'){
       const classes=[...new Set(list.map(d=>d.classId))];requireList(classes,'বৈধ নথি নেই।');
       modal('জামাতভিত্তিক প্রিন্ট',select(docKind==='দাওয়াতপত্র'?'অনুষ্ঠান':'জামাত','classId',classes)+action('printClass','নথি খুলুন','','primary','printer'));return;
     }
     modal(list[0].type,(await docHtml(list[0]))+printButton());return;
   }
   if(k==='printClass'){
     const c=document.querySelector('#dialog select').value,list=rows('documents').filter(d=>d.type===docKind&&d.active&&d.classId===c);
     modal('জামাতের নথি',(await Promise.all(list.map(docHtml))).join('')+printButton());return;
   }
   if(k==='revoke')return guard('নথি বাতিল',text('বাতিলের কারণ','reason'),(f,secret)=>send('revokeDoc',{docId:id,reason:f.reason},secret));
 }
 function receiptRoute(){
   const q=new URLSearchParams(location.hash.slice(1)),sid=q.get('familyReceipt'),serial=q.get('serial');
   if(!sid||!serial||(!local()&&ctx.actor().role!=='guardian'))return;
   const links=local()?find('families',familyUid)?.children:ctx.data().children;
   if(!links)return;
   history.replaceState(history.state,'',location.pathname+location.search);
   if(!links.some(c=>c.id===sid)){notify('এই ছাত্রের রসিদ দেখার অনুমতি নেই।');return}
   child(sid,serial).catch(()=>notify('রসিদ খোলা যায়নি।'));
 }
 return {page,allowed,run,change,receiptRoute};
}

export async function verifyRoute(){
 const hash=new URLSearchParams(location.hash.slice(1)),id=hash.get('verify');
 if(!id)return;
 let record;
 try{
   record=hash.get('source')==='training'?(await localRead())['branches/main/verification/'+id]:await cloud.publicVerification(id);
   modal(hash.get('source')==='training'?'প্রশিক্ষণ নথি যাচাই':'নথি যাচাই',record?notes([['অবস্থা',record.active?'বৈধ':'বাতিল'],['প্রতিষ্ঠান',record.institution],['নথি',record.type],['সিরিয়াল',record.serial],['ইস্যুর তারিখ',dateLabel(record.issued)]]):empty('এই সিরিয়ালের নথি পাওয়া যায়নি।'));
 }catch{modal('নথি যাচাই',empty('যাচাই করা যায়নি। ইন্টারনেট সংযোগ পরীক্ষা করে আবার খুলুন।'))}
}
