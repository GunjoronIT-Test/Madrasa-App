import {zipSync,strToU8} from 'fflate';
import {esc} from './ui.js';
export function saveBlob(blob,name){
  const url=URL.createObjectURL(blob),a=document.createElement('a');
  a.href=url;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(url),3000);
}
export function excel(title,headers,rows){
  const ns='http://schemas.openxmlformats.org/spreadsheetml/2006/main';
  const rel='http://schemas.openxmlformats.org/officeDocument/2006/relationships';
  const pack='http://schemas.openxmlformats.org/package/2006/relationships';
  const files={};
  function add(path,s){files[path]=strToU8('<?xml version="1.0" encoding="UTF-8"?>'+s)}
  add('[Content_Types].xml','<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/></Types>');
  add('_rels/.rels',`<Relationships xmlns="${pack}"><Relationship Id="r1" Type="${rel}/officeDocument" Target="xl/workbook.xml"/></Relationships>`);
  add('xl/workbook.xml',`<workbook xmlns="${ns}" xmlns:r="${rel}"><sheets><sheet name="রিপোর্ট" sheetId="1" r:id="r1"/></sheets></workbook>`);
  add('xl/_rels/workbook.xml.rels',`<Relationships xmlns="${pack}"><Relationship Id="r1" Type="${rel}/worksheet" Target="worksheets/sheet1.xml"/></Relationships>`);
  const data=[[title],headers,...rows].map((r,i)=>`<row r="${i+1}">${r.map(v=>typeof v==='number'?`<c><v>${v}</v></c>`:`<c t="inlineStr"><is><t xml:space="preserve">${esc(v).replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f]/g,'')}</t></is></c>`).join('')}</row>`).join('');
  add('xl/worksheets/sheet1.xml',`<worksheet xmlns="${ns}"><cols><col min="1" max="${headers.length}" width="24" customWidth="1"/></cols><sheetData>${data}</sheetData></worksheet>`);
  return new Blob([zipSync(files)],{type:'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'});
}
export const posterSizes={square:[1080,1080],a4:[1240,1754],story:[1080,1920]};
export const templates={
  'মাহফিল':['বার্ষিক মাহফিল','সকলকে সাদর আমন্ত্রণ।'],
  'ভর্তি বিজ্ঞপ্তি':['ভর্তি চলছে','ভর্তির বিস্তারিত জানতে মাদ্রাসার অফিসে যোগাযোগ করুন।'],
  'রমযান ও ঈদ':['রমযানের সময়সূচি','পরিবর্তিত সময়সূচি অনুযায়ী কার্যক্রম চলবে।'],
  'নোটিশ':['বিশেষ বিজ্ঞপ্তি','সকলের অবগতির জন্য জানানো যাচ্ছে।'],
  'ফলাফল':['পরীক্ষার ফলাফল','প্রকাশিত ফলাফল অফিস থেকে সংগ্রহ করুন।'],
  'দান আবেদন':['সহযোগিতার আবেদন','প্রতিষ্ঠানের শিক্ষা কার্যক্রমে সহযোগিতার আহ্বান।']
};
export async function poster(brand,model){
  await Promise.all([400,600,700].map(w=>document.fonts.load(w+' 48px Gunjoron','শিক্ষা')));
  const canvas=document.createElement('canvas');[canvas.width,canvas.height]=posterSizes[model.size];
  const w=canvas.width,h=canvas.height,c=canvas.getContext('2d'),pad=Math.round(w*.085);
  c.fillStyle='#faf8ef';c.fillRect(0,0,w,h);
  c.fillStyle=brand.primaryColor;c.fillRect(0,0,w,Math.round(h*.25));
  c.strokeStyle=brand.accentColor;c.lineWidth=3;
  for(let x=w-280;x<w+150;x+=52)for(let y=-80;y<h*.25-30;y+=52){
    c.beginPath();c.moveTo(x,y-24);c.lineTo(x+24,y);c.lineTo(x,y+24);c.lineTo(x-24,y);c.closePath();c.stroke();
  }
  // Each layout keeps the lower text column clear of ornament.
  c.lineWidth=4;c.strokeStyle=brand.accentColor;c.fillStyle=brand.accentColor;
  const edge=h*.25;
  switch(model.template){
    case 'মাহফিল':
      c.beginPath();c.moveTo(w*.58,edge-4);c.quadraticCurveTo(w*.74,edge-15,w*.79,edge-145);c.quadraticCurveTo(w*.85,edge-15,w,edge-4);c.stroke();break;
    case 'ভর্তি বিজ্ঞপ্তি':
      c.fillRect(0,edge-12,w,12);c.fillRect(0,edge,pad*.22,h-edge);break;
    case 'রমযান ও ঈদ':
      c.beginPath();c.arc(w-pad,edge-86,44,0,2*Math.PI);c.fill();
      c.fillStyle=brand.primaryColor;c.beginPath();c.arc(w-pad+17,edge-99,43,0,2*Math.PI);c.fill();break;
    case 'নোটিশ':
      c.strokeRect(pad*.4,edge+18,w-pad*.8,h-edge-42);break;
    case 'ফলাফল':
      for(let i=0;i<3;i++)c.fillRect(w-pad-85+i*32,edge-30-i*17,18,30+i*17);break;
    case 'দান আবেদন':
      c.beginPath();c.moveTo(0,edge);c.lineTo(w,edge);c.lineTo(w,edge+19);c.closePath();c.fill();break;
  }
  let y=pad;
  const wrap=(text,maxWidth)=>{
    const out=[];
    for(const part of text.split('\n')){
      let line='';
      for(const word of part.split(/\s+/)){
        if(c.measureText(word).width>maxWidth)throw Error('একটি শব্দ ছবির প্রস্থ ছাড়িয়েছে। শব্দটি ছোট করুন।');
        const next=line?line+' '+word:word;
        if(line&&c.measureText(next).width>maxWidth){out.push(line);line=word}else line=next;
      }out.push(line);
    }
    return out;
  };
  c.textBaseline='top';
  if(brand.logo){
    const img=new Image();img.src=brand.logo;await img.decode();
    const scale=Math.min(80/img.width,80/img.height);c.drawImage(img,pad,y,img.width*scale,img.height*scale);
  }
  const bx=pad+(brand.logo?100:0);c.font='600 42px Gunjoron';c.fillStyle='#fff';
  const lines=wrap(brand.nameBn,w-bx-pad);
  if(y+lines.length*60>h*.25)throw Error('প্রতিষ্ঠানের নামের জন্য বড় সাইজ বেছে নিন।');
  lines.forEach((line,i)=>c.fillText(line,bx,y+i*60));
  y=h*.30;
  const block=(str,font,color,step)=>{
    c.font=font;c.fillStyle=color;
    for(const line of wrap(str,w-2*pad)){c.fillText(line,pad,y);y+=step}
  };
  block(model.template,'600 32px Gunjoron',brand.accentColor,54);
  block(model.title,'700 68px Gunjoron',brand.primaryColor,100);
  y+=14;block(model.body,'400 39px Gunjoron','#21352d',67);
  if(model.when){y+=18;block(model.when,'600 33px Gunjoron',brand.primaryColor,54)}
  c.font='400 29px Gunjoron';const foot=wrap([brand.address,brand.publicPhone].filter(Boolean).join(' · '),w-2*pad);
  const footer=h-42-foot.length*48;
  if(y>footer-32)throw Error('লেখা ছবির জায়গা ছাড়িয়েছে। লেখা ছোট করুন অথবা স্টোরি / A4 বেছে নিন।');
  c.fillStyle=brand.accentColor;c.fillRect(pad,footer-20,w-2*pad,2);y=footer;block(foot.join('\n'),'400 29px Gunjoron','#394e43',48);
  return canvas;
}
