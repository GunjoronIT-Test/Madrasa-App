import {enterStep,stepBack,resetSteps} from './navigation.js';
import './scroll-guides.js';
import {branchDirectory,createPhase4,pages4} from './phase4.js';
import {createPhase3,pages3,labels3,verifyRoute} from './phase3.js';
import {listTools} from './list-tools.js';
import {createPhase2,phasePages,phaseLabels} from './phase2.js';
import QRCode from 'qrcode';
import readSheet from 'read-excel-file';
import {roles,permissions,statusNames,funds,accounts} from '../functions/domain.js';
import {trainingBranch,trainingKey,seed,today,localRead,localReplace,localCommand,trainingActor,split} from './local.js';
import * as cloud from './cloud.js';
import {suspendTask,setSectionIcon,esc,icon,bn,numberStyle,cash,dateLabel,input,select,btn,section,empty,table,titlebar,notify,modal,fileData,errorText} from './ui.js';
import {pack,unpack,download} from './backup.js';

const root=document.querySelector('#app'),dialog=document.querySelector('#dialog');
const pages={home:['সারসংক্ষেপ','layout-dashboard'],students:['ছাত্র ও ভর্তি','users'],attendance:['হাজিরা','clipboard-check'],fees:['ফি ও বকেয়া','receipt'],finance:['আয় ও ব্যয়','wallet'],...phasePages,...pages3,...pages4,settings:['সেটিংস','settings']};
const labels={...phaseLabels,...labels3,fee:'ফি আদায়',waiver:'ফি মওকুফ',donation:'দান গ্রহণ',income:'অন্যান্য আয়',expense:'ব্যয়',reversal:'বাতিল এন্ট্রি'};
let mode=sessionStorage.getItem('madrasa.mode'), data={},actor=trainingActor,page='home',range='month',from=today(-29),to=today(),chosenDate=today(),classFilter='',text='',archived=false,financialKind='',month=today().slice(0,7),sort='roll',formStep=0,draft={},editing=false,lastNotices=new Map();
const can=k=>permissions[k]?.includes(actor.role);
const rows=k=>data[k]||[];
const financeRole=()=>can('fee');
const pending=()=>rows('requests').filter(r=>r.status==='queued');
const names=()=>new Map(rows('roster').map(s=>[s.id,s.displayName]));
const local=()=>mode==='training';
const amountInput=(n,label='পরিমাণ (টাকা)',v='')=>input(label,n,'number',v,'min="0.01" max="10000000000" step="0.01" required');
const minor=v=>Math.round(Number(v)*100);
function showIntro(){
  invalidateHistory();
  mode=null;sessionStorage.removeItem('madrasa.mode');
  root.innerHTML=`<main class="welcome" id="intro"><div class="intro-cover"><div class="welcome-mark">${icon('book-open',32)}</div><h1>মাদ্রাসা ব্যবস্থাপনা</h1><p>ভর্তি, হাজিরা ও হিসাব এক জায়গায় পরিচালনা করুন।</p></div><div class="choice"><div class="choice-icon">${icon('landmark',24)}</div><div><h2>প্রতিষ্ঠানের কর্মক্ষেত্র</h2><p>${cloud.configured?'প্রতিষ্ঠানের অ্যাকাউন্ট দিয়ে প্রবেশ করুন।':'Firebase সংযোগের নির্দেশনা ZIP-এর গাইডে পাবেন।'}</p></div>${cloud.configured?btn('login','প্রবেশ করুন','arrow-right','primary'):''}</div><div class="choice"><div class="choice-icon sand">${icon('graduation-cap',24)}</div><div><h2>প্রশিক্ষণ কর্মক্ষেত্র</h2><p>এই ব্রাউজারে নমুনা ডেটা দিয়ে কাজ করে দেখুন।</p></div>${btn('demo','প্রশিক্ষণ খুলুন','arrow-right','primary')}</div>${btn('blank','নিজের তথ্য দিয়ে স্থানীয় সেটআপ','settings','link')}</main>`;
  const directory=branchDirectory();
  if(directory.length)document.querySelector('#intro').insertAdjacentHTML('beforeend',section('প্রতিষ্ঠানের শাখা',directory.map(c=>'<p><a href="'+esc(c.url)+'">'+esc(c.name)+'</a></p>').join('')));
  if(cloud.configured)cloud.publicBrand().then(b=>{
    const intro=document.querySelector('#intro');if(!b?.name||!intro)return;
    intro.querySelector('h1').textContent=b.name;
    if(/^#[a-f0-9]{6}$/i.test(b.color))intro.style.setProperty('--brand',b.color);
    if(/^data:image\/(png|jpeg|webp);base64,[a-zA-Z0-9+/=]+$/.test(b.logo||'')){
      const img=document.createElement('img');img.width=52;img.height=52;img.alt='';img.src=b.logo;intro.querySelector('.welcome-mark').replaceChildren(img);
    }
  }).catch(()=>{});
}
function loginForm(){
  modal('প্রতিষ্ঠানের অ্যাকাউন্ট',input('ইমেইল','email','email','','required autocomplete="username"')+input('পাসওয়ার্ড','password','password','','required autocomplete="current-password"')+'<label class="inline"><input type="checkbox" name="trusted">ব্যক্তিগত ডিভাইসে অফলাইনের জন্য তথ্য রাখুন</label>',async v=>{
    await cloud.login(v.email,v.password,!!v.trusted);mode='cloud';sessionStorage.setItem('madrasa.mode',mode);await connect();
  },'প্রবেশ করুন');
}
async function connect(){
  if(local()){data=split(await localRead());actor=trainingActor;return render()}
  root.innerHTML='<main class="welcome">কর্মক্ষেত্র লোড হচ্ছে…</main>';
  await cloud.observe((v,a)=>{
    data=v;actor=a;
    for(const r of rows('requests')){
      if(lastNotices.get(r.id)==='queued'&&r.status!=='queued')notify(r.status==='accepted'?'সার্ভারে সংরক্ষিত হয়েছে।':r.message);
      lastNotices.set(r.id,r.status);
    }
    if(!(document.querySelector('#setupform') && (editing||!data.brand)))render();
  },async e=>{notify(errorText(e));try{await cloud.logout()}finally{showIntro()}});
}
async function send(kind,payload,password){
  const id=local()?await localCommand(kind,payload):await cloud.cloudCommand(kind,payload,password);
  if(local()){data=split(await localRead());render();notify('সংরক্ষণ হয়েছে।')}
  else notify(navigator.onLine?'অনুরোধ জমা হয়েছে। সিঙ্ক তালিকায় ফল দেখুন।':'অফলাইন অনুরোধ রাখা হয়েছে।');
  return id;
}
function wizard(){
  const steps=['প্রতিষ্ঠান','মুহতামিম','বিভাগ ও জামাত','ফি কাঠামো','শিক্ষাবর্ষ'];
  const b=draft;
  const fields=[
    input('প্রতিষ্ঠানের বাংলা নাম','nameBn','text',b.nameBn,'required maxlength="120"')+input('ঠিকানা','address','text',b.address,'required')+input('প্রকাশ্য ফোন','publicPhone','tel',b.publicPhone)+input('লোগো · সর্বোচ্চ ১৫০ কিলোবাইট','logoFile','file','','accept="image/png,image/webp,image/jpeg"')+'<div class="grid2">'+input('প্রধান রঙ','primaryColor','color',b.primaryColor||'#185747')+input('সহায়ক রঙ','accentColor','color',b.accentColor||'#ad8346')+'</div><details><summary>অতিরিক্ত পরিচিতি</summary>'+[['nameEn','ইংরেজি নাম'],['slogan','স্লোগান'],['publicEmail','ইমেইল'],['website','ওয়েবসাইট'],['registrationNo','নিবন্ধন নম্বর'],['establishedYear','প্রতিষ্ঠার সাল']].map(([k,t])=>input(t,k,'text',b[k])).join('')+select('মুদ্রা','currency',['৳','BDT'],b.currency)+select('সংখ্যা','digits',[['bn','বাংলা'],['en','ইংরেজি']],b.digits)+input('সিলের ছবি','sealFile','file','','accept="image/png,image/jpeg,image/webp"')+input('স্বাক্ষরের ছবি','signatureFile','file','','accept="image/png,image/jpeg,image/webp"')+'</details>',
    input('মুহতামিমের নাম','principalName','text',b.principalName,'required')+`<p class="hint">${local()?'এই কর্মক্ষেত্র শুধু এই ব্রাউজারে সংরক্ষিত হবে।':'আপনার যাচাইকৃত Firebase সদস্যপদ দিয়ে সেটআপ সংরক্ষণ হবে।'}</p>`,
    input('জামাতের নাম (কমা দিয়ে আলাদা করুন)','classesText','text',b.classesText??b.classes?.join(', ')??'হিফজ, নাজেরা, কিতাব','required'),
    input('ভর্তি ফি (টাকা)','admission','number',b.admission??(b.admissionMinor??0)/100,'required min="0" step="0.01"')+input('মাসিক ফি (টাকা)','monthly','number',b.monthly??(b.monthlyMinor??0)/100,'required min="0" step="0.01"')+input('ব্যয় অনুমোদনের সীমা (টাকা, ০ হলে বন্ধ)','expenseLimit','number',b.expenseLimit??(b.expenseLimitMinor??0)/100,'min="0" step="0.01"'),
    input('শিক্ষাবর্ষের নাম','academicYear','text',b.academicYear||today().slice(0,4),'required')+input('শুরুর তারিখ','startDate','date',b.startDate||today().slice(0,4)+'-01-01','required')+(editing&&!local()?passwordField():'')
  ];
  root.innerHTML=`<main class="welcome setup"><div class="welcome-mark">${icon('landmark',30)}</div><small>ধাপ ${bn(formStep+1)} / ৫</small><h1>${steps[formStep]}</h1><progress max="5" value="${formStep+1}"></progress><form id="setupform">${fields[formStep]}<p class="error" role="alert"></p><div class="actions">${btn('back','ফিরুন','chevron-left')}<button class="primary">${formStep===4?'সেটআপ সংরক্ষণ':'পরবর্তী ধাপ'}${icon('arrow-right',16)}</button></div></form></main>`;
  document.querySelector('#setupform').onsubmit=async e=>{
    e.preventDefault();const button=e.submitter;button.disabled=true;
    try{
      const v=Object.fromEntries(new FormData(e.target)),file=v.logoFile;delete v.logoFile;
      if(file?.size){if(file.size>150*1024)throw new Error('১৫০ কিলোবাইটের মধ্যে লোগো দিন।');v.logo=await fileData(file)}
      for(const field of ['signature','seal']){
        const f=v[field+'File'];delete v[field+'File'];
        if(f?.size){if(f.size>150*1024)throw new Error('১৫০ কিলোবাইটের মধ্যে ছবি দিন।');v[field]=await fileData(f)}
      }
      const secret={password:v.password,pin:v.pin};delete v.password;delete v.pin;Object.assign(draft,v);
      if(formStep<4){const previous=formStep;enterStep(()=>{formStep=previous;wizard()});formStep++;wizard();return}
      const p={...draft,classes:draft.classesText.split(/[,،]/).map(s=>s.trim()).filter(Boolean),expenseLimitMinor:minor(draft.expenseLimit||0),monthlyMinor:minor(draft.monthly),admissionMinor:minor(draft.admission)};
      await send(editing?'brand':'setup',p,secret);editing=false;formStep=0;draft={};invalidateHistory();page='home';render();
    }catch(err){e.target.querySelector('.error').textContent=errorText(err)}finally{button.disabled=false}
  };
}
function allowedPage(k){
  if(pages4[k])return phase4.allowed(k);
  if(pages3[k])return phase3.allowed(k);
  if(phasePages[k])return phase2.allowed(k);
  if(k==='students')return can('admission')||can('attendance')||financeRole();
  if(k==='attendance')return can('attendance');
  if(['fees','finance'].includes(k))return financeRole();return true;
}
const groups=[
 ['প্রতিষ্ঠান',['home','notices','events','family']],
 ['শিক্ষা বিভাগ',['students','attendance','scanning','hifz','exams','documents','library']],
 ['অর্থ ও হিসাব',['fees','onlineFees','finance','payroll','loans','reports','analytics']],
 ['পরিচালনা',['boarding','inventory','posters','sms','campuses','settings']]
];
const pageIcons={home:'layout-dashboard',students:'graduation-cap',library:'library-books',documents:'library-id',family:'family-house',boarding:'boarding-house',inventory:'box-stock',hifz:'hifz-book',events:'event-ticket',exams:'trophy',notices:'broadcast',posters:'palette',finance:'ledger-book',fees:'coin-stack',campuses:'campus'};
function nav(k){
 return btn('page',pages[k][0],pageIcons[k]||pages[k][1],'navbtn '+(k===page?'current':''),k);
}
function groupedNav(needle=''){
 return groups.map(([title,keys])=>{
   const available=keys.filter(k=>pages[k]&&allowedPage(k)&&pages[k][0].includes(needle));
   return available.length?'<div class="navgroup"><h3>'+title+'</h3><div>'+available.map(nav).join('')+'</div></div>':'';
 }).join('');
}
const shortNames={home:'হোম',students:'ছাত্র',attendance:'হাজিরা',fees:'ফি',finance:'হিসাব',onlineFees:'অনলাইন ফি',analytics:'বিশ্লেষণ',scanning:'QR হাজিরা',documents:'সনদ',family:'পরিবার',inventory:'স্টক',campuses:'শাখা',payroll:'বেতন'};
function dockKey(){return ['madrasa.dock',mode,local()?trainingBranch:actor.branchId,actor.uid,actor.role].join('.')}
function dockPages(){
 const options=Object.keys(pages).filter(k=>k!=='home'&&allowedPage(k));
 let saved=[];
 try{const value=JSON.parse(localStorage.getItem(dockKey())||'[]');if(Array.isArray(value))saved=value}catch{}
 return ['home',...new Set([...saved,...options].filter(k=>options.includes(k)))].slice(0,4);
}
function dockSettings(){
 const options=Object.keys(pages).filter(k=>k!=='home'&&allowedPage(k)).map(k=>[k,pages[k][0]]);
 const slots=dockPages().slice(1);
 modal('শর্টকাট সাজান','<p class="dock-help">নিচের বারে যে ক্রমে বিভাগগুলো দেখতে চান, সেই ক্রমে বেছে নিন।</p>'+slots.map((k,i)=>select('শর্টকাট '+bn(i+1),'slot'+i,options,k)).join(''),v=>{
   const chosen=slots.map((_,i)=>v['slot'+i]);
   if(new Set(chosen).size!==chosen.length)throw Error('প্রতিটি ঘরে আলাদা বিভাগ বেছে নিন।');
   localStorage.setItem(dockKey(),JSON.stringify(chosen));render();
 });
}
function dock(){
 const tabs=dockPages();
 const tab=(k,last=false)=>{
   const active=last?!tabs.includes(page):page===k;
   const name=last?'আরও':shortNames[k]||pages[k][0];
   const symbol=last?'menu':pageIcons[k]||pages[k][1];
   return '<button type="button" class="dock-item navbtn'+(active?' current':'')+'" data-act="'+(last?'more':'page')+'" data-val="'+k+'" aria-label="'+(last?'সব বিভাগ':pages[k][0])+'"'+(active?' aria-current="location"':'')+'><span class="dock-glyph">'+icon(symbol,22)+'</span><span class="dock-label">'+esc(name)+'</span></button>';
 };
 return '<nav class="bottom" aria-label="দ্রুত নেভিগেশন"><div class="dock-track">'+tabs.map(k=>tab(k)).join('')+tab('more',true)+'</div></nav>';
}
function syncLabel(){
 if(local())return 'প্রশিক্ষণ';
 if(pending().length)return bn(pending().length)+'টি অপেক্ষমাণ';
 return navigator.onLine?'সংযুক্ত':'অফলাইন';
}
function campusName(){
 if(!local())return branchDirectory().find(c=>{try{return new URL(c.url).origin===location.origin}catch{return false}})?.name||'প্রতিষ্ঠানের শাখা';
 if(trainingBranch==='main')return 'প্রধান শাখা';
 try{return JSON.parse(localStorage.getItem('madrasa.campuses')||'[]').find(c=>c.id===trainingBranch)?.name||'প্রশিক্ষণ শাখা'}catch{return 'প্রশিক্ষণ শাখা'}
}
function masthead(b){
 const badge='<img class="mast-seal" src="'+esc(b.logo||'./assets/icons/app-192.png')+'" alt="">';
 const branch=esc(campusName());
 return '<header class="masthead"><button class="mast-identity" data-act="page" data-val="campuses" aria-label="শাখা নির্বাচন">'+badge+'<span><strong>'+esc(b.nameBn)+'</strong><small>'+branch+icon('chevron-down',12)+'</small></span></button>'+
 '<div class="mast-tools"><button class="mast-search" type="button" data-act="find" aria-label="বিভাগ খুঁজুন">'+icon('search',20)+'<span>বিভাগ খুঁজুন</span><kbd>Ctrl K</kbd></button>'+
 '<button class="mast-account" data-act="account" aria-label="আমার অ্যাকাউন্ট">'+icon('user-round-plus',21)+'<i class="state-lamp '+(local()?'training':navigator.onLine?'online':'offline')+'"></i></button></div></header>';
}
function accountPage(){
 modal('আমার অ্যাকাউন্ট',summaryRows([['প্রতিষ্ঠান',esc(data.brand.nameBn)],['শাখা',esc(campusName())],['দায়িত্ব',esc(roles[actor.role])],['কর্মক্ষেত্র',esc(syncLabel())]])+'<div class="account-actions">'+btn('sync','সংরক্ষণ ও সিঙ্ক','cloud')+btn('customDock','শর্টকাট সাজান','sliders-horizontal')+btn('logout','বের হন','log-out')+'</div>');
}
document.addEventListener('keydown',e=>{
 if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='k'&&root.querySelector('.masthead')&&!dialog.open){
   e.preventDefault();directory();dialog.querySelector('[name=moduleQuery]').focus();
 }
});
function directory(){
 modal('সব বিভাগ','<label class="directory-search">'+icon('search',22)+'<input name="moduleQuery" type="search" placeholder="বিভাগ খুঁজুন" aria-label="বিভাগ খুঁজুন"></label><div class="directory-options">'+btn('customDock','শর্টকাট সাজান','sliders-horizontal','link')+'</div><div class="directory-list">'+groupedNav()+'</div>');
 const search=dialog.querySelector('[name=moduleQuery]');
 search.oninput=()=>{dialog.querySelector('.directory-list').innerHTML=groupedNav(search.value.trim())||empty('এই নামে কোনো বিভাগ পাওয়া যায়নি।')};
}
function invalidateHistory(){
 if(dialog.open)dialog.close();
 dialog.replaceChildren();resetSteps();
}
function navigate(target){
 if(!pages[target]||!allowedPage(target))return;
 if(target==='home'){invalidateHistory()}
 else if(page!==target||dialog.open){
   const previous={page,text,archived,classFilter},restoreTask=suspendTask();
   enterStep(()=>{
     page=previous.page;text=previous.text;archived=previous.archived;classFilter=previous.classFilter;
     render();restoreTask();
   });
 }
 page=target;text='';archived=false;classFilter='';render();window.scrollTo(0,0);
}
window.madrasaBack=()=>{
 if(stepBack())return true;
 if(dialog.open){dialog.close();return true}
 if(document.querySelector('#setupform')){
   if(formStep){formStep--;wizard()}else{editing=false;draft={};if(data.brand)render();else showIntro()}
   return true;
 }
 if(page!=='home'&&mode){navigate('home');return true}
 return false;
};
window.addEventListener('madrasa-access-changed',()=>{invalidateHistory();page='home'});
function render(){
  if(!mode)return showIntro();
  if(editing||!data.brand){
    if(!can('setup')){root.innerHTML='<main class="welcome"><p>প্রতিষ্ঠানের সেটআপ মুহতামিম সম্পন্ন করবেন।</p>'+btn('logout','বের হন','log-out')+'</main>';return}
    if(!data.brand&&pending().some(r=>r.kind==='setup')){root.innerHTML='<main class="welcome">সেটআপ সার্ভারে যাচাই হচ্ছে…</main>';return}
    return wizard();
  }
  const b=data.brand;numberStyle(b);
  for(const [css,k] of [['--brand','primaryColor'],['--accent','accentColor']])if(/^#[a-f\d]{6}$/i.test(b[k]))document.documentElement.style.setProperty(css,b[k]);
  if(location.hash==='#notices'){history.replaceState(history.state,'',location.pathname+location.search);if(page!=='notices'){navigate('notices');return}}
  if(!allowedPage(page))page='home';
  root.innerHTML=`<div class="shell"><aside><div class="identity">${b.logo?`<img src="${esc(b.logo)}" alt="">`:`<span class="mark">${icon('book-open',23)}</span>`}<strong>${esc(b.nameBn)}</strong></div><nav aria-label="মূল নেভিগেশন">${groupedNav()}</nav><div class="profile"><span class="avatar">${icon('user-round-plus',19)}</span><div><strong>${esc(roles[actor.role])}</strong><small>${local()?'প্রশিক্ষণ অ্যাকাউন্ট':'প্রতিষ্ঠানের অ্যাকাউন্ট'}</small></div></div></aside><div class="workspace">${masthead(b)}<main class="content" id="content"></main>${dock()}</div></div>`;
  renderContent();phase2.documentRoute();phase3.receiptRoute();
  if(location.hash.startsWith('#receipt=') && rows('ledger').length){
    const id=decodeURIComponent(location.hash.slice(9));history.replaceState(history.state,'',location.pathname+location.search);receipt(id);
  }
}
function renderContent(){
 const target=document.querySelector('#content');if(!target)return;
 target.dataset.module=page;setSectionIcon(page==='home'?'':pageIcons[page]||pages[page][1]);
 if(pages4[page]){target.innerHTML=phase4.page(page);return}
 if(pages3[page]){target.innerHTML=phase3.page(page);listTools(target,page);return}
 if(phasePages[page]){target.innerHTML=phase2.page(page);if(['payroll','loans','exams'].includes(page))listTools(target,page);return}
 target.innerHTML=({home:dashboard,students:studentPage,attendance:attendancePage,fees:feesPage,finance:financePage,settings:settingsPage})[page]();
}
function period(){
 const d=today();
 if(range==='today')return [d,d];if(range==='week')return [today(-6),d];if(range==='year')return [d.slice(0,4)+'-01-01',d];if(range==='custom')return [from,to];return [d.slice(0,7)+'-01',d];
}
const periodSelect=()=>select('সময়কাল','range',[['today','আজ'],['week','গত ৭ দিন'],['month','চলতি মাস'],['year','চলতি বছর'],['custom','নিজস্ব সময়সীমা']],range);
const rangeFields=()=>periodSelect()+(range==='custom'?input('শুরু','from','date',from)+input('শেষ','to','date',to):'');
const sum=(list,fn)=>list.reduce((a,v)=>a+fn(v),0);
const delta=v=>v.amountMinor*v.direction;
function stat(page,label,value,ico,tone,sub){
 return `<button class="stat ${tone}" data-act="page" data-val="${page}"><span class="stat-top"><i>${icon(ico)}</i>${icon('arrow-up-right',16)}</span><span>${label}</span><strong>${value}</strong><small>${sub}</small></button>`;
}
function chart(list){
 const [a,b]=period(),start=Date.parse(a),end=Date.parse(b),days=Math.max(1,Math.round((end-start)/86400000)+1);
 if(!Number.isFinite(days)||days>3660)return empty('সর্বোচ্চ ১০ বছরের সময়সীমা বেছে নিন।');
 const groups=Array.from({length:Math.min(7,days)},(_,i)=>({date:new Date(start+Math.floor(i*days/Math.min(7,days))*86400000).toISOString().slice(0,10),income:0,expense:0}));
 for(const r of list){const slot=groups.findLast(v=>r.date>=v.date);if(slot)slot[delta(r)>=0?'income':'expense']+=Math.abs(delta(r))}
 const max=Math.max(1,...groups.flatMap(x=>[x.income,x.expense]));
 return `<div class="legend"><span><i></i>প্রাপ্তি</span><span><i></i>প্রদান</span></div><div class="plot">${groups.map(g=>`<div class="plot-col" title="${dateLabel(g.date)} · আয় ${cash(g.income)} · ব্যয় ${cash(g.expense)}"><div class="bars"><i style="height:${100*g.income/max}%"></i><i style="height:${100*g.expense/max}%"></i></div><small>${bn(Number(g.date.slice(8)))}/${bn(Number(g.date.slice(5,7)))}</small></div>`).join('')}</div>`;
}
function dashboard(){
 const [a,b]=period(),all=rows('ledger'),list=all.filter(v=>v.date>=a&&v.date<=b),students=rows('roster').filter(s=>s.status==='active'),att=rows('attendance').filter(r=>r.date===today()),due=sum(rows('invoices'),r=>r.amountMinor-r.paidMinor-r.waivedMinor);
 const title=titlebar('প্রতিষ্ঠানের সারসংক্ষেপ',dateLabel(today())+' · '+new Intl.DateTimeFormat('bn-BD-u-ca-islamic',{day:'numeric',month:'long',year:'numeric',timeZone:'Asia/Dhaka'}).format(new Date()).replace(/\s*যুগ$/,' হিজরি'),can('admission')?btn('admit','ছাত্র ভর্তি','plus','primary'):'');
 if(actor.role==='guardian')return phase3.page('family');
 const stats=stat('students','মোট ছাত্র',bn(students.length),'users','green','সক্রিয় তালিকা')+(can('attendance')?stat('attendance','আজ উপস্থিত',bn(att.filter(x=>['present','late'].includes(x.status)).length),'clipboard-check','blue','অনুপস্থিত '+bn(att.filter(x=>x.status==='absent').length)+' জন'):'')+(financeRole()?stat('finance','মোট স্থিতি',cash(sum(all,delta)),'wallet','gold','সব তহবিল ও হিসাব')+stat('fees','বকেয়া ফি',cash(due),'receipt','rose','সব অসম্পূর্ণ দাবি'):'');
 const shortcuts=['attendance','fees','scanning','notices'].filter(allowedPage);
 let out='<div class="overview-hero">'+title+'</div><div class="stats">'+stats+'</div>'+
   '<div class="quickbar">'+shortcuts.map(k=>btn('page',pages[k][0],pageIcons[k]||pages[k][1],'quick-action',k)).join('')+'</div>';
 if(financeRole()){
  out+='<div class="dashgrid">'+section('টাকা আসা ও যাওয়ার প্রবাহ','<div class="filters">'+rangeFields()+'</div>'+chart(list))+
   section('হিসাবের সারাংশ',summaryRows([['আয়',cash(sum(list.filter(x=>['income','fee','donation'].includes(x.category||x.originalKind||x.kind)),delta))],['ব্যয়',cash(-sum(list.filter(x=>['expense','salaryPay'].includes(x.category||x.originalKind||x.kind)),delta))],['অনুদান (নিট)',cash(sum(list.filter(x=>(x.category||x.originalKind||x.kind)==='donation'),delta))],['নিট পরিবর্তন',cash(sum(list,delta))]]))+'</div>'+section('সাম্প্রতিক লেনদেন',ledgerTable([...all].sort(byDate).slice(0,5)),btn('page','সব দেখুন','chevron-right','link','finance'));
 }else out+=section('ছাত্র তালিকা',studentTable(students.slice(0,8)));
 if(financeRole()){
   const unpaid=rows('payslips').filter(s=>s.netMinor>s.paidMinor),loans=rows('loans').filter(l=>l.status==='active');
   out+=section('বেতন ও ঋণ',summaryRows([['বকেয়া বেতন স্লিপ',bn(unpaid.length)+'টি · '+cash(sum(unpaid,s=>s.netMinor-s.paidMinor))],['মোট দেনা',cash(sum(loans.filter(l=>l.side==='borrow'),l=>l.principalMinor-l.paidMinor))],['মোট পাওনা',cash(sum(loans.filter(l=>l.side==='lend'),l=>l.principalMinor-l.paidMinor))],['মেয়াদ পেরোনো কিস্তি',bn(sum(loans,l=>l.installments.filter(i=>i.due<today()&&i.expected>i.paid).length))+'টি']]));
 }
 const upcoming=rows('events').filter(e=>e.date>=today()).sort((a,b)=>a.date.localeCompare(b.date)).slice(0,4);
 if(upcoming.length)out+=section('আসন্ন অনুষ্ঠান',table(['তারিখ','অনুষ্ঠান','স্থান'],upcoming.map(e=>[dateLabel(e.date),esc(e.title),esc(e.venue)])),btn('page','সব দেখুন','chevron-right','link','events'));
 const approvals=rows('approvals').filter(a=>a.status==='pending');
 if(approvals.length)out+=section('অনুমোদনের অপেক্ষায়',table(['বিবরণ','পরিমাণ','সিদ্ধান্ত'],approvals.map(a=>[esc(a.payload.note||a.payload.fund),cash(a.payload.amountMinor),can('approveExpense')?btn('approveExpense','অনুমোদন',null,'link',a.id)+btn('denyExpense','প্রত্যাখ্যান',null,'link',a.id):'অপেক্ষমাণ'])));
 return out;
}
const byDate=(a,b)=>b.date.localeCompare(a.date)||b.createdAt.localeCompare(a.createdAt);
const summaryRows=pairs=>'<dl class="summary">'+pairs.map(([k,v])=>`<div><dt>${k}</dt><dd>${v}</dd></div>`).join('')+'</dl>';
function ledgerTable(list){
 return table(['বিবরণ','তারিখ','তহবিল','পরিমাণ','রসিদ'],list.map(r=>[`<strong>${esc(labels[r.kind])}</strong><small>${esc(r.party||r.note||r.account)}</small>`,dateLabel(r.date),esc(r.fund),`<b class="${r.direction<0?'minus':'positive'}">${r.direction<0?'−':''}${cash(r.amountMinor)}</b>`,btn('receipt','দেখুন','receipt','link',r.id)]));
}
function roster(){
 const list=rows('roster').filter(s=>(s.status==='archived')===archived&&(!classFilter||s.classId===classFilter)&&[s.displayName,s.classId,String(s.roll),bn(s.roll)].some(v=>v.includes(text)));
 return list.sort((a,b)=>sort==='name'?a.displayName.localeCompare(b.displayName,'bn'):a.roll-b.roll);
}
const classSelect=()=>select('জামাত','classFilter',[['','সব জামাত'],...data.brand.classes],classFilter);
const search=()=>input('খুঁজুন','search','search',text,'placeholder="নাম অথবা রোল"');
function studentTable(list){
 return table(['নাম','রোল','জামাত','আবাসন','প্রোফাইল'],list.map(s=>[esc(s.displayName),bn(s.roll),esc(s.classId),esc(rows('studentPrivate').find(p=>p.id===s.id)?.residentialStatus||'—'),btn('student','দেখুন','chevron-right','link',s.id)]));
}
function studentPage(){
 return titlebar('ছাত্র ও ভর্তি','জামাত অনুযায়ী ছাত্রের পরিচিতি ও ভর্তির তথ্য।',can('admission')?'<div class="toolbar">'+btn('bulk','Excel আমদানি','upload')+btn('admit','ছাত্র ভর্তি','plus','primary')+'</div>':'')+section(archived?'আর্কাইভ':'ছাত্র তালিকা','<div class="filters">'+search()+classSelect()+select('ক্রম','sort',[['roll','রোল'],['name','নাম']],sort)+select('অবস্থা','archived',[['0','সক্রিয়'],['1','আর্কাইভ']],archived?'1':'0')+'</div>'+studentTable(roster()));
}
function admission(){
 modal('ছাত্র ভর্তি',input('ছাত্রের পূর্ণ নাম','displayName','text','','required maxlength="120"')+'<div class="grid2">'+input('অভিভাবকের নাম','guardian','text','','required')+input('মোবাইল নম্বর','phone','tel','','required pattern="01[3-9][0-9]{8}" placeholder="01XXXXXXXXX"')+'</div>'+input('ঠিকানা','address')+'<div class="grid2">'+select('জামাত','classId',data.brand.classes)+select('আবাসন','residentialStatus',['অনাবাসিক','আবাসিক','লিল্লাহ বোর্ডিং','এতিম'])+'</div>'+input('ভর্তির তারিখ','date','date',today(),'required')+'<details><summary>ভর্তি পরীক্ষা, ছবি ও নথি</summary>'+input('ভর্তি পরীক্ষার নম্বর (১০০)','examScore','number','','min="0" max="100" step="0.01"')+input('ছাত্রের ছবি · ১৫০ কেবি','photo','file','','accept="image/jpeg,image/png"')+input('ভর্তির নথি · ১৫০ কেবি','document','file','','accept=".pdf,image/jpeg,image/png"')+'</details>',async v=>{
   const files=[];
   for(const kind of ['photo','document']){
     const file=v[kind];delete v[kind];if(!file?.size)continue;
     if(file.size>150*1024)throw new Error('প্রতিটি সংযুক্তি ১৫০ কিলোবাইটের মধ্যে দিন।');
     files.push({kind,name:file.name,mime:file.type,bytes:(await fileData(file)).split(',')[1]});
   }
   await send('admission',{...v,files});
 },'ভর্তি সংরক্ষণ');
}
function profile(id){
 const s=rows('roster').find(x=>x.id===id),p=rows('studentPrivate').find(x=>x.id===id);
 modal('ছাত্রের প্রোফাইল',summaryRows([['নাম',esc(s.displayName)],['রোল',bn(s.roll)],['জামাত',esc(s.classId)],['ভর্তির তারিখ',dateLabel(s.joinedOn)],...(p?[['অভিভাবক',esc(p.guardian)],['ফোন',esc(p.phone)],['ঠিকানা',esc(p.address)],['ভর্তি পরীক্ষার নম্বর',p.examScore==null?'—':bn(p.examScore)],['স্বাস্থ্য নোট',esc(p.healthNote||'—')],['আচরণ নোট',esc(p.disciplineNote||'—')]]:[])])+(p?.attachments||[]).map(a=>btn('attachment',esc(a.name),'download','btn',a.id)).join('')+(p&&can('profile')?btn('editprofile','প্রোফাইল সম্পাদনা','settings','btn',id):'')+(can('archive')?btn(s.status==='active'?'archive':'restore',s.status==='active'?'আর্কাইভে রাখুন':'ফিরিয়ে আনুন','archive','btn',id):''));
}
function attendancePage(){
 const found=new Map(rows('attendance').filter(a=>a.date===chosenDate).map(a=>[a.studentId,a]));
 return titlebar('দৈনিক হাজিরা','তারিখ ও জামাত বেছে ছাত্রের উপস্থিতি লিখুন।')+section('হাজিরা খাতা','<div class="filters">'+input('তারিখ','chosenDate','date',chosenDate)+classSelect()+search()+'</div>'+table(['ছাত্র','জামাত','উপস্থিতির অবস্থা'],roster().map(s=>{
 const a=found.get(s.id);
 return [esc(s.displayName)+'<small>রোল '+bn(s.roll)+'</small>',esc(s.classId),'<div class="attendance-actions">'+Object.entries(statusNames).map(([k,v])=>btn('mark',v,null,'markbtn '+(a?.status===k?'on':''),s.id+'|'+k)).join('')+'</div>'];
 })));
}
function feesPage(){
 const n=names(), invoices=rows('invoices').filter(i=>i.period===month && (!text||(n.get(i.studentId)||'').includes(text))).sort((a,b)=>(n.get(a.studentId)||'').localeCompare(n.get(b.studentId)||'','bn'));
 return titlebar('ফি ও বকেয়া','প্রতি ছাত্রের দাবি, জমা ও মওকুফের হিসাব।','<div class="toolbar">'+btn('charge','অন্য ফি','receipt')+btn('generate','মাসিক দাবি তৈরি','plus','primary')+'</div>')+section('ফি খাতা','<div class="filters">'+input('মাস','month','month',month)+search()+'</div>'+table(['ছাত্র','খাত','দাবি','জমা / মওকুফ','বকেয়া','করণীয়'],invoices.map(i=>{
 const remain=i.amountMinor-i.paidMinor-i.waivedMinor;
 return [esc(n.get(i.studentId)),esc(i.label),cash(i.amountMinor),cash(i.paidMinor)+' / '+cash(i.waivedMinor),cash(remain),remain?btn('collect','আদায়',null,'link',i.id)+(can('waiver')?btn('waive','মওকুফ',null,'link',i.id):''):'পরিশোধিত'];
 })));
}
function financePage(){
 const [a,b]=period(),list=rows('ledger').filter(r=>r.date>=a&&r.date<=b&&(!financialKind||r.kind===financialKind)&&(!text||[r.party,r.note,r.serial,r.fund].some(x=>x?.includes(text)))).sort(byDate);
 return titlebar('আয় ও ব্যয়','তহবিল ও হিসাব অনুযায়ী লেনদেন সংরক্ষণ করুন।',btn('entry','লেনদেন লিখুন','plus','primary'))+section('লেনদেনের খাতা','<div class="filters">'+rangeFields()+select('লেনদেন','financialKind',[['','সব ধরন'],...Object.entries(labels)],financialKind)+input('অনুসন্ধান','search','search',text,'placeholder="নাম, রসিদ বা তহবিল"')+'</div>'+ledgerTable(list))+section('তহবিল ও হিসাবের স্থিতি',table(['তহবিল','হিসাব','স্থিতি'],balances()));
}
function balances(){
 const totals=new Map();for(const r of rows('ledger')){const k=r.fund+'|'+r.account;totals.set(k,(totals.get(k)||0)+delta(r))}
 return [...totals].map(([k,v])=>[...k.split('|').map(esc),cash(v)]);
}
const passwordField=()=>local()?'':input('পরিচয় নিশ্চিত করতে পাসওয়ার্ড','password','password','','required autocomplete="current-password"')+input('ছয় অঙ্কের পিন','pin','password','','required pattern="[0-9]{6}" inputmode="numeric"');
function moneyForm(kind,invoiceId){
 const inv=rows('invoices').find(i=>i.id===invoiceId);
 modal(inv?labels[kind]:'নতুন লেনদেন',(inv?'<p>'+esc(names().get(inv.studentId))+' · '+esc(inv.label)+'</p>':select('লেনদেনের ধরন','kind',[['donation','দান গ্রহণ'],['income','অন্যান্য আয়'],['expense','ব্যয়']]))+'<div class="grid2">'+amountInput('amount','পরিমাণ (টাকা)',inv?(inv.amountMinor-inv.paidMinor-inv.waivedMinor)/100:'')+input('তারিখ','date','date',today(),'required')+'</div><div class="grid2">'+select('তহবিল','fund',funds)+select('হিসাব','account',accounts)+'</div>'+(inv?'':input('দাতা বা প্রাপকের নাম','party'))+input(kind==='waiver'?'মওকুফের কারণ':'বিবরণ','note','text','',kind==='waiver'?'required':'')+(kind==='waiver'?passwordField():''),async v=>{
  const {password,pin,...p}=v;const id=await send(kind||v.kind,{...p,amountMinor:minor(v.amount),...(inv?{invoiceId}:{})},{password,pin});
  if(local())setTimeout(()=>receipt(id),0);
 });
}
async function receipt(id){
 const r=rows('ledger').find(x=>x.id===id);if(!r){notify('রসিদ পাওয়া যায়নি বা দেখার অনুমতি নেই।');return}
 const print=r.printVersion?(local()?rows('printBrands').find(v=>v.id===r.printVersion):await cloud.printBrand(r.printVersion)):null;
 const address=new URL(location.href);address.hash='receipt='+encodeURIComponent(id);
 const qr=await QRCode.toDataURL(address.href,{width:120,margin:1});
 modal('লেনদেনের রসিদ',`<article class="receipt"><div class="receipt-top">${(print?.logo||(!print&&data.brand.logo))?`<img class="receiptlogo" src="${esc(print?.logo||data.brand.logo)}" alt="">`:''}<div><strong>${esc(r.institution)}</strong><small>${esc(r.address)} · ${esc(r.phone)}</small></div>${icon('receipt',30)}</div><h2>${labels[r.kind]}</h2><small>${esc(r.serial)}</small>${summaryRows([['তারিখ',dateLabel(r.date)],['নাম',esc(r.party||'—')],['তহবিল',esc(r.fund)],['হিসাব',esc(r.account)],['বিবরণ',esc(r.note||'—')],['পরিমাণ',cash(r.amountMinor,r.currency)]])}<div class="signatures">${['seal','signature'].filter(k=>print?.[k]).map(k=>`<img src="${esc(print[k])}" alt="${k==='seal'?'সিল':'স্বাক্ষর'}">`).join('')}</div><img width="96" height="96" src="${qr}" alt="রসিদ যাচাইয়ের কিউআর"><small>${local()?'প্রশিক্ষণ রসিদ':'অনুমোদিত কর্মক্ষেত্রে স্ক্যান করে যাচাই করুন'}</small></article><div class="actions">${btn('print','প্রিন্ট / PDF','printer','primary')}${can('reversal')&&r.kind!=='reversal'&&!rows('ledger').some(v=>v.kind==='reversal'&&v.sourceId===id)?btn('reverse','বাতিল এন্ট্রি','rotate-ccw','btn',id):''}</div>`);
}
function settingsPage(){
 return titlebar('সেটিংস','প্রতিষ্ঠানের পরিচিতি, ডেটা ও সংযোগ।')+section('প্রতিষ্ঠানের পরিচিতি',summaryRows([['নাম',esc(data.brand.nameBn)],['ঠিকানা',esc(data.brand.address)],['শিক্ষাবর্ষ',esc(data.brand.academicYear)],['মাসিক ফি',cash(data.brand.monthlyMinor)],['জামাত',esc(data.brand.classes.join(', '))]]),can('brand')?btn('brand','সম্পাদনা','settings','link'):'')+(actor.role==='principal'?section('ব্যাকআপ','<p>শাখার তথ্য JSON ফাইলে সংরক্ষণ করুন। এতে ছাত্র ও অভিভাবকের ব্যক্তিগত তথ্য থাকবে।</p><div class="actions">'+btn('export','ব্যাকআপ ডাউনলোড','download','primary')+(local()?btn('import','প্রশিক্ষণ ব্যাকআপ ফেরান','upload'):'')+'</div>'):'')+(local()?'':section('নিরাপত্তা',btn('pin','প্রথম পিন নির্ধারণ','shield-check')))+section('সিঙ্কের অবস্থা',syncList());
}
function syncList(){
 if(local())return '<p>প্রশিক্ষণের তথ্য এই ব্রাউজারে থাকে।</p>';
 return table(['কাজ','অবস্থা','ফল'],[...rows('requests')].sort((a,b)=>(b.createdAt?.seconds||0)-(a.createdAt?.seconds||0)).slice(0,60).map(r=>[esc(labels[r.kind]||({setup:'সেটআপ',brand:'ব্র্যান্ডিং',attendance:'হাজিরা',admission:'ভর্তি',charge:'অন্য ফি',profile:'প্রোফাইল',approveExpense:'ব্যয় অনুমোদন',denyExpense:'ব্যয় প্রত্যাখ্যান',invoice:'ফি দাবি',restore:'পুনরুদ্ধার',archive:'আর্কাইভ'})[r.kind]),esc(({queued:'অপেক্ষমাণ',accepted:'সংরক্ষিত',rejected:'প্রত্যাখ্যাত'})[r.status]),r.status==='queued'?btn('pending','প্রাপ্তিস্বীকার','file-text','link',r.id):esc(r.message||'—')]));
}
const phase2=createPhase2({data:()=>data,rows,can,send,passwordField,local,refresh:renderContent,pushEnabled:cloud.pushEnabled,push:cloud.togglePush});
const phase4=createPhase4({rows,can,local,send,today,refresh:renderContent});
const phase3=createPhase3({rows,can,send,local,passwordField,refresh:renderContent,data:()=>data,actor:()=>actor,navigate,poster:m=>{phase2.usePoster(m);navigate('posters')}});
root.addEventListener('change',phase3.change);
root.addEventListener('change',phase2.change);
async function action(k,v){
 if(k.startsWith('p4-'))return phase4.run(k.slice(3),v);
 if(k.startsWith('p3-'))return phase3.run(k.slice(3),v);
 if(k.startsWith('p2-'))return phase2.action(k.slice(3),v);
 if(k==='close')return stepBack();
 if(k==='page')return navigate(v);
 if(k==='login')return loginForm();
 if(k==='demo'||k==='blank'){
  if(!navigator.locks)throw new Error('localhost অথবা HTTPS ঠিকানা থেকে খুলুন।');
  if(k==='demo')await seed();mode='training';sessionStorage.setItem('madrasa.mode',mode);return connect();
 }
 if(k==='logout'){
   if(!local()&&pending().length)throw new Error('অপেক্ষমাণ অনুরোধ সিঙ্ক হওয়ার পরে বের হন।');
   if(!local())await cloud.logout();sessionStorage.removeItem('madrasa.mode');location.reload();return;
 }
 if(k==='back'){if(stepBack())return;if(formStep){formStep--;wizard()}else{editing=false;draft={};if(data.brand)render();else showIntro()}return}
 if(k==='find'){directory();return dialog.querySelector('[name=moduleQuery]').focus()}
 if(k==='more')return directory();
 if(k==='account')return accountPage();
 if(k==='customDock')return dockSettings();
 if(k==='brand'){enterStep(()=>{editing=false;draft={};formStep=0;render()});editing=true;draft={...data.brand};formStep=0;wizard();return}
 if(k==='pin')return modal('প্রথম পিন নির্ধারণ',passwordField(),async f=>{await cloud.setPin(f.password,f.pin);notify('পিন নির্ধারণ হয়েছে।')});
 if(k==='sync')return modal('সংরক্ষণ ও সিঙ্ক',syncList());
 if(k==='pending'){
  const r=rows('requests').find(x=>x.id===v);
  return modal('অস্থায়ী প্রাপ্তিস্বীকার','<p>সার্ভারে যাচাই অপেক্ষমাণ</p>'+summaryRows([['অনুরোধ নম্বর',esc(v)],['তারিখ',esc(r.payload.date||'—')],['পরিমাণ',cash(r.payload.amountMinor)]])+btn('print','প্রিন্ট','printer'));
 }
 if(k==='admit')return admission();
 if(k==='student')return profile(v);
 if(k==='editprofile'){
   const s=rows('roster').find(r=>r.id===v),p=rows('studentPrivate').find(r=>r.id===v);
   return modal('প্রোফাইল সম্পাদনা',input('ছাত্রের নাম','displayName','text',s.displayName,'required')+select('জামাত','classId',data.brand.classes,s.classId)+input('অভিভাবকের নাম','guardian','text',p.guardian,'required')+input('মোবাইল','phone','tel',p.phone,'required')+input('ঠিকানা','address','text',p.address)+input('স্বাস্থ্য নোট','healthNote','text',p.healthNote)+input('আচরণ নোট','disciplineNote','text',p.disciplineNote),f=>send('profile',{...f,studentId:v,revision:p.updatedAt}));
 }
 if(k==='bulk'){
   return modal('Excel থেকে ভর্তি','<p>প্রথম শিটে এই পাঁচটি কলাম রাখুন। মোবাইল নম্বর Text হিসেবে দিন।</p><p>নাম, অভিভাবক, মোবাইল, জামাত, আবাসন</p>'+input('Excel ফাইল','sheet','file','','accept=".xlsx" required')+input('ভর্তির তারিখ','date','date',today(),'required'),async f=>{
     if(f.sheet.size>2*1024*1024)throw new Error('সর্বোচ্চ ২ মেগাবাইটের ফাইল দিন।');
     const [head,...lines]=await readSheet(f.sheet);
     const expected=['নাম','অভিভাবক','মোবাইল','জামাত','আবাসন'];
     if(!head||expected.some((x,i)=>head[i]!==x)||!lines.length||lines.length>200)throw new Error('কলামের নাম মিলিয়ে ১ থেকে ২০০টি সারি দিন।');
     const batch=lines.map((line,i)=>{
       const [displayName,guardian,phone,classId,residentialStatus]=line.map(c=>String(c??'').trim());
       if(!displayName||!guardian||!/^01[3-9]\d{8}$/.test(phone)||!data.brand.classes.includes(classId)||!['আবাসিক','অনাবাসিক','এতিম','লিল্লাহ বোর্ডিং'].includes(residentialStatus))throw new Error('সারি '+bn(i+2)+' ঠিক করে আবার চেষ্টা করুন।');
       return {displayName,guardian,phone,classId,residentialStatus,date:f.date};
     });
     let added=0,skipped=0;
     for(const row of batch){
       if(rows('roster').some(s=>s.displayName===row.displayName&&rows('studentPrivate').some(p=>p.id===s.id&&p.phone===row.phone))){skipped++;continue}
       await send('admission',row);added++;
     }
     notify((local()?'সংরক্ষিত ':'জমা হয়েছে ')+bn(added)+'টি। আগে ছিল '+bn(skipped)+'টি।');
   },'ভর্তি জমা দিন');
 }
 if(k==='attachment'){
   const f=local()?rows('studentFiles').find(r=>r.id===v):await cloud.readFile(v);
   const blob=new Blob([Uint8Array.from(atob(f.bytes),c=>c.charCodeAt(0))],{type:f.mime});
   const url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=f.name;a.click();setTimeout(()=>URL.revokeObjectURL(url),3000);return;
 }
 if(k==='mark'){
   const [studentId,status]=v.split('|'),prev=rows('attendance').find(a=>a.studentId===studentId&&a.date===chosenDate);
   if(prev?.status===status)return;
   return send('attendance',{studentId,status,date:chosenDate,revision:prev?.revision||0});
 }
 if(k==='approveExpense'||k==='denyExpense')return modal('ব্যয়ের সিদ্ধান্ত',passwordField(),async f=>send(k,{approvalId:v},f),'নিশ্চিত করুন');
 if(k==='entry')return moneyForm();
 if(k==='collect'||k==='waive')return moneyForm(k==='collect'?'fee':'waiver',v);
 if(k==='charge'){
   const students=rows('roster').filter(s=>s.status==='active');
   if(!students.length)throw new Error('আগে ছাত্র ভর্তি করুন।');
   return modal('নতুন ফি দাবি',select('ছাত্র','studentId',students.map(s=>[s.id,s.displayName+' · '+bn(s.roll)]))+select('খাত','label',['পরীক্ষা ফি','খাবার ফি','হোস্টেল ফি','অন্যান্য ফি'])+input('মাস','period','month',month,'required')+amountInput('amount'),f=>send('charge',{...f,amountMinor:minor(f.amount)}));
 }
 if(k==='generate'){
   if(!data.brand.monthlyMinor)throw new Error('সেটিংসে মাসিক ফি নির্ধারণ করুন।');
   const ids=rows('roster').filter(s=>s.status==='active'&&s.joinedOn.slice(0,7)<=month&&!rows('invoices').some(i=>i.id===s.id+'_'+month)).map(s=>s.id);
   return modal('মাসিক ফি দাবি','<p>'+esc(month)+' মাসে '+bn(ids.length)+' জনের জন্য নতুন দাবি তৈরি হবে।</p>',async()=>{
     for(const studentId of ids)await send('invoice',{studentId,period:month});
     notify(local()?'মাসিক দাবি তৈরি হয়েছে।':'দাবি তৈরির অনুরোধ জমা হয়েছে।');
   },'দাবি তৈরি করুন');
 }
 if(k==='receipt')return receipt(v);
 if(k==='print'){await document.fonts.ready;window.print();return}
 if(['reverse','archive','restore'].includes(k))return modal(k==='reverse'?'বাতিল এন্ট্রি নিশ্চিত করুন':k==='archive'?'ছাত্রকে আর্কাইভে রাখুন':'ছাত্রকে ফিরিয়ে আনুন',(k==='reverse'?input('বাতিলের কারণ','note','text','','required'):'<p>ছাত্রের তালিকায় এই পরিবর্তন সংরক্ষিত হবে।</p>')+(k==='restore'?'':passwordField()),async f=>send(k==='reverse'?'reversal':k,k==='reverse'?{entryId:v,note:f.note,date:today()}:{studentId:v},{password:f.password,pin:f.pin}),'নিশ্চিত করুন');
 if(k==='export'){
   const records=local()?await localRead():await cloud.cloudBackup();
   download('madrasa-'+mode+'-'+today()+'.json',await pack(records,mode,local()?trainingBranch:undefined));return notify('ব্যাকআপ ডাউনলোড শুরু হয়েছে।');
 }
 if(k==='import')return modal('প্রশিক্ষণ ব্যাকআপ ফেরান',input('JSON ফাইল','backup','file','','accept=".json" required')+'<label class="inline"><input type="checkbox" required>বর্তমান প্রশিক্ষণ তথ্য প্রতিস্থাপনে সম্মত আছি</label>',async f=>{
   const records=await unpack(f.backup,trainingBranch);await navigator.locks.request(trainingKey,()=>localReplace(records));await connect();
 },'যাচাই করে ফেরান');
}
document.addEventListener('click',async e=>{
 const target=e.target.closest('[data-act]');if(!target)return;
 target.disabled=true;try{await action(target.dataset.act,target.dataset.val)}catch(err){notify(errorText(err))}finally{target.disabled=false}
});
root.addEventListener('change',e=>{
 const c=e.target;if(!c.closest('.filters'))return;
 if(c.name==='range')range=c.value;
 if(c.name==='from'||c.name==='to'){
   const a=c.name==='from'?c.value:from,b=c.name==='to'?c.value:to;
   if(!a||!b||a>b){notify('শেষ তারিখ শুরুর তারিখের পরে দিন।');return renderContent()}from=a;to=b;
 }
 if(c.name==='classFilter')classFilter=c.value;
 if(c.name==='chosenDate'&&c.value)chosenDate=c.value;
 if(c.name==='month'&&c.value)month=c.value;
 if(c.name==='financialKind')financialKind=c.value;
 if(c.name==='archived')archived=c.value==='1';
 if(c.name==='sort')sort=c.value;
 renderContent();
});
root.addEventListener('input',e=>{
 if(e.target.name!=='search')return;text=e.target.value;renderContent();const c=root.querySelector('[name=search]');c.focus();c.setSelectionRange(text.length,text.length);
});
window.addEventListener('online',()=>{if(mode)render()});window.addEventListener('offline',()=>{if(mode)render()});
window.addEventListener('command-error',e=>notify(e.detail));
if('serviceWorker' in navigator)navigator.serviceWorker.register('./sw.js').catch(()=>notify('অফলাইন পৃষ্ঠা প্রস্তুত হয়নি।'));
if(!mode&&cloud.configured&&localStorage.getItem('madrasa.trusted')==='1')mode='cloud';
(mode?connect():Promise.resolve(showIntro())).catch(e=>{showIntro();notify(errorText(e))});

window.addEventListener('hashchange',verifyRoute);verifyRoute();
