import {input,select} from './ui.js';
const prefs=new Map();
const collator=new Intl.Collator('bn',{numeric:true,sensitivity:'base'});
const plain=s=>s.toLocaleLowerCase().replace(/[০-৯]/g,c=>String('০১২৩৪৫৬৭৮৯'.indexOf(c))).trim();
export function listTools(container,page){
  for(const [index,t] of [...container.querySelectorAll('table')].entries()){
    const body=t.tBodies[0],entries=[...body.rows];
    if(entries.length<2)continue;
    const key=page+'-'+index;
    const pref=prefs.get(key)||{q:'',order:''};
    const columns=[...t.tHead.rows[0].cells].map((c,i)=>[String(i),c.textContent]).filter(([i])=>!entries.some(r=>r.cells[i]?.querySelector('button')));
    const box=document.createElement('div');box.className='filters compactfilter';
    box.innerHTML=input('তালিকায় খুঁজুন','p2find','search',pref.q)+select('সাজান','p2order',[['','মূল ক্রম'],...columns],pref.order);
    t.closest('.scroll').before(box);
    const msg=document.createElement('p');msg.className='hint';msg.textContent='মিল পাওয়া যায়নি।';box.after(msg);
    const q=box.querySelector('input'),order=box.querySelector('select');
    function apply(){
      let count=0;
      const ordered=entries.slice();
      if(order.value!==''){
        const n=Number(order.value);
        ordered.sort((a,b)=>collator.compare(plain(a.cells[n].textContent).replace(/,/g,''),plain(b.cells[n].textContent).replace(/,/g,'')));
      }
      for(const tr of ordered){tr.hidden=!plain(tr.textContent).includes(plain(q.value));if(!tr.hidden)count++;body.append(tr)}
      msg.hidden=count!==0;prefs.set(key,{q:q.value,order:order.value});
    }
    q.oninput=apply;order.onchange=apply;apply();
  }
}
