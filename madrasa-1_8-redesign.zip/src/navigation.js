// Each entry describes how to return to the screen immediately before it.
// The browser holds only an index. Form values stay in memory.
let session=crypto.randomUUID(),steps=[],waiting=false;
const state=()=>({...history.state,madrasaRoute:{session,depth:steps.length}});
history.replaceState(state(),'');
export function resetSteps(){
 steps=[];waiting=false;session=crypto.randomUUID();history.replaceState(state(),'');
}
export function enterStep(restore,task=false){
 steps.push({restore,task});history.pushState(state(),'');
}
export function stepBack(){
 if(!steps.length)return false;
 if(!waiting){waiting=true;history.back()}
 return true;
}
export function finishTask(){
 let count=0;
 for(let i=steps.length-1;i>=0&&steps[i].task;i--)count++;
 if(count&&!waiting){waiting=true;history.go(-count)}
}
window.addEventListener('popstate',e=>{
 waiting=false;
 const route=e.state?.madrasaRoute;
 if(route?.session!==session)return;
 const depth=Math.max(0,Math.min(route.depth,steps.length));
 // A history-menu jump may skip several entries.
 while(steps.length>depth)steps.pop().restore();
 if(route.depth!==depth)history.replaceState(state(),'');
});
