import {stepBack} from './navigation.js';
import jsQR from 'jsqr';
import * as deployment from '../public/config.js';
import {trainingBranch} from './local.js';
import {checkout} from './cloud.js';
import {btn,esc,bn,cash,input,select,table,titlebar,section,empty,modal,notify} from './ui.js';

export const pages4={scanning:['QR হাজিরা','scan-line'],onlineFees:['অনলাইন ফি','wallet'],sms:['অভিভাবককে SMS','message-square'],analytics:['মাসভিত্তিক বিশ্লেষণ','chart-column'],campuses:['শাখা নির্বাচন','landmark']};
const statusLabel={simulation:'প্রশিক্ষণ',queued:'অপেক্ষমাণ',sending:'প্রেরণ চলছে',accepted:'গেটওয়ে গ্রহণ করেছে',rejected:'গেটওয়ে প্রত্যাখ্যান করেছে',unknown:'গেটওয়েতে যাচাই করুন',pending:'চেকআউট শুরু',credited:'জমা হয়েছে',review:'হিসাব যাচাই প্রয়োজন'};
const due=i=>i.amountMinor-i.waivedMinor-i.paidMinor;
const campusList=()=>JSON.parse(localStorage.getItem('madrasa.campuses')||'[]');
function codeFrom(value,training){
  const url=new URL(value,location.href),hash=new URLSearchParams(url.hash.slice(1));
  if(url.origin!==location.origin||url.pathname!==location.pathname||(training&&(url.searchParams.get('campus')||'main')!==trainingBranch)||
     hash.get('source')!==(training?'training':'cloud')||!/^[-\w]{1,100}$/.test(hash.get('verify')||''))throw Error('এই শাখার পরিচয়পত্রের QR দিন।');
  return hash.get('verify');
}
function decode(frame){
  const width=frame.videoWidth||frame.width,height=frame.videoHeight||frame.height;
  if(!width||!height)return;
  const scale=Math.min(1,1100/Math.max(width,height)),canvas=document.createElement('canvas');
  canvas.width=Math.round(width*scale);canvas.height=Math.round(height*scale);
  const ctx=canvas.getContext('2d',{willReadFrequently:true});ctx.drawImage(frame,0,0,canvas.width,canvas.height);
  const pixels=ctx.getImageData(0,0,canvas.width,canvas.height);
  return jsQR(pixels.data,pixels.width,pixels.height)?.data;
}
export const branchDirectory=()=>(deployment.branches||[]).filter(c=>{try{return new URL(c.url).protocol==='https:'}catch{return false}});
export function createPhase4({rows,can,local,send,today,refresh}){
  let period=today().slice(0,7);
  const name=id=>rows('roster').find(s=>s.id===id)?.displayName||'ছাত্র';
  const act=(k,label,icon,val='')=>btn('p4-'+k,label,icon,'btn',val);
  const allowed=k=>({scanning:can('attendance'),onlineFees:can('fee'),sms:can('smsQueue'),analytics:can('fee'),campuses:true})[k];
  const scan=value=>send('qrAttendance',{cardId:codeFrom(value,local()),date:today()});
  function analytics(){
    const months=Array.from({length:6},(_,i)=>{const d=new Date(period+'-01T00:00:00Z');d.setUTCMonth(d.getUTCMonth()-5+i);return d.toISOString().slice(0,7)});
    const summary=months.map(m=>{
      const invoices=rows('invoices').filter(i=>i.period===m),sum=k=>invoices.reduce((a,i)=>a+i[k],0);
      const billed=sum('amountMinor')-sum('waivedMinor'),paid=sum('paidMinor');
      return [esc(m),cash(billed),cash(paid),cash(billed-paid),billed?bn(Math.round(paid*100/billed))+'%':'—'];
    });
    const flow=new Map(months.map(m=>[m,{income:0,expense:0}]));
    for(const r of rows('ledger')){
      const group=flow.get(r.date.slice(0,7));
      if(!group||!r.direction)continue;
      const effect=r.direction*r.amountMinor;
      if((r.kind==='reversal'?-r.direction:r.direction)>0)group.income+=effect;
      else group.expense-=effect;
    }
    const movements=months.map(m=>{const g=flow.get(m);return [esc(m),cash(g.income),cash(g.expense),cash(g.income-g.expense)]});
    const grouped=new Map();
    for(const r of rows('attendance').filter(r=>r.date.startsWith(period))){
      const g=grouped.get(r.classId)||{total:0,present:0};g.total++;
      if(['present','late'].includes(r.status))g.present++;grouped.set(r.classId,g);
    }
    return section('মাস অনুযায়ী বিল ও আদায়',table(['বিলের মাস','মওকুফ বাদে বিল','এ পর্যন্ত আদায়','বকেয়া','আদায়ের হার'],summary))+
      section('লেনদেনের তারিখ অনুযায়ী আয় ও ব্যয়',table(['মাস','আয়','ব্যয়','নিট প্রবাহ'],movements))+
      (can('attendance')?section('জামাত অনুযায়ী হাজিরা · '+esc(period),table(['জামাত','রেকর্ড','উপস্থিত ও দেরি','উপস্থিতির হার'],Array.from(grouped,([k,g])=>[esc(k),bn(g.total),bn(g.present),bn(Math.round(100*g.present/g.total))+'%']))):'');
  }
  function page(k){
    const header=(sub,controls='')=>titlebar(pages4[k][0],sub,controls);
    if(k==='analytics')return header('নির্বাচিত মাসসহ ছয় মাসের বিল এবং নির্বাচিত মাসের নথিভুক্ত হাজিরা।',act('month','মাস বাছুন','calendar-days'))+analytics();
    if(k==='scanning')return header('আজকের হাজিরা লিখতে ছাত্রের সক্রিয় পরিচয়পত্র স্ক্যান করুন।')+section('পরিচয়পত্র পড়ুন','<div class="actions">'+act('camera','ক্যামেরা খুলুন','scan-line')+act('photo','QR ছবি বাছুন','upload')+act('link','QR লিংক দিন','clipboard-check')+'</div>');
    if(k==='sms')return header('ছাত্রের ভর্তি ফর্মে রাখা অভিভাবকের নম্বরে বার্তা পাঠান।',act('message','বার্তা লিখুন','message-square'))+
      section('প্রেরণের ইতিহাস',table(['ছাত্র','বার্তা','অবস্থা'],[...rows('smsOutbox')].sort((a,b)=>b.createdAt.localeCompare(a.createdAt)).map(r=>[esc(name(r.studentId)),esc(r.body),esc(statusLabel[r.status])])));
    if(k==='onlineFees')return header(local()?'প্রশিক্ষণে নমুনা রসিদ তৈরি হবে।':'বকেয়া বিল বেছে গেটওয়ের মাধ্যমে পরিশোধ করুন।')+section('বকেয়া বিল',table(['ছাত্র','বিল','বকেয়া',''],rows('invoices').filter(i=>due(i)>0).map(i=>[esc(name(i.studentId)),esc(i.label)+' · '+esc(i.period),cash(due(i)),act('pay','পরিশোধ','wallet',i.id)])))+
      (can('smsQueue')?section('গেটওয়ের লেনদেন',table(['লেনদেন','পরিমাণ','অবস্থা'],rows('paymentOrders').map(o=>[esc(o.id),cash(o.amountMinor),esc(statusLabel[o.status])]))):'');
    const localChoices=[{id:'main',name:'প্রধান শাখা'},...campusList()];
    const cloudLinks=branchDirectory();
    return header(local()?'প্রতি প্রশিক্ষণ শাখার তথ্য এই ব্রাউজারে আলাদাভাবে সংরক্ষিত হয়।':'শাখার কর্মক্ষেত্র খুলে সেই শাখার অ্যাকাউন্ট দিয়ে প্রবেশ করুন।',local()?act('addCampus','শাখা যোগ করুন','plus'):'')+section('শাখার তালিকা',local()?table(['শাখা','কর্মক্ষেত্র'],localChoices.map(c=>[esc(c.name),trainingBranch===c.id?'বর্তমান শাখা':act('switch','খুলুন','arrow-right',c.id)])):
      cloudLinks.length?table(['শাখা','কর্মক্ষেত্র'],cloudLinks.map(c=>[esc(c.name),'<a href="'+esc(c.url)+'">শাখা খুলুন</a>'])):empty('এই প্রতিষ্ঠানের শাখার ঠিকানা config.js-এ যোগ করুন।'));
  }
  async function run(k,v){
    if(k==='month')return modal('বিশ্লেষণের মাস',input('শেষ মাস','month','month',period,'required min="1900-01" max="9999-12"'),x=>{period=x.month;refresh()});
    if(k==='addCampus')return modal('প্রশিক্ষণ শাখা',input('শাখার নাম','name','text','','required maxlength="80"'),x=>{
      const name=x.name.trim();if(!name)throw Error('শাখার নাম দিন।');
      localStorage.setItem('madrasa.campuses',JSON.stringify([...campusList(),{id:crypto.randomUUID(),name}]));refresh();
    });
    if(k==='switch'){const url=new URL(location.href);url.hash='';url.searchParams.set('campus',v);location.assign(url.href);return}
    if(k==='message'){
      const students=rows('roster').filter(s=>s.status==='active');
      if(!students.length)throw Error('প্রথমে ছাত্র ভর্তি করুন।');
      return modal('অভিভাবককে বার্তা',select('ছাত্র','studentId',students.map(s=>[s.id,s.displayName+' · '+bn(s.roll)]))+'<label>বার্তা<textarea name="body" maxlength="480" required></textarea></label><label class="inline"><input type="checkbox" name="consent" required>প্রাপকের সম্মতি নিয়েছি</label>',x=>send('smsQueue',{studentId:x.studentId,body:x.body,confirmed:x.consent==='on'}),local()?'নমুনা সংরক্ষণ':'পাঠান');
    }
    if(k==='pay'){
      const i=rows('invoices').find(r=>r.id===v);
      return modal(local()?'প্রশিক্ষণ পেমেন্ট':'অনলাইন ফি পরিশোধ','<p>'+ (i?esc(i.label)+' · '+cash(due(i))+'<br>':'')+(local()?'নমুনা হিসেবে ফি জমা ও রসিদ তৈরি হবে।':'নিরাপদ চেকআউটে উপলভ্য বিকাশ বা নগদ চ্যানেল বেছে নিন।')+'</p>',async()=>{
        if(local())await send('fee',{invoiceId:v,amountMinor:due(i),date:today(),fund:'সাধারণ',account:'ব্যাংক',note:'অনলাইন পেমেন্ট প্রশিক্ষণ'});
        else location.assign(await checkout(v));
      },local()?'নমুনা জমা করুন':'চেকআউটে যান');
    }
    if(k==='link')return modal('পরিচয়পত্রের লিংক',input('QR থেকে পাওয়া লিংক','url','url','','required'),x=>scan(x.url),'হাজিরা লিখুন');
    if(k==='photo')return modal('QR ছবি থেকে হাজিরা',input('পরিচয়পত্রের ছবি','qr','file','','accept="image/*" required'),async(_,form)=>{
      const file=form.elements.qr.files[0];if(file.size>10000000)throw Error('১০ এমবির মধ্যে ছবি দিন।');
      const frame=await createImageBitmap(file);let value;try{value=decode(frame)}finally{frame.close()}
      if(!value)throw Error('QR পড়া যায়নি। পরিষ্কার ছবি দিন।');await scan(value);
    },'হাজিরা লিখুন');
    if(k==='camera'){
      modal('ক্যামেরায় QR পড়ুন','<video muted autoplay playsinline style="width:100%"></video><p role="status">পরিচয়পত্রটি ক্যামেরার সামনে ধরুন।</p>');
      const dialog=document.querySelector('#dialog'),video=dialog.querySelector('video');
      let stream;
      try{stream=await navigator.mediaDevices.getUserMedia({video:{facingMode:{ideal:'environment'}},audio:false})}
      catch{dialog.querySelector('[role=status]').textContent='ক্যামেরার অনুমতি দিন অথবা QR ছবির বিকল্প ব্যবহার করুন।';return}
      const stop=()=>stream.getTracks().forEach(t=>t.stop());
      if(!dialog.open||!video.isConnected){stop();return}
      dialog.addEventListener('close',stop,{once:true});video.srcObject=stream;
      async function inspect(){
        if(!dialog.open||!video.isConnected){stop();return}
        try{const value=decode(video);if(value){stop();await scan(value);stepBack();return}}
        catch(e){stop();notify(e.message);stepBack();return}
        setTimeout(inspect,220);
      }
      inspect();
    }
  }
  return {page,run,allowed};
}
