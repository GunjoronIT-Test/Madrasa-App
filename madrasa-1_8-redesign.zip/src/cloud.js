import {p3Protected} from '../functions/phase3.js';
import {protectedPhase2} from '../functions/phase2.js';
import {initializeApp} from 'firebase/app';
import {getAuth,signInWithEmailAndPassword,signOut,onAuthStateChanged,connectAuthEmulator,setPersistence,browserSessionPersistence,browserLocalPersistence,reauthenticateWithCredential,EmailAuthProvider} from 'firebase/auth';
import {initializeFirestore,persistentLocalCache,persistentMultipleTabManager,memoryLocalCache,connectFirestoreEmulator,doc,collection,query,where,getDoc,onSnapshot,setDoc,serverTimestamp,terminate,clearIndexedDbPersistence} from 'firebase/firestore';
import {getFunctions,httpsCallable,connectFunctionsEmulator} from 'firebase/functions';
import {firebaseConfig,useEmulators} from '../public/config.js';
export const configured=!!firebaseConfig?.projectId;
let app,auth,db,fn,stops=[],member;
const b='branches/main/';
function start(trusted){
  if(app)return;
  app=initializeApp(firebaseConfig);
  auth=getAuth(app);
  db=initializeFirestore(app,{localCache:trusted?persistentLocalCache({tabManager:persistentMultipleTabManager()}):memoryLocalCache()});
  fn=getFunctions(app);
  if(useEmulators){
    connectFirestoreEmulator(db,'127.0.0.1',8080);connectAuthEmulator(auth,'http://127.0.0.1:9099',{disableWarnings:true});connectFunctionsEmulator(fn,'127.0.0.1',5001);
  }
}
export async function login(email,password,trusted){
  start(trusted);
  await setPersistence(auth,trusted?browserLocalPersistence:browserSessionPersistence);
  await signInWithEmailAndPassword(auth,email,password);
  localStorage.setItem('madrasa.trusted',trusted?'1':'0');
}
export async function observe(update,fail){
  start(localStorage.getItem('madrasa.trusted')==='1');
  const u=await new Promise(resolve=>{const off=onAuthStateChanged(auth,v=>{off();resolve(v)})});
  if(!u)throw new Error('ইমেইল ও পাসওয়ার্ড দিয়ে প্রবেশ করুন।');
  const m=await getDoc(doc(db,b+'members/'+u.uid));
  if(!m.exists()||!m.data().active)throw new Error('এই শাখায় সক্রিয় সদস্যপদ নেই।');
  member={...m.data(),uid:u.uid};
  const state={};let ready=false;
  const send=()=>{if(ready)update(state,member)};
  stops.push(onSnapshot(doc(db,b+'members/'+u.uid),s=>{
    if(!s.exists()||!s.data().active||s.data().role!==member.role || JSON.stringify(s.data().classIds)!==JSON.stringify(member.classIds)) fail(new Error('সদস্যপদ বদলেছে। আবার প্রবেশ করুন।'));
  },fail));
  stops.push(onSnapshot(doc(db,'settings/institution'),s=>{state.brand=s.data();ready=true;send()},fail));
  const top=['principal','deputy'].includes(member.role);
  function listen(col,q){
    stops.push(onSnapshot(q,{includeMetadataChanges:true},s=>{state[col]=s.docs.map(d=>({...d.data(),id:d.id}));send()},fail));
  }
  if(member.role!=='guardian'){
    for(const col of ['roster','attendance',...((top||['academic','teacher'].includes(member.role))?['exams','results','hifzLogs']:[])]){
      if(col==='attendance' && !top&&!['academic','teacher'].includes(member.role))continue;
      if(member.role==='teacher'){
        // Separate listeners support all assigned classes without an IN-query limit.
        const parts=new Map();
        for(const c of member.classIds||[])stops.push(onSnapshot(query(collection(db,b+col),where('classId','==',c)),s=>{
          parts.set(c,s.docs.map(d=>({...d.data(),id:d.id})));state[col]=[...parts.values()].flat();send();
        },fail));
      }else listen(col,collection(db,b+col));
    }
  }
  if(top||member.role==='office')listen('studentPrivate',collection(db,b+'studentPrivate'));
  if(top||member.role==='accountant')for(const col of ['ledger','invoices','approvals','payContracts','payslips','loans'])listen(col,collection(db,b+col));
  if(top||member.role==='office')for(const col of ['staff','staffAttendance'])listen(col,collection(db,b+col));
  if(top||member.role==='office')for(const col of ['events','eventTasks','media','rooms','beds','allocationsHostel','meals','stockItems','stockMoves','assets','repairs','books','bookLoans'])listen(col,collection(db,b+col));
  if(member.role==='accountant')for(const col of ['events','meals'])listen(col,collection(db,b+col));
  if(top)for(const col of ['families','documents','familyMessages','smsOutbox','paymentOrders'])listen(col,collection(db,b+col));
  if(member.role==='guardian')stops.push(onSnapshot(doc(db,b+'families/'+u.uid),s=>{
    const next=s.data()?.children||[];
    if(JSON.stringify(next)!==JSON.stringify(state.children))window.dispatchEvent(new Event('madrasa-access-changed'));
    state.children=next;send();
  },fail));
  listen('notices',top?collection(db,b+'notices'):query(collection(db,b+'notices'),where('audience','in',['all',member.role])));
  listen('requests',query(collection(db,b+'requests'),where('actorUid','==',u.uid)));
  listen('items',collection(db,b+'views/'+u.uid+'/items'));
}
export async function cloudCommand(kind,payload,password){
  if(!navigator.onLine && localStorage.getItem('madrasa.trusted')!=='1')throw new Error('অফলাইন এন্ট্রির জন্য ব্যক্তিগত ডিভাইসের সংরক্ষণ চালু করে প্রবেশ করুন।');
  const id=crypto.randomUUID();
  if([...p3Protected,...protectedPhase2,'archive','reversal','waiver','brand','approveExpense','denyExpense'].includes(kind)){
    await reauthenticateWithCredential(auth.currentUser,EmailAuthProvider.credential(auth.currentUser.email,password.password));
    await auth.currentUser.getIdToken(true);await httpsCallable(fn,'confirmAction')({id,kind,pin:password.pin});
  }
  const commit=setDoc(doc(db,b+'requests/'+id),{actorUid:member.uid,branchId:'main',createdAt:serverTimestamp(),kind,payload,status:'queued'});
  if(navigator.onLine) await commit;
  else commit.catch(e=>window.dispatchEvent(new CustomEvent('command-error',{detail:e.message})));
  return id;
}
export async function logout(){
  const token=localStorage.getItem('madrasa.push');
  if(token&&auth?.currentUser){
    try{await httpsCallable(fn,'registerPush')({token,remove:true});await deleteToken(getMessaging(app))}
    catch{ /* Push payloads contain no private notice text. Auth is checked when the app opens. */ }
    localStorage.removeItem('madrasa.push');
  }
  for(const stop of stops)stop();stops=[];
  if(auth){await signOut(auth);await terminate(db);await clearIndexedDbPersistence(db)}
  localStorage.removeItem('madrasa.trusted');
}
export async function cloudBackup(){return (await httpsCallable(fn,'exportBranch')({})).data.records}
export async function readFile(id){return (await httpsCallable(fn,'readAttachment')({id})).data}

export async function setPin(password,pin){
  await reauthenticateWithCredential(auth.currentUser,EmailAuthProvider.credential(auth.currentUser.email,password));
  await auth.currentUser.getIdToken(true);await httpsCallable(fn,'setPin')({pin});
}
export async function publicBrand(){
 if(!configured)return null;
 const base=useEmulators?'http://127.0.0.1:8080':'https://firestore.googleapis.com';
 const res=await fetch(base+'/v1/projects/'+encodeURIComponent(firebaseConfig.projectId)+'/databases/(default)/documents/settings/institution');
 if(!res.ok)return null;
 const f=(await res.json()).fields;
 return {name:f?.nameBn?.stringValue,logo:f?.logo?.stringValue,color:f?.primaryColor?.stringValue};
}

export async function printBrand(id){return (await getDoc(doc(db,b+'printBrands/'+id))).data()}

import * as deployment from '../public/config.js';
import {getMessaging,getToken,deleteToken,isSupported} from 'firebase/messaging';
export async function enablePush(){
  if(!deployment.webPushKey)throw Error('Firebase Web Push-এর public VAPID key কনফিগার করুন।');
  if(!await isSupported())throw Error('এই ব্রাউজার Web Push সমর্থন করে না। HTTPS-এ সমর্থিত ব্রাউজার খুলুন।');
  if(await Notification.requestPermission()!=='granted')throw Error('ব্রাউজারের সেটিংসে নোটিফিকেশনের অনুমতি দিন।');
  const token=await getToken(getMessaging(app),{vapidKey:deployment.webPushKey,serviceWorkerRegistration:await navigator.serviceWorker.ready});
  await httpsCallable(fn,'registerPush')({token});localStorage.setItem('madrasa.push',token);
}

export function pushEnabled(){return !!localStorage.getItem('madrasa.push')}
export async function togglePush(){
  if(!pushEnabled())return enablePush();
  const token=localStorage.getItem('madrasa.push');
  await httpsCallable(fn,'registerPush')({token,remove:true});
  localStorage.removeItem('madrasa.push');await deleteToken(getMessaging(app));
}

export async function guardianData(studentId){return (await httpsCallable(fn,'guardianSummary')({studentId})).data}
export async function publicVerification(id){
  if(!configured||!/^[-\w]{16,80}$/.test(id))return null;
  const base=useEmulators?'http://127.0.0.1:8080':'https://firestore.googleapis.com';
  const res=await fetch(base+'/v1/projects/'+encodeURIComponent(firebaseConfig.projectId)+'/databases/(default)/documents/branches/main/verification/'+encodeURIComponent(id),{cache:'no-store'});
  if(res.status===404)return null;if(!res.ok)throw Error('যাচাই করা যায়নি। ইন্টারনেট সংযোগ পরীক্ষা করুন।');
  const f=(await res.json()).fields;
  return {serial:f.serial.stringValue,type:f.type.stringValue,issued:f.issued.stringValue,institution:f.institution.stringValue,active:f.active.booleanValue};
}
export async function uploadMedia(payload){return (await httpsCallable(fn,'uploadEventMedia')(payload)).data}
export async function readMedia(id){return (await httpsCallable(fn,'readEventMedia')({id})).data}
export async function checkout(invoiceId){
  return (await httpsCallable(fn,'startCheckout')({invoiceId})).data.url;
}
