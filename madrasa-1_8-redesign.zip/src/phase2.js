import {btn,table,titlebar,section,empty,esc,bn,cash,input,select,modal,notify,dateLabel} from './ui.js';
import {funds,accounts} from '../functions/domain.js';
import {defaultGrades,ranking} from '../functions/phase2.js';
import {today} from './local.js';
import {excel,saveBlob,poster,templates} from './exports.js';
import QRCode from 'qrcode';
export const phasePages={payroll:['কর্মী ও বেতন','banknote'],loans:['ঋণ ও পাওনা','landmark'],exams:['পরীক্ষা ও ফল','graduation-cap'],notices:['নোটিশ','file-text'],posters:['পোস্টার','layers'],reports:['রিপোর্ট','chart-column']};
export const phaseLabels={salaryPay:'বেতন পরিশোধ',loanOpen:'ঋণের মূলধন',loanPay:'কিস্তি',staffAdd:'কর্মী নিয়োগ',staffEdit:'কর্মী সম্পাদনা',staffDay:'কর্মীর হাজিরা',salarySlip:'বেতন স্লিপ',salaryAdjust:'বেতন সমন্বয়',examCreate:'পরীক্ষা',examMark:'ফলাফল',noticePublish:'নোটিশ'};
const allRoles={teacher:'ওস্তাদ',guardian:'অভিভাবক',accountant:'হিসাবরক্ষক',academic:'শিক্ষা বিভাগ',office:'অফিস স্টাফ',all:'সকল সদস্য'};
const act=(k,label,val='',style='link',ico)=>btn('p2-'+k,label,ico,style,val);
const primary=(k,label,ico)=>act(k,label,'','primary',ico);
const fields=(...xs)=>'<div class="grid2">'+xs.join('')+'</div>';
const text=(label,name,v='',extra='required')=>input(label,name,'text',v,extra);
const amount=(label,name,v='',min='.01')=>input(label,name,'number',v,'required min="'+min+'" step=".01"');
const date=(label,name,v=today())=>input(label,name,'date',v,'required');
const memo=(label,name,v='')=>'<label>'+label+'<textarea required name="'+name+'">'+esc(v)+'</textarea></label>';
const periodInput=(v)=>input('মাস','period','month',v,'required');
const accountForm=()=>fields(select('তহবিল','fund',funds),select('হিসাব','account',accounts));
const toMinor=v=>Math.round(Number(v)*100);
const tool=(...xs)=>'<div class="toolbar">'+xs.join('')+'</div>';
const balances=(label,val)=>'<div><dt>'+label+'</dt><dd>'+esc(val)+'</dd></div>';
const dhakaDate=iso=>new Date(Date.parse(iso)+21600000).toISOString().slice(0,10);
const tags=(str)=>'<span class="badge2">'+esc(str)+'</span>';
export function createPhase2(ctx){
 const {rows,can,send,passwordField,local,refresh}=ctx;
 const brand=()=>ctx.data().brand;
 const find=(c,id)=>rows(c).find(r=>r.id===id);
 const val=(c,id)=>{const r=find(c,id);if(!r)throw Error('রেকর্ডটি এখনো পাওয়া যায়নি।');return r};
 let period=today().slice(0,7),examId='',reportKind='ledger',start=today().slice(0,7)+'-01',end=today(),posterModel,posterCanvas;
 function allowed(page){
   if(page==='payroll')return can('salarySlip')||can('staffDay');
   if(page==='loans'||page==='reports')return can('salarySlip');
   if(page==='exams')return can('examMark');
   if(page==='posters')return can('examCreate')||can('admission');
   return true;
 }
 const actions=(kind,payload,f)=>send(kind,payload,{password:f?.password,pin:f?.pin});
 function guarded(title,form,fn){modal(title,form+passwordField(),fn)}
 function payroll(){
   const contracts=rows('payContracts'),slips=rows('payslips').filter(s=>s.period===period);
   let html=titlebar('কর্মী ও বেতন','মাসিক স্লিপ, অগ্রিম, পরিশোধ ও কর্মীর উপস্থিতি।',can('staffAdd')?primary('staff','কর্মী যোগ করুন','plus'):'');
   if(can('salarySlip'))html+=section('মাসিক বেতন স্লিপ',tool(input('বেতনের মাস','p2-period','month',period),act('slips','স্লিপ তৈরি করুন','','btn','refresh-cw'))+table(['নাম ও পদ','প্রাপ্য','পরিশোধ','বকেয়া','করণীয়'],slips.map(s=>[esc(s.name)+'<small>'+esc(s.designation)+'</small>',cash(s.netMinor),cash(s.paidMinor),cash(s.netMinor-s.paidMinor),tool(act('slip','স্লিপ',s.id),act('adjust','সমন্বয়',s.id),s.netMinor>s.paidMinor?act('salary','পরিশোধ',s.id):'')])));
   const staff=can('staffDay')?rows('staff'):contracts;
   html+=section('কর্মী তালিকা',table(['নাম','পদ','যোগদান','করণীয়'],staff.map(s=>[esc(s.name),esc(s.designation),dateLabel(s.joinedOn),tool(can('staffDay')?act('staffday','হাজিরা / ছুটি',s.id):'',can('staffEdit')?act('staffedit','প্রোফাইল',s.id):'')])));
   if(can('staffDay'))html+=section('হাজিরা ও ছুটির রেকর্ড',table(['তারিখ','কর্মী','অবস্থা','মন্তব্য'],[...rows('staffAttendance')].sort((a,b)=>b.date.localeCompare(a.date)).map(s=>[dateLabel(s.date),esc(s.name),esc(s.status),esc(s.note)])));
   return html;
 }
 function loans(){
   const list=rows('loans'),due=l=>l.status==='cancelled'?0:l.principalMinor-l.paidMinor;
   const total=side=>list.filter(l=>l.side===side).reduce((v,l)=>v+due(l),0);
   return titlebar('ঋণ ও পাওনা','মূলধন, কিস্তির মেয়াদ ও পরিশোধের খাতা।',primary('loan','নতুন ঋণ / পাওনা','plus'))+section('বর্তমান স্থিতি','<dl class="summary">'+balances('মাদ্রাসার দেনা',cash(total('borrow')))+balances('মাদ্রাসার পাওনা',cash(total('lend')))+'</dl>')+section('ঋণের তালিকা',table(['পক্ষ','ধরন','মূলধন','বাকি','পরবর্তী মেয়াদ','সূচি'],list.map(l=>{const next=l.installments.find(i=>i.paid<i.expected);return [esc(l.party),l.side==='borrow'?'দেনা':'পাওনা',cash(l.principalMinor),cash(due(l)),l.status==='cancelled'?'বাতিল':next?(next.due<today()?tags('মেয়াদ পেরিয়েছে')+' ':'')+dateLabel(next.due):'নিষ্পত্তি',act('schedule','কিস্তি দেখুন',l.id)]})));
 }
 function selectedExam(){return find('exams',examId)||rows('exams')[0]}
 const examStudents=e=>rows('roster').filter(s=>s.status==='active'&&s.classId===e.classId).sort((a,b)=>a.roll-b.roll);
 const results=e=>ranking(rows('results').filter(r=>r.examId===e.id));
 function exams(){
   const e=selectedExam();
   let html=titlebar('পরীক্ষা ও ফলাফল','সময়সূচি, প্রবেশপত্র, নম্বর ও মেধা তালিকা।',can('examCreate')?primary('exam','পরীক্ষা তৈরি','plus'):'');
   if(!e)return html+section('পরীক্ষার তালিকা',empty('এখনো পরীক্ষা তৈরি হয়নি।'));
   const list=results(e),byStudent=new Map(list.map(r=>[r.studentId,r]));
   html+=section('পরীক্ষার সময়সূচি',select('পরীক্ষা','p2-exam',rows('exams').map(r=>[r.id,r.name+' · '+r.classId]),e.id)+table(['বিষয়','তারিখ','সময়','পূর্ণমান','পাস'],e.subjects.map(s=>[esc(s.name),dateLabel(s.date),esc(s.time),bn(s.max),bn(s.pass)])));
   return html+section('প্রবেশপত্র ও নম্বর',table(['রোল / আসন','ছাত্র','মোট','গ্রেড','করণীয়'],examStudents(e).map(s=>{const r=byStudent.get(s.id);return [bn(s.roll),esc(s.displayName),r?bn(r.total):'—',esc(r?.grade||'—'),tool(act('admitcard','প্রবেশপত্র',s.id),act('marks','নম্বর',s.id),r?act('marksheet','মার্কশিট',s.id):'')]})),act('bulkcards','সব প্রবেশপত্র','','btn','printer'))+section('মেধা তালিকা',table(['মেধাক্রম','নাম','রোল','মোট','গ্রেড','মার্কশিট'],list.map(r=>[bn(r.rank),esc(r.name),bn(r.roll),bn(r.total),esc(r.grade),act('marksheet','খুলুন',r.studentId)])),act('rankprint','ফলশিট','','btn','printer'));
 }
 function notices(){
   const list=rows('notices').slice().sort((a,b)=>b.publishedAt.localeCompare(a.publishedAt));
   return titlebar('নোটিশ বোর্ড','প্রতিষ্ঠান থেকে প্রকাশিত বিজ্ঞপ্তি।',tool(!local()?act('push',ctx.pushEnabled()?'ফোনে নোটিশ বন্ধ':'ফোনে নোটিশ চালু','','btn','cloud'):'',can('noticePublish')?primary('notice','নোটিশ প্রকাশ','plus'):''))+section('প্রকাশিত নোটিশ',list.length?list.map(n=>'<article class="notice-card"><small>'+dateLabel(dhakaDate(n.publishedAt))+' · '+esc(allRoles[n.audience])+'</small><h2>'+esc(n.title)+'</h2><p>'+esc(n.body)+'</p></article>').join(''):empty('এখনো কোনো নোটিশ প্রকাশিত হয়নি।'));
 }
 function posters(){
   const m=posterModel||{template:'মাহফিল',size:'square',title:templates['মাহফিল'][0],body:templates['মাহফিল'][1],when:''};
   return titlebar('পোস্টার তৈরি','প্রতিষ্ঠানের পরিচিতি ও স্থানীয় ফন্ট দিয়ে মুদ্রণযোগ্য পোস্টার।')+section('পোস্টারের বিষয়বস্তু','<form id="p2-poster">'+fields(select('টেমপ্লেট','template',Object.keys(templates),m.template),select('সাইজ','size',[['square','ফেসবুক · বর্গাকার'],['a4','A4'],['story','স্টোরি']],m.size))+text('শিরোনাম','title',m.title,'required maxlength="140"')+memo('বিবরণ','body',m.body)+text('সময় ও স্থান','when',m.when,'maxlength="160"')+act('preview','পোস্টার দেখুন','','primary','file-text')+'</form>');
 }
 const reportTypes={events:'অনুষ্ঠানের হিসাব',staffDays:'কর্মীর হাজিরা ও ছুটি',ledger:'আর্থিক লেনদেন',donations:'দান',salary:'বেতনের স্লিপ',loans:'ঋণ ও পাওনা',students:'ছাত্র ভর্তি',attendance:'ছাত্র হাজিরা',results:'পরীক্ষার ফল',annual:'বার্ষিক সারাংশ'};
 function report(){
   let headers,lines;const between=d=>d>=start&&d<=end;
   const ledger=rows('ledger').filter(r=>between(r.date)).sort((a,b)=>a.date.localeCompare(b.date));
   if(reportKind==='events'){headers=['তারিখ','অনুষ্ঠান','বাজেট টাকা','মোট দান টাকা','মোট ব্যয় টাকা'];lines=rows('events').filter(e=>between(e.date)).map(e=>[e.date,e.title,e.budgetMinor/100,e.incomeMinor/100,e.expenseMinor/100]);}
   else if(reportKind==='ledger'||reportKind==='donations'){
     headers=['তারিখ','রসিদ','বিবরণ','তহবিল','হিসাব','নিট টাকা'];
     lines=ledger.filter(r=>reportKind==='ledger'||(r.category||r.originalKind||r.kind)==='donation').map(r=>[r.date,r.serial,[r.party,r.note].filter(Boolean).join(' · '),r.fund,r.account,r.direction*r.amountMinor/100]);
   }else if(reportKind==='staffDays'){
     headers=['তারিখ','কর্মী','অবস্থা','মন্তব্য'];lines=rows('staffAttendance').filter(s=>between(s.date)).map(s=>[s.date,s.name,s.status,s.note]);
   }else if(reportKind==='salary'){
     headers=['মাস','কর্মী','প্রাপ্য টাকা','পরিশোধ টাকা','বর্তমান বাকি'];
     lines=rows('payslips').filter(s=>s.period>=start.slice(0,7)&&s.period<=end.slice(0,7)).map(s=>[s.period,s.name,s.netMinor/100,s.paidMinor/100,(s.netMinor-s.paidMinor)/100]);
   }else if(reportKind==='loans'){
     headers=['শুরুর তারিখ','পক্ষ','ধরন','মূলধন টাকা','বর্তমান বাকি'];lines=rows('loans').filter(s=>between(s.openedOn)&&s.status!=='cancelled').map(s=>[s.openedOn,s.party,s.side==='borrow'?'দেনা':'পাওনা',s.principalMinor/100,(s.principalMinor-s.paidMinor)/100]);
   }else if(reportKind==='students'){
     headers=['ভর্তি','নাম','রোল','জামাত'];lines=rows('roster').filter(s=>between(s.joinedOn)).map(s=>[s.joinedOn,s.displayName,s.roll,s.classId]);
   }else if(reportKind==='attendance'){
     headers=['তারিখ','ছাত্র','জামাত','অবস্থা'];lines=rows('attendance').filter(s=>between(s.date)).map(s=>[s.date,find('roster',s.studentId)?.displayName||'—',s.classId,({present:'উপস্থিত',absent:'অনুপস্থিত',late:'দেরি',leave:'ছুটি'})[s.status]]);
   }else if(reportKind==='results'){
     headers=['পরীক্ষা','ছাত্র','জামাত','মোট','গ্রেড'];lines=rows('results').filter(s=>between(dhakaDate(s.updatedAt))).map(s=>[find('exams',s.examId)?.name||'',s.name,s.classId,s.total,s.grade]);
   }else{
     headers=['সূচক','মান','একক'];
     const amountFor=types=>ledger.filter(r=>types.includes(r.category||r.originalKind||r.kind)).reduce((a,r)=>a+r.amountMinor*r.direction,0)/100;
     lines=[['নতুন ভর্তি',rows('roster').filter(r=>between(r.joinedOn)).length,'জন'],['ফি আদায়',amountFor(['fee']),'টাকা'],['দান',amountFor(['donation']),'টাকা'],['অন্যান্য আয়',amountFor(['income']),'টাকা'],['ব্যয় ও বেতন',-amountFor(['expense','salaryPay']),'টাকা'],['ঋণ সংক্রান্ত নিট নগদ',amountFor(['loanOpen','loanPay']),'টাকা']];
   }
   return {headers,lines,title:reportTypes[reportKind]};
 }
 const displayRows=rs=>rs.map(r=>r.map(v=>typeof v==='number'?bn(v):esc(v)));
 function reports(){
   const r=report();const choices=Object.entries(reportTypes).filter(([k])=>(!['attendance','results'].includes(k)||can('examMark'))&&(k!=='staffDays'||can('staffDay')));
   return titlebar('রিপোর্ট ও এক্সপোর্ট','সময়কাল নির্বাচন করে হিসাব দেখুন অথবা ফাইল সংরক্ষণ করুন।')+section('রিপোর্টের সীমা',tool(select('বিষয়','p2-report',choices,reportKind),date('শুরু','p2-start',start),date('শেষ','p2-end',end)))+section(r.title,table(r.headers,displayRows(r.lines)),tool(act('xlsx','Excel','','btn','download'),act('reportprint','PDF / প্রিন্ট','','btn','printer'),act('summary','সারাংশ','','btn','file-text')));
 }
 function page(k){return ({payroll,loans,exams,notices,posters,reports})[k]()}
 function change(e){
   const t=e.target;
   if(t.closest('#p2-poster')&&t.name==='template'){const [a,b]=templates[t.value];t.form.elements.namedItem('title').value=a;t.form.elements.body.value=b;posterModel=Object.fromEntries(new FormData(t.form));return}
   if(t.closest('#p2-poster'))posterModel=Object.fromEntries(new FormData(t.form));
   if(!t.name?.startsWith('p2-'))return;
   if(t.name==='p2-period'&&t.value)period=t.value;
   if(t.name==='p2-exam')examId=t.value;
   if(t.name==='p2-report'){reportKind=t.value;if(reportKind==='annual'){start=today().slice(0,4)+'-01-01';end=today()}}
   if(t.name==='p2-start'&&t.value&&t.value<=end)start=t.value;
   if(t.name==='p2-end'&&t.value&&t.value>=start)end=t.value;
   refresh();
 }
 function printHead(title,sub){
   const b=brand();
   return '<div class="paperhead">'+(b.logo?'<img src="'+esc(b.logo)+'" alt="">':'')+'<div><strong>'+esc(b.nameBn)+'</strong><small>'+esc([b.address,b.publicPhone].filter(Boolean).join(' · '))+'</small></div></div><h2>'+esc(title)+'</h2><p>'+esc(sub)+'</p>';
 }
 const printButton=()=>btn('print','প্রিন্ট / PDF','printer','primary');
 function paper(title,sub,body){modal(title,'<article class="paper2">'+printHead(title,sub)+body+'</article><div class="actions">'+printButton()+'</div>')}
 async function examPaper(e,s,kind){
   const r=results(e).find(v=>v.studentId===s.id),marks=kind==='marksheet';
   if(marks&&!r)throw Error('নম্বর সংরক্ষণ করার পরে মার্কশিট তৈরি করুন।');
   const serial=(marks?'M':'A')+'-'+e.id+'-'+s.id;
   const url=new URL(location.href);url.hash=new URLSearchParams({exam:e.id,student:s.id,document:kind}).toString();
   const qr=await QRCode.toDataURL(url.href,{width:110,margin:1});
   const body=marks?table(['বিষয়','পূর্ণমান','প্রাপ্ত নম্বর'],e.subjects.map((sub,i)=>[esc(sub.name),bn(sub.max),r.scores[i]===null?'অনুপস্থিত':bn(r.scores[i])]))+'<strong>মোট '+bn(r.total)+' / '+bn(r.max)+' · '+esc(r.grade)+' · মেধাক্রম '+bn(r.rank)+'</strong>':table(['বিষয়','তারিখ','সময়'],e.subjects.map(sub=>[esc(sub.name),dateLabel(sub.date),esc(sub.time)]));
   return '<article class="paper2">'+printHead(marks?'মার্কশিট':'প্রবেশপত্র',[e.name,e.board,e.academicYear].filter(Boolean).join(' · '))+'<dl class="summary">'+balances('ছাত্র',r?.name||s.displayName)+balances('জামাত',e.classId)+balances('রোল / আসন',bn(r?.roll||s.roll))+balances('কক্ষ',e.room)+'</dl>'+body+'<footer><img width="80" height="80" src="'+qr+'" alt="যাচাইয়ের কিউআর"><small>'+esc(serial)+'</small></footer></article>';
 }
 function documentRoute(){
   const slip=new URLSearchParams(location.hash.slice(1)).get('salary');
   if(slip&&can('salarySlip')&&find('payslips',slip)){
     history.replaceState(history.state,'',location.pathname+location.search);
     action('slip',slip).catch(()=>notify('বেতন স্লিপ খোলা যায়নি।'));return;
   }
   const hash=new URLSearchParams(location.hash.slice(1)),eid=hash.get('exam');
   if(!eid||!can('examMark'))return;
   const e=find('exams',eid),sid=hash.get('student'),kind=hash.get('document');
   const historical=rows('results').find(r=>r.examId===eid&&r.studentId===sid);
   const s=kind==='marksheet'&&historical?{id:sid,displayName:historical.name,roll:historical.roll,classId:historical.classId}:find('roster',sid);
   if(!e||!s||e.classId!==s.classId||!['admitcard','marksheet'].includes(kind))return;
   if(kind==='marksheet'&&!rows('results').some(r=>r.studentId===s.id&&r.examId===e.id))return;
   history.replaceState(history.state,'',location.pathname+location.search);
   examPaper(e,s,kind).then(html=>modal('নথি যাচাই',html+printButton())).catch(()=>notify('নথি খোলা যায়নি।'));
 }
 async function action(k,id){
   if(k==='staff')return guarded('কর্মী যোগ করুন',text('কর্মীর নাম','name')+fields(text('পদ','designation'),text('ফোন','phone','',''))+fields(amount('মূল বেতন (টাকা)','base'),date('যোগদানের তারিখ','joinedOn')),f=>actions('staffAdd',{name:f.name,designation:f.designation,phone:f.phone,baseMinor:toMinor(f.base),joinedOn:f.joinedOn},f));
   if(k==='staffedit'){
     const s=val('staff',id),c=val('payContracts',id);
     return guarded('কর্মীর প্রোফাইল',text('নাম','name',s.name)+fields(text('পদ','designation',s.designation),text('ফোন','phone',s.phone,''))+fields(amount('মূল বেতন (টাকা)','base',c.baseMinor/100),periodInput(period))+select('চাকরির অবস্থা','status',[['active','সক্রিয়'],['inactive','নিষ্ক্রিয়']],s.status)+'<p>নতুন হারে নির্বাচিত মাস থেকে নতুন স্লিপ তৈরি হবে। ইতিমধ্যে তৈরি স্লিপ সমন্বয়ের জন্য বোনাস ও কর্তন ব্যবহার করুন।</p>',f=>actions('staffEdit',{staffId:id,name:f.name,designation:f.designation,phone:f.phone,status:f.status,effective:f.period,baseMinor:toMinor(f.base),revision:c.updatedAt},f));
   }
   if(k==='staffday')return modal('কর্মীর হাজিরা ও ছুটি',date('তারিখ','date')+select('অবস্থা','status',['উপস্থিত','অনুপস্থিত','ছুটি','দেরি'])+text('মন্তব্য','note','',''),f=>send('staffDay',{...f,staffId:id}));
   if(k==='slips')return modal('মাসিক স্লিপ তৈরি',periodInput(period),async f=>{
     for(const s of rows('payContracts').filter(s=>s.active&&s.joinedOn.slice(0,7)<=f.period))await send('salarySlip',{period:f.period,staffId:s.id});
     period=f.period;refresh();
   },'স্লিপ তৈরি করুন');
   if(['salary','adjust','slip'].includes(k)){
     const s=val('payslips',id);
     if(k==='slip'){
       const url=new URL(location.href);url.hash='salary='+encodeURIComponent(id);
       const qr=await QRCode.toDataURL(url.href,{width:110,margin:1});
       return paper('বেতন স্লিপ',s.name+' · '+s.designation+' · '+s.period,'<dl class="summary">'+[['মূল বেতন',s.baseMinor],['বোনাস',s.bonusMinor],['কর্তন',s.deductionMinor],['প্রাপ্য',s.netMinor],['পরিশোধিত (অগ্রিমসহ)',s.paidMinor],['এর মধ্যে অগ্রিম',s.advanceMinor],['বাকি',s.netMinor-s.paidMinor]].map(([t,n])=>balances(t,cash(n))).join('')+'</dl><footer><img width="80" height="80" src="'+qr+'" alt="স্লিপ যাচাইয়ের কিউআর"><small>S-'+esc(id)+'</small></footer>');
     }
     if(k==='adjust')return guarded('বেতন সমন্বয়',fields(amount('বোনাস','bonus',s.bonusMinor/100,'0'),amount('কর্তন','deduction',s.deductionMinor/100,'0'))+text('কারণ','note'),f=>actions('salaryAdjust',{slipId:id,revision:s.updatedAt,bonusMinor:toMinor(f.bonus),deductionMinor:toMinor(f.deduction),note:f.note},f));
     return guarded('বেতন পরিশোধ',amount('পরিমাণ (টাকা)','amount',(s.netMinor-s.paidMinor)/100)+date('পরিশোধের তারিখ','date')+select('ধরন','kind',['বেতন','অগ্রিম'])+accountForm(),f=>actions('salaryPay',{slipId:id,amountMinor:toMinor(f.amount),advance:f.kind==='অগ্রিম',fund:f.fund,account:f.account,date:f.date},f));
   }
   if(k==='loan')return guarded('নতুন ঋণ / পাওনা',select('ধরন','side',[['borrow','ঋণ গ্রহণ (দেনা)'],['lend','ঋণ প্রদান (পাওনা)']])+text('পক্ষের নাম','party')+fields(amount('মূলধন (টাকা)','amount'),input('মাসিক কিস্তির সংখ্যা','count','number','1','required min="1" max="60"'))+fields(date('লেনদেনের তারিখ','date'),date('প্রথম কিস্তির মেয়াদ','due'))+accountForm()+text('বিবরণ','note','',''),f=>actions('loanOpen',{side:f.side,party:f.party,amountMinor:toMinor(f.amount),count:Number(f.count),date:f.date,due:f.due,fund:f.fund,account:f.account,note:f.note},f));
   if(k==='schedule'){
     const l=val('loans',id);
     return modal('কিস্তির সূচি · '+l.party,table(['মেয়াদ','দাবি','জমা','করণীয়'],l.installments.map((n,i)=>[dateLabel(n.due),cash(n.expected),cash(n.paid),l.status==='active'&&n.expected>n.paid?act('installment','পরিশোধ',id+'|'+i):l.status==='cancelled'?'বাতিল':'নিষ্পত্তি'])));
   }
   if(k==='installment'){
     const [loanId,i]=id.split('|'),item=val('loans',loanId).installments[Number(i)];
     return guarded('কিস্তি পরিশোধ',amount('পরিমাণ (টাকা)','amount',(item.expected-item.paid)/100)+date('তারিখ','date')+accountForm(),f=>actions('loanPay',{loanId,installment:Number(i),amountMinor:toMinor(f.amount),date:f.date,fund:f.fund,account:f.account},f));
   }
   if(k==='exam'){
     const subjectRow=(name='')=>'<fieldset class="exam-subject"><legend>বিষয়</legend>'+text('বিষয়ের নাম','subject',name)+fields(input('পূর্ণমান','max','number',100,'required min="1" max="1000"'),input('পাস নম্বর','pass','number',33,'required min="0" max="1000"'))+fields(date('পরীক্ষার তারিখ','date'),input('শুরুর সময়','time','time','09:00','required'))+act('removeSubject','বিষয় বাদ দিন')+'</fieldset>';
     const form=text('পরীক্ষার নাম','name')+fields(select('জামাত','classId',brand().classes),text('কক্ষ','room'))+text('বোর্ড (ঐচ্ছিক)','board','','')+'<div id="exam-subjects">'+subjectRow('কুরআন')+'</div>'+act('addSubject','আরও বিষয় যোগ করুন','','btn','plus')+'<details><summary>গ্রেডের সীমা সম্পাদনা</summary>'+memo('প্রতি লাইনে ন্যূনতম শতাংশ | গ্রেড','grades',defaultGrades.map(g=>g.min+' | '+g.label).join('\n'))+'</details>';
     modal('পরীক্ষা তৈরি',form,(f,el)=>{
       const subjects=Array.from(el.querySelectorAll('.exam-subject'),row=>{
         const get=k=>row.querySelector('[name="'+k+'"]').value;
         return {name:get('subject'),max:Number(get('max')),pass:Number(get('pass')),date:get('date'),time:get('time')};
       });
       const grades=f.grades.trim().split('\n').filter(line=>line.trim()).map(line=>{const [n,label]=line.split('|').map(x=>x.trim());return {min:Number(n),label}});
       return send('examCreate',{name:f.name,classId:f.classId,room:f.room,board:f.board,subjects,grades});
     });
     const box=document.querySelector('#exam-subjects');
     document.querySelector('[data-act="p2-addSubject"]').onclick=e=>{e.stopPropagation();if(box.children.length<30)box.insertAdjacentHTML('beforeend',subjectRow())};
     box.onclick=e=>{if(e.target.closest('[data-act="p2-removeSubject"]')){e.stopPropagation();if(box.children.length>1)e.target.closest('fieldset').remove()}};
     return;
   }
   if(['marks','admitcard','marksheet','bulkcards','rankprint'].includes(k)){
     const e=selectedExam(),list=results(e);
     if(k==='rankprint')return paper('ফলশিট',e.name+' · '+e.classId,table(['মেধাক্রম','রোল','নাম','মোট','গ্রেড'],list.map(r=>[bn(r.rank),bn(r.roll),esc(r.name),bn(r.total),esc(r.grade)])));
     if(k==='bulkcards'){
       const docs=await Promise.all(examStudents(e).map(s=>examPaper(e,s,'admitcard')));
       return modal('জামাতের প্রবেশপত্র',docs.join('')+printButton());
     }
     const r=list.find(r=>r.studentId===id);
     const s=(k==='marksheet'&&r)?{id:r.studentId,roll:r.roll,displayName:r.name}:val('roster',id);
     if(k==='marks')return modal('নম্বর · '+s.displayName,'<p>অনুপস্থিত হলে সংশ্লিষ্ট ঘরটি খালি রাখুন।</p>'+e.subjects.map((sub,i)=>input(esc(sub.name)+' / '+bn(sub.max),'mark'+i,'number',r?.scores[i]??'','min="0" step=".01" max="'+sub.max+'"')).join(''),f=>send('examMark',{examId:e.id,studentId:id,revision:r?.revision||0,scores:e.subjects.map((_,i)=>f['mark'+i]===''?null:Number(f['mark'+i]))}));
     return modal(k==='admitcard'?'প্রবেশপত্র':'মার্কশিট',(await examPaper(e,s,k))+printButton());
   }
   if(k==='notice')return modal('নোটিশ প্রকাশ',text('শিরোনাম','title')+memo('বিজ্ঞপ্তি','body')+select('প্রাপক','audience',Object.entries(allRoles))+(local()?'':'<label class="inline"><input type="checkbox" name="push">নিবন্ধিত ডিভাইসে পুশ পাঠান</label>'),f=>send('noticePublish',{title:f.title,body:f.body,audience:f.audience,push:!!f.push}),'প্রকাশ করুন');
   if(k==='push'){const enabled=ctx.pushEnabled();await ctx.push();refresh();notify(enabled?'এই ব্রাউজারে পুশ বন্ধ হয়েছে।':'এই ব্রাউজারে পুশ নোটিফিকেশন চালু হয়েছে।');return}
   if(k==='summary'){
     const r=report(),summary=[brand().nameBn,r.title+' · '+start+' — '+end,'রেকর্ড '+bn(r.lines.length)+'টি'];
     if(['ledger','donations'].includes(reportKind))summary.push('নিট পরিমাণ '+cash(Math.round(r.lines.reduce((v,line)=>v+line.at(-1),0)*100)));
     if(reportKind==='annual')summary.push(...r.lines.map(([k,v,unit])=>k+' · '+bn(v)+' '+unit));
     const msg=summary.join('\n');
     if(navigator.share){await navigator.share({text:msg});return}
     modal('রিপোর্টের সারাংশ',memo('কপি করে শেয়ার করুন','summary',msg));return;
   }
   if(k==='xlsx'||k==='reportprint'){
     const r=report(),sub=start+' — '+end;
     if(k==='reportprint')return paper(r.title,sub,table(r.headers,displayRows(r.lines)));
     saveBlob(excel(brand().nameBn+' · '+r.title+' · '+sub,r.headers,r.lines),'report-'+reportKind+'-'+end+'.xlsx');return;
   }
   if(k==='preview'){
     const form=document.querySelector('#p2-poster');if(!form.reportValidity())return;
     posterModel=Object.fromEntries(new FormData(form));posterCanvas=await poster(brand(),posterModel);
     const paperSize={a4:'210mm 297mm',square:'200mm 200mm',story:'108mm 192mm'}[posterModel.size];
     modal('পোস্টারের প্রিভিউ','<style media="print">@page{size:'+paperSize+';margin:0}dialog:has(.posterpreview){padding:0!important;border:0!important}.posterpreview{width:100%!important;max-height:none!important}</style><img class="posterpreview" alt="তৈরি করা পোস্টার" src="'+posterCanvas.toDataURL()+'"><div class="actions">'+act('png','PNG','','primary','download')+printButton()+act('share','শেয়ার','','btn','arrow-up-right')+'</div>');return;
   }
   if(k==='png'||k==='share'){
     const blob=await new Promise(resolve=>posterCanvas.toBlob(resolve,'image/png'));
     if(k==='share'){
       const files=[new File([blob],'poster.png',{type:'image/png'})];
       if(navigator.canShare?.({files})){await navigator.share({files,title:posterModel.title});return}
       notify('এই ব্রাউজারে ফাইল শেয়ার নেই। ডাউনলোড করা PNG শেয়ার করুন।');
     }
     saveBlob(blob,'poster-'+today()+'.png');return;
   }
 }
 return {allowed,page,change,action,documentRoute,usePoster:m=>{posterModel=m}};
}
