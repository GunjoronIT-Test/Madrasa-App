import {execute} from '../functions/domain.js';
const ROOT='branches/main/';
export const trainingBranch=new URLSearchParams(location.search).get('campus')||'main';
if(!/^[a-z0-9-]{1,40}$/.test(trainingBranch))throw Error('শাখা কোড সঠিক নয়।');
export const trainingKey='madrasa.training.v1'+(trainingBranch==='main'?'':'.'+trainingBranch);
const actor={uid:'training',training:true,branchId:'main',active:true,role:'principal'};
export const trainingActor=actor;
function open(){
  return new Promise((resolve,reject)=>{
    const r=indexedDB.open(trainingKey,1);
    r.onupgradeneeded=()=>r.result.createObjectStore('records');
    r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error);
  });
}
async function transact(mode,run){
  const db=await open();
  try{return await new Promise((resolve,reject)=>{
    const tx=db.transaction('records',mode),s=tx.objectStore('records');
    let value;
    const read=s.get('data');
    read.onsuccess=()=>{try{value=run(read.result||{},s)}catch(e){tx.abort();reject(e)}};
    tx.oncomplete=()=>resolve(value);tx.onabort=()=>reject(tx.error||new Error('সংরক্ষণ ব্যর্থ হয়েছে।'));tx.onerror=()=>reject(tx.error);
  })}finally{db.close()}
}
export const localRead=()=>transact('readonly',x=>x);
export const localReplace=data=>transact('readwrite',(_,store)=>{store.put(data,'data')});
export async function localCommand(kind,payload,id=crypto.randomUUID()){
  return navigator.locks.request(trainingKey,async()=>{
    const data=await localRead();
    if(kind==='familyLink'&&payload.uid==='training-guardian')data['branches/main/members/training-guardian']={role:'guardian',active:true,branchId:'main'};
    const {writes,result}=await execute({get:path=>structuredClone(data[path])},actor,{kind,payload,id});
    for(const [path,row] of writes)data[path]=row;
    await localReplace(data);return result;
  });
}
export function split(data){
  const result={brand:data['settings/institution']};
  for(const [path,row] of Object.entries(data)){
    if(!path.startsWith(ROOT))continue;
    const [, ,col,id]=path.split('/');
    (result[col]||=[]).push({...row,id});
  }
  return result;
}
export function today(offset=0){
  return new Date(Date.now()+6*3600000+offset*86400000).toISOString().slice(0,10);
}
export async function seed(){
  return navigator.locks.request(trainingKey,async()=>{
  const data=await localRead();if(data['settings/institution'])return;
  async function add(kind,payload){
    const cmd={kind,payload,id:crypto.randomUUID()};
    const {writes,result}=await execute({get:path=>structuredClone(data[path])},actor,cmd);
    for(const [path,row] of writes)data[path]=row;
    return result;
  }
  await add('setup',{nameBn:'দারুল ইলম মাদ্রাসা',address:'ঢাকা, বাংলাদেশ',publicPhone:'',principalName:'প্রশিক্ষণ প্রশাসক',classes:['হিফজ','নাজেরা','কিতাব'],monthlyMinor:150000,admissionMinor:50000,academicYear:today().slice(0,4),startDate:today().slice(0,4)+'-01-01',primaryColor:'#185747',accentColor:'#ad8346'});
  for(const [i,name] of ['আবদুল্লাহ হাসান','সাদিক আহমেদ','তাহসিন মাহমুদ','মুহাম্মদ রায়হান','আনাস ইবনে সালেহ','ইউসুফ রহমান'].entries()){
    const id=await add('admission',{displayName:name,guardian:'নমুনা অভিভাবক',phone:'0170000000'+i,classId:['হিফজ','নাজেরা','কিতাব'][i%3],residentialStatus:'অনাবাসিক',date:today(-6)});
    await add('attendance',{studentId:id,date:today(),status:i===2?'absent':'present',revision:0});
    await add('invoice',{studentId:id,period:today().slice(0,7)});
    if(i<3)await add('fee',{invoiceId:'adm_'+id,amountMinor:50000,date:today(-i),fund:'সাধারণ',account:'নগদ'});
  }
  for(const [i,amount] of [5000,3500,8000,2500,4500,6000,3000].entries()){
    await add('donation',{amountMinor:amount*100,date:today(-i),fund:'সাধারণ',account:'নগদ',party:'নমুনা দাতা',note:'সাধারণ অনুদান'});
    await add('expense',{amountMinor:(i+1)*15000,date:today(-i),fund:'সাধারণ',account:'নগদ',note:'খাবার'});
  }
  await localReplace(data);
  });
}
