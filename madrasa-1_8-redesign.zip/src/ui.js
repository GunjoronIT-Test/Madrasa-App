import {enterStep,stepBack,finishTask} from './navigation.js';
export const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'})[c]);
export const icon=(name,size=20)=>`<svg class="icon" width="${size}" height="${size}" aria-hidden="true"><use href="./assets/icons/ui.svg#${name}"/></svg>`;
let locale='bn-BD',currency='৳';
export function numberStyle(brand){locale=brand.digits==='en'?'en-BD':'bn-BD';currency=brand.currency==='BDT'?'BDT':'৳'}
export const bn=n=>Number(n||0).toLocaleString(locale);
export const cash=(n,unit=currency)=>(unit==='BDT'?'BDT':'৳')+' '+bn((n||0)/100);
export const dateLabel=d=>new Intl.DateTimeFormat('bn-BD',{day:'numeric',month:'short',year:'numeric',timeZone:'Asia/Dhaka'}).format(new Date(d+'T06:00:00Z'));
export const input=(label,name,type='text',value='',extra='')=>`<label>${label}<input name="${name}" type="${type}" value="${esc(value)}" ${extra}></label>`;
export const select=(label,name,options,value)=>`<label>${label}<select name="${name}">${options.map(o=>{const [v,t]=Array.isArray(o)?o:[o,o];return `<option value="${esc(v)}" ${v===value?'selected':''}>${esc(t)}</option>`}).join('')}</select></label>`;
export const btn=(id,label,ico,style='btn',val='')=>`<button type="button" class="${style}" data-act="${id}" data-val="${esc(val)}">${ico?icon(ico,17):''}${label}</button>`;
export const section=(title,content,action='')=>`<section class="panel"><div class="sectionhead"><h2>${title}</h2>${action}</div>${content}</section>`;
export const empty=message=>`<p class="empty">${icon('spark',34)}<span>${message}</span></p>`;
export function table(headers,rows){
  return rows.length?`<div class="scroll"><table><thead><tr>${headers.map(h=>'<th>'+h+'</th>').join('')}</tr></thead><tbody>${rows.map(r=>'<tr>'+r.map((x,i)=>'<td data-label="'+esc(headers[i])+'">'+x+'</td>').join('')+'</tr>').join('')}</tbody></table></div>`:empty('কোনো রেকর্ড পাওয়া যায়নি।');
}
let sectionIcon='';
export function setSectionIcon(name){sectionIcon=name}
export const titlebar=(title,sub,action='')=>`<div class="titlebar"><div class="module-heading">${sectionIcon?'<i class="module-mark">'+icon(sectionIcon,30)+'</i>':''}<div><h1>${title}</h1><p>${sub}</p></div></div>${action}</div>`;
export function notify(message){
  const t=document.querySelector('#toast');t.textContent=message;t.classList.add('show');clearTimeout(notify.timer);notify.timer=setTimeout(()=>t.classList.remove('show'),4800);
}
const taskView=document.querySelector('#dialog');
export function suspendTask(){
 const focus=document.activeElement,scroll=window.scrollY;
 const nodes=taskView.open?[...taskView.childNodes]:null;
 if(nodes){taskView.replaceChildren();taskView.close()}
 return ()=>{
   if(taskView.open)taskView.close();
   taskView.replaceChildren();
   if(nodes){taskView.append(...nodes);taskView.show()}
   if(focus?.isConnected)focus.focus({preventScroll:true});
   window.scrollTo(0,scroll);
 };
}
document.addEventListener('keydown',e=>{if(e.key==='Escape'&&taskView.open){e.preventDefault();stepBack()}});
export function modal(title,content,handler,submit='সংরক্ষণ করুন'){
  const d=taskView,parent=d.open?d.querySelector('#task-title')?.textContent:document.querySelector('#content h1,#intro h1,.setup h1')?.textContent;
  enterStep(suspendTask(),true);
  d.innerHTML=`<div class="sectionhead task-head"><div class="task-trail">${btn('close','ফিরে যান','chevron-left','task-back')}<span>${esc(parent||'কর্মক্ষেত্র')}</span></div><div class="task-heading"><i>${icon(sectionIcon||'layers',26)}</i><h2 id="task-title" tabindex="-1">${esc(title)}</h2></div></div><form>${content}<p class="error" role="alert"></p>${handler?`<div class="actions"><button class="primary">${submit}</button></div>`:''}</form>`;
  d.show();
  d.setAttribute('aria-labelledby','task-title');
  window.scrollTo(0,0);
  d.querySelector('#task-title').focus({preventScroll:true});
  d.querySelector('form').onsubmit=async e=>{
    e.preventDefault();if(!handler)return;
    const button=e.submitter;button.disabled=true;
    try{await handler(Object.fromEntries(new FormData(e.target)),e.target);if(d.open && e.target.isConnected)finishTask()}
    catch(err){d.querySelector('.error').textContent=errorText(err)}
    finally{button.disabled=false}
  };
}
export function errorText(e){
  if(String(e.code||'').startsWith('auth/'))return 'লগইন যাচাই হয়নি। ইমেইল, পাসওয়ার্ড ও সংযোগ পরীক্ষা করুন।';
  return /[\u0980-\u09ff]/.test(e.message)?e.message:'কাজটি সম্পন্ন হয়নি। সংযোগ ও প্রবেশাধিকার পরীক্ষা করুন।';
}
export const fileData=file=>new Promise((resolve,reject)=>{const r=new FileReader();r.onload=()=>resolve(r.result);r.onerror=reject;r.readAsDataURL(file)});
