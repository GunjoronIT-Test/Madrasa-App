async function checksum(text){
  const bytes=new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(text)));
  return Array.from(bytes,n=>n.toString(16).padStart(2,'0')).join('');
}
export async function pack(records,mode,campus='main'){
  const data=JSON.stringify(records);
  return {format:'madrasa-branch-backup',version:1,mode,campus,branchId:'main',exportedAt:new Date().toISOString(),count:Object.keys(records).length,checksum:await checksum(data),records};
}
export async function unpack(file,campus='main'){
  if(!file||file.size>80*1024*1024)throw new Error('সর্বোচ্চ ৮০ মেগাবাইটের JSON দিন।');
  const v=JSON.parse(await file.text());
  if((v.campus||'main')!==campus||v.format!=='madrasa-branch-backup'||v.version!==1||v.mode!=='training'||v.branchId!=='main'||!v.records?.['settings/institution']||
     Object.keys(v.records).length!==v.count||await checksum(JSON.stringify(v.records))!==v.checksum)throw new Error('ব্যাকআপের সংস্করণ, উৎস বা অখণ্ডতা মেলেনি।');
  for(const [path,row] of Object.entries(v.records)){
    if((path!=='settings/institution'&&!/^branches\/main\/[A-Za-z]+\/[^/]+$/.test(path))||row?.branchId!=='main')throw new Error('ব্যাকআপের শাখা বা পথ সঠিক নয়।');
  }
  return v.records;
}
export function download(name,obj){
 const url=URL.createObjectURL(new Blob([JSON.stringify(obj,null,2)],{type:'application/json'}));
 const a=document.createElement('a');a.href=url;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(url),3000);
}
