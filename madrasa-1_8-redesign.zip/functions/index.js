import {randomBytes,scryptSync,timingSafeEqual} from 'node:crypto';
import {initializeApp} from 'firebase-admin/app';
import {getFirestore} from 'firebase-admin/firestore';
import {onDocumentCreated} from 'firebase-functions/v2/firestore';
import {onCall,HttpsError} from 'firebase-functions/v2/https';
import {execute} from './domain.js';

initializeApp();
const db=getFirestore();
import {protectedPhase2} from './phase2.js';
import {p3Protected} from './phase3.js';
const restricted=[...p3Protected,...protectedPhase2,'reversal','archive','waiver','brand','approveExpense','denyExpense'];
export const setPin=onCall(async req=>{
  const {pin}=req.data||{};
  if(!req.auth||Date.now()/1000-req.auth.token.auth_time>180)throw new HttpsError('unauthenticated','পরিচয় আবার নিশ্চিত করুন।');
  if(typeof pin!=='string'||!/^\d{6}$/.test(pin))throw new HttpsError('invalid-argument','ছয় অঙ্কের পিন দিন।');
  const uid=req.auth.uid,ref=db.doc('securityPins/'+uid);
  const m=(await db.doc('branches/main/members/'+uid).get()).data();
  if(!m?.active||m.branchId!=='main')throw new HttpsError('permission-denied','সদস্যপদ প্রয়োজন।');
  const salt=randomBytes(16).toString('hex');
  await db.runTransaction(async tx=>{
    if((await tx.get(ref)).exists)throw new HttpsError('already-exists','পিন আগে নির্ধারণ করা হয়েছে।');
    tx.create(ref,{salt,hash:scryptSync(pin,salt,32).toString('hex'),attempts:0,lockedUntil:0});
  });
  return {ok:true};
});
export const confirmAction=onCall(async req=>{
  const {id,kind}=req.data||{};
  if(!req.auth || Date.now()/1000-req.auth.token.auth_time>180)throw new HttpsError('unauthenticated','আবার লগইন করুন।');
  if(!restricted.includes(kind)||!/^[-\w]{16,80}$/.test(id))throw new HttpsError('invalid-argument','অনুরোধ সঠিক নয়।');
  const pin=req.data.pin;if(typeof pin!=='string'||!/^\d{6}$/.test(pin))throw new HttpsError('invalid-argument','ছয় অঙ্কের পিন দিন।');
  const ref=db.doc('securityPins/'+req.auth.uid);
  const valid=await db.runTransaction(async tx=>{
    const record=(await tx.get(ref)).data();
    if(!record)throw new HttpsError('failed-precondition','সেটিংসে প্রথমে পিন নির্ধারণ করুন।');
    if(record.lockedUntil>Date.now())throw new HttpsError('resource-exhausted','১৫ মিনিট পরে আবার চেষ্টা করুন।');
    const match=timingSafeEqual(Buffer.from(record.hash,'hex'),scryptSync(pin,record.salt,32));
    const attempts=match?0:record.attempts+1;
    tx.update(ref,{attempts:attempts>=5?0:attempts,lockedUntil:attempts>=5?Date.now()+900000:0});
    if(match)tx.create(db.doc('branches/main/confirmations/'+id),{uid:req.auth.uid,kind,expiresAt:Date.now()+180000});
    return match;
  });
  if(!valid)throw new HttpsError('permission-denied','পিন মেলেনি।');
  return {ok:true};
});
export const processRequest=onDocumentCreated({document:'branches/{branch}/requests/{id}',retry:true},async event=>{
  const {branch,id}=event.params;
  const ref=event.data.ref;
  await db.runTransaction(async tx=>{
    const snap=await tx.get(ref),r=snap.data();
    if(!r || r.status!=='queued')return;
    const read=async path=>(await tx.get(db.doc(path))).data();
    const member=await read('branches/'+branch+'/members/'+r.actorUid);
    try{
      if(branch!=='main'||!member)throw new Error('সক্রিয় সদস্যপদ প্রয়োজন।');
      if(restricted.includes(r.kind)){
        const confirm=await read('branches/main/confirmations/'+id);
        if(confirm?.uid!==r.actorUid||confirm.kind!==r.kind||confirm.expiresAt<Date.now())throw new Error('পরিচয় আবার নিশ্চিত করুন।');
      }
      const {writes,result}=await execute({get:read},{...member,uid:r.actorUid},{id,kind:r.kind,payload:r.payload});
      for(const [path,data] of writes)tx.set(db.doc(path),data);
      const payload={...r.payload};delete payload.files;
      tx.update(ref,{payload,status:'accepted',result,completedAt:new Date().toISOString()});
    }catch(e){
      if(e.code!==undefined)throw e;
      tx.update(ref,{status:'rejected',message:e.message,completedAt:new Date().toISOString()});
    }
  });
});
// The callable exports only Phase 1 branch documents. Auth and Storage are backed up separately.
export const exportBranch=onCall({timeoutSeconds:120},async req=>{
  if(!req.auth)throw new HttpsError('unauthenticated','প্রবেশ করুন।');
  const root=db.doc('branches/main'),m=(await root.collection('members').doc(req.auth.uid).get()).data();
  if(!m?.active||m.branchId!=='main'||m.role!=='principal')throw new HttpsError('permission-denied','মুহতামিমের অনুমতি প্রয়োজন।');
  
  // A consistent snapshot across the module's collections.
  const cols=await root.listCollections();
  const records=await db.runTransaction(async tx=>{
    const records={};
    const brand=await tx.get(db.doc('settings/institution'));if(brand.exists)records[brand.ref.path]=brand.data();
    for(const col of cols){
      if(['confirmations','views'].includes(col.id))continue;
      for(const d of (await tx.get(col)).docs)records[d.ref.path]=d.data();
    }
    return records;
  },{readOnly:true});
  let estimated=Buffer.byteLength(JSON.stringify(records));
  for(const [path,f] of Object.entries(records)){
    if((path.startsWith('branches/main/studentFiles/')||path.startsWith('branches/main/media/'))&&f.storagePath&&!f.bytes){
      const file=getStorage().bucket().file(f.storagePath),[metadata]=await file.getMetadata();
      estimated+=4*Math.ceil(Number(metadata.size)/3)+16;
      if(estimated>8*1024*1024)throw new HttpsError('resource-exhausted','বড় ব্যাকআপের জন্য অ্যাডমিন এক্সপোর্ট ব্যবহার করুন।');
      f.bytes=(await file.download())[0].toString('base64');
    }
  }
  if(Buffer.byteLength(JSON.stringify(records))>8*1024*1024)throw new HttpsError('resource-exhausted','বড় ব্যাকআপের জন্য অ্যাডমিন এক্সপোর্ট ব্যবহার করুন।');
  return {records};
});

import {getStorage} from 'firebase-admin/storage';
import {onSchedule} from 'firebase-functions/v2/scheduler';

export const storeAttachment=onDocumentCreated({document:'branches/main/studentFiles/{fileId}',retry:true},async event=>{
  const ref=event.data.ref,s=(await ref.get()).data();if(!s?.bytes)return;
  await getStorage().bucket().file(s.storagePath).save(Buffer.from(s.bytes,'base64'),{resumable:false,metadata:{contentType:s.mime,cacheControl:'private, no-store'}});
  // Retain the source bytes through upload failures. A retried upload uses the same object path.
  await ref.update({bytes:null,uploaded:true});
});
export const readAttachment=onCall(async req=>{
  if(!req.auth)throw new HttpsError('unauthenticated','প্রবেশ করুন।');
  const id=req.data?.id;if(typeof id!=='string'||!/^[-\w]{1,100}$/.test(id))throw new HttpsError('invalid-argument','ফাইলের পরিচয় সঠিক নয়।');
  const m=(await db.doc('branches/main/members/'+req.auth.uid).get()).data();
  if(!m?.active||m.branchId!=='main'||!['principal','deputy','office'].includes(m.role))throw new HttpsError('permission-denied','অনুমতি নেই।');
  const file=(await db.doc('branches/main/studentFiles/'+id).get()).data();
  if(!file)throw new HttpsError('not-found','ফাইল পাওয়া যায়নি।');
  return {name:file.name,mime:file.mime,bytes:file.bytes||(await getStorage().bucket().file(file.storagePath).download())[0].toString('base64')};
});
export const monthlyFees=onSchedule({schedule:'5 0 1 * *',timeZone:'Asia/Dhaka',retryCount:3,timeoutSeconds:540},async event=>{
  const period=new Date(Date.parse(event.scheduleTime)+21600000).toISOString().slice(0,7);
  const brand=(await db.doc('settings/institution').get()).data();if(!brand?.monthlyMinor)return;
  const students=db.collection('branches/main/students').where('status','==','active');
  for await(const snap of students.stream()){
    if(snap.data().joinedOn.slice(0,7)>period)continue;
    await db.runTransaction(async tx=>{
      const store={get:async p=>(await tx.get(db.doc(p))).data()};
      const fresh=await store.get(snap.ref.path);if(fresh?.status!=='active')return;
      const request={id:'monthly_'+snap.id+'_'+period,kind:'invoice',payload:{studentId:snap.id,period}};
      const res=await execute(store,{role:'principal',branchId:'main',active:true,uid:'scheduler'},request);
      for(const [p,v] of res.writes)tx.set(db.doc(p),v);
    });
  }
});

import {createHash} from 'node:crypto';
import {getMessaging} from 'firebase-admin/messaging';

export const registerPush=onCall(async req=>{
  if(!req.auth)throw new HttpsError('unauthenticated','প্রবেশ করুন।');
  const token=req.data?.token;
  if(typeof token!=='string'||token.length<20||token.length>4096)throw new HttpsError('invalid-argument','ডিভাইস টোকেন সঠিক নয়।');
  const uid=req.auth.uid,id=createHash('sha256').update(token).digest('hex');
  const ref=db.doc('pushDevices/'+id);
  await db.runTransaction(async tx=>{
    if(req.data.remove===true){
      if((await tx.get(ref)).data()?.uid===uid)tx.delete(ref);
      return;
    }
    const member=(await tx.get(db.doc('branches/main/members/'+uid))).data();
    if(!member?.active||member.branchId!=='main')throw new HttpsError('permission-denied','সক্রিয় সদস্যপদ প্রয়োজন।');
    tx.set(ref,{uid,token,branchId:'main',updatedAt:new Date().toISOString()});
  });
  return {ok:true};
});
export const notifyMembers=onDocumentCreated({document:'branches/main/notices/{noticeId}',retry:true,timeoutSeconds:540},async event=>{
  const note=event.data.data();if(!note.push)return;
  const noticeId=event.params.noticeId;
  const brand=(await db.doc('settings/institution').get()).data();
  for await(const device of db.collection('pushDevices').where('branchId','==','main').stream()){
    const {uid,token}=device.data();
    const m=(await db.doc('branches/main/members/'+uid).get()).data();
    if(!m?.active||m.branchId!=='main'||(note.audience!=='all'&&m.role!==note.audience))continue;
    const receipt=db.doc('pushReceipts/'+noticeId+'_'+device.id);
    if((await receipt.get()).exists)continue;
    try{
      await getMessaging().send({token,data:{type:'madrasa-notice',noticeId,institution:brand?.nameBn||'মাদ্রাসা ব্যবস্থাপনা'}});
      await receipt.set({sentAt:new Date().toISOString()});
    }catch(error){
      if(!['messaging/registration-token-not-registered','messaging/invalid-registration-token'].includes(error.code))throw error;
      await device.ref.delete();
    }
  }
});
export const monthlyPayroll=onSchedule({schedule:'10 0 1 * *',timeZone:'Asia/Dhaka',retryCount:3,timeoutSeconds:540},async event=>{
  const period=new Date(Date.parse(event.scheduleTime)+21600000).toISOString().slice(0,7);
  for await(const contract of db.collection('branches/main/payContracts').where('active','==',true).stream()){
    if(contract.data().joinedOn.slice(0,7)>period)continue;
    await db.runTransaction(async tx=>{
      const store={get:async path=>(await tx.get(db.doc(path))).data()};
      const command={kind:'salarySlip',id:'payroll_'+contract.id+'_'+period,payload:{period,staffId:contract.id}};
      const result=await execute(store,{role:'principal',uid:'scheduler',branchId:'main',active:true},command);
      for(const [path,row] of result.writes)tx.set(db.doc(path),row);
    });
  }
});

import {familySummary} from './family.js';
export const guardianSummary=onCall(async req=>{
  if(!req.auth)throw new HttpsError('unauthenticated','প্রবেশ করুন।');
  const sid=req.data?.studentId;
  if(typeof sid!=='string'||!/^[-\w]{1,100}$/.test(sid))throw new HttpsError('invalid-argument','ছাত্রের পরিচয় সঠিক নয়।');
  const root=db.doc('branches/main'),uid=req.auth.uid;
  return db.runTransaction(async tx=>{
    const member=(await tx.get(root.collection('members').doc(uid))).data();
    const family=(await tx.get(root.collection('families').doc(uid))).data();
    if(member?.role!=='guardian'||member.branchId!=='main'||!member.active||!family?.children?.some(c=>c.id===sid))throw new HttpsError('permission-denied','এই ছাত্রের তথ্য দেখার অনুমতি নেই।');
    const s=(await tx.get(root.collection('roster').doc(sid))).data();
    if(!s)throw new HttpsError('not-found','ছাত্র পাওয়া যায়নি।');
    const records={receipts:[]};
    for(const col of ['attendance','results','hifzLogs','invoices']){
      records[col]=(await tx.get(root.collection(col).where('studentId','==',sid))).docs.map(d=>({...d.data(),id:d.id}));
    }
    records.messages=(await tx.get(root.collection('familyMessages').where('studentId','==',sid))).docs.map(d=>d.data()).filter(m=>m.uid===uid);
    for(const r of records.results){
      r.examName=(await tx.get(root.collection('exams').doc(r.examId))).data()?.name||'পরীক্ষা';
    }
    for(let i=0;i<records.invoices.length;i+=30){
      const ids=records.invoices.slice(i,i+30).map(row=>row.id);
      records.receipts.push(...(await tx.get(root.collection('receipts').where('invoiceId','in',ids))).docs.map(d=>d.data()));
    }
    return familySummary(s,records);
  },{readOnly:true});
});

import {mediaFile} from './phase3.js';
async function mediaOperator(req){
  if(!req.auth)throw new HttpsError('unauthenticated','প্রবেশ করুন।');
  const m=(await db.doc('branches/main/members/'+req.auth.uid).get()).data();
  if(!m?.active||m.branchId!=='main'||!['principal','deputy','office'].includes(m.role))throw new HttpsError('permission-denied','অনুমতি নেই।');
}
export const uploadEventMedia=onCall({memory:'256MiB'},async req=>{
  await mediaOperator(req);
  const {eventId,title,consent}=req.data||{};
  if(!/^[\w-]{1,100}$/.test(eventId)||typeof title!=='string'||!title.trim()||title.length>120||consent!==true)throw new HttpsError('invalid-argument','অনুষ্ঠান, ক্যাপশন ও সম্মতি যাচাই করুন।');
  if(!(await db.doc('branches/main/events/'+eventId).get()).exists)throw new HttpsError('not-found','অনুষ্ঠান পাওয়া যায়নি।');
  let f;try{f=mediaFile(req.data.file)}catch(e){throw new HttpsError('invalid-argument',e.message)}
  const bytes=Buffer.from(f.bytes,'base64');
  if(bytes.length>4*1024*1024)throw new HttpsError('invalid-argument','ফাইল ৪ মেগাবাইটের মধ্যে দিন।');
  const id=createHash('sha256').update(eventId+'|'+req.auth.uid+'|'+title+'|').update(bytes).digest('hex');
  const ref=db.doc('branches/main/media/'+id),path='branches/main/eventMedia/'+eventId+'/'+id;
  if((await ref.get()).exists)return {id};
  await getStorage().bucket().file(path).save(bytes,{resumable:false,metadata:{contentType:f.mime,cacheControl:'private,no-store'}});
  const now=new Date().toISOString();
  const meta={branchId:'main',schemaVersion:1,createdAt:now,updatedAt:now};
  const batch=db.batch();
  batch.set(ref,{...meta,eventId,title:title.trim(),consent:true,kind:f.mime.startsWith('image/')?'ছবি':'ভিডিও',name:f.name,mime:f.mime,storagePath:path});
  batch.set(db.doc('branches/main/audit/'+id),{...meta,actorUid:req.auth.uid,action:'eventMedia',result:id});
  await batch.commit();return {id};
});
export const readEventMedia=onCall(async req=>{
  await mediaOperator(req);const id=req.data?.id;
  if(typeof id!=='string'||!/^\w{64}$/.test(id))throw new HttpsError('invalid-argument','ফাইলের পরিচয় সঠিক নয়।');
  const r=(await db.doc('branches/main/media/'+id).get()).data();
  if(!r?.storagePath)throw new HttpsError('not-found','ফাইল পাওয়া যায়নি।');
  return {mime:r.mime,name:r.name,bytes:(await getStorage().bucket().file(r.storagePath).download())[0].toString('base64')};
});
export {startCheckout,paymentCallback,deliverSms} from './services.js';
