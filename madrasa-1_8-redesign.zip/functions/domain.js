import {p3Roles,command3,reverse3} from './phase3.js';
import {phase2Roles,phase2Command,reversePhase2} from './phase2.js';
// Commands stage all writes before the adapter commits them atomically.
export const roles = {
  principal:'মুহতামিম', deputy:'নায়েবে মুহতামিম', accountant:'হিসাবরক্ষক',
  academic:'শিক্ষা বিভাগের দায়িত্বশীল', teacher:'ওস্তাদ', office:'অফিস স্টাফ', guardian:'অভিভাবক'
};
const managers=['principal','deputy'], finance=[...managers,'accountant'];
export const permissions={
  ...phase2Roles,...p3Roles,
  setup:['principal'], brand:['principal'], approveExpense:['principal'], denyExpense:['principal'], admission:[...managers,'office'],
  profile:[...managers,'office'],archive:[...managers,'office'], restore:[...managers,'office'],
  smsQueue:managers,qrAttendance:[...managers,'academic','teacher'],attendance:[...managers,'academic','teacher'], invoice:finance,charge:finance,
  fee:finance, waiver:managers, donation:finance, income:finance, expense:finance, reversal:managers
};
export const statusNames={present:'উপস্থিত',absent:'অনুপস্থিত',leave:'ছুটি',late:'দেরি'};
export const funds=['সাধারণ','যাকাত','সদকা','ফিতরা','কুরবানির চামড়া'];
export const accounts=['নগদ','ব্যাংক','বিকাশ','নগদ মোবাইল'];
export function check(ok,message){if(!ok)throw new Error(message)}
function txt(v,title,max=120){
  check(typeof v==='string' && v.trim() && v.trim().length<=max,title+' সঠিকভাবে দিন।');return v.trim();
}
function optional(v,title,max){return v ? txt(v,title,max) : ''}
function one(v,values){check(values.includes(v),'তালিকা থেকে সঠিক মান বেছে নিন।');return v}
function key(v){check(typeof v==='string' && /^[\w-]{1,100}$/.test(v),'রেকর্ডের পরিচয় সঠিক নয়।');return v}
function money(v,zero=false){check(Number.isSafeInteger(v) && v>=(zero?0:1) && v<=1e12,'টাকার পরিমাণ সঠিকভাবে দিন।');return v}
function day(v){
  check(typeof v==='string' && /^\d{4}-\d\d-\d\d$/.test(v) && !Number.isNaN(Date.parse(v)) && new Date(v).toISOString().slice(0,10)===v,'তারিখ সঠিকভাবে দিন।');return v;
}
function month(v){day(v+'-01');return v}
function color(v){check(/^#[a-f\d]{6}$/i.test(v),'রঙ সঠিক নয়।');return v}
export async function execute(store, actor, cmd, now=new Date().toISOString()){
  const action=cmd.kind, id=key(cmd.id);
  let kind=action,p=cmd.payload;
  check(actor.active && actor.branchId==='main' && permissions[kind]?.includes(actor.role),'এই কাজের অনুমতি নেই।');
  const path=(collection,id)=>'branches/main/'+collection+'/'+id;
  const writes=new Map();
  const get=async(c,k)=>writes.get(path(c,k)) ?? await store.get(path(c,k));
  const put=(c,k,data)=>writes.set(path(c,k),{...data,branchId:'main',schemaVersion:1,createdAt:data.createdAt||now,updatedAt:now});
  const required=async(c,k)=>{const r=await get(c,key(k));check(r,'রেকর্ড খুঁজে পাওয়া যায়নি।');return r};
  const brand=await store.get('settings/institution');
  const log=await get('audit',id);
  if(log){check(log.actorUid===actor.uid && log.action===action,'অনুরোধ নম্বর আগে ব্যবহৃত হয়েছে।');return {writes:new Map(),result:log.result}}
  let result=id;
  if(kind==='setup'||kind==='brand'){
    check(kind==='brand'?!!brand:!brand,'প্রতিষ্ঠানের সেটআপ অবস্থা পরিবর্তিত হয়েছে।');
    const classes=Array.isArray(p.classes)?[...new Set(p.classes.map(n=>txt(n,'জামাত',50)))]:[];
    check(classes.length>0 && classes.length<=50,'১ থেকে ৫০টি জামাত দিন।');
    if(brand)check(brand.classes.every(c=>classes.includes(c)),'ব্যবহৃত জামাত রেখে নতুন জামাত যোগ করুন।');
    const logo=p.logo||'';
    check(!logo || (typeof logo==='string' && /^data:image\/(png|jpeg|webp);base64,[a-zA-Z0-9+/=]+$/.test(logo) && logo.length<220000),'লোগো ১৫০ কিলোবাইটের মধ্যে দিন।');
    const b={branchId:'main',schemaVersion:1,nameBn:txt(p.nameBn,'প্রতিষ্ঠানের নাম'),address:txt(p.address,'ঠিকানা',250),
      publicPhone:optional(p.publicPhone,'ফোন',30),principalName:txt(p.principalName,'মুহতামিমের নাম'),classes,
      expenseLimitMinor:money(p.expenseLimitMinor||0,true),monthlyMinor:money(p.monthlyMinor,true),admissionMinor:money(p.admissionMinor,true),academicYear:txt(p.academicYear,'শিক্ষাবর্ষ',40),
      startDate:day(p.startDate),primaryColor:color(p.primaryColor),accentColor:color(p.accentColor),logo,
      createdAt:brand?.createdAt||now,updatedAt:now};
    for(const k of ['nameEn','slogan','publicEmail','website','registrationNo','establishedYear'])b[k]=optional(p[k],k,200);
    const previousPrint=brand?.printVersion?await get('printBrands',brand.printVersion):{};
    const print={logo,primaryColor:b.primaryColor,accentColor:b.accentColor};
    for(const field of ['signature','seal']){
      const v=p[field]||previousPrint?.[field]||'';
      check(!v||(typeof v==='string'&&/^data:image\/(png|jpeg|webp);base64,[a-zA-Z0-9+/=]+$/.test(v)&&v.length<220000),'সিল ও স্বাক্ষরের ছবি ১৫০ কিলোবাইটের মধ্যে দিন।');
      print[field]=v;
    }
    b.printVersion=id;b.currency=one(p.currency||'৳',['৳','BDT']);b.digits=one(p.digits||'bn',['bn','en']);
    put('printBrands',id,print);
    writes.set('settings/institution',b);
    put('academicYears','current',{label:b.academicYear,startsOn:b.startDate});
    put('feePlans','default',{monthlyMinor:b.monthlyMinor,admissionMinor:b.admissionMinor});
  }else{
    check(brand,'প্রথমে প্রতিষ্ঠানের সেটআপ সম্পন্ন করুন।');
    const ctx={kind,p,actor,brand,id,now,put,get,required,one,txt,optional,check,day,month,money};
    const movement=p3Roles[kind]?await command3(ctx):phase2Roles[kind]?await phase2Command(ctx):null;
    if(movement?.direction===-1 && brand.expenseLimitMinor>0 && p.amountMinor>brand.expenseLimitMinor){
      check(actor.role==='principal','সীমার বেশি এই পরিশোধ মুহতামিমের অ্যাকাউন্ট থেকে নিশ্চিত করুন।');
    }
    if(kind==='admission'){
      const displayName=txt(p.displayName,'ছাত্রের নাম'),guardian=txt(p.guardian,'অভিভাবকের নাম');
      check(/^01[3-9]\d{8}$/.test(p.phone),'১১ অঙ্কের বাংলাদেশি মোবাইল নম্বর দিন।');
      const duplicateKey=p.phone+'_'+encodeURIComponent(displayName.normalize('NFC').replace(/\s+/g,'')).slice(0,900);
      check(!await get('uniqueKeys',duplicateKey),'এই নাম ও অভিভাবকের নম্বরে ছাত্র আগে ভর্তি হয়েছে।');
      const counter=await get('counters','roll'),roll=(counter?.value||0)+1;
      const classId=one(p.classId,brand.classes), joinedOn=day(p.date);
      const student={displayName,roll,classId,academicYear:brand.academicYear,joinedOn,status:'active',
        residentialStatus:one(p.residentialStatus,['অনাবাসিক','আবাসিক','লিল্লাহ বোর্ডিং','এতিম'])};
      put('students',id,student);
      const {residentialStatus,...roster}=student;put('roster',id,roster);
      put('studentPrivate',id,{studentId:id,guardian,phone:p.phone,residentialStatus,address:optional(p.address,'ঠিকানা',250)});
      const examScore=p.examScore===''||p.examScore==null?null:Number(p.examScore);
      check(examScore===null||(Number.isFinite(examScore)&&examScore>=0&&examScore<=100),'ভর্তি পরীক্ষার নম্বর ০–১০০ হতে হবে।');
      put('applications',id,{studentId:id,status:'admitted',appliedOn:joinedOn,examScore});
      const files=p.files||[];check(Array.isArray(files)&&files.length<=2,'সর্বোচ্চ দুটি ফাইল দিন।');
      const attachments=[];
      for(const [i,file] of files.entries()){
        const name=txt(file.name,'ফাইলের নাম',120),kind=one(file.kind,['photo','document']);
        const mime=one(file.mime,kind==='photo'?['image/jpeg','image/png']:['application/pdf','image/jpeg','image/png']);
        const prefix={'image/jpeg':'/9j/','image/png':'iVBORw0KGgo','application/pdf':'JVBERi0'}[mime];
        check(typeof file.bytes==='string' && file.bytes.startsWith(prefix) && /^[a-zA-Z0-9+/]+={0,2}$/.test(file.bytes) && file.bytes.length<=220000,'ছবি বা PDF ফাইল সঠিক নয় অথবা আকার বেশি।');
        const fid=id+'_'+i;
        put('studentFiles',fid,{studentId:id,kind,name,mime,bytes:file.bytes,storagePath:'branches/main/private/'+id+'/'+fid});
        attachments.push({id:fid,kind,name});
      }
      const priv=await get('studentPrivate',id);put('studentPrivate',id,{...priv,attachments,examScore});
      if(brand.monthlyMinor)put('invoices',id+'_'+joinedOn.slice(0,7),{studentId:id,period:joinedOn.slice(0,7),label:'মাসিক ফি',amountMinor:brand.monthlyMinor,paidMinor:0,waivedMinor:0});
      put('enrolments',id,{studentId:id,classId,startsOn:joinedOn});
      put('uniqueKeys',duplicateKey,{sourceId:id});put('counters','roll',{value:roll});
      if(brand.admissionMinor)put('invoices','adm_'+id,{studentId:id,period:joinedOn.slice(0,7),label:'ভর্তি ফি',amountMinor:brand.admissionMinor,paidMinor:0,waivedMinor:0});
    }
    if(kind==='profile'){
      const s=await required('students',p.studentId),priv=await required('studentPrivate',p.studentId);
      check(priv.updatedAt===p.revision,'প্রোফাইল বদলেছে। আবার খুলুন।');
      const displayName=txt(p.displayName,'ছাত্রের নাম'),guardian=txt(p.guardian,'অভিভাবকের নাম');
      check(/^01[3-9]\d{8}$/.test(p.phone),'মোবাইল নম্বর সঠিক নয়।');
      const identity=p.phone+'_'+encodeURIComponent(displayName.normalize('NFC').replace(/\s+/g,'')).slice(0,900);
      const owner=await get('uniqueKeys',identity);check(!owner||owner.sourceId===p.studentId,'একই পরিচয়ে অন্য ছাত্র আছে।');
      put('uniqueKeys',identity,{sourceId:p.studentId});
      const classId=one(p.classId,brand.classes);
      if(classId!==s.classId)put('enrolments',id,{studentId:p.studentId,classId,startsOn:now.slice(0,10)});
      const updated={...s,displayName,classId};put('students',p.studentId,updated);
      const {residentialStatus,...roster}=updated;put('roster',p.studentId,roster);
      put('studentPrivate',p.studentId,{...priv,guardian,phone:p.phone,address:optional(p.address,'ঠিকানা',250),
        healthNote:optional(p.healthNote,'স্বাস্থ্য নোট',1000),disciplineNote:optional(p.disciplineNote,'আচরণ নোট',1000)});
    }
    if(['archive','restore'].includes(kind)){
      const s=await required('students',p.studentId);
      check((kind==='archive')===(s.status==='active'),'ছাত্রের অবস্থা ইতিমধ্যে বদলেছে।');
      s.status=kind==='archive'?'archived':'active';put('students',p.studentId,s);const {residentialStatus,...roster}=s;put('roster',p.studentId,roster);
    }
    if(kind==='smsQueue'){
      const contact=await required('studentPrivate',p.studentId);
      const student=await required('roster',p.studentId);
      check(student.status==='active' && p.confirmed===true,'সক্রিয় ছাত্র ও প্রাপকের সম্মতি নিশ্চিত করুন।');
      put('smsOutbox',id,{studentId:p.studentId,phone:contact.phone,body:txt(p.body,'বার্তা',480),
        status:actor.training?'simulation':'queued',requestedBy:actor.uid});
    }
    if(kind==='qrAttendance'){
      const card=await required('documents',p.cardId);
      check(card.type==='পরিচয়পত্র' && card.active,'সক্রিয় পরিচয়পত্র স্ক্যান করুন।');
      const date=day(p.date);
      check(date===new Date(Date.parse(now)+21600000).toISOString().slice(0,10),'আজকের তারিখে পরিচয়পত্র স্ক্যান করুন।');
      const previous=await get('attendance',card.studentId+'_'+date);
      check(!previous,'আজকের হাজিরা আগেই লেখা হয়েছে। পরিবর্তন করতে হাজিরা খাতা খুলুন।');
      kind='attendance';p={studentId:card.studentId,date,status:'present',revision:0};
    }
    if(kind==='attendance'){
      const s=await required('students',p.studentId);check(s.status==='active','ছাত্রটি আর্কাইভে আছে।');
      check(actor.role!=='teacher'||actor.classIds?.includes(s.classId),'এই জামাতের দায়িত্ব দেওয়া হয়নি।');
      const date=day(p.date),aid=p.studentId+'_'+date,previous=await get('attendance',aid);
      check((previous?.revision||0)===p.revision,'হাজিরা অন্য জায়গা থেকে বদলেছে। সর্বশেষ রেকর্ড দেখে আবার দিন।');
      put('attendance',aid,{studentId:p.studentId,classId:s.classId,date,status:one(p.status,Object.keys(statusNames)),revision:p.revision+1,teacherUid:actor.uid});
    }
    if(kind==='invoice'){
      const s=await required('students',p.studentId),period=month(p.period);
      check(s.status==='active' && period>=s.joinedOn.slice(0,7),'এই মাসের জন্য ছাত্র সক্রিয় নয়।');
      const iid=p.studentId+'_'+period;
      if(!await get('invoices',iid))put('invoices',iid,{studentId:p.studentId,period,label:'মাসিক ফি',amountMinor:money(brand.monthlyMinor),paidMinor:0,waivedMinor:0});
      result=iid;
    }

    if(kind==='charge'){
      const s=await required('students',p.studentId);
      check(s.status==='active','ছাত্রটি সক্রিয় নয়।');
      const period=month(p.period),label=one(p.label,['পরীক্ষা ফি','খাবার ফি','হোস্টেল ফি','অন্যান্য ফি']);
      const iid=p.studentId+'_'+period+'_c'+['পরীক্ষা ফি','খাবার ফি','হোস্টেল ফি','অন্যান্য ফি'].indexOf(label);
      check(!await get('invoices',iid),'এই মাসে একই খাতের দাবি আগেই তৈরি হয়েছে।');
      put('invoices',iid,{studentId:p.studentId,period,label,amountMinor:money(p.amountMinor),paidMinor:0,waivedMinor:0});
      result=iid;
    }
    if(kind==='approveExpense'||kind==='denyExpense'){
      const approvalId=key(p.approvalId),approval=await required('approvals',approvalId);
      check(approval.status==='pending','আবেদনটির সিদ্ধান্ত আগেই হয়েছে।');
      put('approvals',approvalId,{...approval,status:kind==='approveExpense'?'approved':'denied',reviewedBy:actor.uid,decisionId:id});
      if(kind==='approveExpense'){kind='expense';p=approval.payload;}
    }
    if(kind==='expense' && actor.role!=='principal' && brand.expenseLimitMinor>0 && money(p.amountMinor)>brand.expenseLimitMinor){
      const payload={amountMinor:money(p.amountMinor),fund:one(p.fund,funds),account:one(p.account,accounts),date:day(p.date),party:optional(p.party,'প্রাপক'),note:optional(p.note,'বিবরণ',250)};
      put('approvals',id,{status:'pending',requestedBy:actor.uid,payload});kind='pendingExpense';
    }
    if(movement||['fee','waiver','donation','income','expense','reversal'].includes(kind)){
      const date=day(p.date);
      let entry;
      if(kind==='reversal'){
        const old=await required('ledger',p.entryId);
        check(old.kind!=='reversal'&&!await get('reversals',p.entryId),'এই এন্ট্রি আর বাতিল করা যাবে না।');
        entry={...old,createdAt:now,kind,originalKind:old.kind,sourceId:p.entryId,direction:-old.direction,note:txt(p.note,'কারণ',250)};
        await reverse3(entry,{required,put});
        await reversePhase2(entry,{required,put,check});
        put('reversals',p.entryId,{reversalId:id});
      }else{
        entry={kind,amountMinor:money(p.amountMinor),direction:kind==='expense'?-1:kind==='waiver'?0:1,
          fund:one(p.fund,funds),account:one(p.account,accounts),party:optional(p.party,'নাম'),note:optional(p.note,'বিবরণ',250)};
        if(movement)Object.assign(entry,movement);
        if(kind==='waiver')entry.note=txt(p.note,'মওকুফের কারণ',250);
        if(kind==='fee'||kind==='waiver')entry.invoiceId=key(p.invoiceId);
      }
      if(entry.invoiceId){
        const inv=await required('invoices',entry.invoiceId),field=(entry.originalKind||kind)==='waiver'?'waivedMinor':'paidMinor';
        const s=await required('students',inv.studentId);entry.party=s.displayName;
        inv[field]+=entry.amountMinor*(kind==='reversal'?-1:1);
        check(inv[field]>=0 && inv.paidMinor+inv.waivedMinor<=inv.amountMinor,'পরিমাণ বকেয়ার চেয়ে বেশি।');
        put('invoices',entry.invoiceId,inv);put('allocations',id,{invoiceId:entry.invoiceId,amountMinor:entry.amountMinor,kind,ledgerId:id});
      }
      const bid=funds.indexOf(entry.fund)+'_'+accounts.indexOf(entry.account);
      const balance=await get('balances',bid);
      const total=(balance?.amountMinor||0)+entry.direction*entry.amountMinor;
      check(total>=0 && Number.isSafeInteger(total),'নির্বাচিত তহবিল ও হিসাবে পর্যাপ্ত টাকা নেই।');
      put('balances',bid,{fund:entry.fund,account:entry.account,amountMinor:total});
      const receipt={...entry,printVersion:brand.printVersion||'',currency:brand.currency||'৳',actorUid:actor.uid,date,serial:'R-'+id.toUpperCase(),institution:brand.nameBn,address:brand.address,phone:brand.publicPhone};
      put('ledger',id,receipt);put('receipts',id,receipt);
      if(kind==='donation')put('collections',id,{ledgerId:id,donorName:entry.party,fund:entry.fund,amountMinor:entry.amountMinor,date});
    }
  }
  put('audit',id,{actorUid:actor.uid,action,result});
  return {writes,result};
}
