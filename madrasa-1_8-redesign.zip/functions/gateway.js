import {execute} from './domain.js';

export function validatePayment(order,id,validationId,response){
  if(!['VALID','VALIDATED'].includes(response.status)||response.tran_id!==id||
    response.val_id!==validationId||response.currency!=='BDT'||
    !/^\d+(\.\d{1,2})?$/.test(String(response.amount))||
    Math.round(Number(response.amount)*100)!==order.amountMinor)throw Error('পেমেন্ট যাচাই হয়নি।');
}
export async function settlePayment(store,order,id,response,now=new Date().toISOString()){
  if(['credited','review'].includes(order.status))return {writes:new Map(),status:order.status};
  const invoice=await store.get('branches/main/invoices/'+order.invoiceId);
  if(String(response.risk_level)!=='0'||!invoice||invoice.studentId!==order.studentId||
    invoice.amountMinor-invoice.paidMinor-invoice.waivedMinor<order.amountMinor)return {writes:new Map(),status:'review'};
  const date=new Date(Date.parse(now)+21600000).toISOString().slice(0,10);
  const {writes}=await execute(store,{active:true,role:'accountant',branchId:'main',uid:'gateway'},{
    kind:'fee',id,payload:{date,fund:'সাধারণ',account:'ব্যাংক',amountMinor:order.amountMinor,
      invoiceId:order.invoiceId,note:'অনলাইন পেমেন্ট '+id}},now);
  return {writes,status:'credited'};
}
