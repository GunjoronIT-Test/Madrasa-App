import {randomBytes} from 'node:crypto';
import {getFirestore} from 'firebase-admin/firestore';
import {onCall,onRequest,HttpsError} from 'firebase-functions/v2/https';
import {onDocumentCreated} from 'firebase-functions/v2/firestore';
import {validatePayment,settlePayment} from './gateway.js';

const root='branches/main/';
const secrets=['SSL_STORE_ID','SSL_STORE_PASSWORD'];
const host=()=>process.env.SSL_LIVE==='true'?'securepay.sslcommerz.com':'sandbox.sslcommerz.com';
function credentials(){return {store_id:process.env.SSL_STORE_ID,store_passwd:process.env.SSL_STORE_PASSWORD}}
async function json(url,options={}){
  const r=await fetch(url,{...options,signal:AbortSignal.timeout(20000),redirect:'error'});
  if(!r.ok)throw Error('সেবা থেকে উত্তর পাওয়া যায়নি।');
  return r.json();
}
export const startCheckout=onCall({secrets},async req=>{
  const db=getFirestore(),id=req.data?.invoiceId,uid=req.auth?.uid;
  if(!uid||typeof id!=='string'||!/^[-\w]{1,100}$/.test(id))throw new HttpsError('permission-denied','প্রবেশ করুন।');
  const callback=process.env.PAYMENT_CALLBACK_URL;
  if(!callback?.startsWith('https://')||!credentials().store_id||!credentials().store_passwd)
    throw new HttpsError('failed-precondition','পেমেন্ট গেটওয়ে কনফিগার করুন।');
  const orderId=randomBytes(14).toString('hex'),orderRef=db.doc(root+'paymentOrders/'+orderId);
  const lock=db.doc('checkoutLocks/'+id);
  const details=await db.runTransaction(async tx=>{
    const get=async path=>(await tx.get(db.doc(root+path))).data();
    const member=await get('members/'+uid);
    if(!member?.active||member.branchId!=='main'||!['principal','deputy','accountant','guardian'].includes(member.role))throw new HttpsError('permission-denied','সদস্যপদ যাচাই করুন।');
    const invoice=await get('invoices/'+id);
    if(!invoice||(member.role==='guardian'&&!(await get('families/'+uid))?.children?.some(c=>c.id===invoice.studentId)))throw new HttpsError('permission-denied','এই বিলের অনুমতি নেই।');
    const amountMinor=invoice.amountMinor-invoice.paidMinor-invoice.waivedMinor;
    if(amountMinor<=0)throw new HttpsError('failed-precondition','এই বিলে বকেয়া নেই।');
    const previous=(await tx.get(lock)).data();
    if(previous?.until>Date.now())throw new HttpsError('already-exists','এই বিলের একটি চেকআউট চলছে। ১৫ মিনিট পরে আবার চেষ্টা করুন।');
    const contact=await get('studentPrivate/'+invoice.studentId);
    tx.create(orderRef,{invoiceId:id,studentId:invoice.studentId,amountMinor,status:'pending',uid,createdAt:new Date().toISOString()});
    tx.set(lock,{orderId,until:Date.now()+900000});
    return {amountMinor,contact};
  });
  const params={...credentials(),total_amount:(details.amountMinor/100).toFixed(2),currency:'BDT',tran_id:orderId,
    success_url:callback,fail_url:callback,cancel_url:callback,ipn_url:callback,shipping_method:'NO',
    cus_name:details.contact.guardian,cus_phone:details.contact.phone,cus_email:req.auth.token.email,
    cus_add1:details.contact.address||'Bangladesh',cus_city:'Dhaka',cus_country:'Bangladesh',
    product_name:'Madrasa fees',product_category:'Education',product_profile:'non-physical-goods'};
  const session=await json('https://'+host()+'/gwprocess/v4/api.php',{method:'POST',body:new URLSearchParams(params)});
  const url=new URL(session.GatewayPageURL);
  if(session.status!=='SUCCESS'||url.protocol!=='https:'||url.hostname!==host())throw new HttpsError('unavailable','চেকআউট খোলা যায়নি।');
  return {url:url.href};
});
export const paymentCallback=onRequest({secrets},async(req,res)=>{
  const {tran_id:id,val_id:validationId}=req.body||{};
  if(req.method!=='POST')return res.sendStatus(405);
  if(!validationId)return res.status(200).send('পরিশোধ নিশ্চিত হয়নি। অ্যাপে ফিরে বিল দেখুন।');
  if(!/^[a-f0-9]{28}$/.test(id)||!/^[-\w]{1,100}$/.test(validationId))return res.sendStatus(400);
  const db=getFirestore(),ref=db.doc(root+'paymentOrders/'+id);
  if(!(await ref.get()).exists)return res.sendStatus(404);
  try{
    const query=new URLSearchParams({...credentials(),val_id:validationId,format:'json'});
    const v=await json('https://'+host()+'/validator/api/validationserverAPI.php?'+query);
    const status=await db.runTransaction(async tx=>{
      const order=(await tx.get(ref)).data();
      validatePayment(order,id,validationId,v);
      const result=await settlePayment({get:async path=>(await tx.get(db.doc(path))).data()},order,id,v);
      for(const [path,row] of result.writes)tx.set(db.doc(path),row);
      if(result.status!==order.status)tx.update(ref,{status:result.status,validationId,verifiedAt:new Date().toISOString()});
      return result.status;
    });
    return res.send(status==='credited'?'ফি জমা হয়েছে। অ্যাপে ফিরে রসিদ দেখুন।':'পেমেন্ট হিসাবরক্ষকের যাচাইয়ের অপেক্ষায় আছে।');
  }catch{return res.status(503).send('যাচাই সম্পন্ন হয়নি। হিসাবের অবস্থা পরীক্ষা করুন।')}
});
export const deliverSms=onDocumentCreated({document:root+'smsOutbox/{id}',secrets:['SMS_API_KEY','SMS_SENDER_ID'],retry:true},async event=>{
  const ref=event.data.ref,db=getFirestore();
  const message=await db.runTransaction(async tx=>{
    const row=(await tx.get(ref)).data();
    if(row.status!=='queued')return null;
    tx.update(ref,{status:'sending',startedAt:new Date().toISOString()});return row;
  });
  if(!message)return;
  let status='unknown';
  try{
    const r=await json('https://bulksmsbd.net/api/smsapi',{method:'POST',body:new URLSearchParams({
      api_key:process.env.SMS_API_KEY,senderid:process.env.SMS_SENDER_ID,number:'88'+message.phone,message:message.body})});
    if(Number(r.response_code)===202)status='accepted';
    else if(r.response_code)status='rejected';
  }catch{}
  await ref.update({status,finishedAt:new Date().toISOString()});
});
