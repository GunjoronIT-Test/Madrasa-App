const chief=['principal','deputy'];
const office=[...chief,'office'], academic=[...chief,'academic','teacher'], finance=[...chief,'accountant'];
export const p3Roles={
  eventAdd:office,eventTask:office,eventDone:office,eventMedia:office,eventMoney:finance,
  hifz:academic,roomAdd:office,bedAssign:office,bedRelease:office,mealCount:office,mealCost:finance,
  stockAdd:office,stockMove:office,assetAdd:office,repair:office,bookAdd:office,bookIssue:office,bookReturn:office,
  familyLink:chief,issueDoc:chief,revokeDoc:chief,eventInvite:chief,familyMessage:['guardian'],familyReply:chief
};
export const p3Protected=['familyLink','issueDoc','revokeDoc'];
export const docTypes=['সনদ','ছাড়পত্র','পরিচয়পত্র'];
export const lessonTypes=['সবক','সবকি','আমুখতা','নাজেরা'];
export async function command3(x){
  const {kind,p,actor,brand,id,now,put,get,required,one,txt,optional,check,day,money}=x;
  const n=(v,min,max)=>{check(Number.isInteger(v)&&v>=min&&v<=max,'সংখ্যাটি অনুমোদিত সীমার মধ্যে দিন।');return v};
  const student=async()=>{const s=await required('roster',p.studentId);check(s.status==='active','ছাত্রটি সক্রিয় নয়।');return s};
  switch(kind){
    case 'eventAdd':
      put('events',id,{title:txt(p.title,'অনুষ্ঠানের নাম'),date:day(p.date),venue:txt(p.venue,'স্থান'),committee:optional(p.committee,'কমিটি',600),guests:optional(p.guests,'অতিথি',600),budgetMinor:money(p.budgetMinor,true),incomeMinor:0,expenseMinor:0});break;
    case 'eventTask':
      await required('events',p.eventId);put('eventTasks',id,{eventId:p.eventId,title:txt(p.title,'কাজ'),owner:txt(p.owner,'দায়িত্বপ্রাপ্ত'),due:day(p.due),done:false});break;
    case 'eventDone':{
      const t=await required('eventTasks',p.taskId);put('eventTasks',p.taskId,{...t,done:true});break;
    }
    case 'eventMedia':{
      await required('events',p.eventId);
      check(p.consent===true,'সংরক্ষণের অনুমতি নিশ্চিত করুন।');
      if(p.file){
        check(actor.uid==='training' && actor.training===true,'ক্লাউডে অনুমোদিত আপলোড ব্যবহার করুন।');
        const file=mediaFile(p.file);
        put('media',id,{eventId:p.eventId,title:txt(p.title,'ক্যাপশন'),kind:file.mime.startsWith('image/')?'ছবি':'ভিডিও',file,consent:true});break;
      }
      let url;try{url=new URL(p.url)}catch{throw Error('ফাইল অথবা একটি সঠিক HTTPS লিংক দিন।')};check(url.protocol==='https:'&&!url.username&&!url.password&&url.href.length<=2048,'সঠিক HTTPS লিংক দিন।');
      put('media',id,{eventId:p.eventId,url:url.href,title:txt(p.title,'ক্যাপশন'),kind:one(p.mediaKind,['ছবি','ভিডিও']),consent:true});break;
    }
    case 'eventMoney':{
      const e=await required('events',p.eventId),type=one(p.type,['donation','expense']),amount=money(p.amountMinor);
      const field=type==='donation'?'incomeMinor':'expenseMinor';put('events',p.eventId,{...e,[field]:e[field]+amount});
      return {eventId:p.eventId,eventField:field,category:type,party:optional(p.party,'পক্ষ'),note:e.title+' · '+txt(p.note,'বিবরণ',160),direction:type==='donation'?1:-1};
    }
    case 'hifz':{
      const s=await student(),date=day(p.date),lesson=one(p.lesson,lessonTypes);
      check(actor.role!=='teacher'||actor.classIds?.includes(s.classId),'এই জামাতের দায়িত্ব নেই।');
      const from=n(p.from,1,2000),to=n(p.to,from,2000),logId=p.studentId+'_'+date+'_'+lessonTypes.indexOf(lesson),old=await get('hifzLogs',logId);
      check((old?.revision||0)===p.revision,'অগ্রগতির রেকর্ড বদলেছে। আবার খুলুন।');
      put('hifzLogs',logId,{studentId:p.studentId,name:s.displayName,classId:s.classId,date,lesson,juz:n(p.juz,1,30),from,to,comment:optional(p.comment,'মন্তব্য',500),teacherUid:actor.uid,revision:p.revision+1});break;
    }
    case 'roomAdd':put('rooms',id,{name:txt(p.name,'কক্ষ'),capacity:n(p.capacity,1,200)});break;
    case 'bedAssign':{
      const s=await student(),room=await required('rooms',p.roomId),seat=n(p.seat,1,room.capacity),bid=p.roomId+'_'+seat;
      const b=await get('beds',bid),occupancy=await get('residents',p.studentId);
      check(!b?.active&&!occupancy?.active,'সিট বা ছাত্রের বরাদ্দ আগে থেকেই সক্রিয়।');
      const info={studentId:p.studentId,name:s.displayName,roomId:p.roomId,room:room.name,seat,active:true,start:day(p.date),allocationId:id,bedId:bid};
      put('beds',bid,info);put('residents',p.studentId,info);put('allocationsHostel',id,info);break;
    }
    case 'bedRelease':{
      const b=await required('beds',p.bedId);check(b.active&&b.allocationId===p.allocationId,'সিটের বরাদ্দ বদলেছে।');
      const end=day(p.date);check(end>=b.start,'ছাড়ার তারিখ মিলিয়ে নিন।');
      const updated={...b,end,active:false};put('beds',p.bedId,updated);put('residents',b.studentId,updated);put('allocationsHostel',b.allocationId,updated);break;
    }
    case 'mealCount':{
      const date=day(p.date),types=['সকাল','দুপুর','রাত'],type=one(p.type,types),mid=date+'_'+types.indexOf(type),old=await get('meals',mid);
      check((old?.revision||0)===p.revision,'মিলের রেকর্ড বদলেছে। আবার খুলুন।');
      put('meals',mid,{...old,date,type,count:n(p.count,0,100000),costMinor:old?.costMinor||0,revision:p.revision+1});break;
    }
    case 'mealCost':{
      const m=await required('meals',p.mealId);put('meals',p.mealId,{...m,costMinor:m.costMinor+money(p.amountMinor)});
      return {mealId:p.mealId,category:'expense',direction:-1,note:'খাবার · '+m.date+' · '+m.type};
    }
    case 'stockAdd':put('stockItems',id,{name:txt(p.name,'পণ্য'),unit:txt(p.unit,'একক',24),minimum:n(p.minimum,0,1e12),quantity:0});break;
    case 'stockMove':{
      const item=await required('stockItems',p.itemId),qty=n(p.quantity,1,1e12),type=one(p.type,['in','out']);
      const quantity=item.quantity+qty*(type==='in'?1:-1);check(quantity>=0&&Number.isSafeInteger(quantity),'মজুতের চেয়ে বেশি দেওয়া যাবে না।');
      put('stockItems',p.itemId,{...item,quantity});put('stockMoves',id,{itemId:p.itemId,name:item.name,unit:item.unit,type,quantity:qty,date:day(p.date),note:txt(p.note,'কারণ')});break;
    }
    case 'assetAdd':put('assets',id,{name:txt(p.name,'সম্পদ'),location:txt(p.location,'অবস্থান'),date:day(p.date),valueMinor:money(p.valueMinor,true)});break;
    case 'repair':{
      const a=await required('assets',p.assetId);put('repairs',id,{assetId:p.assetId,name:a.name,date:day(p.date),note:txt(p.note,'মেরামতের বিবরণ',500)});break;
    }
    case 'bookAdd':{
      const code=txt(p.code,'কপি নম্বর',50);const k='book_'+encodeURIComponent(code.normalize('NFC'));
      check(!await get('uniqueKeys',k),'কপি নম্বর আগে ব্যবহার হয়েছে।');put('uniqueKeys',k,{sourceId:id});
      put('books',id,{title:txt(p.title,'কিতাব'),author:optional(p.author,'লেখক'),code,loanId:''});break;
    }
    case 'bookIssue':{
      const b=await required('books',p.bookId),s=await student(),date=day(p.date),due=day(p.due);
      check(!b.loanId&&due>=date,'কপি ইতিমধ্যে ইস্যু হয়েছে অথবা মেয়াদ ভুল।');
      put('books',p.bookId,{...b,loanId:id});put('bookLoans',id,{bookId:p.bookId,title:b.title,code:b.code,studentId:p.studentId,name:s.displayName,date,due,returned:''});break;
    }
    case 'bookReturn':{
      const l=await required('bookLoans',p.loanId),b=await required('books',l.bookId),date=day(p.date);
      check(!l.returned&&b.loanId===p.loanId&&date>=l.date,'ফেরতের তথ্য মিলছে না।');
      put('books',l.bookId,{...b,loanId:''});put('bookLoans',p.loanId,{...l,returned:date});break;
    }
    case 'familyLink':{
      const s=await required('roster',p.studentId),uid=txt(p.uid,'অভিভাবকের UID',128);
      check(/^[A-Za-z0-9_-]+$/.test(uid),'UID সঠিক নয়।');
      const m=await get('members',uid);check(m?.active&&m.role==='guardian'&&m.branchId==='main','সক্রিয় অভিভাবক অ্যাকাউন্ট প্রয়োজন।');
      const link=await get('families',uid)||{children:[]},children=link.children.filter(c=>c.id!==p.studentId);
      if(p.link===true)children.push({id:p.studentId,name:s.displayName});
      check(children.length<=30,'এক অ্যাকাউন্টে সর্বোচ্চ ৩০ জন।');
      put('families',uid,{children});break;
    }
    case 'familyMessage':{
      const links=await get('families',actor.uid);check(links?.children?.some(c=>c.id===p.studentId),'সন্তানের সংযোগ পাওয়া যায়নি।');
      const s=await required('roster',p.studentId),type=one(p.type,['ছুটির আবেদন','অভিযোগ','পরামর্শ']);
      const row={uid:actor.uid,studentId:p.studentId,name:s.displayName,type,body:txt(p.body,'বিবরণ',1000),status:'অপেক্ষমাণ'};
      if(type==='ছুটির আবেদন'){row.from=day(p.from);row.to=day(p.to);check(row.from<=row.to,'ছুটির সময়সীমা সঠিক নয়।');}
      put('familyMessages',id,row);break;
    }
    case 'familyReply':{
      const m=await required('familyMessages',p.messageId);check(m.status==='অপেক্ষমাণ','আবেদনে সিদ্ধান্ত দেওয়া হয়েছে।');
      put('familyMessages',p.messageId,{...m,status:one(p.status,m.type==='ছুটির আবেদন'?['অনুমোদিত','প্রত্যাখ্যাত']:['নিষ্পত্তি']),reply:txt(p.reply,'উত্তর',600)});break;
    }
    case 'eventInvite':{
      const e=await required('events',p.eventId),issued=day(p.date),serial='INV-'+id.toUpperCase();
      const doc={serial,type:'দাওয়াতপত্র',name:txt(p.guest,'আমন্ত্রিত অতিথি'),classId:e.title,academicYear:brand.academicYear,issued,body:txt(p.body,'দাওয়াতের বক্তব্য',1600),eventId:p.eventId,eventDate:e.date,venue:e.venue,institution:brand.nameBn,address:brand.address,printVersion:brand.printVersion||'',active:true};
      put('documents',id,doc);put('verification',id,{serial,type:doc.type,issued,institution:doc.institution,active:true});break;
    }
    case 'issueDoc':{
      const s=await required('roster',p.studentId),type=one(p.type,docTypes),issued=day(p.date);
      const serial=['CERT','TC','ID'][docTypes.indexOf(type)]+'-'+id.toUpperCase();
      const doc={serial,type,studentId:p.studentId,name:s.displayName,roll:s.roll,classId:s.classId,academicYear:s.academicYear,issued,body:txt(p.body,'নথির বক্তব্য',1600),institution:brand.nameBn,address:brand.address,printVersion:brand.printVersion||'',active:true};
      if(type==='পরিচয়পত্র'){
        check(doc.body.length<=160,'পরিচয়পত্রের বক্তব্য ১৬০ অক্ষরের মধ্যে দিন।');
        const priv=await get('studentPrivate',p.studentId);doc.photoId=priv?.attachments?.find(f=>f.kind==='photo')?.id||'';
      }
      put('documents',id,doc);
      put('verification',id,{serial,type,issued,institution:brand.nameBn,active:true});break;
    }
    case 'revokeDoc':{
      const d=await required('documents',p.docId),v=await required('verification',p.docId);
      check(d.active,'নথি ইতিমধ্যে বাতিল।');put('documents',p.docId,{...d,active:false,reason:txt(p.reason,'বাতিলের কারণ')});put('verification',p.docId,{...v,active:false});break;
    }
  }
  return null;
}
export async function reverse3(e,{required,put}){
  if(e.originalKind==='eventMoney'){
    const ev=await required('events',e.eventId);put('events',e.eventId,{...ev,[e.eventField]:ev[e.eventField]-e.amountMinor});
  }
  if(e.originalKind==='mealCost'){
    const m=await required('meals',e.mealId);put('meals',e.mealId,{...m,costMinor:m.costMinor-e.amountMinor});
  }
}
export function mediaFile(file){
  const prefixes={'image/jpeg':'/9j/','image/png':'iVBORw0KGgo','video/webm':'GkXf','video/mp4':''};
  if(!file||!Object.hasOwn(prefixes,file.mime)||typeof file.bytes!=='string'||!file.bytes.length||file.bytes.length>5592408||!/^[A-Za-z0-9+/]+=*$/.test(file.bytes)||!file.bytes.startsWith(prefixes[file.mime]))throw Error('সর্বোচ্চ ৪ মেগাবাইটের JPEG, PNG, MP4 বা WebM দিন।');
  if(file.mime==='video/mp4'&&atob(file.bytes.slice(0,16)).slice(4,8)!=='ftyp')throw Error('সঠিক MP4 ফাইল দিন।');
  return {name:String(file.name||'media').slice(0,120),mime:file.mime,bytes:file.bytes};
}
