const chiefs=['principal','deputy'];
const finance=[...chiefs,'accountant'];
const academics=[...chiefs,'academic'];
export const phase2Roles={
  staffAdd:chiefs,staffEdit:chiefs,staffDay:[...chiefs,'office'],salarySlip:finance,salaryAdjust:finance,salaryPay:finance,
  loanOpen:finance,loanPay:finance,examCreate:academics,examMark:[...academics,'teacher'],noticePublish:chiefs
};
export const protectedPhase2=['staffAdd','staffEdit','salaryAdjust','salaryPay','loanOpen','loanPay'];
export const defaultGrades=[{min:80,label:'মুমতাজ'},{min:65,label:'জায়্যিদ জিদ্দান'},{min:50,label:'জায়্যিদ'},{min:33,label:'মাকবুল'},{min:0,label:'রাসিব'}];
export function monthAfter(date,n){
  const first=new Date(date.slice(0,7)+'-01T00:00:00Z');
  first.setUTCMonth(first.getUTCMonth()+n);
  const last=new Date(Date.UTC(first.getUTCFullYear(),first.getUTCMonth()+1,0));
  first.setUTCDate(Math.min(Number(date.slice(8)),last.getUTCDate()));
  return first.toISOString().slice(0,10);
}
export function ranking(results){
  const sorted=[...results].sort((a,b)=>Number(b.passed)-Number(a.passed)||b.total-a.total||a.roll-b.roll);
  let rank=0;
  return sorted.map((r,i)=>{if(!i||r.total!==sorted[i-1].total||r.passed!==sorted[i-1].passed)rank=i+1;return {...r,rank}});
}
export async function phase2Command(ctx){
  const {kind,p,actor,brand,id,now,put,get,required,one,txt,optional,check,day,month,money}=ctx;
  if(kind==='staffAdd'){
    const name=txt(p.name,'নাম'),designation=txt(p.designation,'পদ'),joinedOn=day(p.joinedOn);
    put('staff',id,{name,designation,joinedOn,phone:optional(p.phone,'ফোন',30),status:'active'});
    put('payContracts',id,{staffId:id,name,designation,joinedOn,baseMinor:money(p.baseMinor),active:true});
  }
  if(kind==='staffEdit'){
    const staff=await required('staff',p.staffId),contract=await required('payContracts',p.staffId);
    check(contract.updatedAt===p.revision,'কর্মীর তথ্য বদলেছে। পুনরায় খুলুন।');
    const name=txt(p.name,'নাম'),designation=txt(p.designation,'পদ'),baseMinor=money(p.baseMinor);
    const effective=month(p.effective);
    check(effective>=staff.joinedOn.slice(0,7),'কার্যকর মাস যোগদানের আগে হতে পারে না।');
    const history=contract.rates||[{period:staff.joinedOn.slice(0,7),amount:contract.baseMinor}];
    const rates=history.filter(r=>r.period!==effective).concat({period:effective,amount:baseMinor}).sort((a,b)=>a.period.localeCompare(b.period));
    const status=one(p.status,['active','inactive']);
    put('staff',p.staffId,{...staff,name,designation,phone:optional(p.phone,'ফোন',30),status});
    put('payContracts',p.staffId,{...contract,name,designation,active:status==='active',baseMinor,rates});
  }
  if(kind==='staffDay'){
    const s=await required('staff',p.staffId),date=day(p.date);
    check(date>=s.joinedOn,'যোগদানের আগের তারিখ দেওয়া যাবে না।');
    put('staffAttendance',p.staffId+'_'+date,{staffId:p.staffId,name:s.name,date,status:one(p.status,['উপস্থিত','অনুপস্থিত','ছুটি','দেরি']),note:optional(p.note,'কারণ',250)});
  }
  if(kind==='salarySlip'){
    const s=await required('payContracts',p.staffId),period=month(p.period),sid=p.staffId+'_'+period;
    check(s.active&&period>=s.joinedOn.slice(0,7),'এই মাসের সক্রিয় চুক্তি নেই।');
    const base=s.rates?.filter(r=>r.period<=period).at(-1)?.amount??s.baseMinor;
    if(!await get('payslips',sid))put('payslips',sid,{staffId:p.staffId,name:s.name,designation:s.designation,period,
      baseMinor:base,bonusMinor:0,deductionMinor:0,paidMinor:0,advanceMinor:0,netMinor:base});
  }
  if(kind==='salaryAdjust'){
    const s=await required('payslips',p.slipId);
    check(s.updatedAt===p.revision,'স্লিপটি বদলেছে। আবার খুলুন।');
    const bonusMinor=money(p.bonusMinor,true),deductionMinor=money(p.deductionMinor,true);
    const netMinor=s.baseMinor+bonusMinor-deductionMinor;
    check(netMinor>=s.paidMinor,'প্রাপ্য বেতন ইতিমধ্যে পরিশোধিত অঙ্কের নিচে হতে পারে না।');
    put('payslips',p.slipId,{...s,bonusMinor,deductionMinor,netMinor,reason:txt(p.note,'সমন্বয়ের কারণ',250)});
  }
  if(kind==='salaryPay'){
    const s=await required('payslips',p.slipId),amount=money(p.amountMinor),advance=p.advance===true;
    const contract=await required('payContracts',s.staffId);
    check(day(p.date)>=contract.joinedOn,'বেতন পরিশোধের তারিখ যোগদানের আগে হতে পারে না।');
    check(s.paidMinor+amount<=s.netMinor,'বকেয়া বেতনের চেয়ে বেশি পরিশোধ করা যাবে না।');
    put('payslips',p.slipId,{...s,paidMinor:s.paidMinor+amount,advanceMinor:s.advanceMinor+(advance?amount:0)});
    put('salaryPayments',id,{slipId:p.slipId,amountMinor:amount,ledgerId:id,advance});
    return {slipId:p.slipId,advance,party:s.name,direction:-1,note:(advance?'অগ্রিম বেতন · ':'বেতন · ')+s.period};
  }
  if(kind==='loanOpen'){
    const party=txt(p.party,'পক্ষের নাম'),side=one(p.side,['borrow','lend']),amount=money(p.amountMinor);
    const start=day(p.date),due=day(p.due),count=p.count;
    check(due>=start&&Number.isInteger(count)&&count>=1&&count<=60&&count<=amount,'প্রথম মেয়াদ ও কিস্তির সংখ্যা যাচাই করুন (১–৬০)।');
    const installments=Array.from({length:count},(_,i)=>({due:monthAfter(due,i),expected:Math.floor(amount/count)+(i<amount%count?1:0),paid:0}));
    put('loans',id,{party,side,openedOn:start,principalMinor:amount,paidMinor:0,installments,status:'active',note:optional(p.note,'বিবরণ',250)});
    return {loanId:id,party,direction:side==='borrow'?1:-1,note:side==='borrow'?'ঋণ গ্রহণ':'ঋণ প্রদান'};
  }
  if(kind==='loanPay'){
    const l=await required('loans',p.loanId),i=p.installment,amount=money(p.amountMinor);
    check(l.status==='active'&&Number.isInteger(i)&&l.installments[i],'কিস্তিটি সক্রিয় নয়।');
    check(day(p.date)>=l.openedOn,'ঋণ শুরুর আগের তারিখ দেওয়া যাবে না।');
    const item=l.installments[i];check(item.paid+amount<=item.expected,'কিস্তির বকেয়ার চেয়ে বেশি পরিশোধ করা যাবে না।');
    item.paid+=amount;l.paidMinor+=amount;
    put('loans',p.loanId,l);
    put('loanPayments',id,{loanId:p.loanId,installment:i,amountMinor:amount,ledgerId:id});
    return {loanId:p.loanId,installment:i,party:l.party,direction:l.side==='borrow'?-1:1,note:'কিস্তি '+(i+1)};
  }
  if(kind==='examCreate'){
    const classId=one(p.classId,brand.classes),name=txt(p.name,'পরীক্ষার নাম');
    check(Array.isArray(p.subjects)&&p.subjects.length>=1&&p.subjects.length<=30,'১ থেকে ৩০টি বিষয় দিন।');
    const subjects=p.subjects.map(s=>{
      check(Number.isInteger(s.max)&&s.max>=1&&s.max<=1000&&Number.isInteger(s.pass)&&s.pass>=0&&s.pass<=s.max,'পূর্ণমান ও পাস নম্বর মিলিয়ে দিন।');
      check(/^([01]\d|2[0-3]):[0-5]\d$/.test(s.time),'সময়সূচি দিন।');
      return {name:txt(s.name,'বিষয়',60),max:s.max,pass:s.pass,date:day(s.date),time:s.time};
    });
    check(new Set(subjects.map(s=>s.name)).size===subjects.length&&new Set(subjects.map(s=>s.date+' '+s.time)).size===subjects.length,'একই বিষয় বা সময় একাধিকবার দেওয়া হয়েছে।');
    check(Array.isArray(p.grades)&&p.grades.length>1&&p.grades.length<=12,'গ্রেডের তালিকা দিন।');
    const grades=p.grades.map(g=>{check(Number.isFinite(g.min)&&g.min>=0&&g.min<=100,'গ্রেড সীমা ০ থেকে ১০০ দিন।');return {min:g.min,label:txt(g.label,'গ্রেড',40)}}).sort((a,b)=>b.min-a.min);
    check(grades.at(-1).min===0&&new Set(grades.map(g=>g.min)).size===grades.length,'গ্রেডের শেষ সীমা ০ দিন এবং প্রতিটি সীমা একবার দিন।');
    put('exams',id,{name,classId,board:optional(p.board,'বোর্ড',100),room:txt(p.room,'কক্ষ',80),subjects,grades,academicYear:brand.academicYear});
  }
  if(kind==='examMark'){
    const exam=await required('exams',p.examId),student=await required('roster',p.studentId);
    check(student.status==='active'&&exam.classId===student.classId&&(actor.role!=='teacher'||actor.classIds?.includes(exam.classId)),'এই জামাত বা ছাত্রের নম্বর লেখার অনুমতি নেই।');
    const rid=p.examId+'_'+p.studentId,previous=await get('results',rid);
    check((previous?.revision||0)===p.revision,'নম্বর অন্য জায়গা থেকে বদলেছে। আবার খুলুন।');
    check(Array.isArray(p.scores)&&p.scores.length===exam.subjects.length,'সব বিষয়ের নম্বর দিন।');
    const scores=p.scores.map((n,i)=>{check(n===null||(Number.isFinite(n)&&n>=0&&n<=exam.subjects[i].max&&Math.abs(n*100-Math.round(n*100))<1e-7),'বিষয়ের নম্বর পূর্ণমানের মধ্যে দিন।');return n});
    const total=scores.reduce((a,n)=>a+Math.round((n||0)*100),0)/100,max=exam.subjects.reduce((a,s)=>a+s.max,0);
    const passed=scores.every((n,i)=>n!==null&&n>=exam.subjects[i].pass);
    put('results',rid,{examId:p.examId,studentId:p.studentId,classId:exam.classId,name:student.displayName,roll:student.roll,scores,total,max,passed,
      grade:passed?exam.grades.find(g=>g.min<=100*total/max).label:exam.grades.at(-1).label,revision:p.revision+1,teacherUid:actor.uid});
  }
  if(kind==='noticePublish'){
    const audience=one(p.audience,['all','teacher','guardian','office','academic','accountant']);
    put('notices',id,{title:txt(p.title,'শিরোনাম',120),body:txt(p.body,'বিজ্ঞপ্তি',2000),audience,publishedAt:now,push:p.push===true});
  }
  return null;
}

export async function reversePhase2(entry,{required,put,check}){
  const amount=entry.amountMinor;
  if(entry.originalKind==='salaryPay'){
    const s=await required('payslips',entry.slipId);
    put('payslips',entry.slipId,{...s,paidMinor:s.paidMinor-amount,advanceMinor:s.advanceMinor-(entry.advance?amount:0)});
  }
  if(entry.originalKind==='loanOpen'){
    const l=await required('loans',entry.loanId);
    check(l.paidMinor===0,'আগে পরিশোধিত কিস্তির বিপরীত এন্ট্রি দিন।');
    put('loans',entry.loanId,{...l,status:'cancelled'});
  }
  if(entry.originalKind==='loanPay'){
    const l=await required('loans',entry.loanId);
    l.installments[entry.installment].paid-=amount; l.paidMinor-=amount;
    put('loans',entry.loanId,l);
  }
}
