// Only explicitly listed fields are included in a guardian response.
export function familySummary(student,records){
  const project=(list,fields)=>list.map(r=>Object.fromEntries(fields.filter(k=>r[k]!==undefined).map(k=>[k,r[k]])));
  return {
    student:{name:student.displayName,roll:student.roll,classId:student.classId},
    attendance:project(records.attendance,['date','status']),
    results:project(records.results,['examName','grade','total','max','passed']),
    progress:project(records.hifzLogs,['date','lesson','juz','from','to','comment']),
    invoices:project(records.invoices,['id','label','period','amountMinor','paidMinor','waivedMinor']),
    messages:project(records.messages||[],['type','body','status','reply','from','to']),
    receipts:project(records.receipts,['serial','kind','date','amountMinor','direction','institution','address','party','currency'])
  };
}
