// Insert the public Web App configuration from Firebase Console.
export const firebaseConfig = null;
export const useEmulators = false;
// Firebase Console → Cloud Messaging → Web Push certificates (public VAPID key).
export const webPushKey = '';
// List each deployed branch by its public HTTPS Hosting URL.
export const branches = [];
