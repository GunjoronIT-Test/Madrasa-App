const CACHE='madrasa-shell-ce2ebd447c66';
const files=["./config.js","./index.html","./manifest.webmanifest","./premium.css","./style.css","./type-sample.css","./type-sample.html","./workspace.css","./assets/courtyard.svg","./assets/jsQR-LICENSE.txt","./js/app.js?v=a4f68feab72e97e0","./assets/fonts/FONTLOG.txt","./assets/fonts/NotoSerifByGunjoron-Bold.ttf","./assets/fonts/NotoSerifByGunjoron-Medium.ttf","./assets/fonts/NotoSerifByGunjoron-Regular.ttf","./assets/fonts/NotoSerifByGunjoron-SemiBold.ttf","./assets/fonts/OFL.txt","./assets/icons/LUCIDE-LICENSE.txt","./assets/icons/PHOSPHOR-LICENSE.txt","./assets/icons/app-192.png","./assets/icons/app-512.png","./assets/icons/book.svg","./assets/icons/ui.svg"];
self.addEventListener('install',e=>e.waitUntil(caches.open(CACHE).then(c=>c.addAll(files.map(url=>new Request(url,{cache:'reload'}))))));
self.addEventListener('activate',e=>e.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k.startsWith('madrasa-shell-')&&k!==CACHE).map(k=>caches.delete(k)))).then(()=>self.clients.claim())));
self.addEventListener('fetch',e=>{
 if(e.request.method!=='GET'||new URL(e.request.url).origin!==location.origin)return;
 if(e.request.mode==='navigate'){e.respondWith(fetch(e.request).catch(()=>caches.match('./index.html')));return;}
 if(files.some(p=>new URL(p,self.registration.scope).href===e.request.url))e.respondWith(caches.open(CACHE).then(async c=>{
 if(e.request.url.endsWith('/config.js')){try{const r=await fetch(e.request);if(r.ok){await c.put(e.request,r.clone());return r}}catch{}}
 return await c.match(e.request)||fetch(e.request)}));
});
self.addEventListener('push',event=>{
 let data;try{data=event.data?.json()?.data}catch{return}
 if(data?.type!=='madrasa-notice')return;
 event.waitUntil(self.registration.showNotification(data.institution||'মাদ্রাসা ব্যবস্থাপনা',{body:'নতুন নোটিশ দেখতে কর্মক্ষেত্র খুলুন।',tag:'notice-'+data.noticeId,icon:'./assets/icons/app-192.png',data:{notice:true}}));
});
self.addEventListener('notificationclick',event=>{
 if(!event.notification.data?.notice)return;
 event.notification.close();const url=new URL('./#notices',self.registration.scope).href;
 event.waitUntil(clients.openWindow(url));
});