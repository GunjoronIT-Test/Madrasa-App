# ফেজ ২ পরীক্ষার ফল

| পরিবেশ | কী চালানো হয়েছে | ফল |
|---|---|---|
| Firebase Firestore ও Storage Emulator, Node | npm test | ৫০ পরীক্ষা পাস। ফেজ ১-এর ৩১টি regression সহ বেতন, ঋণ, reversal, চুক্তির কার্যকর মাস, নম্বর, মেধাস্থান, প্রাপক ও জামাতভিত্তিক query পরীক্ষা |
| Auth, Firestore, Storage ও Functions Emulator | tests/cloud.mjs | অনুমোদিত অনুরোধ ও PIN যাচাইয়ের পথে কর্মী, স্লিপ, বেতন, ঋণ, কিস্তি, পরীক্ষা, নম্বর, নোটিশ, ডিভাইস নিবন্ধন/অপসারণ এবং ব্যাকআপ পরীক্ষা |
| Scheduler handler + Firestore Emulator | tests/monthly.mjs | একই মাসের handler দুবার চালিয়ে সক্রিয় চুক্তি প্রতি একটি বেতন স্লিপ ও ছাত্র প্রতি একটি মাসিক ফি দাবি |
| Chromium | tests/phase2_ui.py | বেতন সমন্বয় ও আংশিক পরিশোধ, কিস্তি, মেধা, QR-সহ বাংলা মার্কশিট, জামাতের প্রবেশপত্র, নোটিশ ও পোস্টার |
| PDF, PNG ও XLSX ফাইল | Chromium PDF, pdffonts, Pillow ও openpyxl | মার্কশিট PDF-এ Gunjoron font embedded। A4 পোস্টার ১২৪০×১৭৫৪। Excel-এর টাকার ঘর সংখ্যার ধরনে খোলে |
| Chromium · ৩৬০ পিক্সেল | নতুন রিপোর্ট স্ক্রিন | পৃষ্ঠা প্রস্থ মোবাইল পর্দার মধ্যে |
| ফেজ ১ → ফেজ ২ | tests/upgrade_ui.py, একই origin ও service worker আপডেট | আগের ছাত্রতালিকা ও লেনদেনের সারিগুলো নতুন সংস্করণে হুবহু মিলেছে |
| অফলাইন ও ব্যাকআপ regression | tests/training_ui.py, setup_ui.py, cloud_ui.py | পাঁচ ধাপের সেটআপ, Excel ভর্তি, আংশিক ফি, ব্যাকআপ ফেরানো, অফলাইন হাজিরা ও পুনঃসংযোগে দানের QR রসিদ যাচাই |
| পুশের স্থানীয় পরীক্ষা | registerPush callable, notice access rules, tests/push-worker.mjs | ডিভাইস নিবন্ধন ও অপসারণ, প্রাপকের অনুমতি, সাধারণ লক-স্ক্রিন বার্তা, নোটিশ খোলার লিংক যাচাই |

বাস্তব FCM ডেলিভারি ও নির্ধারিত সময়ে Google Cloud Scheduler থেকে কল যাচাইয়ের জন্য প্রতিষ্ঠানের test project ও অনুমোদিত ফোন লাগবে। মুদ্রণের পরীক্ষা Chromium-এর PDF আউটপুটে হয়েছে। শারীরিক প্রিন্টারে প্রতিষ্ঠানের কাগজ ও মার্জিন অনুযায়ী একটি নমুনা মিলিয়ে নিন।

## পুনরায় চালাতে

Node.js ২২ ও JDK ২১ দিয়ে madrasa ফোল্ডারে চালান।

```sh
npm ci
npm ci --prefix functions
npm run build
npm test
npm run test:cloud
```

ব্রাউজার যাচাইয়ের জন্য Python Playwright, Chromium, Pillow, openpyxl ও pdffonts ব্যবহার করা হয়েছে। npm start চালিয়ে অন্য টার্মিনালে নিচের কমান্ড দিন। CHROMIUM ও APP_URL দিয়ে executable ও ঠিকানা বদলানো যায়।

```sh
python tests/phase2_ui.py
python tests/upgrade_ui.py /path/to/phase-1/madrasa/public
```

মাসিক স্লিপ, আগের ফি scheduler ও ক্লাউড সিঙ্ক একই emulator session-এ যাচাইয়ের কমান্ড নিচে দেওয়া আছে।

```sh
npx firebase emulators:exec --only firestore,storage,auth,functions --project demo-madrasa "node tests/cloud.mjs && node tests/monthly.mjs && python tests/cloud_ui.py"
```
