# ফেজ ২-এর ডেটা ও অনুমতি

একই branches/main ও আগের request queue ব্যবহৃত হয়। আর্থিক অবস্থা, রসিদ, খাতা, ব্যালেন্স ও অডিট একই transaction-এ লেখা হয়। সব অর্থ পূর্ণসংখ্যা পয়সায়।

| কালেকশন | সম্পর্ক ও গুরুত্বপূর্ণ ফিল্ড |
|---|---|
| staff, payContracts | একই staffId; পদ, ফোন, যোগদান ও সক্রিয়তা। payContracts-এ baseMinor ও কার্যকর মাসভিত্তিক rates |
| staffAttendance | staffId_date অনুযায়ী দৈনিক অবস্থা ও ছুটির কারণ |
| payslips | staffId_period; মূল বেতন, বোনাস, কর্তন, প্রাপ্য, paidMinor ও advanceMinor। অগ্রিম paidMinor-এর একটি অংশ |
| salaryPayments | পরিশোধের অনুরোধ নম্বরই ledgerId। বিপরীত জার্নাল মূল এন্ট্রির রেফারেন্স বহন করে |
| loans | side, party, principalMinor, paidMinor ও মাসিক installments তালিকা। প্রতি কিস্তির due, expected ও paid থাকে |
| loanPayments | loanId, কিস্তির সূচক, amountMinor ও ledgerId |
| exams | জামাত, কক্ষ, বোর্ড, শিক্ষাবর্ষ, বিষয়ভিত্তিক সময়সূচি, পূর্ণমান, পাস ও গ্রেড সীমা |
| results | examId_studentId; ছাত্র পরিচয়ের snapshot, scores, total, max, grade, passed ও revision। মেধাক্রম পরীক্ষার result set থেকে নির্ণীত |
| notices | প্রকাশক নিয়ন্ত্রিত শিরোনাম, body, audience, publishedAt ও push পছন্দ |
| pushDevices, pushReceipts | project-স্তরের server-only ডিভাইস নিবন্ধন ও পাঠানোর রেকর্ড। শাখার JSON ব্যাকআপে পুশ টোকেন যায় না |

সরাসরি client write বন্ধ। বেতন, ঋণ, কিস্তি ও কর্মীর চুক্তির সংবেদনশীল পরিবর্তনে সাম্প্রতিক পরিচয় ও পিন লাগে। মুহতামিম/নায়েব কর্মী সম্পাদনা করেন। অফিস কর্মী হাজিরা ও ছুটি লেখেন। হিসাবরক্ষক বেতন ও ঋণ পরিচালনা করেন। ওস্তাদের প্রশ্ন ও নম্বরের অনুমতি জামাতের classIds দিয়ে সীমিত। প্রকাশিত নোটিশের Firestore query-তে ‘all’ ও নিজের role দিয়ে audience filter লাগে।

নতুন মূল ফাইল functions/phase2.js (লেনদেন, শিক্ষা ও নোটিশের নিয়ম), src/phase2.js (স্ক্রিন ও নথি), src/exports.js (XLSX ও পোস্টার), src/list-tools.js (তালিকা খোঁজ ও ক্রম)। functions/index.js-এ FCM ও মাসিক বেতন, src/cloud.js-এ সীমিত query ও পুশ নিবন্ধন, build.mjs-এ notification service worker যুক্ত হয়েছে।
