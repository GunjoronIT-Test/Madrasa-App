# ডেটা অভিধান

প্রতি প্রতিষ্ঠানের আলাদা Firebase project। একটি সক্রিয় শাখা দিয়ে শুরু। সকল ব্যবসায়িক রেকর্ডের পথ `branches/{branchId}/{collection}/{id}`। প্রতিটি রেকর্ডে branchId, schemaVersion (integer), createdAt, updatedAt (server timestamp)। ঐচ্ছিক মান বাদ যায়। date ধরনের দিন YYYY-MM-DD, মাস YYYY-MM, সময় Asia/Dhaka। *Id একই শাখার রেকর্ডের string ID, *Uid Auth UID, [] তালিকা, *Minor পূর্ণসংখ্যা পয়সা। পরিমাণ integer, গ্রেড/নম্বর নীতিমালা প্রতিষ্ঠান নির্ধারণ করবে। সাধারণ নাম ও মন্তব্য string, active ও absent boolean। সার্ভার সম্পর্ক ও সীমা যাচাই করবে।

| কালেকশন | ব্যবহার | নিজস্ব ফিল্ড | পাঠাধিকার গোষ্ঠী |
|---|---|---|---|
| `applications` | আবেদন | `studentName guardianName phone departmentId classId status examScore documentIds[] appliedOn` | office |
| `students` | ছাত্রের সাধারণ পরিচিতি | `displayName roll classId departmentId academicYearId residentialStatus admissionId status photoPath` | office |
| `studentPrivate` | শিক্ষার্থী ও অভিভাবকের সীমিত তথ্য | `studentId guardianIds[] address phone birthDate healthNote welfareFlags[] documentIds[]` | office |
| `enrolments` | শ্রেণি ও বর্ষ পরিবর্তনের ইতিহাস | `studentId classId academicYearId startDate endDate status` | office |
| `discipline` | আচরণের রেকর্ড | `studentId date note action` | office |
| `staff` | কর্মীদের যোগাযোগ ও নিয়োগ | `displayName phone designation joinedOn status` | office |
| `staffAttendance` | কর্মী হাজিরা | `staffId date status` | office |
| `leaveRequests` | ছুটি | `applicantUid studentId staffId fromDate toDate reason status` | office |
| `departments` | বিভাগ | `name active` | academic |
| `classes` | জামাত | `name departmentId academicYearId` | academic |
| `academicYears` | শিক্ষাবর্ষ | `label startsOn endsOn status` | academic |
| `subjects` | বিষয় | `name classId fullMarks passMarks` | academic |
| `routines` | রুটিন | `classId staffId subjectId weekday startsAt endsAt roomId` | academic |
| `holidays` | ছুটি ও ক্যালেন্ডার | `title startsOn endsOn hijriLabel` | academic |
| `attendance` | ছাত্র হাজিরা | `studentId classId date status teacherUid` | academic |
| `exams` | পরীক্ষা ও বোর্ড | `name board gradingScale academicYearId` | academic |
| `examSessions` | পরীক্ষার সময়সূচি | `examId subjectId classId date startsAt roomId` | academic |
| `examSeats` | আসন ও রোল | `examId studentId seatNumber roll` | academic |
| `marks` | নম্বর | `examId subjectId studentId score absent teacherUid` | academic |
| `results` | প্রকাশিত ফল | `examId studentId total grade rank publishedAt` | academic |
| `hifzLogs` | সবক সবকি আমুখতা | `studentId classId date lessonType juz pageFrom pageTo comment teacherUid` | academic |
| `funds` | তহবিল | `name purpose spendingRestrictions active` | finance |
| `accounts` | নগদ ব্যাংক ও মোবাইল হিসাব | `label kind openingTransactionId` | finance |
| `ledger` | আর্থিক জার্নাল | `kind fundId accountId amountMinor direction businessDate sourceType sourceId reversalOf receiptId actorUid requestId` | finance |
| `feePlans` | ফি কাঠামো | `classId category amountMinor frequency academicYearId` | finance |
| `invoices` | ফি দাবি | `studentId feePlanId period dueDate amountMinor` | finance |
| `allocations` | আংশিক পরিশোধ ও মওকুফ | `invoiceId ledgerId kind amountMinor reason approvedBy` | finance |
| `receipts` | রসিদ | `serial ledgerId issuedAt partyLabel verificationId` | finance |
| `payContracts` | বেতন কাঠামো | `staffId baseMinor effectiveDate` | finance |
| `payslips` | বেতন দাবি | `staffId month baseMinor bonusMinor advanceMinor deductionMinor netMinor` | finance |
| `salaryPayments` | বেতন পরিশোধ | `payslipId amountMinor ledgerId` | finance |
| `donors` | দাতা | `displayName phone consent collectorId` | finance |
| `pledges` | প্রতিশ্রুত দান | `donorId campaignId expectedMinor dueDate` | finance |
| `campaigns` | দান অভিযান | `title fundId targetMinor startsOn endsOn` | finance |
| `collections` | দান ও সংগ্রাহক | `donorId collectorId campaignId pledgeId ledgerId commissionMinor` | finance |
| `loans` | ঋণ ও পাওনা | `partyName direction principalMinor openedOn accountId` | finance |
| `instalments` | কিস্তি | `loanId dueDate expectedMinor` | finance |
| `loanPayments` | কিস্তি পরিশোধ | `instalmentId ledgerId amountMinor` | finance |
| `approvals` | ব্যয়সীমা ও অনুমোদন | `requestId requestedBy reviewedBy status limitMinor` | finance |
| `events` | অনুষ্ঠান | `title date venue budgetMinor campaignId` | ops |
| `eventTasks` | কমিটি ও কাজ | `eventId title ownerUid dueDate status` | ops |
| `eventGuests` | বক্তা ও অতিথি | `eventId displayName responsibility` | ops |
| `media` | অনুষ্ঠানের মিডিয়া | `eventId storagePath caption consent` | ops |
| `rooms` | আবাসিক কক্ষ | `name capacity` | ops |
| `beds` | সিট বরাদ্দ | `roomId bedLabel studentId startsOn endsOn` | ops |
| `meals` | দৈনিক মিল | `date mealType count costMinor ledgerId` | ops |
| `stockItems` | স্টক | `name unit minimumQty` | ops |
| `stockMoves` | স্টকের পরিবর্তন | `itemId date signedQty reason` | ops |
| `assets` | স্থায়ী সম্পদ | `name acquiredOn valueMinor location` | ops |
| `repairs` | মেরামত | `assetId date detail ledgerId` | ops |
| `books` | কিতাবের কপি | `title author accessionNo` | ops |
| `bookLoans` | ইস্যু ও ফেরত | `bookId studentId issuedOn dueDate returnedOn` | ops |
| `notices` | নোটিশের মূল কপি | `title body audience publishAt` | admin |
| `templates` | বার্তা ও পোস্টারের নকশা | `kind title content size` | admin |
| `documents` | প্রবেশপত্র মার্কশিট সনদ TC ও পরিচয়পত্র | `kind studentId staffId serial issuedAt snapshot verificationId` | admin |
| `messages` | বার্তা পাঠানোর ইতিহাস | `templateId recipientUid channel status providerRef` | admin |
| `feedback` | অভিযোগ ও পরামর্শ | `senderUid message submittedAt status` | admin |
| `devices` | পুশ সাবস্ক্রিপশন | `ownerUid token updatedAt` | admin |
| `paymentOrders` | গেটওয়ে অর্ডার | `invoiceId provider expectedMinor providerRef status` | admin |
| `paymentEvents` | ওয়েবহুক পুনরাবৃত্তি যাচাই | `provider eventId orderId verifiedAt` | admin |
| `scans` | কিউআর হাজিরা | `studentId nonce scannedAt attendanceId` | admin |
| `audit` | অডিট | `actorUid action targetId requestId occurredAt changedFields[]` | admin |
| `backupRuns` | ব্যাকআপের তালিকা | `storagePath checksum schemaVersion completedAt restoreTestAt` | admin |
| `aggregates` | অনুমোদিত সারাংশ | `period metric value computedAt` | admin |
| `trash` | পুনরুদ্ধার তালিকা | `sourceCollection sourceId removedAt removedBy` | admin |

## পরিচয়, সেটিংস ও ব্যক্তিগত ভিউ

- `settings/institution` প্রকাশযোগ্য ব্র্যান্ড রেকর্ড। branchId, nameBn, nameEn, slogan, logoPath, address, publicPhone, publicEmail, website, establishedYear, registrationNo, principalName, primaryColor, accentColor, currency, yearStartMonth। সিল ও স্বাক্ষর আলাদা সীমিত পথে।
- `branches/{b}` শাখার নাম ও সক্রিয় অবস্থা। `branches/{b}/members/{uid}` এর branchId, role ও active বিশ্বস্ত প্রশাসনিক প্রক্রিয়া থেকে লেখা হয়। সর্বোচ্চ পদ principal, তার পর deputy। office, academic, accountant নিজ নিজ গোষ্ঠী পড়তে পারেন। teacher ও guardian শুধু নিজের প্রকাশিত ভিউ পান। staff ব্যক্তিগত রেকর্ড ও অ্যাকাউন্টের UID আলাদা।
- `branches/{b}/views/{uid}/items/{id}` এর kind, sourceId, branchId, publishedAt, payload। যাচাইকৃত অভিভাবক-সন্তান সম্পর্ক বা ওস্তাদের নির্ধারিত জামাত অনুযায়ী সার্ভার অনুমোদিত ফিল্ড বেছে প্রকাশ করবে। সম্পর্ক বদলালে পুরনো ভিউ সরাতে হবে। `assignments/{id}` এর uid, studentId বা classId, kind, active শাখার অধীনে সার্ভার নিয়ন্ত্রিত।
- `branches/{b}/requests/{uuid}` অফলাইন ইনপুটের রসিদ। actorUid, branchId, kind, payload, createdAt, status। ক্লায়েন্ট শুধু queued অবস্থায় নিজের অনুরোধ তৈরি করে। প্রসেসর সদস্যপদ, scope, ইনপুট, সম্পর্ক ও অনুমোদন পুনরায় যাচাই করে ফল প্রকাশ করবে। প্রক্রিয়াকরণ ও ভিউ প্রকাশ ফেজ ১-এর কাজ।
- `branches/{b}/uniqueKeys/{id}` এ kind, sourceId, branchId। ভর্তি রোল, মাসিক ফি, মাসিক বেতন, যাচাই সিরিয়াল ও গেটওয়ে eventId-র নির্দিষ্ট key এবং সংশ্লিষ্ট রেকর্ড একই transaction-এ তৈরি হবে।
- Storage-তে `branches/{b}/private/{studentId}/{fileId}` ছাত্রের ফাইল, `branches/{b}/finance/{entryId}/{fileId}` ভাউচার, `branches/{b}/seals/{fileId}` সিল, `branding/{fileId}` প্রকাশযোগ্য লোগো। ফাইলের ধরন, সাইজ ও মালিকানা যাচাই করে বিশ্বস্ত uploader লিখবে। ব্যক্তিগত ফাইলে স্থায়ী share token দেওয়া যাবে না।

## হিসাব ও পুনরুদ্ধারের চুক্তি

একই requestId পুনরায় এলে আগের ফল ফেরত দিতে হবে। পেমেন্ট, বরাদ্দ, ব্যালেন্স, অডিট ও রসিদ একই transaction-এ। বাতিলের জন্য মূল এন্ট্রি অপরিবর্তিত রেখে বিপরীত direction সহ reversalOf লিখতে হবে। একবারের বেশি reversal, অতিরিক্ত মওকুফ, বন্ধ তহবিল এবং সীমার বেশি ব্যয় অনুমোদন ছাড়া প্রত্যাখ্যান। চূড়ান্ত রসিদ সার্ভার স্বীকার করলে ইস্যু হবে। অফলাইনে স্থানীয় অনুরোধ নম্বরসহ অস্থায়ী প্রাপ্তিস্বীকার।

ছাত্র হাজিরার key = তারিখ ও studentId, মাসিক invoice key = period, studentId ও feePlanId। সমসাময়িক সংশোধনে revision মিলিয়ে নিতে হবে। রুটিনে জামাত/ওস্তাদ/কক্ষ একই সময়ে দ্বিতীয়বার বরাদ্দ বন্ধ করতে হবে। ডুপ্লিকেট ফোন একটি সতর্কতা, কারণ ভাইবোনের অভিভাবক একই হতে পারেন।

ব্যাকআপে version, শাখা, তারিখ, record count, checksum ও ফাইল manifest থাকবে। পৃথক পরীক্ষার project-এ restore করে মোট টাকা, ছাত্রসংখ্যা ও নমুনা সংযুক্তি মিলিয়ে তারপর বাস্তব পুনরুদ্ধার। আর্থিক ও audit রেকর্ড recycle bin-এর বাইরে থাকবে।
