# ফেজ ১-এর কার্যকর ডেটা চুক্তি

ফেজ ০-এর অভিধান দীর্ঘমেয়াদি মডিউলগুলোর পরিকল্পনা। এই সংস্করণের রেকর্ডের নির্দিষ্ট ফিল্ড ও validation-এর কর্তৃত্বপূর্ণ উৎস functions/domain.js। সব পরিচালন রেকর্ড branches/main-এর অধীনে। নিচের ফিল্ডগুলো অফিস ও হিসাবের স্ক্রিনগুলো সরাসরি ব্যবহার করে।

| পথ | কাজ |
|---|---|
| settings/institution | প্রকাশ্য নাম, রঙ, লোগো, জামাতের নাম, ফি, শিক্ষাবর্ষ ও printVersion। ছাত্রের ব্যক্তিগত নথি ও সিল আলাদা |
| printBrands/{version} | প্রকাশের সময়কার লোগো, সিল ও স্বাক্ষর। অর্থ বিভাগের পাঠাধিকার দিয়ে রসিদে লোড হয় |
| members/{uid} | শাখা ও সক্রিয় রোল। ওস্তাদের classIds-এ অনুমোদিত জামাতের নাম |
| requests/{uuid} | client command। queued থেকে accepted বা rejected। server timestamp, ফল ও ব্যর্থতার বাংলা কারণ |
| students, enrolments, applications | ব্যক্তিগত ছাত্র রেকর্ড, ভর্তির সময় রোল ও পরবর্তী জামাত পরিবর্তনের ইতিহাস |
| roster/{studentId} | নাম, রোল, জামাত, ভর্তি তারিখ, শিক্ষাবর্ষ ও অবস্থা। ওস্তাদ শুধুমাত্র নির্ধারিত জামাত পাঠ করেন |
| studentPrivate, studentFiles | অভিভাবক, ফোন, স্বাস্থ্য নোট, ফাইল manifest। ফাইল প্রথমে সুরক্ষিত সার্ভার রেকর্ডে আসে, তারপর Storage-এ কপি হলে staging bytes সরানো হয় |
| counters/roll, uniqueKeys | একই transaction-এ রোল বরাদ্দ ও পরিচয়ের পুনরাবৃত্তি রোধ |
| attendance/{studentId_date} | status, classId, teacherUid ও revision |
| invoices | ভর্তি বা মাসিক দাবির amountMinor, paidMinor, waivedMinor। বকেয়া এই তিন মান থেকে হিসাব হয় |
| ledger, receipts, allocations, reversals | অপরিবর্তনীয় এন্ট্রি, রসিদ snapshot, ফি সমন্বয় ও একবারের বাতিল |
| balances | স্থিতি fund ও account-এর জোড়ায়। পরিমাণ পূর্ণসংখ্যা পয়সা, direction হলো ১, −১ বা ০ |
| collections | দানের এন্ট্রি, দাতার নাম ও তহবিল। pledge ও প্রচারাভিযানের বিস্তৃত ব্যবস্থাপনা পরের মডিউলের বিষয় |
| approvals | সীমার বেশি ব্যয়। সিদ্ধান্তের সময় আবার তহবিল যাচাই করে খরচ লেখা হয় |
| audit/{requestId} | action, actorUid, result ও সময়। একই requestId পুনরায় এলে আগের ফল |
| confirmations, securityPins | confirmation শাখার অধীনে। PIN verifier project-স্তরের securityPins/{uid}-এ। সাধারণ ক্লায়েন্ট থেকে পাঠ বা লেখা বন্ধ |

আর্কাইভ করা ছাত্রের মূল পরিচয় ও আর্থিক ইতিহাস থাকে। জামাতের পরিচয় হিসেবে এই সংস্করণে প্রতিষ্ঠানের কনফিগার করা নাম ব্যবহৃত হয়। আগে ব্যবহৃত জামাতের নাম রেখে নতুন জামাত যোগ করা যায়। ঋণ, বেতন ও ইভেন্টের তথ্য সংশ্লিষ্ট ফেজে যুক্ত হবে।
