# Firebase চালুর নির্দেশিকা

স্থানীয় ফেজ ০ চালাতে README অনুসরণ করুন। বাস্তব প্রতিষ্ঠানের জন্য নিচের ধাপগুলো একটি নতুন পরীক্ষামূলক project দিয়ে শুরু করুন।

১. Firebase Console-এ project তৈরি করে মালিক ও বিলিংয়ের দায়িত্ব নির্ধারণ করুন। প্রতি মাদ্রাসার আলাদা project রাখার নকশা ব্যবহার করা হয়েছে। সেটিংস থেকে Web App নিবন্ধন করে web config সংরক্ষণ করুন।
২. Authentication → Sign-in method-এ Email/Password চালু করুন। Firestore-এর (default) database production mode-এ খুলুন। ডেটা কোথায় থাকবে ঠিক করে location বেছে নিন। Storage bucket তৈরির সময় Console-এর Blaze billing requirement ও location দেখুন। বিলিং চালুর আগে budget alert দিন। alert খরচের সীমা প্রয়োগ করে না।
৩. স্থানীয় পরীক্ষার পর শুধু নতুন test project-এর ID বসিয়ে নিচের কমান্ড চালান। ডেপ্লয় করলে ওই project-এর রুলস ও hosting content বদলাবে। Storage Rules থেকে Firestore পড়ার অনুমতি চাওয়া হলে সংশ্লিষ্ট সেবা-পরিচয় ও project মিলিয়ে দিন।

```sh
npx firebase login
npx firebase projects:list
npx firebase deploy --only firestore:rules,firestore:indexes,storage,hosting --project YOUR_TEST_PROJECT_ID
```

৪. প্রথম মুহতামিমের ইমেইল Authentication-এ তৈরি করে UID কপি করুন। নিয়ন্ত্রিত Console থেকে branches/main ডকুমেন্টে branchId = main ও active = true দিন। branches/main/members/{UID} ডকুমেন্টে branchId = main, role = principal ও active = true লিখুন। পরের সংস্করণে এই আমন্ত্রিত পরিচয় দিয়েই সেটআপ সম্পন্ন হবে। সাধারণ নিবন্ধন থেকে পদ দেওয়ার সুযোগ থাকবে না।
৫. settings/institution প্রকাশ্য পাঠযোগ্য। এখানে শুধু প্রকাশযোগ্য ব্র্যান্ড তথ্য দিন। সিল, ব্যক্তিগত নম্বর, শিশুর ছবি বা credentials রাখবেন না। ব্যক্তিগত ফাইল ও server credentials-এর জন্য নির্ধারিত সীমিত পথ ব্যবহার করুন।
৬. ফেজ ১-এ বিশ্বস্ত server processor লাগবে। কাজটি Cloud Functions দিয়ে করলে billing যুক্ত করতে হবে। Admin SDK রুলসের বাইরে কাজ করে, তাই প্রতিটি command-এ সদস্যপদ, শাখা, অনুমোদন, ইনপুট ও পুনরাবৃত্তি সার্ভারেই যাচাই করতে হবে। service account key বা পাসওয়ার্ড চ্যাটে শেয়ার করার প্রয়োজন নেই।
৭. বাস্তব চালুর আগে আলাদা test project থেকে read/write ও restore পরীক্ষা করুন। পূর্ণ ব্যাকআপে Firestore, Storage ফাইল ও পরিচয় পুনরুদ্ধারের আলাদা পরিকল্পনা রাখুন। উৎপাদনে প্রবেশাধিকার শুধু নির্ধারিত অপারেটরদের দিন।

Supabase এই নকশায় প্রয়োজন নেই। ফেজ ২-এ push চালুর সময় FCM ও Web Push VAPID সেটিংস, ফেজ ৪-এ SMS gateway ও bKash/Nagad merchant sandbox লাগবে। ওই পর্যায়ে provider, খরচ ও callback ঠিকানা নিশ্চিত করতে হবে।
