# ফেজ ১ যাচাই

| পরিবেশ | পরীক্ষা | পর্যবেক্ষণ |
|---|---|---|
| Firestore ও Storage Emulator | ফেজ ০-এর ২২টি অনুমতি পরীক্ষা | সব পাস। অন্য শাখা, নিজে রোল বদলানো, ব্যক্তিগত ফাইল ও সরাসরি ledger লেখা/মোছার নিষেধাজ্ঞা বহাল |
| Node.js | হিসাব ও ছাত্রের ৯টি পরীক্ষা | আংশিক ফি, একই অনুরোধের retry, মওকুফ, বাতিল, তহবিলের ঘাটতি, অনুমোদন, পুনর্বহাল, হাজিরার revision, প্রোফাইল ও ফি খাত যাচাই হয়েছে |
| Firebase Auth, Firestore, Functions ও Storage Emulator | tests/cloud.mjs | লগইন, ভুল পিন প্রত্যাখ্যান, ভর্তি নথি গ্রহণ ও পাঠ, অফলাইন হাজিরা ও ফি, PIN-সহ reversal, বকেয়া এবং export মিলেছে |
| Chromium | tests/setup_ui.py | পাঁচ ধাপে খালি প্রতিষ্ঠান তৈরি, Excel থেকে ভর্তি ও ব্যক্তিগত প্রোফাইল পরিবর্তন |
| Chromium | tests/training_ui.py | ডেমো ভর্তি, আংশিক ফি, QR রসিদ, JSON ডাউনলোড ও ফেরানো, অফলাইন রিলোডের পরে হাজিরা। ৩৬০ পিক্সেলে পৃষ্ঠা প্রস্থ ও গুঞ্জরণ ফন্ট পরীক্ষা |
| Chromium ও Firebase Emulator | tests/cloud_ui.py | ব্যক্তিগত ডিভাইসে লগইন, নেট বন্ধ রেখে দান, অস্থায়ী প্রাপ্তিস্বীকার, পুনঃসংযোগে গৃহীত রসিদ, লগআউট |
| Firestore Emulator | tests/monthly.mjs | ঢাকার সময় মাসের প্রথম দিনে একই scheduled handler দুবার চালিয়ে প্রত্যেক সক্রিয় ছাত্রের একটি দাবি পাওয়া গেছে |
| আলাদা emulator project | scripts/restore-emulator.mjs | ১২৫টি রেকর্ডের ক্লাউড ব্যাকআপ পুনরুদ্ধার করে হিসাব ও সংযুক্তি মিলেছে। মহড়ার নিট স্থিতি ৭৭০০ পয়সা |

উৎপাদনের Firebase project, billing, বাস্তব ব্যবহারকারী ও Android যন্ত্রে স্থাপনের পরীক্ষা প্রতিষ্ঠানের নিজস্ব test project-এ করতে হবে। Scheduler-এর handler স্থানীয়ভাবে চালানো হয়েছে। বাস্তব সময়ে Google Cloud Scheduler থেকে ডেলিভারি যাচাইয়ের জন্য deploy করা job প্রয়োজন।

## পরীক্ষা আবার চালানো

সাধারণ regression-এর জন্য docs/phase-1.md-তে দেওয়া npm test ও npm run test:cloud ব্যবহার করুন। Chromium পরীক্ষার জন্য Python, Playwright ও Chromium প্রয়োজন। app URL ও Chromium executable-এর অবস্থান APP_URL ও CHROMIUM দিয়ে বদলানো যায়।

```sh
npm start
```

অন্য টার্মিনালে Linux/macOS-এ চালান।

```sh
APP_URL=http://127.0.0.1:4173 python tests/setup_ui.py
APP_URL=http://127.0.0.1:4173 python tests/training_ui.py
```

Cloud browser ও scheduler পরীক্ষার জন্য একই লোকাল emulator session চালু রাখুন। test fixture শুধুমাত্র demo-madrasa project ও loopback host গ্রহণ করে।

```sh
npx firebase emulators:start --only auth,firestore,storage,functions --project demo-madrasa
```

অন্য টার্মিনালে চালান।

```sh
FIRESTORE_EMULATOR_HOST=127.0.0.1:8080 FIREBASE_AUTH_EMULATOR_HOST=127.0.0.1:9099 node tests/cloud.mjs
python tests/cloud_ui.py
GCLOUD_PROJECT=demo-madrasa FIRESTORE_EMULATOR_HOST=127.0.0.1:8080 node tests/monthly.mjs
```
