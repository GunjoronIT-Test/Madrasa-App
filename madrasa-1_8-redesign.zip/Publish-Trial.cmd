@echo off
setlocal
where git >nul 2>nul
if errorlevel 1 (
  echo Install Git for Windows from https://git-scm.com/downloads/win then run this file again.
  pause
  exit /b 1
)
set "trial_work=%TEMP%\madrasa-trial-%RANDOM%-%RANDOM%"
git clone --branch android-trial "%~dp0madrasa-android-trial.bundle" "%trial_work%"
if errorlevel 1 goto failed
git -C "%trial_work%" remote set-url origin https://github.com/gunjoron-test/Madrasa-App.git
git -C "%trial_work%" push origin HEAD:refs/heads/android-trial
if errorlevel 1 goto failed
start "" "https://github.com/gunjoron-test/Madrasa-App/actions"
echo Uploaded android-trial. Open the latest Android trial APK run.
pause
exit /b 0
:failed
echo Upload did not finish. See the Git message above. Your files are unchanged.
pause
exit /b 1
