# JS Bridge মেথডগুলো চালু রাখা
-keepclassmembers class com.madrasa.darululum.app.MainActivity$AndroidBridge {
    @android.webkit.JavascriptInterface <methods>;
}

# সর্বোচ্চ অবফাসকেশন ও লগ রিমুভাল (releaseHardened-এর জন্য)
-repackageclasses 'o'
-allowaccessmodification
-optimizationpasses 5
-assumenosideeffects class android.util.Log {
    public static boolean isLoggable(java.lang.String, int);
    public static int v(...);
    public static int d(...);
    public static int i(...);
    public static int w(...);
    public static int e(...);
}
