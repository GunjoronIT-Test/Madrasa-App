/**
 * ফায়ারবেজ কনফিগারেশন টেমপ্লেট (White-Label Deployment)
 *
 * নির্দেশনা:
 * ১. এই ফাইলটি কপি করে একই ফোল্ডারে `firebase-config.js` নামে সেভ করুন।
 * ২. আপনার Firebase Console > Project Settings > Web App থেকে প্রাপ্ত মানগুলো নিচে বসান।
 * ৩. ভিন্ন মাদ্রাসার জন্য শুধু এই একটি ফাইল বদলালেই হবে, অ্যাপের মূল কোডে হাত দিতে হবে না।
 */
export const firebaseConfig = {
  apiKey: "PASTE_YOUR_API_KEY",
  authDomain: "YOUR_PROJECT_ID.firebaseapp.com",
  projectId: "YOUR_PROJECT_ID",
  storageBucket: "YOUR_PROJECT_ID.firebasestorage.app",
  messagingSenderId: "PASTE_YOUR_MESSAGING_SENDER_ID",
  appId: "PASTE_YOUR_APP_ID"
};

/**
 * লোকাল ডেভেলপমেন্টে Firebase Emulator ব্যবহার করতে চাইলে true করুন।
 * প্রোডাকশনে সবসময় false রাখুন।
 */
export const USE_FIREBASE_EMULATOR = false;
