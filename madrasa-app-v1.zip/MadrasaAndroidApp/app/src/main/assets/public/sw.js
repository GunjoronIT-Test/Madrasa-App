const CACHE_NAME = 'madrasa-app-v4-final';
const CORE_ASSETS = [
  './',
  './index.html',
  './manifest.json',
  './css/tokens.css',
  './css/base.css',
  './css/print.css',
  './assets/icons/icons.svg',
  './assets/fonts/NotoSerifByGunjoron-Regular.ttf',
  './assets/fonts/NotoSerifByGunjoron-Medium.ttf',
  './assets/fonts/NotoSerifByGunjoron-SemiBold.ttf',
  './assets/fonts/NotoSerifByGunjoron-Bold.ttf',
  './js/app.js',
  './js/core/firebase.js',
  './js/core/store.js',
  './js/core/brand.js',
  './js/core/icons.js',
  './js/core/auth.js',
  './js/core/router.js',
  './js/core/utils.js',
  './js/core/qr.js',
  './js/core/audit.js',
  './js/core/demo-data.js'
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => cache.addAll(CORE_ASSETS)).then(() => self.skipWaiting())
  );
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(keys.filter((k) => k !== CACHE_NAME).map((k) => caches.delete(k)))
    ).then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', (event) => {
  if (event.request.method !== 'GET') return;
  const url = new URL(event.request.url);
  if (url.origin !== self.location.origin) return;

  event.respondWith(
    caches.match(event.request).then((cached) => {
      const networkFetch = fetch(event.request)
        .then((res) => {
          if (res && res.status === 200) {
            const copy = res.clone();
            caches.open(CACHE_NAME).then((cache) => cache.put(event.request, copy));
          }
          return res;
        })
        .catch(() => cached);
      return cached || networkFetch;
    })
  );
});
