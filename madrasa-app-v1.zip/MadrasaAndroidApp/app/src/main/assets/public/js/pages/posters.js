import { getBrand } from '../core/brand.js';
import { icon } from '../core/icons.js';
import { escapeHtml, showToast } from '../core/utils.js';

const POSTER_TEMPLATES = {
  mahfil: { label: 'বার্ষিক ওয়াজ মাহফিল', badge: 'দ্বীনি মাহফিল বিজ্ঞপ্তি', headline: 'বার্ষিক ওয়াজ ও দোয়ার মাহফিল', subtitle: 'প্রধান মেহমান: হযরত মাওলানা ...', details: 'তারিখ: আগামী শুক্রবার | সময়: বাদ আসর\nস্থান: মাদ্রাসা প্রাঙ্গণ' },
  admission: { label: 'ভর্তি বিজ্ঞপ্তি', badge: 'নতুন শিক্ষাবর্ষে ভর্তি চলছে', headline: 'মক্তব, নাজেরা, হিফজ ও কিতাব বিভাগে ভর্তি', subtitle: 'আবাসিক, অনাবাসিক ও লিল্লাহ বোর্ডিং ব্যবস্থা', details: 'ভর্তির শেষ তারিখ: ...\nঅফিসে যোগাযোগ করুন সকাল ৮টা – বিকাল ৪টা' },
  ramadan: { label: 'রমযান / ঈদ বিজ্ঞপ্তি', badge: 'মাহে রমযান ও ঈদ শুভেচ্ছা', headline: 'পবিত্র মাহে রমযানের মুবারকবাদ', subtitle: 'সকল অভিভাবক, দাতা ও শুভানুধ্যায়ীদের প্রতি শুভেচ্ছা', details: 'যাকাত, সদকা ও ফিতরা দিয়ে এতিম ও লিল্লাহ ছাত্রদের পাশে থাকুন।' },
  donation: { label: 'দান ও যাকাত আবেদন', badge: 'সদকায়ে জারিয়া', headline: 'এতিম ও লিল্লাহ বোর্ডিংয়ে আপনার যাকাত দান করুন', subtitle: 'আপনার দানে গড়ে উঠবে একজন হাফেজ ও আলেম', details: 'বিকাশ / ব্যাংক অ্যাকাউন্ট নম্বর অফিসে জানুন।' },
  notice: { label: 'জরুরি নোটিশ', badge: 'অফিশিয়াল বিজ্ঞপ্তি', headline: 'জরুরি সাধারণ বিজ্ঞপ্তি', subtitle: 'সকল ছাত্র ও অভিভাবকের অবগতির জন্য', details: 'বিস্তারিত তথ্যের জন্য মাদ্রাসা অফিসে যোগাযোগ করুন।' }
};

const SIZES = {
  fb: { label: 'ফেসবুক পোস্ট (1080×1080)', w: 1080, h: 1080 },
  a4: { label: 'A4 প্রিন্ট (794×1123)', w: 794, h: 1123 },
  story: { label: 'স্টোরি / স্ট্যাটাস (1080×1920)', w: 1080, h: 1920 }
};

export async function renderPosters(container) {
  const brand = getBrand() || {};
  let tplKey = 'mahfil';
  let sizeKey = 'fb';

  container.innerHTML = `
    <div class="page-header no-print">
      <div>
        <h1>অটো পোস্টার জেনারেটর</h1>
        <p class="page-subtitle">মাদ্রাসার নাম, লোগো, ঠিকানা ও রঙ স্বয়ংক্রিয়ভাবে বসবে — PNG ডাউনলোড বা প্রিন্ট করুন</p>
      </div>
      <div style="display:flex;gap:8px;">
        <button type="button" class="btn btn-secondary btn-sm" id="pst-print">${icon('print', 'sm')} প্রিন্ট / PDF</button>
        <button type="button" class="btn btn-primary btn-sm" id="pst-download">${icon('download', 'sm')} PNG ডাউনলোড</button>
      </div>
    </div>

    <div class="card no-print">
      <div class="form-grid cols-2">
        <div class="form-group">
          <label class="form-label">টেমপ্লেট নির্বাচন</label>
          <select id="pst-tpl" class="form-control">
            ${Object.entries(POSTER_TEMPLATES).map(([k, v]) => `<option value="${k}">${v.label}</option>`).join('')}
          </select>
        </div>
        <div class="form-group">
          <label class="form-label">পোস্টারের সাইজ</label>
          <select id="pst-size" class="form-control">
            ${Object.entries(SIZES).map(([k, v]) => `<option value="${k}">${v.label}</option>`).join('')}
          </select>
        </div>
        <div class="form-group">
          <label class="form-label">ব্যাজ / উপ-শিরোনাম</label>
          <input id="pst-badge" class="form-control" value="${escapeHtml(POSTER_TEMPLATES.mahfil.badge)}">
        </div>
        <div class="form-group">
          <label class="form-label">মূল শিরোনাম</label>
          <input id="pst-headline" class="form-control" value="${escapeHtml(POSTER_TEMPLATES.mahfil.headline)}">
        </div>
        <div class="form-group" style="grid-column:1/-1;">
          <label class="form-label">বিশেষ তথ্য / বক্তা</label>
          <input id="pst-sub" class="form-control" value="${escapeHtml(POSTER_TEMPLATES.mahfil.subtitle)}">
        </div>
        <div class="form-group" style="grid-column:1/-1;">
          <label class="form-label">তারিখ, সময় ও বিস্তারিত (নতুন লাইন ব্যবহার করতে পারবেন)</label>
          <textarea id="pst-details" class="form-control" rows="3">${escapeHtml(POSTER_TEMPLATES.mahfil.details)}</textarea>
        </div>
      </div>
    </div>

    <div class="card" style="text-align:center;">
      <canvas id="poster-canvas" style="max-width:100%;height:auto;border:1px solid var(--border-color);border-radius:8px;"></canvas>
    </div>
  `;

  const canvas = document.getElementById('poster-canvas');
  const ctx = canvas.getContext('2d');

  function wrapLines(text, maxWidth, font) {
    ctx.font = font;
    const out = [];
    String(text || '').split('\n').forEach((para) => {
      const words = para.split(' ');
      let line = '';
      for (const w of words) {
        const test = line ? `${line} ${w}` : w;
        if (ctx.measureText(test).width > maxWidth && line) {
          out.push(line);
          line = w;
        } else {
          line = test;
        }
      }
      if (line) out.push(line);
    });
    return out;
  }

  async function drawPoster() {
    if (document.fonts && document.fonts.ready) await document.fonts.ready;
    const { w, h } = SIZES[sizeKey];
    canvas.width = w;
    canvas.height = h;

    const primary = brand.primaryColor || '#0F6E56';
    const accent = brand.accentColor || '#B47B2B';
    const fontFamily = '"Noto Serif by Gunjoron", Georgia, serif';

    // পটভূমি ও বর্ডার
    ctx.fillStyle = '#F9FBF9';
    ctx.fillRect(0, 0, w, h);

    ctx.strokeStyle = primary;
    ctx.lineWidth = Math.round(w * 0.016);
    ctx.strokeRect(24, 24, w - 48, h - 48);

    ctx.strokeStyle = accent;
    ctx.lineWidth = 3;
    ctx.strokeRect(44, 44, w - 88, h - 88);

    // হেডার ব্যানার (প্রতিষ্ঠানের নাম ও স্লোগান)
    const headerH = Math.round(h * 0.21);
    ctx.fillStyle = primary;
    ctx.fillRect(44, 44, w - 88, headerH);

    ctx.fillStyle = '#FFFFFF';
    ctx.textAlign = 'center';
    ctx.font = `700 ${Math.round(w * 0.044)}px ${fontFamily}`;
    ctx.fillText(brand.nameBn || 'মাদ্রাসা ম্যানেজমেন্ট সিস্টেম', w / 2, 44 + Math.round(headerH * 0.48), w - 140);

    ctx.font = `400 ${Math.round(w * 0.023)}px ${fontFamily}`;
    ctx.fillStyle = '#E6F4F0';
    ctx.fillText(brand.slogan || brand.address || '', w / 2, 44 + Math.round(headerH * 0.76), w - 140);

    // ব্যাজ পিল
    const badgeText = document.getElementById('pst-badge').value.trim();
    const badgeY = 44 + headerH + Math.round(h * 0.075);
    ctx.font = `600 ${Math.round(w * 0.026)}px ${fontFamily}`;
    const bw = Math.min(w - 160, ctx.measureText(badgeText).width + 64);
    const bh = Math.round(w * 0.056);
    ctx.fillStyle = accent;
    ctx.beginPath();
    ctx.roundRect((w - bw) / 2, badgeY - bh / 2, bw, bh, bh / 2);
    ctx.fill();
    ctx.fillStyle = '#FFFFFF';
    ctx.fillText(badgeText, w / 2, badgeY + Math.round(w * 0.009));

    // মূল শিরোনাম
    const headFont = `700 ${Math.round(w * 0.052)}px ${fontFamily}`;
    const headLines = wrapLines(document.getElementById('pst-headline').value.trim(), w - 160, headFont);
    ctx.fillStyle = '#14221D';
    ctx.font = headFont;
    let curY = badgeY + Math.round(h * 0.09);
    const headStep = Math.round(w * 0.072);
    headLines.forEach((ln) => {
      ctx.fillText(ln, w / 2, curY);
      curY += headStep;
    });

    // বিশেষ তথ্য / বক্তা
    const subFont = `600 ${Math.round(w * 0.03)}px ${fontFamily}`;
    const subLines = wrapLines(document.getElementById('pst-sub').value.trim(), w - 180, subFont);
    ctx.fillStyle = primary;
    ctx.font = subFont;
    curY += Math.round(h * 0.025);
    subLines.forEach((ln) => {
      ctx.fillText(ln, w / 2, curY);
      curY += Math.round(w * 0.046);
    });

    // বিস্তারিত বক্স
    const detFont = `400 ${Math.round(w * 0.026)}px ${fontFamily}`;
    const detLines = wrapLines(document.getElementById('pst-details').value.trim(), w - 210, detFont);
    const boxY = curY + Math.round(h * 0.025);
    const lineH = Math.round(w * 0.044);
    const boxH = Math.max(120, detLines.length * lineH + 56);
    ctx.fillStyle = '#EDF4F1';
    ctx.beginPath();
    ctx.roundRect(96, boxY, w - 192, boxH, 16);
    ctx.fill();
    ctx.fillStyle = '#14221D';
    ctx.font = detFont;
    detLines.forEach((ln, idx) => {
      ctx.fillText(ln, w / 2, boxY + 46 + idx * lineH);
    });

    // ফুটার (ঠিকানা ও ফোন অটো)
    const footH = Math.round(h * 0.11);
    const footY = h - 44 - footH;
    ctx.fillStyle = '#14221D';
    ctx.fillRect(44, footY, w - 88, footH);
    ctx.fillStyle = '#FFFFFF';
    ctx.font = `600 ${Math.round(w * 0.024)}px ${fontFamily}`;
    ctx.fillText(brand.address || 'মাদ্রাসার ঠিকানা', w / 2, footY + Math.round(footH * 0.44), w - 140);
    ctx.font = `400 ${Math.round(w * 0.022)}px ${fontFamily}`;
    ctx.fillStyle = '#D7E0DC';
    ctx.fillText(`যোগাযোগ: ${brand.phone || ''} | মুহতামিম: ${brand.muhtamimName || ''}`, w / 2, footY + Math.round(footH * 0.76), w - 140);
  }

  document.getElementById('pst-tpl').onchange = (e) => {
    tplKey = e.target.value;
    const t = POSTER_TEMPLATES[tplKey];
    document.getElementById('pst-badge').value = t.badge;
    document.getElementById('pst-headline').value = t.headline;
    document.getElementById('pst-sub').value = t.subtitle;
    document.getElementById('pst-details').value = t.details;
    drawPoster();
  };

  document.getElementById('pst-size').onchange = (e) => {
    sizeKey = e.target.value;
    drawPoster();
  };

  ['pst-badge', 'pst-headline', 'pst-sub', 'pst-details'].forEach((id) => {
    document.getElementById(id).oninput = drawPoster;
  });

  document.getElementById('pst-download').onclick = () => {
    const a = document.createElement('a');
    a.download = `madrasa-poster-${tplKey}-${sizeKey}.png`;
    a.href = canvas.toDataURL('image/png');
    a.click();
    showToast('পোস্টার PNG ডাউনলোড হয়েছে', 'success');
  };

  document.getElementById('pst-print').onclick = () => window.print();

  drawPoster();
}
