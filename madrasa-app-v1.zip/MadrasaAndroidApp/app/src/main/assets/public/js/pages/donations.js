import { listCollection, addDocItem, setDocById, nextSerial, getDocById } from '../core/store.js';
import { getBrand } from '../core/brand.js';
import { getCurrentUser } from '../core/auth.js';
import { logAudit } from '../core/audit.js';
import { navigate } from '../core/router.js';
import { icon } from '../core/icons.js';
import { todayISO, getHijriDateString, formatCurrency, formatNum, escapeHtml, openModal, closeModal, showToast } from '../core/utils.js';

export async function renderDonations(container) {
  const [donors, funds, accounts] = await Promise.all([
    listCollection('donors', (d) => !d.isDeleted),
    listCollection('funds'),
    listCollection('accounts')
  ]);

  container.innerHTML = `
    <div class="page-header">
      <div>
        <h1>দান ও দাতা ব্যবস্থাপনা</h1>
        <p class="page-subtitle">নিয়মিত ও এককালীন দাতা, প্রতিশ্রুত দান ও অটো রিসিট</p>
      </div>
      <div style="display:flex;gap:8px;">
        <button type="button" class="btn btn-secondary btn-sm" id="dnr-add-btn">${icon('plus', 'sm')} নতুন দাতা</button>
        <button type="button" class="btn btn-primary btn-sm" id="dnr-collect-btn">${icon('donation', 'sm')} দান গ্রহণ</button>
      </div>
    </div>

    ${donors.length === 0 ? `
      <div class="card empty-state">
        ${icon('donation', 'lg')}
        <p>এখনো কোনো দাতা যুক্ত করা হয়নি।</p>
      </div>
    ` : `
      <div class="list-stack">
        ${donors.map((d) => {
          const msg = encodeURIComponent(`আসসালামু আলাইকুম ${d.nameBn}, ${getBrand()?.nameBn || 'আমাদের মাদ্রাসা'}-এর পক্ষ থেকে আপনার দানের জন্য জাযাকাল্লাহু খাইরান।`);
          const cleanPhone = String(d.phone || '').replace(/[^0-9]/g, '');
          return `
            <div class="list-item" style="flex-wrap:wrap;">
              <div class="list-item-main">
                <div class="list-item-title">
                  ${escapeHtml(d.nameBn)}
                  <span class="badge ${d.donorType === 'regular' ? 'badge-success' : 'badge-neutral'}">${d.donorType === 'regular' ? 'নিয়মিত দাতা' : 'এককালীন'}</span>
                </div>
                <div class="list-item-sub">
                  ফোন: ${formatNum(d.phone || '-')} | ঠিকানা: ${escapeHtml(d.address || '-')}
                  ${d.pledgedAmount ? ` | প্রতিশ্রুত: ${formatCurrency(d.pledgedAmount)}` : ''}
                </div>
              </div>
              <div class="list-item-actions">
                ${cleanPhone ? `<a class="btn btn-outline btn-sm" target="_blank" rel="noopener" href="https://wa.me/88${cleanPhone}?text=${msg}">ধন্যবাদ বার্তা</a>` : ''}
                <button type="button" class="btn btn-primary btn-sm" data-donate="${d.id}">দান নিন</button>
              </div>
            </div>
          `;
        }).join('')}
      </div>
    `}
  `;

  document.getElementById('dnr-add-btn').onclick = () => {
    openModal({
      title: 'নতুন দাতা যুক্ত করুন',
      bodyHtml: `
        <div class="form-grid">
          <div class="form-group">
            <label class="form-label">দাতার নাম *</label>
            <input id="d-name" class="form-control" required>
          </div>
          <div class="form-group">
            <label class="form-label">ফোন নম্বর</label>
            <input id="d-phone" class="form-control" placeholder="017XXXXXXXX">
          </div>
          <div class="form-group">
            <label class="form-label">ঠিকানা</label>
            <input id="d-addr" class="form-control">
          </div>
          <div class="form-group">
            <label class="form-label">দাতার ধরন</label>
            <select id="d-type" class="form-control">
              <option value="regular">নিয়মিত দাতা</option>
              <option value="one_time">এককালীন দাতা</option>
            </select>
          </div>
          <div class="form-group">
            <label class="form-label">মাসিক প্রতিশ্রুত দান (ঐচ্ছিক, টাকা)</label>
            <input id="d-pledge" class="form-control" type="number" min="0" value="0">
          </div>
        </div>
      `,
      footerHtml: `
        <button type="button" class="btn btn-secondary" id="d-cancel">বাতিল</button>
        <button type="button" class="btn btn-primary" id="d-save">সংরক্ষণ</button>
      `
    });
    document.getElementById('d-cancel').onclick = closeModal;
    document.getElementById('d-save').onclick = async () => {
      const nameBn = document.getElementById('d-name').value.trim();
      if (!nameBn) return showToast('দাতার নাম লিখুন', 'warning');
      await addDocItem('donors', {
        branchId: 'main',
        nameBn,
        phone: document.getElementById('d-phone').value.trim(),
        address: document.getElementById('d-addr').value.trim(),
        donorType: document.getElementById('d-type').value,
        pledgedAmount: Number(document.getElementById('d-pledge').value || 0),
        isDeleted: false
      });
      closeModal();
      showToast('দাতা যুক্ত হয়েছে', 'success');
      renderDonations(container);
    };
  };

  function openDonateModal(donor = null) {
    openModal({
      title: donor ? `দান গ্রহণ — ${donor.nameBn}` : 'দান গ্রহণ',
      bodyHtml: `
        <div class="form-grid">
          <div class="form-group">
            <label class="form-label">দাতার নাম *</label>
            <input id="don-name" class="form-control" value="${escapeHtml(donor?.nameBn || '')}" placeholder="দাতার নাম (বা গোপন দান)">
          </div>
          <div class="form-group">
            <label class="form-label">তহবিল নির্বাচন *</label>
            <select id="don-fund" class="form-control">
              ${funds.map((f) => `<option value="${f.id}">${escapeHtml(f.nameBn)}</option>`).join('')}
            </select>
          </div>
          <div class="form-group">
            <label class="form-label">গ্রহণ অ্যাকাউন্ট *</label>
            <select id="don-acc" class="form-control">
              ${accounts.map((a) => `<option value="${a.id}">${escapeHtml(a.nameBn)}</option>`).join('')}
            </select>
          </div>
          <div class="form-group">
            <label class="form-label">টাকার পরিমাণ *</label>
            <input id="don-amt" class="form-control" type="number" min="1" value="${donor?.pledgedAmount || ''}" placeholder="0">
          </div>
        </div>
      `,
      footerHtml: `
        <button type="button" class="btn btn-secondary" id="don-cancel">বাতিল</button>
        <button type="button" class="btn btn-primary" id="don-save">গ্রহণ ও রিসিট</button>
      `
    });
    document.getElementById('don-cancel').onclick = closeModal;
    document.getElementById('don-save').onclick = async () => {
      const donorName = document.getElementById('don-name').value.trim() || 'সম্মানিত দাতা';
      const amount = Number(document.getElementById('don-amt').value || 0);
      if (amount <= 0) return showToast('সঠিক অঙ্ক লিখুন', 'warning');

      const fundId = document.getElementById('don-fund').value;
      const accountId = document.getElementById('don-acc').value;
      const fundObj = funds.find((f) => f.id === fundId);
      const year = new Date().getFullYear();
      const receiptNo = await nextSerial(`receipt_${year}`, `RCP-${year}-`);
      const verifyCode = receiptNo.replace('RCP-', 'VRF-');

      const tx = await addDocItem('transactions', {
        branchId: 'main',
        receiptNo,
        date: todayISO(),
        hijriDate: getHijriDateString(new Date()),
        type: 'income',
        category: fundObj?.code === 'zakat' ? 'zakat' : fundObj?.code === 'sadaqah' ? 'sadaqah' : 'general_donation',
        fundId,
        accountId,
        amount,
        description: `${fundObj?.nameBn || 'দান'} — ${donorName}`,
        donorId: donor?.id || null,
        status: 'posted',
        approvalStatus: 'auto_approved',
        verifyCode,
        createdBy: getCurrentUser()?.uid || 'system'
      });

      const fund = await getDocById('funds', fundId);
      if (fund) await setDocById('funds', fundId, { currentBalance: Number(fund.currentBalance || 0) + amount }, true);
      const acc = await getDocById('accounts', accountId);
      if (acc) await setDocById('accounts', accountId, { currentBalance: Number(acc.currentBalance || 0) + amount }, true);

      await setDocById('public_verifications', verifyCode, {
        docType: 'receipt',
        serialNo: receiptNo,
        holderName: donorName,
        amount,
        issuedDate: todayISO(),
        status: 'valid'
      });

      await logAudit({ action: 'RECEIVE_DONATION', collection: 'transactions', docId: tx.id, summary: `দান গ্রহণ ${amount} টাকা (${donorName})` });
      closeModal();
      showToast('দান গৃহীত হয়েছে', 'success');
      navigate(`/receipt/${tx.id}`);
    };
  }

  document.getElementById('dnr-collect-btn').onclick = () => openDonateModal(null);
  container.querySelectorAll('[data-donate]').forEach((b) => {
    b.onclick = () => openDonateModal(donors.find((x) => x.id === b.dataset.donate));
  });
}
