import { listCollection, addDocItem, setDocById, nextSerial, getDocById } from '../core/store.js';
import { getCurrentUser, requirePinConfirmation } from '../core/auth.js';
import { logAudit } from '../core/audit.js';
import { icon } from '../core/icons.js';
import { todayISO, getHijriDateString, formatCurrency, formatNum, escapeHtml, openModal, closeModal, showToast } from '../core/utils.js';

let dirFilter = 'payable'; // 'payable' (ঋণ/দেনা) | 'receivable' (পাওনা)

export async function renderLoans(container) {
  const [loans, accounts, funds] = await Promise.all([
    listCollection('loans'),
    listCollection('accounts'),
    listCollection('funds')
  ]);

  const totalPayable = loans.filter((l) => l.direction === 'payable').reduce((s, l) => s + Number(l.remainingAmount || 0), 0);
  const totalReceivable = loans.filter((l) => l.direction === 'receivable').reduce((s, l) => s + Number(l.remainingAmount || 0), 0);
  const filtered = loans.filter((l) => l.direction === dirFilter);
  const today = todayISO();

  container.innerHTML = `
    <div class="page-header">
      <div>
        <h1>ঋণ ও পাওনা হিসাব</h1>
        <p class="page-subtitle">মাদ্রাসার মোট ঋণ: ${formatCurrency(totalPayable)} | মোট পাওনা: ${formatCurrency(totalReceivable)}</p>
      </div>
      <button type="button" class="btn btn-primary btn-sm" id="btn-add-loan">${icon('plus', 'sm')} নতুন এন্ট্রি</button>
    </div>

    <div class="tabs">
      <button type="button" class="tab-btn ${dirFilter === 'payable' ? 'active' : ''}" data-dir="payable">মাদ্রাসার ঋণ / দেনা</button>
      <button type="button" class="tab-btn ${dirFilter === 'receivable' ? 'active' : ''}" data-dir="receivable">মাদ্রাসার পাওনা</button>
    </div>

    ${filtered.length === 0
      ? `<div class="card empty-state">${icon('loan', 'lg')}<p>এই বিভাগে কোনো ঋণ বা পাওনার রেকর্ড নেই।</p></div>`
      : `<div class="list-stack">
          ${filtered.map((l) => {
            const overdue = l.dueDate && l.dueDate < today && Number(l.remainingAmount) > 0;
            const settled = Number(l.remainingAmount) <= 0;
            return `
              <div class="list-item" style="flex-wrap:wrap;">
                <div class="list-item-main">
                  <div class="list-item-title">
                    ${escapeHtml(l.partyName)}
                    ${settled ? `<span class="badge badge-success">পরিশোধিত</span>` : overdue ? `<span class="badge badge-danger">মেয়াদ উত্তীর্ণ</span>` : `<span class="badge badge-warning">চলমান</span>`}
                  </div>
                  <div class="list-item-sub">
                    ফোন: ${formatNum(l.partyPhone || '-')} | মূল: ${formatCurrency(l.principalAmount)} | পরিশোধ: ${formatCurrency(l.paidAmount || 0)} | বাকি: <strong>${formatCurrency(l.remainingAmount)}</strong>
                    ${l.dueDate ? ` | মেয়াদ: ${escapeHtml(l.dueDate)}` : ''}
                  </div>
                </div>
                <div class="list-item-actions">
                  ${!settled ? `<button type="button" class="btn btn-primary btn-sm" data-installment="${l.id}">কিস্তি পরিশোধ</button>` : ''}
                </div>
              </div>
            `;
          }).join('')}
        </div>`}
  `;

  container.querySelectorAll('.tab-btn').forEach((b) => {
    b.onclick = () => {
      dirFilter = b.dataset.dir;
      renderLoans(container);
    };
  });

  document.getElementById('btn-add-loan').onclick = () => {
    openModal({
      title: 'নতুন ঋণ বা পাওনা যুক্ত করুন',
      bodyHtml: `
        <div class="form-grid">
          <div class="form-group">
            <label class="form-label">ধরন *</label>
            <select id="ln-dir" class="form-control">
              <option value="payable" ${dirFilter === 'payable' ? 'selected' : ''}>মাদ্রাসার ঋণ / দেনা</option>
              <option value="receivable" ${dirFilter === 'receivable' ? 'selected' : ''}>মাদ্রাসার পাওনা</option>
            </select>
          </div>
          <div class="form-group">
            <label class="form-label">ব্যক্তি বা প্রতিষ্ঠানের নাম *</label>
            <input id="ln-party" class="form-control" required placeholder="নাম লিখুন">
          </div>
          <div class="form-group">
            <label class="form-label">ফোন নম্বর</label>
            <input id="ln-phone" class="form-control" placeholder="017XXXXXXXX">
          </div>
          <div class="form-group">
            <label class="form-label">টাকার পরিমাণ *</label>
            <input id="ln-amt" class="form-control" type="number" min="1" required>
          </div>
          <div class="form-group">
            <label class="form-label">পরিশোধের সম্ভাব্য তারিখ</label>
            <input id="ln-due" class="form-control" type="date">
          </div>
          <div class="form-group">
            <label class="form-label">কারণ / বিবরণ</label>
            <input id="ln-note" class="form-control" placeholder="যেমন: ভবন নির্মাণ বাবদ করজে হাসানা">
          </div>
        </div>
      `,
      footerHtml: `
        <button type="button" class="btn btn-secondary" id="ln-cancel">বাতিল</button>
        <button type="button" class="btn btn-primary" id="ln-save">সংরক্ষণ</button>
      `
    });
    document.getElementById('ln-cancel').onclick = closeModal;
    document.getElementById('ln-save').onclick = async () => {
      const partyName = document.getElementById('ln-party').value.trim();
      const principalAmount = Number(document.getElementById('ln-amt').value || 0);
      if (!partyName || principalAmount <= 0) return showToast('নাম ও সঠিক অঙ্ক দিন', 'warning');

      const doc = await addDocItem('loans', {
        branchId: 'main',
        direction: document.getElementById('ln-dir').value,
        partyName,
        partyPhone: document.getElementById('ln-phone').value.trim(),
        principalAmount,
        paidAmount: 0,
        remainingAmount: principalAmount,
        dueDate: document.getElementById('ln-due').value || '',
        note: document.getElementById('ln-note').value.trim(),
        installments: [],
        status: 'active',
        createdBy: getCurrentUser()?.uid || 'system'
      });
      await logAudit({ action: 'ADD_LOAN', collection: 'loans', docId: doc.id, summary: `ঋণ/পাওনা এন্ট্রি: ${partyName} (${principalAmount} টাকা)` });
      closeModal();
      showToast('রেকর্ড সংরক্ষিত হয়েছে', 'success');
      renderLoans(container);
    };
  };

  container.querySelectorAll('[data-installment]').forEach((b) => {
    b.onclick = () => {
      const loan = loans.find((x) => x.id === b.dataset.installment);
      openModal({
        title: `কিস্তি — ${loan.partyName}`,
        bodyHtml: `
          <div class="form-grid">
            <div class="form-group">
              <label class="form-label">কিস্তির পরিমাণ (বাকি: ${formatCurrency(loan.remainingAmount)})</label>
              <input id="ins-amt" class="form-control" type="number" min="1" max="${loan.remainingAmount}" value="${loan.remainingAmount}">
            </div>
            <div class="form-group">
              <label class="form-label">অ্যাকাউন্ট</label>
              <select id="ins-acc" class="form-control">
                ${accounts.map((a) => `<option value="${a.id}">${escapeHtml(a.nameBn)}</option>`).join('')}
              </select>
            </div>
          </div>
        `,
        footerHtml: `
          <button type="button" class="btn btn-secondary" id="ins-cancel">বাতিল</button>
          <button type="button" class="btn btn-primary" id="ins-ok">PIN দিয়ে নিশ্চিত করুন</button>
        `
      });
      document.getElementById('ins-cancel').onclick = closeModal;
      document.getElementById('ins-ok').onclick = async () => {
        const amt = Number(document.getElementById('ins-amt').value || 0);
        if (amt <= 0 || amt > Number(loan.remainingAmount)) return showToast('সঠিক অঙ্ক লিখুন', 'warning');
        const accId = document.getElementById('ins-acc').value;
        closeModal();

        const ok = await requirePinConfirmation(`${loan.partyName}-এর ${formatCurrency(amt)} কিস্তি রেকর্ড করতে PIN দিন।`);
        if (!ok) return;

        const isPayable = loan.direction === 'payable';
        const year = new Date().getFullYear();
        const serial = await nextSerial(isPayable ? `voucher_${year}` : `receipt_${year}`, isPayable ? `VCH-${year}-` : `RCP-${year}-`);

        const tx = await addDocItem('transactions', {
          branchId: 'main',
          receiptNo: serial,
          date: todayISO(),
          hijriDate: getHijriDateString(new Date()),
          type: isPayable ? 'expense' : 'income',
          category: isPayable ? 'loan_repayment' : 'loan_recovery',
          fundId: funds[0]?.id || 'fund_general',
          accountId: accId,
          amount: amt,
          description: `${isPayable ? 'ঋণ পরিশোধ' : 'পাওনা আদায়'} — ${loan.partyName}`,
          loanId: loan.id,
          status: 'posted',
          approvalStatus: 'auto_approved',
          createdBy: getCurrentUser()?.uid || 'system'
        });

        const delta = isPayable ? -amt : amt;
        const acc = await getDocById('accounts', accId);
        if (acc) await setDocById('accounts', accId, { currentBalance: Number(acc.currentBalance || 0) + delta }, true);
        const fund = await getDocById('funds', funds[0]?.id || 'fund_general');
        if (fund) await setDocById('funds', fund.id, { currentBalance: Number(fund.currentBalance || 0) + delta }, true);

        const newPaid = Number(loan.paidAmount || 0) + amt;
        const newRem = Math.max(0, Number(loan.principalAmount) - newPaid);
        await setDocById('loans', loan.id, {
          paidAmount: newPaid,
          remainingAmount: newRem,
          status: newRem === 0 ? 'settled' : 'active',
          installments: [...(loan.installments || []), { date: todayISO(), amount: amt, txId: tx.id }]
        }, true);

        await logAudit({ action: 'LOAN_INSTALLMENT', collection: 'loans', docId: loan.id, summary: `ঋণ কিস্তি: ${loan.partyName} (${amt} টাকা)` });
        showToast('কিস্তি সফলভাবে রেকর্ড হয়েছে', 'success');
        renderLoans(container);
      };
    };
  });
}
