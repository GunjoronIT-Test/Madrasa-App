import { getDocById, setDocById, listCollection } from '../core/store.js';
import { getBrand } from '../core/brand.js';
import { logAudit } from '../core/audit.js';
import { icon } from '../core/icons.js';
import { formatNum, formatCurrency, escapeHtml, showToast } from '../core/utils.js';

export async function renderIntegrations(container) {
  const [cfg, invoices, students] = await Promise.all([
    getDocById('settings', 'integrations'),
    listCollection('fee_invoices', (i) => Number(i.dueAmount || 0) > 0),
    listCollection('students', (s) => !s.isDeleted)
  ]);

  const stuMap = Object.fromEntries(students.map((s) => [s.id, s]));
  const conf = cfg || {
    smsProvider: 'bulksmsbd',
    smsSenderId: '',
    smsEnabled: false,
    bkashMerchantNo: '',
    bkashEnabled: false,
    nagadMerchantNo: '',
    nagadEnabled: false
  };

  container.innerHTML = `
    <div class="page-header">
      <div>
        <h1>SMS ও অনলাইন পেমেন্ট (bKash / Nagad)</h1>
        <p class="page-subtitle">Cloud Functions ইন্টিগ্রেশন, বাল্ক বকেয়া SMS এবং অনলাইন পেমেন্ট সেটআপ</p>
      </div>
    </div>

    <div class="alert-box alert-info">
      ${icon('shield', 'sm')}
      <span>নিরাপত্তা নীতি: SMS API Key এবং bKash/Nagad App Secret কখনো ব্রাউজারে রাখা হবে না—এগুলো শুধু Firebase Cloud Functions এনভায়রনমেন্টে (<code>functions/index.js</code>) সংরক্ষিত থাকবে।</span>
    </div>

    <div class="card">
      <h2 style="margin-bottom:12px;">গেটওয়ে কনফিগারেশন</h2>
      <form id="int-form" class="form-grid cols-2">
        <div class="form-group">
          <label class="form-label">SMS গেটওয়ে প্রোভাইডার</label>
          <select id="int-sms-prov" class="form-control">
            <option value="bulksmsbd" ${conf.smsProvider === 'bulksmsbd' ? 'selected' : ''}>BulkSMSBD</option>
            <option value="sslwireless" ${conf.smsProvider === 'sslwireless' ? 'selected' : ''}>SSL Wireless</option>
            <option value="alphasms" ${conf.smsProvider === 'alphasms' ? 'selected' : ''}>Alpha SMS</option>
          </select>
        </div>
        <div class="form-group">
          <label class="form-label">SMS Sender ID / Masking</label>
          <input id="int-sms-sender" class="form-control" value="${escapeHtml(conf.smsSenderId || '')}" placeholder="যেমন: 88096176XXXXX">
        </div>
        <div class="form-group">
          <label class="form-label">bKash মার্চেন্ট নম্বর</label>
          <input id="int-bkash" class="form-control" value="${escapeHtml(conf.bkashMerchantNo || '')}" placeholder="017XXXXXXXX">
        </div>
        <div class="form-group">
          <label class="form-label">Nagad মার্চেন্ট নম্বর</label>
          <input id="int-nagad" class="form-control" value="${escapeHtml(conf.nagadMerchantNo || '')}" placeholder="018XXXXXXXX">
        </div>
        <div style="grid-column:1/-1;display:flex;gap:16px;flex-wrap:wrap;">
          <label style="display:flex;align-items:center;gap:6px;"><input type="checkbox" id="int-sms-on" ${conf.smsEnabled ? 'checked' : ''}> SMS অটো রিমাইন্ডার চালু</label>
          <label style="display:flex;align-items:center;gap:6px;"><input type="checkbox" id="int-bk-on" ${conf.bkashEnabled ? 'checked' : ''}> bKash পেমেন্ট চালু</label>
          <label style="display:flex;align-items:center;gap:6px;"><input type="checkbox" id="int-ng-on" ${conf.nagadEnabled ? 'checked' : ''}> Nagad পেমেন্ট চালু</label>
        </div>
        <div style="grid-column:1/-1;display:flex;justify-content:flex-end;">
          <button type="submit" class="btn btn-primary">${icon('check', 'sm')} কনফিগারেশন সংরক্ষণ</button>
        </div>
      </form>
    </div>

    <div class="card">
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:10px;flex-wrap:wrap;gap:8px;">
        <h3>বকেয়া ফি রিমাইন্ডার তালিকা (${formatNum(invoices.length)} জন)</h3>
        <button type="button" class="btn btn-outline btn-sm" id="int-copy-sms">বাল্ক SMS প্রিভিউ কপি</button>
      </div>
      ${invoices.length === 0 ? `<p class="text-muted">বর্তমানে কোনো বকেয়া ইনভয়েস নেই।</p>` : `
        <div class="list-stack">
          ${invoices.slice(0, 10).map((inv) => {
            const stu = stuMap[inv.studentId];
            const brandName = getBrand()?.nameBn || 'মাদ্রাসা';
            const smsText = `আসসালামু আলাইকুম, ${brandName}-এ ${stu?.nameBn || ''}-এর ${inv.billingMonth} মাসের বকেয়া ${formatCurrency(inv.dueAmount)}।`;
            const phone = String(stu?.guardianPhone || '').replace(/[^0-9]/g, '');
            return `
              <div class="list-item" style="flex-wrap:wrap;">
                <div class="list-item-main">
                  <div class="list-item-title">${escapeHtml(stu?.nameBn || inv.studentId)} — বকেয়া ${formatCurrency(inv.dueAmount)}</div>
                  <div class="list-item-sub">ফোন: ${formatNum(stu?.guardianPhone || '-')} | বার্তা: ${escapeHtml(smsText)}</div>
                </div>
                ${phone ? `<a class="btn btn-secondary btn-sm" href="sms:${phone}?body=${encodeURIComponent(smsText)}">ডিভাইস SMS</a>` : ''}
              </div>
            `;
          }).join('')}
        </div>
      `}
    </div>
  `;

  document.getElementById('int-form').onsubmit = async (e) => {
    e.preventDefault();
    await setDocById('settings', 'integrations', {
      smsProvider: document.getElementById('int-sms-prov').value,
      smsSenderId: document.getElementById('int-sms-sender').value.trim(),
      smsEnabled: document.getElementById('int-sms-on').checked,
      bkashMerchantNo: document.getElementById('int-bkash').value.trim(),
      bkashEnabled: document.getElementById('int-bk-on').checked,
      nagadMerchantNo: document.getElementById('int-nagad').value.trim(),
      nagadEnabled: document.getElementById('int-ng-on').checked
    }, true);
    await logAudit({ action: 'UPDATE_INTEGRATIONS', collection: 'settings', docId: 'integrations', summary: 'SMS ও পেমেন্ট কনফিগারেশন হালনাগাদ' });
    showToast('ইন্টিগ্রেশন কনফিগারেশন সংরক্ষিত হয়েছে', 'success');
  };

  document.getElementById('int-copy-sms').onclick = async () => {
    const lines = invoices.map((inv) => {
      const stu = stuMap[inv.studentId];
      return `${stu?.guardianPhone || ''}: ${stu?.nameBn || ''} - বকেয়া ${inv.dueAmount} টাকা`;
    }).join('\n');
    try {
      await navigator.clipboard.writeText(lines || 'কোনো বকেয়া নেই');
      showToast('বকেয়া তালিকা ক্লিপবোর্ডে কপি হয়েছে', 'success');
    } catch {
      showToast('কপি করা যায়নি', 'warning');
    }
  };
}
