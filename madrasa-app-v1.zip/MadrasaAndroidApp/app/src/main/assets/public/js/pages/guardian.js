import { listCollection, addDocItem, setDocById } from '../core/store.js';
import { getCurrentUser, hasAnyRole } from '../core/auth.js';
import { navigate } from '../core/router.js';
import { icon } from '../core/icons.js';
import { todayISO, formatCurrency, formatNum, escapeHtml, openModal, closeModal, showToast } from '../core/utils.js';

let selectedStudentId = '';

export async function renderGuardianPortal(container) {
  const user = getCurrentUser();
  const [allStudents, attendance, invoices, hifzLogs, results, notices, leaves] = await Promise.all([
    listCollection('students', (s) => !s.isDeleted && s.status === 'active'),
    listCollection('attendance', (a) => a.type === 'student'),
    listCollection('fee_invoices'),
    listCollection('hifz_logs'),
    listCollection('exam_results'),
    listCollection('notices'),
    listCollection('leave_requests')
  ]);

  const visibleStudents = user?.role === 'guardian' && Array.isArray(user.linkedStudentIds)
    ? allStudents.filter((s) => user.linkedStudentIds.includes(s.id))
    : allStudents;

  if (!selectedStudentId && visibleStudents.length > 0) selectedStudentId = visibleStudents[0].id;
  const stu = visibleStudents.find((s) => s.id === selectedStudentId) || null;

  const stuAtt = stu ? attendance.filter((a) => a.targetId === stu.id) : [];
  const presentCnt = stuAtt.filter((a) => a.status === 'present').length;
  const absentCnt = stuAtt.filter((a) => a.status === 'absent').length;
  const stuInv = stu ? invoices.filter((i) => i.studentId === stu.id) : [];
  const totalDue = stuInv.reduce((s, i) => s + Number(i.dueAmount || 0), 0);
  const stuHifz = stu ? hifzLogs.filter((h) => h.studentId === stu.id).sort((a, b) => String(b.date).localeCompare(String(a.date))) : [];
  const stuRes = stu ? results.filter((r) => r.studentId === stu.id) : [];
  const stuLeaves = stu ? leaves.filter((l) => l.studentId === stu.id) : [];

  container.innerHTML = `
    <div class="page-header">
      <div>
        <h1>অভিভাবক পোর্টাল</h1>
        <p class="page-subtitle">সন্তানের হাজিরা, হিফজ অগ্রগতি, ফলাফল, বকেয়া ফি ও ছুটির আবেদন</p>
      </div>
      <button type="button" class="btn btn-primary btn-sm" id="gp-leave-btn">${icon('plus', 'sm')} ছুটির আবেদন</button>
    </div>

    ${visibleStudents.length > 1 ? `
      <div class="toolbar">
        <select id="gp-stu-select" class="form-control">
          ${visibleStudents.map((s) => `<option value="${s.id}" ${s.id === selectedStudentId ? 'selected' : ''}>${escapeHtml(s.nameBn)} (রোল ${formatNum(s.rollNumber)})</option>`).join('')}
        </select>
      </div>
    ` : ''}

    ${!stu ? `<div class="card empty-state"><p>কোনো ছাত্র যুক্ত নেই।</p></div>` : `
      <div class="kpi-grid">
        <div class="card" style="padding:14px;">
          <div class="form-hint">মোট উপস্থিতি</div>
          <div style="font-size:1.2rem;font-weight:700;" class="text-success">${formatNum(presentCnt)} দিন</div>
          <div class="form-hint">অনুপস্থিত: ${formatNum(absentCnt)} দিন</div>
        </div>
        <div class="card" style="padding:14px;">
          <div class="form-hint">বকেয়া ফি</div>
          <div style="font-size:1.2rem;font-weight:700;" class="text-warning">${formatCurrency(totalDue)}</div>
          <div class="form-hint">মোট ইনভয়েস: ${formatNum(stuInv.length)}</div>
        </div>
        <div class="card" style="padding:14px;">
          <div class="form-hint">সর্বশেষ হিফজ পারা</div>
          <div style="font-size:1.2rem;font-weight:700;">পারা ${formatNum(stuHifz[0]?.paraNo || 0)}</div>
          <div class="form-hint">${escapeHtml(stuHifz[0]?.sabaq || 'রেকর্ড নেই')}</div>
        </div>
        <div class="card" style="padding:14px;">
          <div class="form-hint">সর্বশেষ ফলাফল</div>
          <div style="font-size:1.1rem;font-weight:700;">${escapeHtml(stuRes[0]?.grade || 'প্রকাশিত নয়')}</div>
          <div class="form-hint">মোট নম্বর: ${formatNum(stuRes[0]?.total || 0)}</div>
        </div>
      </div>

      <div class="card">
        <h3 style="margin-bottom:10px;">ফি ও রিসিট তালিকা</h3>
        ${stuInv.length === 0 ? `<p class="text-muted">কোনো ফি ইনভয়েস নেই।</p>` : `
          <div class="list-stack">
            ${stuInv.map((inv) => `
              <div class="list-item">
                <div class="list-item-main">
                  <div class="list-item-title">মাস: ${escapeHtml(inv.billingMonth)}</div>
                  <div class="list-item-sub">পরিশোধ: ${formatCurrency(inv.paidAmount)} | বকেয়া: ${formatCurrency(inv.dueAmount)}</div>
                </div>
                ${inv.transactionIds?.length
                  ? `<button type="button" class="btn btn-outline btn-sm" data-gp-rcp="${inv.transactionIds[inv.transactionIds.length - 1]}">রিসিট দেখুন</button>`
                  : `<span class="badge badge-warning">বাকি</span>`}
              </div>
            `).join('')}
          </div>
        `}
      </div>

      <div class="card">
        <h3 style="margin-bottom:10px;">ছুটির আবেদনসমূহ</h3>
        ${stuLeaves.length === 0 ? `<p class="text-muted">কোনো ছুটির আবেদন নেই।</p>` : `
          <div class="list-stack">
            ${stuLeaves.map((lv) => `
              <div class="list-item" style="flex-wrap:wrap;">
                <div class="list-item-main">
                  <div class="list-item-title">${escapeHtml(lv.reason)} <span class="badge ${lv.status === 'approved' ? 'badge-success' : lv.status === 'rejected' ? 'badge-danger' : 'badge-warning'}">${lv.status === 'approved' ? 'অনুমোদিত' : lv.status === 'rejected' ? 'প্রত্যাখ্যাত' : 'অপেক্ষমাণ'}</span></div>
                  <div class="list-item-sub">তারিখ: ${escapeHtml(lv.fromDate)} থেকে ${escapeHtml(lv.toDate)}</div>
                </div>
                ${lv.status === 'pending' && hasAnyRole(['muhtamim', 'nayeb_muhtamim', 'education_secretary']) ? `
                  <div class="list-item-actions">
                    <button type="button" class="btn btn-primary btn-sm" data-lv-act="${lv.id}" data-st="approved">অনুমোদন</button>
                    <button type="button" class="btn btn-secondary btn-sm" data-lv-act="${lv.id}" data-st="rejected">বাতিল</button>
                  </div>
                ` : ''}
              </div>
            `).join('')}
          </div>
        `}
      </div>

      <div class="card">
        <h3 style="margin-bottom:10px;">সাম্প্রতিক মাদ্রাসা নোটিশ</h3>
        ${notices.slice(0, 3).map((n) => `
          <div style="padding:8px 0;border-bottom:1px solid var(--border-color);">
            <strong>${escapeHtml(n.title)}</strong>
            <div class="list-item-sub">${escapeHtml(n.body)}</div>
          </div>
        `).join('') || `<p class="text-muted">কোনো নোটিশ নেই।</p>`}
      </div>
    `}
  `;

  document.getElementById('gp-stu-select')?.addEventListener('change', (e) => {
    selectedStudentId = e.target.value;
    renderGuardianPortal(container);
  });

  container.querySelectorAll('[data-gp-rcp]').forEach((b) => {
    b.onclick = () => navigate(`/receipt/${b.dataset.gpRcp}`);
  });

  container.querySelectorAll('[data-lv-act]').forEach((b) => {
    b.onclick = async () => {
      await setDocById('leave_requests', b.dataset.lvAct, { status: b.dataset.st }, true);
      showToast('ছুটির আবেদন হালনাগাদ হয়েছে', 'success');
      renderGuardianPortal(container);
    };
  });

  document.getElementById('gp-leave-btn').onclick = () => {
    if (!stu) return;
    openModal({
      title: `ছুটির আবেদন — ${stu.nameBn}`,
      bodyHtml: `
        <div class="form-grid">
          <div class="form-group"><label class="form-label">শুরুর তারিখ</label><input id="lv-from" class="form-control" type="date" value="${todayISO()}"></div>
          <div class="form-group"><label class="form-label">শেষ তারিখ</label><input id="lv-to" class="form-control" type="date" value="${todayISO()}"></div>
          <div class="form-group"><label class="form-label">ছুটির কারণ *</label><textarea id="lv-reason" class="form-control" rows="3" placeholder="যেমন: পারিবারিক অনুষ্ঠান / অসুস্থতা"></textarea></div>
        </div>
      `,
      footerHtml: `<button type="button" class="btn btn-primary" id="lv-submit">আবেদন জমা দিন</button>`
    });
    document.getElementById('lv-submit').onclick = async () => {
      const reason = document.getElementById('lv-reason').value.trim();
      if (!reason) return showToast('কারণ লিখুন', 'warning');
      await addDocItem('leave_requests', {
        branchId: 'main',
        studentId: stu.id,
        fromDate: document.getElementById('lv-from').value,
        toDate: document.getElementById('lv-to').value,
        reason,
        status: 'pending',
        submittedBy: user?.uid || 'guardian'
      });
      closeModal();
      showToast('ছুটির আবেদন জমা হয়েছে', 'success');
      renderGuardianPortal(container);
    };
  };
}
