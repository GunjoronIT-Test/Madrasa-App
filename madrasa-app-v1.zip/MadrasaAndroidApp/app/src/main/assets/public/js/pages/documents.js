import { listCollection, setDocById, nextSerial } from '../core/store.js';
import { getBrand } from '../core/brand.js';
import { generateQrSvg } from '../core/qr.js';
import { icon } from '../core/icons.js';
import { todayISO, getHijriDateString, formatNum, escapeHtml, showToast } from '../core/utils.js';

let docMode = 'id_cards'; // 'id_cards' | 'certificate' | 'tc'
let selectedJamat = 'all';
let selectedStudentId = '';

export async function renderDocuments(container) {
  const brand = getBrand() || {};
  const [students, jamats] = await Promise.all([
    listCollection('students', (s) => !s.isDeleted),
    listCollection('jamats', (j) => !j.isDeleted)
  ]);

  const jamatMap = Object.fromEntries(jamats.map((j) => [j.id, j.nameBn]));
  const filteredStu = students.filter((s) => selectedJamat === 'all' || s.jamatId === selectedJamat);
  if (!selectedStudentId && students.length > 0) selectedStudentId = students[0].id;
  const activeStu = students.find((s) => s.id === selectedStudentId) || null;

  let previewHtml = '';
  if (docMode === 'id_cards') {
    previewHtml = `
      <div style="display:grid;grid-template-columns:repeat(auto-fill, minmax(260px, 1fr));gap:16px;">
        ${filteredStu.map((s) => {
          const code = `ID-${s.studentCode || s.id.slice(-4)}`;
          const qr = generateQrSvg(`${window.location.origin}${window.location.pathname}#/verify/${code}`, 64);
          return `
            <div class="receipt-paper" style="padding:14px;page-break-inside:avoid;border-top:6px solid var(--brand-primary);">
              <div style="text-align:center;border-bottom:1px solid var(--border-color);padding-bottom:8px;margin-bottom:10px;">
                <strong style="font-size:0.95rem;color:var(--brand-primary);">${escapeHtml(brand.nameBn || 'মাদ্রাসা')}</strong>
                <div style="font-size:0.7rem;color:#485B54;">ছাত্র পরিচয়পত্র (ID CARD)</div>
              </div>
              <div style="display:flex;justify-content:space-between;gap:10px;align-items:center;">
                <div style="font-size:0.8rem;">
                  <div><strong>নাম:</strong> ${escapeHtml(s.nameBn)}</div>
                  <div><strong>আইডি:</strong> ${escapeHtml(s.studentCode || s.id)}</div>
                  <div><strong>জামাত:</strong> ${escapeHtml(jamatMap[s.jamatId] || '-')}</div>
                  <div><strong>রোল:</strong> ${formatNum(s.rollNumber)}</div>
                  <div><strong>ফোন:</strong> ${formatNum(s.guardianPhone || '-')}</div>
                </div>
                <div>${qr}</div>
              </div>
            </div>
          `;
        }).join('')}
      </div>
    `;
  } else if (activeStu) {
    const isTc = docMode === 'tc';
    const verifyCode = `${isTc ? 'TC' : 'CRT'}-${activeStu.studentCode || activeStu.id.slice(-4)}`;
    const qr = generateQrSvg(`${window.location.origin}${window.location.pathname}#/verify/${verifyCode}`, 84);
    previewHtml = `
      <div class="receipt-paper" style="border:3px double var(--brand-primary);padding:28px;">
        <div style="text-align:center;margin-bottom:20px;">
          <h2 style="font-size:1.35rem;color:var(--brand-primary);">${escapeHtml(brand.nameBn || 'মাদ্রাসা')}</h2>
          <div style="font-size:0.85rem;color:#485B54;">${escapeHtml(brand.address || '')} | ফোন: ${escapeHtml(brand.phone || '')}</div>
          <div style="display:inline-block;margin-top:12px;padding:4px 18px;border:1px solid var(--brand-primary);border-radius:99px;font-weight:700;">
            ${isTc ? 'ছাড়পত্র (Transfer Certificate)' : 'প্রশংসাপত্র / একাডেমিক সনদ'}
          </div>
        </div>
        <p style="line-height:1.9;text-align:justify;margin-bottom:24px;">
          এই মর্মে প্রত্যয়ন করা যাচ্ছে যে, <strong>${escapeHtml(activeStu.nameBn)}</strong>,
          পিতা: <strong>${escapeHtml(activeStu.fatherName || '-')}</strong>,
          ছাত্র আইডি: <strong>${escapeHtml(activeStu.studentCode || activeStu.id)}</strong>,
          অত্র মাদ্রাসার <strong>${escapeHtml(jamatMap[activeStu.jamatId] || '')}</strong> জামাতের (রোল: ${formatNum(activeStu.rollNumber)}) একজন নিয়মিত শিক্ষার্থী।
          ${isTc
            ? 'অভিভাবকের আবেদনের প্রেক্ষিতে অদ্য তাকে অত্র প্রতিষ্ঠান হতে ছাড়পত্র প্রদান করা হলো। তার মাদ্রাসার সকল পাওনা পরিশোধিত রয়েছে।'
            : 'অত্র প্রতিষ্ঠানে অধ্যয়নকালে তার আখলাক, চরিত্র ও পড়াশোনার মান অত্যন্ত সন্তোষজনক ছিল। আমরা তার উজ্জ্বল দ্বীনি ভবিষ্যৎ কামনা করি।'}
        </p>
        <div style="display:flex;justify-content:space-between;align-items:flex-end;">
          <div style="display:flex;align-items:center;gap:10px;">
            <div>${qr}</div>
            <div style="font-size:0.75rem;color:#485B54;">
              <div>তারিখ: ${todayISO()}</div>
              <div>${getHijriDateString(new Date())}</div>
              <div>কোড: ${escapeHtml(verifyCode)}</div>
            </div>
          </div>
          <div class="sig-line">${escapeHtml(brand.muhtamimName || 'মুহতামিম')}</div>
        </div>
      </div>
    `;
  }

  container.innerHTML = `
    <div class="page-header no-print">
      <div>
        <h1>সনদ, ছাড়পত্র (TC) ও বাল্ক আইডি কার্ড</h1>
        <p class="page-subtitle">QR যাচাইসহ পুরো জামাতের আইডি কার্ড ও সনদ প্রিন্ট</p>
      </div>
      <div style="display:flex;gap:8px;">
        ${docMode !== 'id_cards' ? `<button type="button" class="btn btn-secondary btn-sm" id="doc-reg-qr">${icon('qr', 'sm')} QR রেজিস্টার</button>` : ''}
        <button type="button" class="btn btn-primary btn-sm" onclick="window.print()">${icon('print', 'sm')} প্রিন্ট / PDF</button>
      </div>
    </div>

    <div class="tabs no-print">
      <button type="button" class="tab-btn ${docMode === 'id_cards' ? 'active' : ''}" data-dmode="id_cards">বাল্ক আইডি কার্ড</button>
      <button type="button" class="tab-btn ${docMode === 'certificate' ? 'active' : ''}" data-dmode="certificate">সনদ / প্রশংসাপত্র</button>
      <button type="button" class="tab-btn ${docMode === 'tc' ? 'active' : ''}" data-dmode="tc">ছাড়পত্র (TC)</button>
    </div>

    <div class="toolbar no-print">
      ${docMode === 'id_cards' ? `
        <select id="doc-jamat" class="form-control">
          <option value="all">সকল জামাত (${formatNum(students.length)} জন)</option>
          ${jamats.map((j) => `<option value="${j.id}" ${selectedJamat === j.id ? 'selected' : ''}>${escapeHtml(j.nameBn)}</option>`).join('')}
        </select>
      ` : `
        <select id="doc-stu" class="form-control">
          ${students.map((s) => `<option value="${s.id}" ${selectedStudentId === s.id ? 'selected' : ''}>${escapeHtml(s.nameBn)} (${escapeHtml(s.studentCode || '')})</option>`).join('')}
        </select>
      `}
    </div>

    ${previewHtml}
  `;

  container.querySelectorAll('[data-dmode]').forEach((b) => {
    b.onclick = () => {
      docMode = b.dataset.dmode;
      renderDocuments(container);
    };
  });

  document.getElementById('doc-jamat')?.addEventListener('change', (e) => {
    selectedJamat = e.target.value;
    renderDocuments(container);
  });

  document.getElementById('doc-stu')?.addEventListener('change', (e) => {
    selectedStudentId = e.target.value;
    renderDocuments(container);
  });

  document.getElementById('doc-reg-qr')?.addEventListener('click', async () => {
    if (!activeStu) return;
    const isTc = docMode === 'tc';
    const verifyCode = `${isTc ? 'TC' : 'CRT'}-${activeStu.studentCode || activeStu.id.slice(-4)}`;
    const serialNo = await nextSerial(isTc ? 'tc_serial' : 'cert_serial', isTc ? 'TC-' : 'CRT-');
    await setDocById('public_verifications', verifyCode, {
      docType: isTc ? 'tc' : 'certificate',
      serialNo,
      holderName: activeStu.nameBn,
      issuedDate: todayISO(),
      status: 'valid'
    });
    if (isTc) {
      await setDocById('students', activeStu.id, { status: 'tc_issued' }, true);
    }
    showToast(`ডকুমেন্ট QR যাচাই কোড (${verifyCode}) রেজিস্টার হয়েছে`, 'success');
  });
}
