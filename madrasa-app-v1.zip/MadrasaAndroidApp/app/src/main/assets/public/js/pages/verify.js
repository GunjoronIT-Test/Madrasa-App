import { getDocById } from '../core/store.js';
import { getBrand } from '../core/brand.js';
import { icon } from '../core/icons.js';
import { formatCurrency, escapeHtml } from '../core/utils.js';

export async function renderVerify(container, route) {
  const code = route.param || '';
  const record = code ? await getDocById('public_verifications', code) : null;
  const brand = getBrand();

  container.innerHTML = `
    <div class="auth-wrap">
      <div class="card">
        <div style="text-align:center;margin-bottom:16px;">
          ${icon('shield', 'lg')}
          <h1 style="margin-top:8px;">ডকুমেন্ট ও রিসিট যাচাই</h1>
          <p class="page-subtitle">${escapeHtml(brand?.nameBn || 'মাদ্রাসা ম্যানেজমেন্ট সিস্টেম')}</p>
        </div>

        ${record ? `
          <div class="alert-box ${record.status === 'valid' ? 'alert-info' : 'alert-danger'}">
            ${icon(record.status === 'valid' ? 'check' : 'alert', 'sm')}
            <span>${record.status === 'valid' ? 'এই ডকুমেন্টটি আসল ও বৈধ।' : 'সতর্কতা: এই রিসিটটি বাতিল (Revoked) করা হয়েছে।'}</span>
          </div>
          <div class="form-grid" style="margin-top:12px;">
            <div><strong>সিরিয়াল নম্বর:</strong> ${escapeHtml(record.serialNo)}</div>
            <div><strong>নাম / বিবরণ:</strong> ${escapeHtml(record.holderName)}</div>
            ${record.amount ? `<div><strong>টাকার পরিমাণ:</strong> ${formatCurrency(record.amount)}</div>` : ''}
            <div><strong>ইস্যু তারিখ:</strong> ${escapeHtml(record.issuedDate)}</div>
          </div>
        ` : `
          <div class="alert-box alert-danger">
            ${icon('alert', 'sm')}
            <span>এই কোডে (${escapeHtml(code || 'খালি')}) কোনো বৈধ রেকর্ড পাওয়া যায়নি।</span>
          </div>
        `}
      </div>
    </div>
  `;
}
