import { getDocById, listCollection, setDocById, isLiveFirebase } from './store.js';
import { getFirebaseState } from './firebase.js';
import { sha256Hex, openModal, closeModal, showToast } from './utils.js';

const SESSION_KEY = 'madrasa_session_uid';
let currentUser = null;

export function getCurrentUser() {
  return currentUser;
}

export function hasAnyRole(roles = []) {
  return Boolean(currentUser && roles.includes(currentUser.role));
}

export async function restoreSession() {
  if (isLiveFirebase()) {
    const { auth, sdk } = getFirebaseState();
    const fbUser = await new Promise((resolve) => {
      const unsub = sdk.authMod.onAuthStateChanged(auth, (u) => {
        unsub();
        resolve(u);
      });
    });
    if (fbUser) {
      currentUser = await getDocById('users', fbUser.uid);
      return currentUser;
    }
    return null;
  }

  const uid = localStorage.getItem(SESSION_KEY);
  if (!uid) return null;
  const user = await getDocById('users', uid);
  if (user && user.status === 'active' && !user.isDeleted) {
    currentUser = user;
    return currentUser;
  }
  localStorage.removeItem(SESSION_KEY);
  return null;
}

export async function loginWithCredentials(email, password) {
  const cleanEmail = String(email || '').trim().toLowerCase();
  if (isLiveFirebase()) {
    const { auth, sdk } = getFirebaseState();
    const cred = await sdk.authMod.signInWithEmailAndPassword(auth, cleanEmail, password);
    const profile = await getDocById('users', cred.user.uid);
    if (!profile || profile.status !== 'active') {
      throw new Error('আপনার অ্যাকাউন্ট সক্রিয় নয়। মুহতামিমের সাথে যোগাযোগ করুন।');
    }
    currentUser = profile;
    return currentUser;
  }

  const users = await listCollection('users', (u) => !u.isDeleted && u.status === 'active');
  const found = users.find((u) => String(u.email || '').toLowerCase() === cleanEmail);
  if (!found) {
    throw new Error('এই ইমেইলে কোনো সক্রিয় অ্যাকাউন্ট পাওয়া যায়নি।');
  }
  const passHash = await sha256Hex(`${found.uid}:${password}`);
  if (found.passwordHash && found.passwordHash !== passHash) {
    throw new Error('পাসওয়ার্ড সঠিক নয়।');
  }
  currentUser = found;
  localStorage.setItem(SESSION_KEY, found.uid);
  return currentUser;
}

export async function setUserPin(uid, rawPin) {
  const salt = `${uid}_pin_v1`;
  const pinHash = await sha256Hex(`${salt}:${rawPin}`);
  await setDocById('users', uid, { pinHash, pinSalt: salt }, true);
  if (currentUser && currentUser.uid === uid) {
    currentUser.pinHash = pinHash;
    currentUser.pinSalt = salt;
  }
}

export function requirePinConfirmation(actionDescription) {
  return new Promise((resolve) => {
    if (!currentUser?.pinHash) {
      resolve(true);
      return;
    }
    openModal({
      title: 'নিরাপত্তা PIN নিশ্চিতকরণ',
      bodyHtml: `
        <p style="margin-bottom:12px;color:var(--text-secondary);">${actionDescription}</p>
        <div class="form-group">
          <label class="form-label" for="pin-confirm-input">আপনার ৪ সংখ্যার PIN দিন</label>
          <input id="pin-confirm-input" class="form-control" type="password" inputmode="numeric" maxlength="6" autocomplete="off" placeholder="****">
        </div>
      `,
      footerHtml: `
        <button type="button" class="btn btn-secondary" id="pin-cancel-btn">বাতিল</button>
        <button type="button" class="btn btn-primary" id="pin-ok-btn">নিশ্চিত করুন</button>
      `
    });
    const input = document.getElementById('pin-confirm-input');
    input?.focus();

    document.getElementById('pin-cancel-btn').onclick = () => {
      closeModal();
      resolve(false);
    };
    document.getElementById('pin-ok-btn').onclick = async () => {
      const val = input.value.trim();
      const hashed = await sha256Hex(`${currentUser.pinSalt || `${currentUser.uid}_pin_v1`}:${val}`);
      if (hashed === currentUser.pinHash) {
        closeModal();
        resolve(true);
      } else {
        showToast('PIN সঠিক নয়। আবার চেষ্টা করুন।', 'error');
        input.value = '';
        input.focus();
      }
    };
  });
}

export async function logout() {
  if (isLiveFirebase()) {
    const { auth, sdk } = getFirebaseState();
    await sdk.authMod.signOut(auth);
  }
  localStorage.removeItem(SESSION_KEY);
  currentUser = null;
}
