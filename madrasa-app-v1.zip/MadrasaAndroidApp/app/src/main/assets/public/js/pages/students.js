import { listCollection, setDocById } from '../core/store.js';
import { navigate } from '../core/router.js';
import { requirePinConfirmation } from '../core/auth.js';
import { logAudit } from '../core/audit.js';
import { icon } from '../core/icons.js';
import { formatNum, formatCurrency, escapeHtml, STUDENT_CATEGORIES, openModal, closeModal, showToast } from '../core/utils.js';

let searchTerm = '';
let filterJamat = 'all';
let filterCat = 'all';
let showBin = false;

export async function renderStudents(container) {
  const [allStudents, jamats] = await Promise.all([
    listCollection('students'),
    listCollection('jamats', (j) => !j.isDeleted)
  ]);

  const jamatMap = Object.fromEntries(jamats.map((j) => [j.id, j.nameBn]));

  const filtered = allStudents
    .filter((s) => (showBin ? s.isDeleted === true : !s.isDeleted))
    .filter((s) => filterJamat === 'all' || s.jamatId === filterJamat)
    .filter((s) => filterCat === 'all' || s.category === filterCat)
    .filter((s) => {
      if (!searchTerm) return true;
      const q = searchTerm.toLowerCase();
      return (
        String(s.nameBn || '').toLowerCase().includes(q) ||
        String(s.studentCode || '').toLowerCase().includes(q) ||
        String(s.guardianPhone || '').toLowerCase().includes(q)
      );
    })
    .sort((a, b) => Number(a.rollNumber || 0) - Number(b.rollNumber || 0));

  container.innerHTML = `
    <div class="page-header">
      <div>
        <h1>ছাত্র ব্যবস্থাপনা</h1>
        <p class="page-subtitle">মোট তালিকাভুক্ত: ${formatNum(filtered.length)} জন</p>
      </div>
      <div style="display:flex;gap:8px;">
        <button type="button" class="btn btn-secondary btn-sm" id="stu-toggle-bin">${showBin ? 'সক্রিয় তালিকা' : 'রিসাইকেল বিন'}</button>
        <button type="button" class="btn btn-primary btn-sm" id="stu-add-btn">${icon('admission', 'sm')} নতুন ভর্তি</button>
      </div>
    </div>

    <div class="toolbar">
      <input type="search" id="stu-search" class="form-control" placeholder="নাম, আইডি বা অভিভাবকের ফোন..." value="${escapeHtml(searchTerm)}">
      <select id="stu-jamat-filter" class="form-control">
        <option value="all">সকল জামাত</option>
        ${jamats.map((j) => `<option value="${j.id}" ${filterJamat === j.id ? 'selected' : ''}>${escapeHtml(j.nameBn)}</option>`).join('')}
      </select>
      <select id="stu-cat-filter" class="form-control">
        <option value="all">সকল ধরন</option>
        ${Object.entries(STUDENT_CATEGORIES).map(([k, v]) => `<option value="${k}" ${filterCat === k ? 'selected' : ''}>${v}</option>`).join('')}
      </select>
    </div>

    ${filtered.length === 0 ? `
      <div class="card empty-state">
        ${icon('students', 'lg')}
        <p>${showBin ? 'রিসাইকেল বিনে কোনো ছাত্র নেই।' : 'কোনো ছাত্র পাওয়া যায়নি।'}</p>
      </div>
    ` : `
      <div class="list-stack">
        ${filtered.map((s) => `
          <div class="list-item">
            <div class="list-item-main">
              <div class="list-item-title">${escapeHtml(s.nameBn)} <span class="badge badge-neutral">রোল ${formatNum(s.rollNumber)}</span></div>
              <div class="list-item-sub">
                ${escapeHtml(jamatMap[s.jamatId] || 'অনির্ধারিত')} |
                ${STUDENT_CATEGORIES[s.category] || 'সাধারণ'} |
                ফোন: ${formatNum(s.guardianPhone || '-')} |
                ফি: ${formatCurrency(Math.max(0, Number(s.monthlyFee || 0) - Number(s.feeWaiverAmount || 0)))}
              </div>
            </div>
            <div class="list-item-actions">
              ${showBin
                ? `<button type="button" class="btn btn-outline btn-sm" data-restore="${s.id}">পুনরুদ্ধার</button>`
                : `<button type="button" class="btn btn-secondary btn-sm" data-view="${s.id}">প্রোফাইল</button>`}
            </div>
          </div>
        `).join('')}
      </div>
    `}
  `;

  document.getElementById('stu-add-btn').onclick = () => navigate('/admission');
  document.getElementById('stu-toggle-bin').onclick = () => {
    showBin = !showBin;
    renderStudents(container);
  };
  document.getElementById('stu-search').oninput = (e) => {
    searchTerm = e.target.value;
    renderStudents(container);
  };
  document.getElementById('stu-jamat-filter').onchange = (e) => {
    filterJamat = e.target.value;
    renderStudents(container);
  };
  document.getElementById('stu-cat-filter').onchange = (e) => {
    filterCat = e.target.value;
    renderStudents(container);
  };

  container.querySelectorAll('[data-view]').forEach((btn) => {
    btn.onclick = () => {
      const stu = allStudents.find((x) => x.id === btn.dataset.view);
      if (!stu) return;
      openModal({
        title: `ছাত্র প্রোফাইল — ${stu.nameBn}`,
        bodyHtml: `
          <div class="form-grid">
            <div><strong>আইডি:</strong> ${escapeHtml(stu.studentCode || stu.id)}</div>
            <div><strong>জামাত:</strong> ${escapeHtml(jamatMap[stu.jamatId] || '-')} (রোল ${formatNum(stu.rollNumber)})</div>
            <div><strong>পিতা / অভিভাবক:</strong> ${escapeHtml(stu.fatherName || '-')} / ${escapeHtml(stu.guardianName || '-')}</div>
            <div><strong>ফোন:</strong> ${formatNum(stu.guardianPhone || '-')}</div>
            <div><strong>ধরন:</strong> ${STUDENT_CATEGORIES[stu.category] || 'সাধারণ'}</div>
            <div><strong>মাসিক ফি:</strong> ${formatCurrency(stu.monthlyFee)} (মওকুফ: ${formatCurrency(stu.feeWaiverAmount || 0)})</div>
            <div class="form-group">
              <label class="form-label">আচরণ / স্বাস্থ্য নোট</label>
              <textarea id="stu-note-edit" class="form-control">${escapeHtml(stu.healthNotes || '')}</textarea>
            </div>
          </div>
        `,
        footerHtml: `
          <button type="button" class="btn btn-danger btn-sm" id="stu-soft-del">রিসাইকেল বিনে পাঠান</button>
          <button type="button" class="btn btn-primary btn-sm" id="stu-save-note">নোট সংরক্ষণ</button>
        `
      });

      document.getElementById('stu-save-note').onclick = async () => {
        const note = document.getElementById('stu-note-edit').value.trim();
        await setDocById('students', stu.id, { healthNotes: note }, true);
        await logAudit({ action: 'UPDATE_STUDENT', collection: 'students', docId: stu.id, summary: `ছাত্র নোট হালনাগাদ: ${stu.nameBn}` });
        closeModal();
        showToast('তথ্য হালনাগাদ হয়েছে', 'success');
        renderStudents(container);
      };

      document.getElementById('stu-soft-del').onclick = async () => {
        closeModal();
        const ok = await requirePinConfirmation(`"${stu.nameBn}"-কে রিসাইকেল বিনে পাঠাতে PIN নিশ্চিত করুন।`);
        if (!ok) return;
        await setDocById('students', stu.id, { isDeleted: true, deletedAt: new Date().toISOString() }, true);
        await logAudit({ action: 'SOFT_DELETE_STUDENT', collection: 'students', docId: stu.id, summary: `রিসাইকেল বিনে পাঠানো হয়েছে: ${stu.nameBn}` });
        showToast('ছাত্রকে রিসাইকেল বিনে পাঠানো হয়েছে', 'warning');
        renderStudents(container);
      };
    };
  });

  container.querySelectorAll('[data-restore]').forEach((btn) => {
    btn.onclick = async () => {
      const id = btn.dataset.restore;
      await setDocById('students', id, { isDeleted: false }, true);
      await logAudit({ action: 'RESTORE_STUDENT', collection: 'students', docId: id, summary: 'রিসাইকেল বিন থেকে ছাত্র পুনরুদ্ধার' });
      showToast('ছাত্র পুনরুদ্ধার করা হয়েছে', 'success');
      renderStudents(container);
    };
  });
}
