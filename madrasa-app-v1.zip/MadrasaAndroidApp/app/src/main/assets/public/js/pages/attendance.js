import { listCollection, setDocById } from '../core/store.js';
import { getCurrentUser } from '../core/auth.js';
import { icon } from '../core/icons.js';
import { todayISO, getHijriDateString, formatNum, escapeHtml, showToast } from '../core/utils.js';

let selectedDate = todayISO();
let selectedJamat = 'all';

export async function renderAttendance(container) {
  const [jamats, students, allAtt] = await Promise.all([
    listCollection('jamats', (j) => !j.isDeleted),
    listCollection('students', (s) => !s.isDeleted && s.status === 'active'),
    listCollection('attendance', (a) => a.type === 'student')
  ]);

  const filteredStudents = students
    .filter((s) => selectedJamat === 'all' || s.jamatId === selectedJamat)
    .sort((a, b) => Number(a.rollNumber || 0) - Number(b.rollNumber || 0));

  const dayMap = {};
  allAtt.filter((a) => a.date === selectedDate).forEach((a) => {
    dayMap[a.targetId] = a.status;
  });

  // গত ৭ দিনে ৩+ দিন অনুপস্থিত সতর্কতা
  const recentAbsences = {};
  allAtt.filter((a) => a.status === 'absent').forEach((a) => {
    recentAbsences[a.targetId] = (recentAbsences[a.targetId] || 0) + 1;
  });

  const presentCnt = filteredStudents.filter((s) => dayMap[s.id] === 'present').length;
  const absentCnt = filteredStudents.filter((s) => dayMap[s.id] === 'absent').length;

  container.innerHTML = `
    <div class="page-header">
      <div>
        <h1>দৈনিক হাজিরা</h1>
        <p class="page-subtitle">উপস্থিত: ${formatNum(presentCnt)} | অনুপস্থিত: ${formatNum(absentCnt)} | মোট: ${formatNum(filteredStudents.length)}</p>
      </div>
      <button type="button" class="btn btn-primary btn-sm" id="att-mark-all">${icon('check', 'sm')} সবাই উপস্থিত</button>
    </div>

    <div class="toolbar">
      <input type="date" id="att-date" class="form-control" value="${selectedDate}">
      <select id="att-jamat" class="form-control">
        <option value="all">সকল জামাত</option>
        ${jamats.map((j) => `<option value="${j.id}" ${selectedJamat === j.id ? 'selected' : ''}>${escapeHtml(j.nameBn)}</option>`).join('')}
      </select>
    </div>

    ${filteredStudents.length === 0 ? `
      <div class="card empty-state">
        ${icon('attendance', 'lg')}
        <p>এই জামাতে কোনো সক্রিয় ছাত্র নেই।</p>
      </div>
    ` : `
      <div class="list-stack">
        ${filteredStudents.map((s) => {
          const st = dayMap[s.id] || '';
          const absCount = recentAbsences[s.id] || 0;
          return `
            <div class="list-item" style="flex-wrap:wrap;">
              <div class="list-item-main">
                <div class="list-item-title">
                  ${formatNum(s.rollNumber)}. ${escapeHtml(s.nameBn)}
                  ${absCount >= 3 ? `<span class="badge badge-danger">বেশি অনুপস্থিত (${formatNum(absCount)} দিন)</span>` : ''}
                </div>
                <div class="list-item-sub">ফোন: ${formatNum(s.guardianPhone || '-')}</div>
              </div>
              <div class="att-btn-group">
                <button type="button" class="att-pill present ${st === 'present' ? 'active' : ''}" data-stu="${s.id}" data-jamat="${s.jamatId}" data-status="present">উপস্থিত</button>
                <button type="button" class="att-pill absent ${st === 'absent' ? 'active' : ''}" data-stu="${s.id}" data-jamat="${s.jamatId}" data-status="absent">অনুপস্থিত</button>
                <button type="button" class="att-pill leave ${st === 'leave' ? 'active' : ''}" data-stu="${s.id}" data-jamat="${s.jamatId}" data-status="leave">ছুটি</button>
                <button type="button" class="att-pill late ${st === 'late' ? 'active' : ''}" data-stu="${s.id}" data-jamat="${s.jamatId}" data-status="late">দেরি</button>
              </div>
            </div>
          `;
        }).join('')}
      </div>
    `}
  `;

  document.getElementById('att-date').onchange = (e) => {
    selectedDate = e.target.value;
    renderAttendance(container);
  };
  document.getElementById('att-jamat').onchange = (e) => {
    selectedJamat = e.target.value;
    renderAttendance(container);
  };

  async function saveStatus(studentId, jamatId, status) {
    const docId = `main_student_${selectedDate}_${studentId}`;
    await setDocById('attendance', docId, {
      branchId: 'main',
      type: 'student',
      date: selectedDate,
      hijriDate: getHijriDateString(new Date(selectedDate)),
      targetId: studentId,
      jamatId: jamatId || '',
      status,
      markedBy: getCurrentUser()?.uid || 'system'
    });
  }

  container.querySelectorAll('.att-pill').forEach((btn) => {
    btn.onclick = async () => {
      await saveStatus(btn.dataset.stu, btn.dataset.jamat, btn.dataset.status);
      renderAttendance(container);
    };
  });

  document.getElementById('att-mark-all').onclick = async () => {
    for (const s of filteredStudents) {
      await saveStatus(s.id, s.jamatId, 'present');
    }
    showToast('সকল ছাত্রকে উপস্থিত হিসেবে সংরক্ষণ করা হয়েছে', 'success');
    renderAttendance(container);
  };
}
