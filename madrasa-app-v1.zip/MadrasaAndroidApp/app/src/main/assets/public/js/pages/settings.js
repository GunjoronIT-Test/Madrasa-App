import { setDocById, listCollection, exportFullBackup, restoreFullBackup } from '../core/store.js';
import { getBrand, loadAndApplyBrand, toggleTheme } from '../core/brand.js';
import { getCurrentUser, logout, setUserPin, requirePinConfirmation, hasAnyRole } from '../core/auth.js';
import { logAudit } from '../core/audit.js';
import { navigate } from '../core/router.js';
import { icon } from '../core/icons.js';
import { escapeHtml, showToast, readFileAsDataUrl, ROLE_LABELS } from '../core/utils.js';

export async function renderSettings(container) {
  const brand = getBrand() || {};
  const user = getCurrentUser();
  const auditLogs = hasAnyRole(['muhtamim', 'nayeb_muhtamim'])
    ? (await listCollection('audit_logs')).sort((a, b) => String(b.createdAt).localeCompare(String(a.createdAt))).slice(0, 15)
    : [];

  container.innerHTML = `
    <div class="page-header">
      <div>
        <h1>সেটিংস, ব্র্যান্ডিং ও ব্যাকআপ</h1>
        <p class="page-subtitle">লগইন: ${escapeHtml(user?.name || '')} (${ROLE_LABELS[user?.role] || user?.role || ''})</p>
      </div>
      <button type="button" class="btn btn-danger btn-sm" id="set-logout">${icon('logout', 'sm')} লগআউট</button>
    </div>

    <div class="card">
      <h2 style="margin-bottom:12px;">প্রতিষ্ঠানের ব্র্যান্ডিং (এক জায়গায় বদলালে সর্বত্র বদলাবে)</h2>
      <form id="brand-form" class="form-grid cols-2">
        <div class="form-group">
          <label class="form-label">মাদ্রাসার নাম (বাংলা)</label>
          <input id="set-nameBn" class="form-control" value="${escapeHtml(brand.nameBn || '')}">
        </div>
        <div class="form-group">
          <label class="form-label">মুহতামিমের নাম</label>
          <input id="set-muhtamim" class="form-control" value="${escapeHtml(brand.muhtamimName || '')}">
        </div>
        <div class="form-group">
          <label class="form-label">ঠিকানা</label>
          <input id="set-address" class="form-control" value="${escapeHtml(brand.address || '')}">
        </div>
        <div class="form-group">
          <label class="form-label">ফোন</label>
          <input id="set-phone" class="form-control" value="${escapeHtml(brand.phone || '')}">
        </div>
        <div class="form-group">
          <label class="form-label">প্রধান রঙ</label>
          <input id="set-primary" class="form-control" type="color" value="${escapeHtml(brand.primaryColor || '#0F6E56')}">
        </div>
        <div class="form-group">
          <label class="form-label">সংখ্যার ফরম্যাট</label>
          <select id="set-numfmt" class="form-control">
            <option value="bn" ${brand.numberFormat !== 'en' ? 'selected' : ''}>বাংলা সংখ্যা (১২৩)</option>
            <option value="en" ${brand.numberFormat === 'en' ? 'selected' : ''}>ইংরেজি সংখ্যা (123)</option>
          </select>
        </div>
        <div class="form-group">
          <label class="form-label">খরচ অনুমোদন সীমা (টাকা)</label>
          <input id="set-limit" class="form-control" type="number" min="0" value="${Number(brand.expenseApprovalLimit || 10000)}">
        </div>
        <div class="form-group">
          <label class="form-label">নতুন লোগো আপলোড</label>
          <input id="set-logo" class="form-control" type="file" accept="image/*">
        </div>
        <div style="grid-column:1/-1;display:flex;justify-content:space-between;flex-wrap:wrap;gap:8px;">
          <button type="button" class="btn btn-secondary" id="set-theme-btn">ডার্ক / লাইট থিম বদলান</button>
          <button type="submit" class="btn btn-primary">${icon('check', 'sm')} ব্র্যান্ডিং সংরক্ষণ</button>
        </div>
      </form>
    </div>

    <div class="card">
      <h2 style="margin-bottom:12px;">নিরাপত্তা PIN ও ডেটা ব্যাকআপ</h2>
      <div class="form-grid cols-2">
        <div class="form-group">
          <label class="form-label">নতুন ৪ সংখ্যার PIN সেট করুন</label>
          <div style="display:flex;gap:8px;">
            <input id="set-new-pin" class="form-control" type="password" inputmode="numeric" maxlength="6" placeholder="****">
            <button type="button" class="btn btn-secondary" id="set-pin-btn">হালনাগাদ</button>
          </div>
        </div>
        <div class="form-group">
          <label class="form-label">পূর্ণ ডেটা ব্যাকআপ ও পুনরুদ্ধার (JSON)</label>
          <div style="display:flex;gap:8px;flex-wrap:wrap;">
            <button type="button" class="btn btn-primary" id="set-export-btn">${icon('download', 'sm')} এক ট্যাপ ব্যাকআপ</button>
            <label class="btn btn-outline" style="cursor:pointer;">
              রিস্টোর করুন
              <input id="set-import-file" type="file" accept="application/json" hidden>
            </label>
          </div>
        </div>
      </div>
    </div>

    ${auditLogs.length > 0 ? `
      <div class="card">
        <h2 style="margin-bottom:12px;">সাম্প্রতিক অডিট লগ (কে কী পরিবর্তন করেছে)</h2>
        <div class="list-stack">
          ${auditLogs.map((l) => `
            <div class="list-item">
              <div class="list-item-main">
                <div class="list-item-title">${escapeHtml(l.summary || l.action)}</div>
                <div class="list-item-sub">${escapeHtml(l.actorName)} (${ROLE_LABELS[l.actorRole] || l.actorRole}) | ${escapeHtml(String(l.createdAt || '').slice(0, 16).replace('T', ' '))}</div>
              </div>
            </div>
          `).join('')}
        </div>
      </div>
    ` : ''}
  `;

  let newLogoUrl = brand.logoUrl || '';
  document.getElementById('set-logo').onchange = async (e) => {
    try {
      newLogoUrl = await readFileAsDataUrl(e.target.files[0], 800 * 1024);
      showToast('নতুন লোগো প্রস্তুত', 'success');
    } catch (err) {
      showToast(err.message, 'error');
    }
  };

  document.getElementById('brand-form').onsubmit = async (e) => {
    e.preventDefault();
    await setDocById('settings', 'institution', {
      nameBn: document.getElementById('set-nameBn').value.trim(),
      muhtamimName: document.getElementById('set-muhtamim').value.trim(),
      address: document.getElementById('set-address').value.trim(),
      phone: document.getElementById('set-phone').value.trim(),
      primaryColor: document.getElementById('set-primary').value,
      numberFormat: document.getElementById('set-numfmt').value,
      expenseApprovalLimit: Number(document.getElementById('set-limit').value || 10000),
      logoUrl: newLogoUrl
    }, true);
    await loadAndApplyBrand();
    await logAudit({ action: 'UPDATE_BRANDING', collection: 'settings', docId: 'institution', summary: 'প্রতিষ্ঠানের ব্র্যান্ডিং হালনাগাদ' });
    showToast('ব্র্যান্ডিং সফলভাবে হালনাগাদ হয়েছে', 'success');
  };

  document.getElementById('set-theme-btn').onclick = () => {
    const next = toggleTheme();
    showToast(next === 'dark' ? 'ডার্ক থিম চালু হয়েছে' : 'লাইট থিম চালু হয়েছে', 'info');
  };

  document.getElementById('set-pin-btn').onclick = async () => {
    const pin = document.getElementById('set-new-pin').value.trim();
    if (pin.length < 4) return showToast('কমপক্ষে ৪ সংখ্যার PIN দিন', 'warning');
    await setUserPin(user.uid, pin);
    document.getElementById('set-new-pin').value = '';
    showToast('নিরাপত্তা PIN হালনাগাদ হয়েছে', 'success');
  };

  document.getElementById('set-export-btn').onclick = async () => {
    const dump = await exportFullBackup();
    const blob = new Blob([JSON.stringify(dump, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `madrasa-backup-${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
    await logAudit({ action: 'EXPORT_BACKUP', collection: 'system', docId: 'backup', summary: 'পূর্ণ ডেটা ব্যাকআপ ডাউনলোড' });
    showToast('পূর্ণ ব্যাকআপ ফাইল ডাউনলোড হয়েছে', 'success');
  };

  document.getElementById('set-import-file').onchange = async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    const ok = await requirePinConfirmation('ব্যাকআপ রিস্টোর করলে বর্তমান ডেটা হালনাগাদ হবে। নিশ্চিত করতে PIN দিন।');
    if (!ok) return;
    try {
      const parsed = JSON.parse(await file.text());
      await restoreFullBackup(parsed);
      await loadAndApplyBrand();
      showToast('ব্যাকআপ সফলভাবে রিস্টোর হয়েছে', 'success');
      renderSettings(container);
    } catch (err) {
      showToast(err.message || 'ব্যাকআপ ফাইল পড়া যায়নি', 'error');
    }
  };

  document.getElementById('set-logout').onclick = async () => {
    await logout();
    showToast('লগআউট সম্পন্ন হয়েছে', 'info');
    navigate('/login');
  };
}
