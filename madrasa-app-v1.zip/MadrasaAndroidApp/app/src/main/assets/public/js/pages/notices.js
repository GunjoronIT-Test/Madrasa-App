import { listCollection, addDocItem } from '../core/store.js';
import { getBrand } from '../core/brand.js';
import { getCurrentUser } from '../core/auth.js';
import { logAudit } from '../core/audit.js';
import { icon } from '../core/icons.js';
import { todayISO, escapeHtml, openModal, closeModal, showToast } from '../core/utils.js';

const TEMPLATES = [
  { label: 'ছুটির বিজ্ঞপ্তি', title: 'মাদ্রাসা ছুটির বিজ্ঞপ্তি', body: 'আসসালামু আলাইকুম। সকল অভিভাবক ও ছাত্রদের জানানো যাচ্ছে যে, আগামী ... তারিখ থেকে ... তারিখ পর্যন্ত মাদ্রাসা বন্ধ থাকবে।' },
  { label: 'বকেয়া ফি রিমাইন্ডার', title: 'মাসিক ফি পরিশোধের অনুরোধ', body: 'সম্মানিত অভিভাবক, আপনার সন্তানের চলতি মাসের ফি দ্রুত মাদ্রাসা অফিসে পরিশোধ করার জন্য বিনীত অনুরোধ করা হলো।' },
  { label: 'পরীক্ষার নোটিশ', title: 'সাময়িক পরীক্ষার সময়সূচি', body: 'আগামী ... তারিখ থেকে মাদ্রাসার সাময়িক পরীক্ষা শুরু হবে। সকল ছাত্রকে প্রবেশপত্র সংগ্রহ করার নির্দেশ দেওয়া হলো।' },
  { label: 'মাহফিল দাওয়াত', title: 'বার্ষিক ওয়াজ ও দোয়ার মাহফিল', body: 'আগামী ... তারিখ বাদ আসর মাদ্রাসা প্রাঙ্গণে বার্ষিক ওয়াজ মাহফিল অনুষ্ঠিত হবে। আপনার সপরিবারে উপস্থিতি কামনা করছি।' }
];

const AUDIENCE_LABELS = {
  all: 'সকল অভিভাবক ও স্টাফ',
  guardians: 'সকল অভিভাবক',
  staff: 'ওস্তাদ ও স্টাফ'
};

export async function renderNotices(container) {
  const notices = (await listCollection('notices'))
    .sort((a, b) => String(b.createdAt || b.date).localeCompare(String(a.createdAt || a.date)));
  const brand = getBrand() || {};

  container.innerHTML = `
    <div class="page-header">
      <div>
        <h1>নোটিশ বোর্ড ও যোগাযোগ</h1>
        <p class="page-subtitle">অভিভাবক ও ওস্তাদদের জন্য নোটিশ, পুশ সতর্কতা ও WhatsApp শেয়ার</p>
      </div>
      <div style="display:flex;gap:8px;">
        <button type="button" class="btn btn-secondary btn-sm" id="btn-req-push">${icon('bell', 'sm')} নোটিফিকেশন চালু</button>
        <button type="button" class="btn btn-primary btn-sm" id="btn-new-notice">${icon('plus', 'sm')} নতুন নোটিশ</button>
      </div>
    </div>

    ${notices.length === 0
      ? `<div class="card empty-state">${icon('bell', 'lg')}<p>এখনো কোনো নোটিশ প্রকাশ করা হয়নি।</p></div>`
      : `<div class="list-stack">
          ${notices.map((n) => {
            const shareText = encodeURIComponent(`${brand.nameBn || 'মাদ্রাসা'}\n${n.title}\n\n${n.body}`);
            return `
              <div class="card">
                <div style="display:flex;justify-content:space-between;align-items:flex-start;gap:8px;margin-bottom:8px;">
                  <div>
                    <h3>${escapeHtml(n.title)}</h3>
                    <div class="list-item-sub">${escapeHtml(n.date || '')} | প্রাপক: ${AUDIENCE_LABELS[n.audience] || n.audience}</div>
                  </div>
                  <span class="badge ${n.priority === 'urgent' ? 'badge-danger' : 'badge-info'}">${n.priority === 'urgent' ? 'জরুরি' : 'সাধারণ'}</span>
                </div>
                <p style="margin-bottom:12px;white-space:pre-line;">${escapeHtml(n.body)}</p>
                <div style="display:flex;justify-content:flex-end;">
                  <a class="btn btn-outline btn-sm" target="_blank" rel="noopener" href="https://wa.me/?text=${shareText}">WhatsApp-এ শেয়ার করুন</a>
                </div>
              </div>
            `;
          }).join('')}
        </div>`}
  `;

  document.getElementById('btn-req-push').onclick = async () => {
    if (!('Notification' in window)) return showToast('এই ব্রাউজারে পুশ নোটিফিকেশন সমর্থিত নয়', 'warning');
    const perm = await Notification.requestPermission();
    showToast(perm === 'granted' ? 'নোটিফিকেশন অনুমতি চালু হয়েছে' : 'অনুমতি দেওয়া হয়নি', perm === 'granted' ? 'success' : 'warning');
  };

  document.getElementById('btn-new-notice').onclick = () => {
    openModal({
      title: 'নতুন নোটিশ প্রকাশ করুন',
      bodyHtml: `
        <div class="form-grid">
          <div class="form-group">
            <label class="form-label">রেডিমেড টেমপ্লেট (ঐচ্ছিক)</label>
            <select id="nt-tpl" class="form-control">
              <option value="">নিজে লিখুন</option>
              ${TEMPLATES.map((t, i) => `<option value="${i}">${t.label}</option>`).join('')}
            </select>
          </div>
          <div class="form-group">
            <label class="form-label">শিরোনাম *</label>
            <input id="nt-title" class="form-control" required placeholder="নোটিশের শিরোনাম">
          </div>
          <div class="form-group">
            <label class="form-label">প্রাপক ও অগ্রাধিকার</label>
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;">
              <select id="nt-aud" class="form-control">
                <option value="all">সকল অভিভাবক ও স্টাফ</option>
                <option value="guardians">সকল অভিভাবক</option>
                <option value="staff">ওস্তাদ ও স্টাফ</option>
              </select>
              <select id="nt-prio" class="form-control">
                <option value="normal">সাধারণ</option>
                <option value="urgent">জরুরি</option>
              </select>
            </div>
          </div>
          <div class="form-group">
            <label class="form-label">বিস্তারিত বার্তা *</label>
            <textarea id="nt-body" class="form-control" rows="4" required></textarea>
          </div>
        </div>
      `,
      footerHtml: `
        <button type="button" class="btn btn-secondary" id="nt-cancel">বাতিল</button>
        <button type="button" class="btn btn-primary" id="nt-save">প্রকাশ করুন</button>
      `
    });

    document.getElementById('nt-tpl').onchange = (e) => {
      const idx = e.target.value;
      if (idx === '') return;
      const tpl = TEMPLATES[Number(idx)];
      document.getElementById('nt-title').value = tpl.title;
      document.getElementById('nt-body').value = tpl.body;
    };

    document.getElementById('nt-cancel').onclick = closeModal;
    document.getElementById('nt-save').onclick = async () => {
      const title = document.getElementById('nt-title').value.trim();
      const body = document.getElementById('nt-body').value.trim();
      if (!title || !body) return showToast('শিরোনাম ও বিস্তারিত লিখুন', 'warning');

      const doc = await addDocItem('notices', {
        branchId: 'main',
        title,
        body,
        audience: document.getElementById('nt-aud').value,
        priority: document.getElementById('nt-prio').value,
        date: todayISO(),
        createdBy: getCurrentUser()?.uid || 'system'
      });

      await logAudit({ action: 'PUBLISH_NOTICE', collection: 'notices', docId: doc.id, summary: `নোটিশ প্রকাশ: ${title}` });
      if ('Notification' in window && Notification.permission === 'granted') {
        new Notification(`${brand.nameBn || 'মাদ্রাসা'}: ${title}`, { body: body.slice(0, 120) });
      }
      closeModal();
      showToast('নোটিশ প্রকাশিত হয়েছে', 'success');
      renderNotices(container);
    };
  };
}
