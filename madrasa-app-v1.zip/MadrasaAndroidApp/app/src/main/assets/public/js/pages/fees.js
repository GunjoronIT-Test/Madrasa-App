import { listCollection, setDocById, addDocItem, nextSerial, getDocById } from '../core/store.js';
import { getCurrentUser } from '../core/auth.js';
import { logAudit } from '../core/audit.js';
import { navigate } from '../core/router.js';
import { icon } from '../core/icons.js';
import { currentMonthISO, todayISO, getHijriDateString, formatCurrency, formatNum, escapeHtml, openModal, closeModal, showToast } from '../core/utils.js';

let selectedMonth = currentMonthISO();
let statusFilter = 'all';

export async function renderFees(container) {
  const [students, invoices, accounts] = await Promise.all([
    listCollection('students', (s) => !s.isDeleted && s.status === 'active'),
    listCollection('fee_invoices', (inv) => inv.billingMonth === selectedMonth),
    listCollection('accounts')
  ]);

  const stuMap = Object.fromEntries(students.map((s) => [s.id, s]));
  const filtered = invoices.filter((inv) => statusFilter === 'all' || inv.status === statusFilter);
  const totalDue = filtered.reduce((s, x) => s + Number(x.dueAmount || 0), 0);
  const totalPaid = filtered.reduce((s, x) => s + Number(x.paidAmount || 0), 0);

  container.innerHTML = `
    <div class="page-header">
      <div>
        <h1>ছাত্র ফি ও বকেয়া</h1>
        <p class="page-subtitle">আদায়: ${formatCurrency(totalPaid)} | বকেয়া: ${formatCurrency(totalDue)}</p>
      </div>
      <button type="button" class="btn btn-primary btn-sm" id="fee-gen-btn">${icon('plus', 'sm')} মাসিক ফি জেনারেট</button>
    </div>

    <div class="toolbar">
      <input type="month" id="fee-month" class="form-control" value="${selectedMonth}">
      <select id="fee-status" class="form-control">
        <option value="all" ${statusFilter === 'all' ? 'selected' : ''}>সকল অবস্থা</option>
        <option value="unpaid" ${statusFilter === 'unpaid' ? 'selected' : ''}>বাকি</option>
        <option value="partial" ${statusFilter === 'partial' ? 'selected' : ''}>আংশিক পরিশোধ</option>
        <option value="paid" ${statusFilter === 'paid' ? 'selected' : ''}>পরিশোধিত</option>
        <option value="waived" ${statusFilter === 'waived' ? 'selected' : ''}>মওকুফ</option>
      </select>
    </div>

    ${filtered.length === 0 ? `
      <div class="card empty-state">
        ${icon('receipt', 'lg')}
        <p>এই মাসের কোনো ফি ইনভয়েস নেই। উপরের "মাসিক ফি জেনারেট" বাটনে ক্লিক করুন।</p>
      </div>
    ` : `
      <div class="list-stack">
        ${filtered.map((inv) => {
          const stu = stuMap[inv.studentId];
          const badgeCls = inv.status === 'paid' ? 'badge-success' : inv.status === 'waived' ? 'badge-info' : inv.status === 'partial' ? 'badge-warning' : 'badge-danger';
          const stLabel = { paid: 'পরিশোধিত', partial: 'আংশিক', unpaid: 'বাকি', waived: 'মওকুফ' }[inv.status] || inv.status;
          return `
            <div class="list-item">
              <div class="list-item-main">
                <div class="list-item-title">${escapeHtml(stu?.nameBn || inv.studentId)} <span class="badge ${badgeCls}">${stLabel}</span></div>
                <div class="list-item-sub">
                  মোট: ${formatCurrency(inv.netAmount)} | পরিশোধ: ${formatCurrency(inv.paidAmount)} | বকেয়া: ${formatCurrency(inv.dueAmount)}
                </div>
              </div>
              <div class="list-item-actions">
                ${Number(inv.dueAmount || 0) > 0
                  ? `<button type="button" class="btn btn-primary btn-sm" data-pay="${inv.id}">ফি গ্রহণ</button>`
                  : (inv.transactionIds?.length ? `<button type="button" class="btn btn-outline btn-sm" data-rcp="${inv.transactionIds[inv.transactionIds.length - 1]}">রিসিট</button>` : '')}
              </div>
            </div>
          `;
        }).join('')}
      </div>
    `}
  `;

  document.getElementById('fee-month').onchange = (e) => {
    selectedMonth = e.target.value;
    renderFees(container);
  };
  document.getElementById('fee-status').onchange = (e) => {
    statusFilter = e.target.value;
    renderFees(container);
  };

  document.getElementById('fee-gen-btn').onclick = async () => {
    let created = 0;
    for (const s of students) {
      const invId = `inv_${selectedMonth}_${s.id}`;
      const existing = invoices.find((x) => x.id === invId);
      if (existing) continue;
      const gross = Number(s.monthlyFee || 0);
      const waiver = Math.min(gross, Number(s.feeWaiverAmount || 0));
      const net = Math.max(0, gross - waiver);
      await setDocById('fee_invoices', invId, {
        branchId: 'main',
        studentId: s.id,
        jamatId: s.jamatId || '',
        billingMonth: selectedMonth,
        feeType: 'monthly',
        grossAmount: gross,
        waiverAmount: waiver,
        waiverReason: s.feeWaiverReason || '',
        netAmount: net,
        paidAmount: 0,
        dueAmount: net,
        status: net === 0 ? 'waived' : 'unpaid',
        transactionIds: []
      });
      created++;
    }
    showToast(`${formatNum(created)} জন ছাত্রের মাসিক ফি জেনারেট হয়েছে`, 'success');
    renderFees(container);
  };

  container.querySelectorAll('[data-rcp]').forEach((btn) => {
    btn.onclick = () => navigate(`/receipt/${btn.dataset.rcp}`);
  });

  container.querySelectorAll('[data-pay]').forEach((btn) => {
    btn.onclick = () => {
      const inv = invoices.find((x) => x.id === btn.dataset.pay);
      const stu = stuMap[inv.studentId];
      openModal({
        title: `ফি গ্রহণ — ${stu?.nameBn || ''}`,
        bodyHtml: `
          <div class="form-grid">
            <div class="form-group">
              <label class="form-label">পরিশোধের পরিমাণ (বকেয়া: ${formatCurrency(inv.dueAmount)})</label>
              <input id="pay-amount" class="form-control" type="number" min="1" max="${inv.dueAmount}" value="${inv.dueAmount}">
            </div>
            <div class="form-group">
              <label class="form-label">গ্রহণ অ্যাকাউন্ট</label>
              <select id="pay-account" class="form-control">
                ${accounts.map((a) => `<option value="${a.id}">${escapeHtml(a.nameBn)}</option>`).join('')}
              </select>
            </div>
          </div>
        `,
        footerHtml: `
          <button type="button" class="btn btn-secondary" id="pay-cancel">বাতিল</button>
          <button type="button" class="btn btn-primary" id="pay-confirm">আদায় ও রিসিট</button>
        `
      });

      document.getElementById('pay-cancel').onclick = closeModal;
      document.getElementById('pay-confirm').onclick = async () => {
        const amt = Number(document.getElementById('pay-amount').value || 0);
        if (amt <= 0 || amt > Number(inv.dueAmount)) {
          showToast('সঠিক অঙ্ক লিখুন', 'warning');
          return;
        }
        const accId = document.getElementById('pay-account').value;
        const year = new Date().getFullYear();
        const receiptNo = await nextSerial(`receipt_${year}`, `RCP-${year}-`);
        const verifyCode = receiptNo.replace('RCP-', 'VRF-');

        const tx = await addDocItem('transactions', {
          branchId: 'main',
          receiptNo,
          date: todayISO(),
          hijriDate: getHijriDateString(new Date()),
          type: 'income',
          category: 'student_fee',
          fundId: 'fund_general',
          accountId: accId,
          amount: amt,
          description: `মাসিক ফি (${selectedMonth}) — ${stu?.nameBn || ''}`,
          studentId: inv.studentId,
          status: 'posted',
          approvalStatus: 'auto_approved',
          verifyCode,
          createdBy: getCurrentUser()?.uid || 'system'
        });

        const newPaid = Number(inv.paidAmount || 0) + amt;
        const newDue = Math.max(0, Number(inv.netAmount) - newPaid);
        await setDocById('fee_invoices', inv.id, {
          paidAmount: newPaid,
          dueAmount: newDue,
          status: newDue === 0 ? 'paid' : 'partial',
          transactionIds: [...(inv.transactionIds || []), tx.id]
        }, true);

        const fund = await getDocById('funds', 'fund_general');
        if (fund) await setDocById('funds', 'fund_general', { currentBalance: Number(fund.currentBalance || 0) + amt }, true);
        const acc = await getDocById('accounts', accId);
        if (acc) await setDocById('accounts', accId, { currentBalance: Number(acc.currentBalance || 0) + amt }, true);

        await setDocById('public_verifications', verifyCode, {
          docType: 'receipt',
          serialNo: receiptNo,
          holderName: stu?.nameBn || '',
          amount: amt,
          issuedDate: todayISO(),
          status: 'valid'
        });

        await logAudit({ action: 'COLLECT_FEE', collection: 'transactions', docId: tx.id, summary: `ফি আদায় ${amt} টাকা (${receiptNo})` });
        closeModal();
        showToast('ফি আদায় সম্পন্ন হয়েছে', 'success');
        navigate(`/receipt/${tx.id}`);
      };
    };
  });
}
