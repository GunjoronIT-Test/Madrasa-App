/**
 * ভেক্টর SVG আইকন সিস্টেম (শূন্য ইমোজি নীতি)
 */
export async function loadIconSprite() {
  const host = document.getElementById('svg-sprite-host');
  if (!host || host.dataset.loaded === 'true') return;
  try {
    const res = await fetch('./assets/icons/icons.svg');
    if (res.ok) {
      host.innerHTML = await res.text();
      host.dataset.loaded = 'true';
    }
  } catch (err) {
    console.warn('SVG sprite load skipped:', err);
  }
}

export function icon(name, size = 'md', extraClass = '') {
  return `<svg class="icon icon-${size} ${extraClass}" aria-hidden="true"><use href="#icon-${name}"></use></svg>`;
}
