import { listCollection, addDocItem, nextSerial, setDocById, getDocById } from '../core/store.js';
import { getCurrentUser } from '../core/auth.js';
import { logAudit } from '../core/audit.js';
import { navigate } from '../core/router.js';
import { icon } from '../core/icons.js';
import { todayISO, getHijriDateString, readFileAsDataUrl, showToast, escapeHtml, STUDENT_CATEGORIES } from '../core/utils.js';

export async function renderAdmission(container) {
  const [jamats, students, accounts] = await Promise.all([
    listCollection('jamats', (j) => !j.isDeleted),
    listCollection('students', (s) => !s.isDeleted),
    listCollection('accounts')
  ]);

  let photoDataUrl = '';

  container.innerHTML = `
    <div class="page-header">
      <div>
        <h1>নতুন ছাত্র ভর্তি ফরম</h1>
        <p class="page-subtitle">অটো রোল নম্বর, ডুপ্লিকেট চেক ও ভর্তি ফি রিসিটসহ</p>
      </div>
      <button type="button" class="btn btn-secondary btn-sm" id="adm-back-btn">ছাত্র তালিকা</button>
    </div>

    <form id="admission-form" class="card form-grid cols-2">
      <div class="form-group">
        <label class="form-label">ছাত্রের নাম (বাংলা) *</label>
        <input id="adm-nameBn" class="form-control" required placeholder="পূর্ণ নাম">
      </div>
      <div class="form-group">
        <label class="form-label">পিতার নাম *</label>
        <input id="adm-father" class="form-control" required placeholder="পিতার পূর্ণ নাম">
      </div>
      <div class="form-group">
        <label class="form-label">অভিভাবকের নাম *</label>
        <input id="adm-guardian" class="form-control" required placeholder="অভিভাবকের নাম">
      </div>
      <div class="form-group">
        <label class="form-label">অভিভাবকের ফোন নম্বর *</label>
        <input id="adm-phone" class="form-control" required placeholder="017XXXXXXXX">
      </div>
      <div class="form-group">
        <label class="form-label">জামাত নির্বাচন *</label>
        <select id="adm-jamat" class="form-control" required>
          ${jamats.map((j) => `<option value="${j.id}" data-fee="${j.monthlyFeeDefault || 1000}" data-dept="${j.departmentId || ''}">${escapeHtml(j.nameBn)}</option>`).join('')}
        </select>
      </div>
      <div class="form-group">
        <label class="form-label">ছাত্রের ধরন *</label>
        <select id="adm-category" class="form-control">
          ${Object.entries(STUDENT_CATEGORIES).map(([k, v]) => `<option value="${k}">${v}</option>`).join('')}
        </select>
      </div>
      <div class="form-group">
        <label class="form-label">নির্ধারিত মাসিক ফি (টাকা)</label>
        <input id="adm-monthlyFee" class="form-control" type="number" min="0" value="${jamats[0]?.monthlyFeeDefault || 1000}">
      </div>
      <div class="form-group">
        <label class="form-label">মওকুফ / ছাড় (টাকা)</label>
        <input id="adm-waiver" class="form-control" type="number" min="0" value="0">
      </div>
      <div class="form-group">
        <label class="form-label">ভর্তি ফি আদায় (ঐচ্ছিক, টাকা)</label>
        <input id="adm-feeNow" class="form-control" type="number" min="0" value="500">
      </div>
      <div class="form-group">
        <label class="form-label">গ্রহণ অ্যাকাউন্ট</label>
        <select id="adm-account" class="form-control">
          ${accounts.map((a) => `<option value="${a.id}">${escapeHtml(a.nameBn)}</option>`).join('')}
        </select>
      </div>
      <div class="form-group" style="grid-column: 1 / -1;">
        <label class="form-label">বর্তমান ঠিকানা</label>
        <input id="adm-address" class="form-control" placeholder="গ্রাম/মহল্লা, উপজেলা, জেলা">
      </div>
      <div class="form-group" style="grid-column: 1 / -1;">
        <label class="form-label">ছাত্রের ছবি (ঐচ্ছিক)</label>
        <input id="adm-photo" class="form-control" type="file" accept="image/*">
      </div>
      <div style="grid-column: 1 / -1;display:flex;justify-content:flex-end;gap:8px;">
        <button type="submit" class="btn btn-primary">${icon('check', 'sm')} ভর্তি সম্পন্ন করুন</button>
      </div>
    </form>
  `;

  document.getElementById('adm-back-btn').onclick = () => navigate('/students');

  document.getElementById('adm-jamat').onchange = (e) => {
    const opt = e.target.selectedOptions[0];
    if (opt) document.getElementById('adm-monthlyFee').value = opt.dataset.fee || 1000;
  };

  document.getElementById('adm-category').onchange = (e) => {
    if (e.target.value === 'orphan' || e.target.value === 'lillah_boarding') {
      document.getElementById('adm-waiver').value = document.getElementById('adm-monthlyFee').value;
    }
  };

  document.getElementById('adm-photo').onchange = async (e) => {
    try {
      photoDataUrl = await readFileAsDataUrl(e.target.files[0], 800 * 1024);
      showToast('ছবি সংযুক্ত হয়েছে', 'success');
    } catch (err) {
      showToast(err.message, 'error');
    }
  };

  document.getElementById('admission-form').onsubmit = async (e) => {
    e.preventDefault();
    const nameBn = document.getElementById('adm-nameBn').value.trim();
    const guardianPhone = document.getElementById('adm-phone').value.trim();
    const jamatSelect = document.getElementById('adm-jamat');
    const jamatId = jamatSelect.value;
    const deptId = jamatSelect.selectedOptions[0]?.dataset.dept || '';

    // ডুপ্লিকেট চেক
    const duplicate = students.find(
      (s) => s.nameBn === nameBn && s.guardianPhone === guardianPhone
    );
    if (duplicate) {
      showToast('এই নাম ও ফোন নম্বরে ছাত্র ইতিমধ্যেই ভর্তি আছে!', 'warning');
      return;
    }

    const jamatStudents = students.filter((s) => s.jamatId === jamatId);
    const nextRoll = jamatStudents.reduce((m, s) => Math.max(m, Number(s.rollNumber || 0)), 0) + 1;
    const studentCode = await nextSerial('student_code', 'STD-');

    const createdStu = await addDocItem('students', {
      branchId: 'main',
      studentCode,
      rollNumber: nextRoll,
      departmentId: deptId,
      jamatId,
      nameBn,
      fatherName: document.getElementById('adm-father').value.trim(),
      guardianName: document.getElementById('adm-guardian').value.trim(),
      guardianPhone,
      category: document.getElementById('adm-category').value,
      monthlyFee: Number(document.getElementById('adm-monthlyFee').value || 0),
      feeWaiverAmount: Number(document.getElementById('adm-waiver').value || 0),
      presentAddress: document.getElementById('adm-address').value.trim(),
      photoUrl: photoDataUrl,
      status: 'active',
      isDeleted: false
    });

    await logAudit({
      action: 'ADMIT_STUDENT',
      collection: 'students',
      docId: createdStu.id,
      summary: `নতুন ছাত্র ভর্তি: ${nameBn} (${studentCode})`
    });

    const admFee = Number(document.getElementById('adm-feeNow').value || 0);
    if (admFee > 0) {
      const year = new Date().getFullYear();
      const receiptNo = await nextSerial(`receipt_${year}`, `RCP-${year}-`);
      const verifyCode = receiptNo.replace('RCP-', 'VRF-');
      const accId = document.getElementById('adm-account').value;
      const tx = await addDocItem('transactions', {
        branchId: 'main',
        receiptNo,
        date: todayISO(),
        hijriDate: getHijriDateString(new Date()),
        type: 'income',
        category: 'student_fee',
        fundId: 'fund_general',
        accountId: accId,
        amount: admFee,
        description: `ভর্তি ফি — ${nameBn} (${studentCode})`,
        studentId: createdStu.id,
        status: 'posted',
        approvalStatus: 'auto_approved',
        verifyCode,
        createdBy: getCurrentUser()?.uid || 'system'
      });

      const fund = await getDocById('funds', 'fund_general');
      if (fund) await setDocById('funds', 'fund_general', { currentBalance: Number(fund.currentBalance || 0) + admFee }, true);
      const acc = await getDocById('accounts', accId);
      if (acc) await setDocById('accounts', accId, { currentBalance: Number(acc.currentBalance || 0) + admFee }, true);

      await setDocById('public_verifications', verifyCode, {
        docType: 'receipt',
        serialNo: receiptNo,
        holderName: nameBn,
        amount: admFee,
        issuedDate: todayISO(),
        status: 'valid'
      });

      showToast('ভর্তি ও রিসিট সম্পন্ন হয়েছে', 'success');
      navigate(`/receipt/${tx.id}`);
      return;
    }

    showToast(`ভর্তি সম্পন্ন হয়েছে (রোল ${nextRoll})`, 'success');
    navigate('/students');
  };
}
