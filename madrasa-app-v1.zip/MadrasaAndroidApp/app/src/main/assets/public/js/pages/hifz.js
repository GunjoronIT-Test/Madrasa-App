import { listCollection, addDocItem } from '../core/store.js';
import { getCurrentUser } from '../core/auth.js';
import { icon } from '../core/icons.js';
import { todayISO, formatNum, escapeHtml, openModal, closeModal, showToast } from '../core/utils.js';

let selectedStuId = 'all';

export async function renderHifz(container) {
  const [students, logs] = await Promise.all([
    listCollection('students', (s) => !s.isDeleted && s.status === 'active'),
    listCollection('hifz_logs')
  ]);

  const stuMap = Object.fromEntries(students.map((s) => [s.id, s]));
  const filtered = logs
    .filter((l) => selectedStuId === 'all' || l.studentId === selectedStuId)
    .sort((a, b) => String(b.date || '').localeCompare(String(a.date || '')));

  // প্রতি ছাত্রের সর্বোচ্চ পারা প্রগ্রেস
  const maxParaByStu = {};
  logs.forEach((l) => {
    const p = Number(l.paraNo || 0);
    if (p > (maxParaByStu[l.studentId] || 0)) maxParaByStu[l.studentId] = p;
  });

  container.innerHTML = `
    <div class="page-header">
      <div>
        <h1>হিফজ ও নাজেরা অগ্রগতি</h1>
        <p class="page-subtitle">দৈনিক সবক, সবকি, আমুখতা ও ৩০ পারা অগ্রগতি রেকর্ড</p>
      </div>
      <button type="button" class="btn btn-primary btn-sm" id="hz-add-btn">${icon('plus', 'sm')} দৈনিক সবক এন্ট্রি</button>
    </div>

    <div class="toolbar">
      <select id="hz-stu-filter" class="form-control">
        <option value="all">সকল ছাত্র</option>
        ${students.map((s) => `<option value="${s.id}" ${selectedStuId === s.id ? 'selected' : ''}>${escapeHtml(s.nameBn)} (পারা ${formatNum(maxParaByStu[s.id] || 0)}/৩০)</option>`).join('')}
      </select>
    </div>

    ${selectedStuId !== 'all' ? (() => {
      const p = maxParaByStu[selectedStuId] || 0;
      const pct = Math.min(100, Math.round((p / 30) * 100));
      return `
        <div class="card" style="margin-bottom:16px;">
          <div style="display:flex;justify-content:space-between;margin-bottom:6px;">
            <strong>${escapeHtml(stuMap[selectedStuId]?.nameBn || '')} — হিফজ অগ্রগতি</strong>
            <span>${formatNum(p)} / ৩০ পারা (${formatNum(pct)}%)</span>
          </div>
          <div style="height:10px;background:var(--bg-subtle);border-radius:99px;overflow:hidden;">
            <div style="height:100%;width:${pct}%;background:var(--brand-primary);"></div>
          </div>
        </div>
      `;
    })() : ''}

    ${filtered.length === 0
      ? `<div class="card empty-state">${icon('book', 'lg')}<p>কোনো সবক-সবকি-আমুখতা রেকর্ড নেই।</p></div>`
      : `<div class="list-stack">
          ${filtered.map((l) => `
            <div class="card" style="padding:14px;">
              <div style="display:flex;justify-content:space-between;margin-bottom:6px;">
                <strong>${escapeHtml(stuMap[l.studentId]?.nameBn || l.studentId)}</strong>
                <span class="badge badge-info">পারা ${formatNum(l.paraNo)} | ${escapeHtml(l.date)}</span>
              </div>
              <div class="receipt-meta-grid" style="margin-bottom:6px;">
                <div><strong>সবক:</strong> ${escapeHtml(l.sabaq || '-')}</div>
                <div><strong>সবকি:</strong> ${escapeHtml(l.sabqi || '-')}</div>
                <div><strong>আমুখতা:</strong> ${escapeHtml(l.amokhta || '-')}</div>
                <div><strong>মান:</strong> ${escapeHtml(l.quality || 'উত্তম')}</div>
              </div>
              ${l.ustadNote ? `<div class="list-item-sub">ওস্তাদের মন্তব্য: ${escapeHtml(l.ustadNote)}</div>` : ''}
            </div>
          `).join('')}
        </div>`}
  `;

  document.getElementById('hz-stu-filter').onchange = (e) => {
    selectedStuId = e.target.value;
    renderHifz(container);
  };

  document.getElementById('hz-add-btn').onclick = () => {
    openModal({
      title: 'দৈনিক সবক-সবকি-আমুখতা এন্ট্রি',
      bodyHtml: `
        <div class="form-grid">
          <div class="form-group">
            <label class="form-label">ছাত্র নির্বাচন *</label>
            <select id="hz-stu" class="form-control">
              ${students.map((s) => `<option value="${s.id}" ${selectedStuId === s.id ? 'selected' : ''}>${escapeHtml(s.nameBn)}</option>`).join('')}
            </select>
          </div>
          <div class="form-group">
            <label class="form-label">তারিখ ও চলমান পারা (১-৩০)</label>
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;">
              <input id="hz-date" class="form-control" type="date" value="${todayISO()}">
              <input id="hz-para" class="form-control" type="number" min="1" max="30" value="1">
            </div>
          </div>
          <div class="form-group">
            <label class="form-label">সবক (নতুন পড়া) *</label>
            <input id="hz-sabaq" class="form-control" placeholder="যেমন: সূরা বাকারা ২ পৃষ্ঠা">
          </div>
          <div class="form-group">
            <label class="form-label">সবকি (সদ্য মুখস্থ)</label>
            <input id="hz-sabqi" class="form-control" placeholder="যেমন: ১০ পৃষ্ঠা">
          </div>
          <div class="form-group">
            <label class="form-label">আমুখতা (পুরনো মুখস্থ)</label>
            <input id="hz-amokhta" class="form-control" placeholder="যেমন: ১ পারা">
          </div>
          <div class="form-group">
            <label class="form-label">শুনানির মান ও ওস্তাদের মন্তব্য</label>
            <input id="hz-note" class="form-control" placeholder="যেমন: মাশাআল্লাহ, তাজবীদ সুন্দর হয়েছে">
          </div>
        </div>
      `,
      footerHtml: `
        <button type="button" class="btn btn-secondary" id="hz-cancel">বাতিল</button>
        <button type="button" class="btn btn-primary" id="hz-save">সংরক্ষণ</button>
      `
    });
    document.getElementById('hz-cancel').onclick = closeModal;
    document.getElementById('hz-save').onclick = async () => {
      const sabaq = document.getElementById('hz-sabaq').value.trim();
      if (!sabaq) return showToast('সবকের বিবরণ লিখুন', 'warning');
      await addDocItem('hifz_logs', {
        branchId: 'main',
        studentId: document.getElementById('hz-stu').value,
        date: document.getElementById('hz-date').value,
        paraNo: Number(document.getElementById('hz-para').value || 1),
        sabaq,
        sabqi: document.getElementById('hz-sabqi').value.trim(),
        amokhta: document.getElementById('hz-amokhta').value.trim(),
        quality: 'উত্তম',
        ustadNote: document.getElementById('hz-note').value.trim(),
        markedBy: getCurrentUser()?.uid || 'system'
      });
      closeModal();
      showToast('সবক রেকর্ড সংরক্ষিত হয়েছে', 'success');
      renderHifz(container);
    };
  };
}
