import { getFirebaseState } from './firebase.js';
import { uid } from './utils.js';

const LOCAL_KEY = 'madrasa_app_db_v1';

function readLocalDb() {
  try {
    const raw = localStorage.getItem(LOCAL_KEY);
    return raw ? JSON.parse(raw) : {};
  } catch {
    return {};
  }
}

function writeLocalDb(db) {
  localStorage.setItem(LOCAL_KEY, JSON.stringify(db));
}

export function isLiveFirebase() {
  return getFirebaseState().mode === 'firebase';
}

export async function getDocById(collectionName, docId) {
  if (isLiveFirebase()) {
    const { db, sdk } = getFirebaseState();
    const snap = await sdk.fsMod.getDoc(sdk.fsMod.doc(db, collectionName, docId));
    return snap.exists() ? { id: snap.id, ...snap.data() } : null;
  }
  const db = readLocalDb();
  const item = db[collectionName]?.[docId];
  return item ? structuredClone(item) : null;
}

export async function setDocById(collectionName, docId, data, merge = true) {
  const now = new Date().toISOString();
  const payload = { ...data, id: docId, updatedAt: now };
  if (!payload.createdAt) payload.createdAt = now;

  if (isLiveFirebase()) {
    const { db, sdk } = getFirebaseState();
    await sdk.fsMod.setDoc(sdk.fsMod.doc(db, collectionName, docId), payload, { merge });
    return payload;
  }
  const db = readLocalDb();
  if (!db[collectionName]) db[collectionName] = {};
  db[collectionName][docId] = merge && db[collectionName][docId]
    ? { ...db[collectionName][docId], ...payload }
    : payload;
  writeLocalDb(db);
  return structuredClone(db[collectionName][docId]);
}

export async function addDocItem(collectionName, data, customId = null) {
  const id = customId || uid(collectionName.slice(0, 4));
  return setDocById(collectionName, id, data, false);
}

export async function listCollection(collectionName, filterFn = null) {
  let items = [];
  if (isLiveFirebase()) {
    const { db, sdk } = getFirebaseState();
    const snap = await sdk.fsMod.getDocs(sdk.fsMod.collection(db, collectionName));
    items = snap.docs.map((d) => ({ id: d.id, ...d.data() }));
  } else {
    const db = readLocalDb();
    items = Object.values(db[collectionName] || {}).map((x) => structuredClone(x));
  }
  return filterFn ? items.filter(filterFn) : items;
}

export async function nextSerial(counterId, prefix = '') {
  const existing = await getDocById('counters', counterId);
  const nextNum = (existing?.lastNumber || 0) + 1;
  await setDocById('counters', counterId, {
    branchId: 'main',
    prefix: prefix || existing?.prefix || '',
    lastNumber: nextNum
  });
  const padded = String(nextNum).padStart(4, '0');
  return `${prefix || existing?.prefix || ''}${padded}`;
}

export async function exportFullBackup() {
  const collections = [
    'settings', 'branches', 'users', 'academic_years', 'departments', 'jamats',
    'admissions', 'students', 'student_enrollments', 'attendance',
    'fee_structures', 'fee_invoices', 'funds', 'accounts', 'transactions',
    'donors', 'counters', 'audit_logs', 'public_verifications'
  ];
  const dump = {
    exportedAt: new Date().toISOString(),
    schemaVersion: '1.0',
    collections: {}
  };
  for (const col of collections) {
    dump.collections[col] = await listCollection(col);
  }
  return dump;
}

export async function restoreFullBackup(dump) {
  if (!dump || !dump.collections || typeof dump.collections !== 'object') {
    throw new Error('অবৈধ ব্যাকআপ ফাইল');
  }
  for (const [col, docs] of Object.entries(dump.collections)) {
    if (!Array.isArray(docs)) continue;
    for (const item of docs) {
      if (item && item.id) {
        await setDocById(col, item.id, item, false);
      }
    }
  }
}

export function clearLocalDatabase() {
  localStorage.removeItem(LOCAL_KEY);
}
