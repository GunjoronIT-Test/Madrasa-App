import { listCollection, setDocById } from '../core/store.js';
import { getCurrentUser } from '../core/auth.js';
import { icon } from '../core/icons.js';
import { todayISO, getHijriDateString, formatNum, escapeHtml, showToast } from '../core/utils.js';

let activeStream = null;
let scanTimer = null;

function stopCamera() {
  if (scanTimer) { clearInterval(scanTimer); scanTimer = null; }
  if (activeStream) {
    activeStream.getTracks().forEach((t) => t.stop());
    activeStream = null;
  }
}

export async function renderQrAttendance(container) {
  stopCamera();
  const [students, todayAtt] = await Promise.all([
    listCollection('students', (s) => !s.isDeleted && s.status === 'active'),
    listCollection('attendance', (a) => a.type === 'student' && a.date === todayISO())
  ]);

  const presentIds = new Set(todayAtt.filter((a) => a.status === 'present').map((a) => a.targetId));
  const recentScanned = [];

  function extractStudent(rawText) {
    const clean = String(rawText || '').trim().toUpperCase();
    return students.find((s) => {
      const code = String(s.studentCode || '').toUpperCase();
      return (code && clean.includes(code)) || clean.endsWith(String(s.id).toUpperCase());
    });
  }

  async function markByCode(rawText) {
    const stu = extractStudent(rawText);
    if (!stu) {
      showToast(`এই QR কোডে (${rawText}) কোনো সক্রিয় ছাত্র পাওয়া যায়নি`, 'warning');
      return;
    }
    const today = todayISO();
    const docId = `main_student_${today}_${stu.id}`;
    await setDocById('attendance', docId, {
      branchId: 'main',
      type: 'student',
      date: today,
      hijriDate: getHijriDateString(new Date()),
      targetId: stu.id,
      jamatId: stu.jamatId || '',
      status: 'present',
      method: 'qr_scan',
      markedBy: getCurrentUser()?.uid || 'system'
    });
    presentIds.add(stu.id);
    recentScanned.unshift({ name: stu.nameBn, code: stu.studentCode || stu.id, time: new Date().toLocaleTimeString('bn-BD') });
    showToast(`উপস্থিতি নিশ্চিত: ${stu.nameBn}`, 'success');
    updateScannedUi();
  }

  function updateScannedUi() {
    const countEl = document.getElementById('qr-present-count');
    if (countEl) countEl.textContent = formatNum(presentIds.size);
    const listEl = document.getElementById('qr-recent-list');
    if (!listEl) return;
    listEl.innerHTML = recentScanned.length === 0
      ? `<p class="text-muted">এখনো কোনো আইডি কার্ড স্ক্যান করা হয়নি।</p>`
      : recentScanned.slice(0, 10).map((r) => `
          <div class="list-item">
            <div class="list-item-main">
              <div class="list-item-title">${escapeHtml(r.name)} <span class="badge badge-success">উপস্থিত</span></div>
              <div class="list-item-sub">কোড: ${escapeHtml(r.code)} | সময়: ${escapeHtml(r.time)}</div>
            </div>
          </div>
        `).join('');
  }

  container.innerHTML = `
    <div class="page-header">
      <div>
        <h1>QR ও আইডি কার্ড হাজিরা</h1>
        <p class="page-subtitle">আজকের উপস্থিত: <strong id="qr-present-count">${formatNum(presentIds.size)}</strong> / ${formatNum(students.length)} জন</p>
      </div>
      <button type="button" class="btn btn-primary btn-sm" id="qr-cam-toggle">${icon('qr', 'sm')} ক্যামেরা চালু করুন</button>
    </div>

    <div class="card">
      <div id="qr-video-wrap" hidden style="margin-bottom:12px;text-align:center;">
        <video id="qr-video" autoplay playsinline muted style="width:100%;max-width:380px;border-radius:10px;border:2px solid var(--brand-primary);"></video>
        <div class="form-hint" style="margin-top:6px;">ছাত্রের আইডি কার্ডের QR কোড ক্যামেরার সামনে ধরুন</div>
      </div>

      <form id="qr-manual-form" class="toolbar" style="margin-bottom:0;">
        <input id="qr-code-input" class="form-control" placeholder="ছাত্রের কোড স্ক্যান বা টাইপ করুন (যেমন: STD-0001)" autocomplete="off">
        <button type="submit" class="btn btn-primary">${icon('check', 'sm')} উপস্থিতি দিন</button>
      </form>
      <p class="form-hint" style="margin-top:8px;">USB/Bluetooth বারকোড স্ক্যানার দিয়ে সরাসরি ইনপুট বক্সে স্ক্যান করলেও অটো হাজিরা হবে।</p>
    </div>

    <div class="card">
      <h3 style="margin-bottom:10px;">সাম্প্রতিক স্ক্যান লগ</h3>
      <div id="qr-recent-list" class="list-stack"></div>
    </div>
  `;

  updateScannedUi();

  document.getElementById('qr-manual-form').onsubmit = async (e) => {
    e.preventDefault();
    const inp = document.getElementById('qr-code-input');
    const val = inp.value.trim();
    if (!val) return;
    await markByCode(val);
    inp.value = '';
    inp.focus();
  };

  const camBtn = document.getElementById('qr-cam-toggle');
  camBtn.onclick = async () => {
    const wrap = document.getElementById('qr-video-wrap');
    if (activeStream) {
      stopCamera();
      wrap.hidden = true;
      camBtn.innerHTML = `${icon('qr', 'sm')} ক্যামেরা চালু করুন`;
      return;
    }
    if (!navigator.mediaDevices?.getUserMedia) {
      return showToast('এই ডিভাইসে ক্যামেরা সমর্থিত নয়; কোড ইনপুট ব্যবহার করুন', 'warning');
    }
    try {
      activeStream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' } });
      const video = document.getElementById('qr-video');
      video.srcObject = activeStream;
      wrap.hidden = false;
      camBtn.innerHTML = `${icon('close', 'sm')} ক্যামেরা বন্ধ করুন`;

      if ('BarcodeDetector' in window) {
        const detector = new window.BarcodeDetector({ formats: ['qr_code'] });
        let lastCode = '';
        let lastTs = 0;
        scanTimer = setInterval(async () => {
          if (video.readyState < 2) return;
          try {
            const codes = await detector.detect(video);
            if (codes.length > 0) {
              const val = codes[0].rawValue;
              if (val && (val !== lastCode || Date.now() - lastTs > 3500)) {
                lastCode = val;
                lastTs = Date.now();
                await markByCode(val);
              }
            }
          } catch {}
        }, 500);
      } else {
        showToast('ক্যামেরা চালু হয়েছে (অটো ডিটেকশন সমর্থিত না হলে কোড টাইপ করুন)', 'info');
      }
    } catch {
      showToast('ক্যামেরা অনুমতি পাওয়া যায়নি', 'error');
    }
  };

  window.addEventListener('hashchange', stopCamera, { once: true });
}
