const routes = new Map();
let guardFn = null;

export function registerRoute(path, handler) {
  routes.set(path, handler);
}

export function setRouteGuard(fn) {
  guardFn = fn;
}

export function navigate(hashPath) {
  const normalized = hashPath.startsWith('#') ? hashPath : `#${hashPath}`;
  if (window.location.hash === normalized) {
    handleRouteChange();
  } else {
    window.location.hash = normalized;
  }
}

export function parseHash() {
  const raw = (window.location.hash || '#/dashboard').replace(/^#/, '');
  const [pathPart, queryPart] = raw.split('?');
  const segments = pathPart.split('/').filter(Boolean);
  const base = '/' + (segments[0] || 'dashboard');
  const param = segments[1] || null;
  const params = new URLSearchParams(queryPart || '');
  return { raw, base, param, params };
}

export async function handleRouteChange() {
  const parsed = parseHash();
  if (guardFn) {
    const redirect = await guardFn(parsed);
    if (redirect) {
      navigate(redirect);
      return;
    }
  }
  const handler = routes.get(parsed.base) || routes.get('/dashboard');
  const main = document.getElementById('app-main');
  if (handler && main) {
    await handler(main, parsed);
    main.focus({ preventScroll: true });
    window.scrollTo({ top: 0, behavior: 'instant' });
  }
}

export function startRouter() {
  window.addEventListener('hashchange', handleRouteChange);
  handleRouteChange();
}
