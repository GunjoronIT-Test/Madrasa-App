import { listCollection, addDocItem, setDocById } from '../core/store.js';
import { logAudit } from '../core/audit.js';
import { navigate } from '../core/router.js';
import { icon } from '../core/icons.js';
import { todayISO, formatCurrency, formatNum, escapeHtml, openModal, closeModal, showToast } from '../core/utils.js';

export async function renderEvents(container) {
  const events = (await listCollection('events'))
    .sort((a, b) => String(b.eventDate || '').localeCompare(String(a.eventDate || '')));

  container.innerHTML = `
    <div class="page-header">
      <div>
        <h1>বাৎসরিক অনুষ্ঠান ও মাহফিল</h1>
        <p class="page-subtitle">মাহফিল, জলসা, দস্তারবন্দি, বাজেট, বক্তা তালিকা ও টাস্ক ব্যবস্থাপনা</p>
      </div>
      <div style="display:flex;gap:8px;">
        <button type="button" class="btn btn-secondary btn-sm" id="ev-go-poster">${icon('poster', 'sm')} পোস্টার বানান</button>
        <button type="button" class="btn btn-primary btn-sm" id="ev-add-btn">${icon('plus', 'sm')} নতুন অনুষ্ঠান</button>
      </div>
    </div>

    ${events.length === 0
      ? `<div class="card empty-state">${icon('calendar', 'lg')}<p>এখনো কোনো বাৎসরিক অনুষ্ঠান যুক্ত করা হয়নি।</p></div>`
      : `<div class="list-stack">
          ${events.map((ev) => {
            const tasks = ev.tasks || [];
            const doneCnt = tasks.filter((t) => t.done).length;
            const balance = Number(ev.collectedAmount || 0) - Number(ev.spentAmount || 0);
            return `
              <div class="card">
                <div style="display:flex;justify-content:space-between;align-items:flex-start;gap:8px;margin-bottom:10px;">
                  <div>
                    <h2>${escapeHtml(ev.titleBn)}</h2>
                    <div class="page-subtitle">তারিখ: ${escapeHtml(ev.eventDate || '-')} | ধরন: ${escapeHtml(ev.eventType || 'মাহফিল')}</div>
                  </div>
                  <span class="badge ${ev.status === 'completed' ? 'badge-success' : 'badge-info'}">${ev.status === 'completed' ? 'সম্পন্ন' : 'আসন্ন'}</span>
                </div>

                <div class="receipt-meta-grid" style="margin-bottom:10px;">
                  <div><strong>বাজেট:</strong> ${formatCurrency(ev.budget || 0)}</div>
                  <div><strong>দান সংগ্রহ:</strong> <span class="text-success">${formatCurrency(ev.collectedAmount || 0)}</span></div>
                  <div><strong>মোট খরচ:</strong> <span class="text-danger">${formatCurrency(ev.spentAmount || 0)}</span></div>
                  <div><strong>উদ্বৃত্ত:</strong> ${formatCurrency(balance)}</div>
                </div>

                ${ev.speakers ? `<div class="list-item-sub" style="margin-bottom:8px;"><strong>বক্তা / অতিথি:</strong> ${escapeHtml(ev.speakers)}</div>` : ''}
                ${ev.committee ? `<div class="list-item-sub" style="margin-bottom:10px;"><strong>দায়িত্বশীল কমিটি:</strong> ${escapeHtml(ev.committee)}</div>` : ''}

                <div style="margin-bottom:10px;">
                  <div class="form-label" style="margin-bottom:6px;">কাজের তালিকা (${formatNum(doneCnt)}/${formatNum(tasks.length)} সম্পন্ন)</div>
                  <div class="list-stack" style="gap:6px;">
                    ${tasks.map((t, idx) => `
                      <label style="display:flex;align-items:center;gap:8px;cursor:pointer;font-size:0.875rem;">
                        <input type="checkbox" data-ev-task="${ev.id}" data-task-idx="${idx}" ${t.done ? 'checked' : ''}>
                        <span style="${t.done ? 'text-decoration:line-through;color:var(--text-muted);' : ''}">${escapeHtml(t.label)}</span>
                      </label>
                    `).join('')}
                  </div>
                </div>

                <div style="display:flex;gap:8px;flex-wrap:wrap;justify-content:flex-end;">
                  <button type="button" class="btn btn-outline btn-sm" data-ev-fin="${ev.id}">দান/খরচ আপডেট</button>
                  <button type="button" class="btn btn-secondary btn-sm" data-ev-addtask="${ev.id}">টাস্ক যোগ</button>
                </div>
              </div>
            `;
          }).join('')}
        </div>`}
  `;

  document.getElementById('ev-go-poster').onclick = () => navigate('/posters');

  document.getElementById('ev-add-btn').onclick = () => {
    openModal({
      title: 'নতুন বাৎসরিক অনুষ্ঠান / মাহফিল',
      bodyHtml: `
        <div class="form-grid">
          <div class="form-group">
            <label class="form-label">অনুষ্ঠানের নাম *</label>
            <input id="ev-title" class="form-control" placeholder="যেমন: বার্ষিক ওয়াজ মাহফিল ও দস্তারবন্দি">
          </div>
          <div class="form-group">
            <label class="form-label">ধরন ও তারিখ</label>
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;">
              <select id="ev-type" class="form-control">
                <option value="ওয়াজ মাহফিল">ওয়াজ মাহফিল</option>
                <option value="দস্তারবন্দি">দস্তারবন্দি</option>
                <option value="খতমে বুখারী">খতমে বুখারী</option>
                <option value="সেমিনার ও পুরস্কার">সেমিনার ও পুরস্কার</option>
              </select>
              <input id="ev-date" class="form-control" type="date" value="${todayISO()}">
            </div>
          </div>
          <div class="form-group">
            <label class="form-label">সম্ভাব্য বাজেট (টাকা)</label>
            <input id="ev-budget" class="form-control" type="number" min="0" value="50000">
          </div>
          <div class="form-group">
            <label class="form-label">প্রধান বক্তা ও অতিথি তালিকা</label>
            <input id="ev-speakers" class="form-control" placeholder="বক্তাদের নাম কমা দিয়ে লিখুন">
          </div>
          <div class="form-group">
            <label class="form-label">দায়িত্বশীল কমিটি</label>
            <input id="ev-committee" class="form-control" placeholder="যেমন: প্রচার কমিটি, মেহমানদারি কমিটি">
          </div>
        </div>
      `,
      footerHtml: `
        <button type="button" class="btn btn-secondary" id="ev-cancel">বাতিল</button>
        <button type="button" class="btn btn-primary" id="ev-save">সংরক্ষণ</button>
      `
    });
    document.getElementById('ev-cancel').onclick = closeModal;
    document.getElementById('ev-save').onclick = async () => {
      const titleBn = document.getElementById('ev-title').value.trim();
      if (!titleBn) return showToast('অনুষ্ঠানের নাম লিখুন', 'warning');
      const doc = await addDocItem('events', {
        branchId: 'main',
        titleBn,
        eventType: document.getElementById('ev-type').value,
        eventDate: document.getElementById('ev-date').value,
        budget: Number(document.getElementById('ev-budget').value || 0),
        collectedAmount: 0,
        spentAmount: 0,
        speakers: document.getElementById('ev-speakers').value.trim(),
        committee: document.getElementById('ev-committee').value.trim(),
        tasks: [
          { label: 'প্যান্ডেল ও সাউন্ড সিস্টেম বুকিং', done: false },
          { label: 'পোস্টার ছাপানো ও প্রচার', done: false },
          { label: 'মেহমানদের দাওয়াত ও আপ্যায়ন', done: false }
        ],
        status: 'upcoming'
      });
      await logAudit({ action: 'CREATE_EVENT', collection: 'events', docId: doc.id, summary: `অনুষ্ঠান যুক্ত: ${titleBn}` });
      closeModal();
      showToast('অনুষ্ঠান সংরক্ষিত হয়েছে', 'success');
      renderEvents(container);
    };
  };

  container.querySelectorAll('[data-ev-task]').forEach((chk) => {
    chk.onchange = async () => {
      const ev = events.find((x) => x.id === chk.dataset.evTask);
      if (!ev) return;
      const tasks = [...(ev.tasks || [])];
      tasks[Number(chk.dataset.taskIdx)].done = chk.checked;
      await setDocById('events', ev.id, { tasks }, true);
      renderEvents(container);
    };
  });

  container.querySelectorAll('[data-ev-addtask]').forEach((btn) => {
    btn.onclick = () => {
      const ev = events.find((x) => x.id === btn.dataset.evAddtask);
      openModal({
        title: 'নতুন কাজ (টাস্ক) যোগ করুন',
        bodyHtml: `<div class="form-group"><label class="form-label">কাজের বিবরণ</label><input id="ev-tk-text" class="form-control" placeholder="যেমন: মাইকিং ব্যবস্থা"></div>`,
        footerHtml: `<button type="button" class="btn btn-primary" id="ev-tk-ok">যোগ করুন</button>`
      });
      document.getElementById('ev-tk-ok').onclick = async () => {
        const label = document.getElementById('ev-tk-text').value.trim();
        if (!label) return;
        await setDocById('events', ev.id, { tasks: [...(ev.tasks || []), { label, done: false }] }, true);
        closeModal();
        renderEvents(container);
      };
    };
  });

  container.querySelectorAll('[data-ev-fin]').forEach((btn) => {
    btn.onclick = () => {
      const ev = events.find((x) => x.id === btn.dataset.evFin);
      openModal({
        title: `আর্থিক হিসাব — ${ev.titleBn}`,
        bodyHtml: `
          <div class="form-grid">
            <div class="form-group">
              <label class="form-label">মোট দান সংগ্রহ (টাকা)</label>
              <input id="ev-col" class="form-control" type="number" min="0" value="${ev.collectedAmount || 0}">
            </div>
            <div class="form-group">
              <label class="form-label">মোট খরচ (টাকা)</label>
              <input id="ev-sp" class="form-control" type="number" min="0" value="${ev.spentAmount || 0}">
            </div>
            <div class="form-group">
              <label class="form-label">অবস্থা</label>
              <select id="ev-st" class="form-control">
                <option value="upcoming" ${ev.status !== 'completed' ? 'selected' : ''}>আসন্ন / চলমান</option>
                <option value="completed" ${ev.status === 'completed' ? 'selected' : ''}>সম্পন্ন</option>
              </select>
            </div>
          </div>
        `,
        footerHtml: `<button type="button" class="btn btn-primary" id="ev-fin-save">হালনাগাদ</button>`
      });
      document.getElementById('ev-fin-save').onclick = async () => {
        await setDocById('events', ev.id, {
          collectedAmount: Number(document.getElementById('ev-col').value || 0),
          spentAmount: Number(document.getElementById('ev-sp').value || 0),
          status: document.getElementById('ev-st').value
        }, true);
        closeModal();
        showToast('অনুষ্ঠানের হিসাব হালনাগাদ হয়েছে', 'success');
        renderEvents(container);
      };
    };
  });
}
