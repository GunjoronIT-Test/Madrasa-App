import { listCollection, addDocItem, setDocById, nextSerial, getDocById } from '../core/store.js';
import { getBrand } from '../core/brand.js';
import { getCurrentUser, requirePinConfirmation } from '../core/auth.js';
import { logAudit } from '../core/audit.js';
import { icon } from '../core/icons.js';
import { currentMonthISO, todayISO, getHijriDateString, formatCurrency, formatNum, escapeHtml, openModal, closeModal, showToast } from '../core/utils.js';

let activeTab = 'list'; // 'list' | 'payroll' | 'attendance'
let selectedMonth = currentMonthISO();
let selectedDate = todayISO();

export async function renderStaff(container) {
  const [staffList, payrolls, staffAtt, accounts, funds] = await Promise.all([
    listCollection('staff', (s) => !s.isDeleted),
    listCollection('payroll', (p) => p.month === selectedMonth),
    listCollection('attendance', (a) => a.type === 'staff' && a.date === selectedDate),
    listCollection('accounts'),
    listCollection('funds')
  ]);

  const staffMap = Object.fromEntries(staffList.map((s) => [s.id, s]));
  const attMap = Object.fromEntries(staffAtt.map((a) => [a.targetId, a.status]));
  const unpaidCount = payrolls.filter((p) => p.status === 'unpaid' || p.status === 'partial').length;
  const totalNet = payrolls.reduce((s, p) => s + Number(p.netAmount || 0), 0);

  let tabContent = '';
  if (activeTab === 'list') {
    tabContent = staffList.length === 0
      ? `<div class="card empty-state">${icon('staff', 'lg')}<p>এখনো কোনো ওস্তাদ বা স্টাফ যুক্ত করা হয়নি।</p></div>`
      : `<div class="list-stack">
          ${staffList.map((s) => `
            <div class="list-item" style="flex-wrap:wrap;">
              <div class="list-item-main">
                <div class="list-item-title">${escapeHtml(s.nameBn)} <span class="badge badge-neutral">${escapeHtml(s.designation || 'ওস্তাদ')}</span></div>
                <div class="list-item-sub">কোড: ${escapeHtml(s.staffCode || s.id)} | ফোন: ${formatNum(s.phone || '-')} | মূল বেতন: ${formatCurrency(s.baseSalary)} + ভাতা: ${formatCurrency(s.allowances || 0)}</div>
              </div>
              <div class="list-item-actions">
                <button type="button" class="btn btn-secondary btn-sm" data-del-staff="${s.id}">অপসারণ</button>
              </div>
            </div>
          `).join('')}
        </div>`;
  } else if (activeTab === 'payroll') {
    tabContent = `
      <div class="toolbar">
        <input type="month" id="pay-month" class="form-control" value="${selectedMonth}">
        <button type="button" class="btn btn-primary" id="btn-gen-payroll">${icon('plus', 'sm')} মাসিক বেতন স্লিপ তৈরি</button>
      </div>
      <div class="alert-box alert-info">
        ${icon('finance', 'sm')}
        <span>মোট বেতন বিল: <strong>${formatCurrency(totalNet)}</strong> | বাকি আছে: <strong>${formatNum(unpaidCount)}</strong> জন</span>
      </div>
      ${payrolls.length === 0
        ? `<div class="card empty-state"><p>এই মাসের বেতন স্লিপ এখনো তৈরি হয়নি। উপরের বাটনে ক্লিক করুন।</p></div>`
        : `<div class="list-stack">
            ${payrolls.map((p) => {
              const st = staffMap[p.staffId];
              const paid = p.status === 'paid';
              return `
                <div class="list-item" style="flex-wrap:wrap;">
                  <div class="list-item-main">
                    <div class="list-item-title">
                      ${escapeHtml(st?.nameBn || p.staffId)}
                      <span class="badge ${paid ? 'badge-success' : 'badge-warning'}">${paid ? 'পরিশোধিত' : 'বাকি'}</span>
                    </div>
                    <div class="list-item-sub">
                      মূল: ${formatCurrency(p.baseSalary)} | বোনাস: ${formatCurrency(p.bonus || 0)} | কর্তন/অগ্রিম: ${formatCurrency(p.advanceDeduction || 0)} | নিট: <strong>${formatCurrency(p.netAmount)}</strong>
                    </div>
                  </div>
                  <div class="list-item-actions">
                    ${paid
                      ? `<button type="button" class="btn btn-outline btn-sm" data-slip="${p.id}">${icon('print', 'sm')} স্লিপ</button>`
                      : `<button type="button" class="btn btn-primary btn-sm" data-pay-salary="${p.id}">বেতন পরিশোধ</button>`}
                  </div>
                </div>
              `;
            }).join('')}
          </div>`}
    `;
  } else {
    tabContent = `
      <div class="toolbar">
        <input type="date" id="staff-att-date" class="form-control" value="${selectedDate}">
      </div>
      <div class="list-stack">
        ${staffList.map((s) => {
          const st = attMap[s.id] || '';
          return `
            <div class="list-item" style="flex-wrap:wrap;">
              <div class="list-item-main">
                <div class="list-item-title">${escapeHtml(s.nameBn)}</div>
                <div class="list-item-sub">${escapeHtml(s.designation || 'ওস্তাদ')}</div>
              </div>
              <div class="att-btn-group">
                <button type="button" class="att-pill present ${st === 'present' ? 'active' : ''}" data-satt="${s.id}" data-st="present">উপস্থিত</button>
                <button type="button" class="att-pill absent ${st === 'absent' ? 'active' : ''}" data-satt="${s.id}" data-st="absent">অনুপস্থিত</button>
                <button type="button" class="att-pill leave ${st === 'leave' ? 'active' : ''}" data-satt="${s.id}" data-st="leave">ছুটি</button>
              </div>
            </div>
          `;
        }).join('')}
      </div>
    `;
  }

  container.innerHTML = `
    <div class="page-header">
      <div>
        <h1>ওস্তাদ, স্টাফ ও বেতন</h1>
        <p class="page-subtitle">মোট জনবল: ${formatNum(staffList.length)} জন</p>
      </div>
      <button type="button" class="btn btn-primary btn-sm" id="btn-add-staff">${icon('plus', 'sm')} নতুন ওস্তাদ/স্টাফ</button>
    </div>

    <div class="tabs">
      <button type="button" class="tab-btn ${activeTab === 'list' ? 'active' : ''}" data-tab="list">তালিকা (${formatNum(staffList.length)})</button>
      <button type="button" class="tab-btn ${activeTab === 'payroll' ? 'active' : ''}" data-tab="payroll">মাসিক বেতন (${formatNum(unpaidCount)} বাকি)</button>
      <button type="button" class="tab-btn ${activeTab === 'attendance' ? 'active' : ''}" data-tab="attendance">স্টাফ হাজিরা</button>
    </div>

    ${tabContent}
  `;

  container.querySelectorAll('.tab-btn').forEach((b) => {
    b.onclick = () => {
      activeTab = b.dataset.tab;
      renderStaff(container);
    };
  });

  document.getElementById('pay-month')?.addEventListener('change', (e) => {
    selectedMonth = e.target.value;
    renderStaff(container);
  });

  document.getElementById('staff-att-date')?.addEventListener('change', (e) => {
    selectedDate = e.target.value;
    renderStaff(container);
  });

  document.getElementById('btn-add-staff').onclick = () => {
    openModal({
      title: 'নতুন ওস্তাদ / স্টাফ যুক্ত করুন',
      bodyHtml: `
        <div class="form-grid">
          <div class="form-group">
            <label class="form-label">পূর্ণ নাম *</label>
            <input id="st-name" class="form-control" required placeholder="যেমন: হাফেজ মাওলানা মাহমুদ">
          </div>
          <div class="form-group">
            <label class="form-label">পদবী *</label>
            <input id="st-desig" class="form-control" value="সিনিয়র ওস্তাদ">
          </div>
          <div class="form-group">
            <label class="form-label">ফোন নম্বর *</label>
            <input id="st-phone" class="form-control" placeholder="017XXXXXXXX">
          </div>
          <div class="form-group">
            <label class="form-label">মাসিক মূল বেতন (টাকা) *</label>
            <input id="st-sal" class="form-control" type="number" min="0" value="12000">
          </div>
          <div class="form-group">
            <label class="form-label">অতিরিক্ত ভাতা (ঐচ্ছিক, টাকা)</label>
            <input id="st-allow" class="form-control" type="number" min="0" value="0">
          </div>
        </div>
      `,
      footerHtml: `
        <button type="button" class="btn btn-secondary" id="st-cancel">বাতিল</button>
        <button type="button" class="btn btn-primary" id="st-save">সংরক্ষণ</button>
      `
    });
    document.getElementById('st-cancel').onclick = closeModal;
    document.getElementById('st-save').onclick = async () => {
      const nameBn = document.getElementById('st-name').value.trim();
      const baseSalary = Number(document.getElementById('st-sal').value || 0);
      if (!nameBn) return showToast('নাম লিখুন', 'warning');
      const code = await nextSerial('staff_code', 'STF-');
      const doc = await addDocItem('staff', {
        branchId: 'main',
        staffCode: code,
        nameBn,
        designation: document.getElementById('st-desig').value.trim() || 'ওস্তাদ',
        phone: document.getElementById('st-phone').value.trim(),
        joiningDate: todayISO(),
        baseSalary,
        allowances: Number(document.getElementById('st-allow').value || 0),
        status: 'active',
        isDeleted: false
      });
      await logAudit({ action: 'ADD_STAFF', collection: 'staff', docId: doc.id, summary: `নতুন স্টাফ যুক্ত: ${nameBn}` });
      closeModal();
      showToast('ওস্তাদ/স্টাফ যুক্ত হয়েছে', 'success');
      renderStaff(container);
    };
  };

  container.querySelectorAll('[data-del-staff]').forEach((b) => {
    b.onclick = async () => {
      const ok = await requirePinConfirmation('এই স্টাফকে তালিকা থেকে অপসারণ (সফট ডিলিট) করতে PIN দিন।');
      if (!ok) return;
      await setDocById('staff', b.dataset.delStaff, { isDeleted: true }, true);
      showToast('অপসারণ সম্পন্ন হয়েছে', 'warning');
      renderStaff(container);
    };
  });

  document.getElementById('btn-gen-payroll')?.addEventListener('click', async () => {
    let created = 0;
    for (const s of staffList) {
      const pid = `pay_${selectedMonth}_${s.id}`;
      if (payrolls.some((p) => p.id === pid)) continue;
      const net = Number(s.baseSalary || 0) + Number(s.allowances || 0);
      await setDocById('payroll', pid, {
        branchId: 'main',
        staffId: s.id,
        month: selectedMonth,
        baseSalary: Number(s.baseSalary || 0),
        bonus: Number(s.allowances || 0),
        advanceDeduction: 0,
        netAmount: net,
        paidAmount: 0,
        status: 'unpaid'
      });
      created++;
    }
    showToast(`${formatNum(created)} জনের মাসিক বেতন স্লিপ তৈরি হয়েছে`, 'success');
    renderStaff(container);
  });

  container.querySelectorAll('[data-pay-salary]').forEach((b) => {
    b.onclick = () => {
      const p = payrolls.find((x) => x.id === b.dataset.paySalary);
      const st = staffMap[p.staffId];
      const generalFunds = funds.filter((f) => !f.zakatRestricted);
      openModal({
        title: `বেতন পরিশোধ — ${st?.nameBn || ''}`,
        bodyHtml: `
          <div class="form-grid">
            <div class="form-group">
              <label class="form-label">বোনাস / ভাতা (টাকা)</label>
              <input id="sal-bonus" class="form-control" type="number" min="0" value="${p.bonus || 0}">
            </div>
            <div class="form-group">
              <label class="form-label">অগ্রিম / কর্তন (টাকা)</label>
              <input id="sal-ded" class="form-control" type="number" min="0" value="${p.advanceDeduction || 0}">
            </div>
            <div class="form-group">
              <label class="form-label">তহবিল (সাধারণ তহবিল থেকে পরিশোধযোগ্য)</label>
              <select id="sal-fund" class="form-control">
                ${(generalFunds.length ? generalFunds : funds).map((f) => `<option value="${f.id}">${escapeHtml(f.nameBn)} (${formatCurrency(f.currentBalance)})</option>`).join('')}
              </select>
            </div>
            <div class="form-group">
              <label class="form-label">পরিশোধ অ্যাকাউন্ট</label>
              <select id="sal-acc" class="form-control">
                ${accounts.map((a) => `<option value="${a.id}">${escapeHtml(a.nameBn)}</option>`).join('')}
              </select>
            </div>
          </div>
        `,
        footerHtml: `
          <button type="button" class="btn btn-secondary" id="sal-cancel">বাতিল</button>
          <button type="button" class="btn btn-primary" id="sal-ok">PIN দিয়ে পরিশোধ</button>
        `
      });
      document.getElementById('sal-cancel').onclick = closeModal;
      document.getElementById('sal-ok').onclick = async () => {
        const bonus = Number(document.getElementById('sal-bonus').value || 0);
        const ded = Number(document.getElementById('sal-ded').value || 0);
        const net = Math.max(0, Number(p.baseSalary) + bonus - ded);
        const fundId = document.getElementById('sal-fund').value;
        const accId = document.getElementById('sal-acc').value;
        closeModal();

        const ok = await requirePinConfirmation(`${st?.nameBn}-এর বেতন ${formatCurrency(net)} পরিশোধ করতে PIN দিন।`);
        if (!ok) return;

        const year = new Date().getFullYear();
        const vchNo = await nextSerial(`voucher_${year}`, `VCH-${year}-`);
        const tx = await addDocItem('transactions', {
          branchId: 'main',
          receiptNo: vchNo,
          date: todayISO(),
          hijriDate: getHijriDateString(new Date()),
          type: 'expense',
          category: 'salary',
          fundId,
          accountId: accId,
          amount: net,
          description: `মাসিক বেতন (${selectedMonth}) — ${st?.nameBn || ''}`,
          status: 'posted',
          approvalStatus: 'auto_approved',
          createdBy: getCurrentUser()?.uid || 'system'
        });

        const fund = await getDocById('funds', fundId);
        if (fund) await setDocById('funds', fundId, { currentBalance: Number(fund.currentBalance || 0) - net }, true);
        const acc = await getDocById('accounts', accId);
        if (acc) await setDocById('accounts', accId, { currentBalance: Number(acc.currentBalance || 0) - net }, true);

        await setDocById('payroll', p.id, {
          bonus,
          advanceDeduction: ded,
          netAmount: net,
          paidAmount: net,
          status: 'paid',
          transactionId: tx.id,
          receiptNo: vchNo,
          paidAt: todayISO()
        }, true);

        await logAudit({ action: 'PAY_SALARY', collection: 'payroll', docId: p.id, summary: `বেতন পরিশোধ: ${st?.nameBn} (${net} টাকা)` });
        showToast('বেতন পরিশোধ ও স্লিপ তৈরি সম্পন্ন হয়েছে', 'success');
        renderStaff(container);
      };
    };
  });

  container.querySelectorAll('[data-slip]').forEach((b) => {
    b.onclick = () => {
      const p = payrolls.find((x) => x.id === b.dataset.slip);
      const st = staffMap[p.staffId];
      const brand = getBrand() || {};
      openModal({
        title: `বেতন স্লিপ — ${p.month}`,
        bodyHtml: `
          <div class="receipt-paper" style="padding:16px;">
            <h3 style="text-align:center;">${escapeHtml(brand.nameBn || 'মাদ্রাসা')}</h3>
            <p style="text-align:center;font-size:12px;color:#485B54;margin-bottom:12px;">বেতন পরিশোধ স্লিপ (${escapeHtml(p.receiptNo || '')})</p>
            <div class="form-grid">
              <div><strong>নাম:</strong> ${escapeHtml(st?.nameBn || '')} (${escapeHtml(st?.designation || '')})</div>
              <div><strong>মাস ও তারিখ:</strong> ${escapeHtml(p.month)} | পরিশোধ: ${escapeHtml(p.paidAt || '')}</div>
              <div><strong>মূল বেতন:</strong> ${formatCurrency(p.baseSalary)}</div>
              <div><strong>বোনাস/ভাতা:</strong> ${formatCurrency(p.bonus || 0)}</div>
              <div><strong>কর্তন/অগ্রিম:</strong> ${formatCurrency(p.advanceDeduction || 0)}</div>
              <div style="font-size:1.1rem;"><strong>মোট পরিশোধিত: ${formatCurrency(p.netAmount)}</strong></div>
            </div>
          </div>
        `,
        footerHtml: `<button type="button" class="btn btn-primary btn-sm" onclick="window.print()">প্রিন্ট / PDF</button>`
      });
    };
  });

  container.querySelectorAll('[data-satt]').forEach((b) => {
    b.onclick = async () => {
      const docId = `main_staff_${selectedDate}_${b.dataset.satt}`;
      await setDocById('attendance', docId, {
        branchId: 'main',
        type: 'staff',
        date: selectedDate,
        hijriDate: getHijriDateString(new Date(selectedDate)),
        targetId: b.dataset.satt,
        status: b.dataset.st,
        markedBy: getCurrentUser()?.uid || 'system'
      });
      renderStaff(container);
    };
  });
}
