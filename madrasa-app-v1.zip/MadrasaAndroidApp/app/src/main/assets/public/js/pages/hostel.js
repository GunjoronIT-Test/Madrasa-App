import { listCollection, addDocItem, setDocById } from '../core/store.js';
import { icon } from '../core/icons.js';
import { todayISO, formatCurrency, formatNum, escapeHtml, openModal, closeModal, showToast } from '../core/utils.js';

let activeTab = 'rooms'; // 'rooms' | 'stock' | 'assets' | 'library'

export async function renderHostel(container) {
  const [rooms, inventory, mealLogs, assets, books, issues, students] = await Promise.all([
    listCollection('hostel_rooms'),
    listCollection('inventory'),
    listCollection('meal_logs'),
    listCollection('assets'),
    listCollection('library_books'),
    listCollection('library_issues'),
    listCollection('students', (s) => !s.isDeleted && s.status === 'active')
  ]);

  const stuMap = Object.fromEntries(students.map((s) => [s.id, s.nameBn]));
  const bookMap = Object.fromEntries(books.map((b) => [b.id, b]));
  const lowStockCount = inventory.filter((i) => Number(i.quantity) <= Number(i.minLevel || 5)).length;

  let bodyHtml = '';
  if (activeTab === 'rooms') {
    bodyHtml = rooms.length === 0
      ? `<div class="card empty-state"><p>কোনো হোস্টেল রুম যুক্ত করা হয়নি।</p></div>`
      : `<div class="list-stack">
          ${rooms.map((r) => `
            <div class="list-item">
              <div class="list-item-main">
                <div class="list-item-title">রুম ${escapeHtml(r.roomNo)} — ${escapeHtml(r.building || 'মূল ভবন')}</div>
                <div class="list-item-sub">মোট আসন: ${formatNum(r.capacity)} | বরাদ্দ: ${formatNum(r.occupied || 0)} | খালি: ${formatNum(Math.max(0, Number(r.capacity) - Number(r.occupied || 0)))}</div>
              </div>
              <span class="badge ${Number(r.occupied || 0) >= Number(r.capacity) ? 'badge-warning' : 'badge-success'}">
                ${Number(r.occupied || 0) >= Number(r.capacity) ? 'পূর্ণ' : 'খালি আছে'}
              </span>
            </div>
          `).join('')}
        </div>`;
  } else if (activeTab === 'stock') {
    bodyHtml = `
      <div class="card" style="margin-bottom:16px;">
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:10px;">
          <h3>রান্নাঘরের স্টক ${lowStockCount > 0 ? `<span class="badge badge-danger">${formatNum(lowStockCount)}টি স্টক কম</span>` : ''}</h3>
          <button type="button" class="btn btn-secondary btn-sm" id="btn-log-meal">আজকের মিল এন্ট্রি</button>
        </div>
        ${inventory.length === 0 ? `<p class="text-muted">কোনো স্টক আইটেম নেই।</p>` : `
          <div class="list-stack">
            ${inventory.map((it) => {
              const low = Number(it.quantity) <= Number(it.minLevel || 5);
              return `
                <div class="list-item">
                  <div class="list-item-main">
                    <div class="list-item-title">${escapeHtml(it.nameBn)} ${low ? `<span class="badge badge-danger">স্টক কম</span>` : ''}</div>
                    <div class="list-item-sub">বর্তমান মজুদ: <strong>${formatNum(it.quantity)} ${escapeHtml(it.unit || 'কেজি')}</strong> (সর্বনিম্ন সীমা: ${formatNum(it.minLevel || 5)})</div>
                  </div>
                  <div class="list-item-actions">
                    <button type="button" class="btn btn-outline btn-sm" data-stock-adj="${it.id}" data-delta="-1">-১</button>
                    <button type="button" class="btn btn-primary btn-sm" data-stock-adj="${it.id}" data-delta="5">+৫</button>
                  </div>
                </div>
              `;
            }).join('')}
          </div>
        `}
      </div>
      <div class="card">
        <h3 style="margin-bottom:10px;">সাম্প্রতিক দৈনিক মিল ও খরচ</h3>
        ${mealLogs.length === 0 ? `<p class="text-muted">কোনো মিল লগ নেই।</p>` : `
          <div class="list-stack">
            ${mealLogs.slice(0, 7).map((m) => `
              <div class="list-item">
                <div class="list-item-main">
                  <div class="list-item-title">${escapeHtml(m.date)} — মোট মিল: ${formatNum(m.mealCount)}</div>
                  <div class="list-item-sub">খরচ: ${formatCurrency(m.totalCost)} | প্রতি মিল: ${formatCurrency(m.mealCount ? m.totalCost / m.mealCount : 0)}</div>
                </div>
              </div>
            `).join('')}
          </div>
        `}
      </div>
    `;
  } else if (activeTab === 'assets') {
    bodyHtml = assets.length === 0
      ? `<div class="card empty-state"><p>কোনো স্থায়ী সম্পদ তালিকাভুক্ত নেই।</p></div>`
      : `<div class="list-stack">
          ${assets.map((a) => `
            <div class="list-item">
              <div class="list-item-main">
                <div class="list-item-title">${escapeHtml(a.nameBn)} <span class="badge badge-neutral">${formatNum(a.quantity || 1)} টি</span></div>
                <div class="list-item-sub">মূল্য: ${formatCurrency(a.value || 0)} | অবস্থা: ${escapeHtml(a.condition || 'ভালো')} | অবস্থান: ${escapeHtml(a.location || '-')}</div>
              </div>
            </div>
          `).join('')}
        </div>`;
  } else {
    bodyHtml = `
      <div class="card" style="margin-bottom:16px;">
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:10px;">
          <h3>কিতাবখানা / লাইব্রেরি (${formatNum(books.length)}টি কিতাব)</h3>
          <button type="button" class="btn btn-primary btn-sm" id="btn-issue-book">কিতাব ইস্যু করুন</button>
        </div>
        ${books.length === 0 ? `<p class="text-muted">কোনো কিতাব যুক্ত করা হয়নি।</p>` : `
          <div class="list-stack">
            ${books.map((b) => `
              <div class="list-item">
                <div class="list-item-main">
                  <div class="list-item-title">${escapeHtml(b.titleBn)}</div>
                  <div class="list-item-sub">লেখক: ${escapeHtml(b.author || '-')} | মোট কপি: ${formatNum(b.totalCopies)} | মজুদ: ${formatNum(b.availableCopies)}</div>
                </div>
              </div>
            `).join('')}
          </div>
        `}
      </div>
      <div class="card">
        <h3 style="margin-bottom:10px;">ইস্যুকৃত কিতাব তালিকা</h3>
        ${issues.length === 0 ? `<p class="text-muted">কোনো কিতাব ইস্যু করা হয়নি।</p>` : `
          <div class="list-stack">
            ${issues.map((is) => `
              <div class="list-item">
                <div class="list-item-main">
                  <div class="list-item-title">${escapeHtml(bookMap[is.bookId]?.titleBn || is.bookId)}</div>
                  <div class="list-item-sub">ছাত্র: ${escapeHtml(stuMap[is.studentId] || is.studentId)} | তারিখ: ${escapeHtml(is.issueDate)}</div>
                </div>
                ${is.status === 'returned'
                  ? `<span class="badge badge-success">ফেরত এসেছে</span>`
                  : `<button type="button" class="btn btn-outline btn-sm" data-ret-book="${is.id}">ফেরত নিন</button>`}
              </div>
            `).join('')}
          </div>
        `}
      </div>
    `;
  }

  container.innerHTML = `
    <div class="page-header">
      <div>
        <h1>আবাসিক, স্টক, সম্পদ ও লাইব্রেরি</h1>
        <p class="page-subtitle">হোস্টেল আসন, দৈনিক মিল, রান্নাঘরের স্টক, স্থায়ী সম্পদ ও কিতাবখানা</p>
      </div>
      <button type="button" class="btn btn-primary btn-sm" id="hs-add-btn">${icon('plus', 'sm')} নতুন যুক্ত করুন</button>
    </div>

    <div class="tabs">
      <button type="button" class="tab-btn ${activeTab === 'rooms' ? 'active' : ''}" data-htab="rooms">হোস্টেল রুম</button>
      <button type="button" class="tab-btn ${activeTab === 'stock' ? 'active' : ''}" data-htab="stock">মিল ও স্টক</button>
      <button type="button" class="tab-btn ${activeTab === 'assets' ? 'active' : ''}" data-htab="assets">স্থায়ী সম্পদ</button>
      <button type="button" class="tab-btn ${activeTab === 'library' ? 'active' : ''}" data-htab="library">লাইব্রেরি</button>
    </div>

    ${bodyHtml}
  `;

  container.querySelectorAll('[data-htab]').forEach((b) => {
    b.onclick = () => {
      activeTab = b.dataset.htab;
      renderHostel(container);
    };
  });

  container.querySelectorAll('[data-stock-adj]').forEach((b) => {
    b.onclick = async () => {
      const it = inventory.find((x) => x.id === b.dataset.stockAdj);
      const nextQty = Math.max(0, Number(it.quantity || 0) + Number(b.dataset.delta));
      await setDocById('inventory', it.id, { quantity: nextQty }, true);
      renderHostel(container);
    };
  });

  document.getElementById('btn-log-meal')?.addEventListener('click', () => {
    openModal({
      title: 'দৈনিক মিল ও বাজার খরচ এন্ট্রি',
      bodyHtml: `
        <div class="form-grid">
          <div class="form-group"><label class="form-label">তারিখ</label><input id="ml-date" class="form-control" type="date" value="${todayISO()}"></div>
          <div class="form-group"><label class="form-label">মোট মিল সংখ্যা</label><input id="ml-cnt" class="form-control" type="number" min="1" value="60"></div>
          <div class="form-group"><label class="form-label">মোট খরচ (টাকা)</label><input id="ml-cost" class="form-control" type="number" min="0" value="3600"></div>
        </div>
      `,
      footerHtml: `<button type="button" class="btn btn-primary" id="ml-save">সংরক্ষণ</button>`
    });
    document.getElementById('ml-save').onclick = async () => {
      await addDocItem('meal_logs', {
        branchId: 'main',
        date: document.getElementById('ml-date').value,
        mealCount: Number(document.getElementById('ml-cnt').value || 0),
        totalCost: Number(document.getElementById('ml-cost').value || 0)
      });
      closeModal();
      showToast('মিল লগ সংরক্ষিত হয়েছে', 'success');
      renderHostel(container);
    };
  });

  document.getElementById('btn-issue-book')?.addEventListener('click', () => {
    openModal({
      title: 'কিতাব ইস্যু করুন',
      bodyHtml: `
        <div class="form-grid">
          <div class="form-group">
            <label class="form-label">কিতাব</label>
            <select id="is-book" class="form-control">${books.filter((b) => Number(b.availableCopies) > 0).map((b) => `<option value="${b.id}">${escapeHtml(b.titleBn)}</option>`).join('')}</select>
          </div>
          <div class="form-group">
            <label class="form-label">ছাত্র</label>
            <select id="is-stu" class="form-control">${students.map((s) => `<option value="${s.id}">${escapeHtml(s.nameBn)}</option>`).join('')}</select>
          </div>
        </div>
      `,
      footerHtml: `<button type="button" class="btn btn-primary" id="is-ok">ইস্যু করুন</button>`
    });
    document.getElementById('is-ok').onclick = async () => {
      const bookId = document.getElementById('is-book').value;
      const studentId = document.getElementById('is-stu').value;
      if (!bookId) return showToast('কোনো মজুদ কিতাব নেই', 'warning');
      const bk = bookMap[bookId];
      await addDocItem('library_issues', { branchId: 'main', bookId, studentId, issueDate: todayISO(), status: 'issued' });
      await setDocById('library_books', bookId, { availableCopies: Math.max(0, Number(bk.availableCopies) - 1) }, true);
      closeModal();
      showToast('কিতাব ইস্যু হয়েছে', 'success');
      renderHostel(container);
    };
  });

  container.querySelectorAll('[data-ret-book]').forEach((b) => {
    b.onclick = async () => {
      const iss = issues.find((x) => x.id === b.dataset.retBook);
      await setDocById('library_issues', iss.id, { status: 'returned', returnedAt: todayISO() }, true);
      const bk = bookMap[iss.bookId];
      if (bk) await setDocById('library_books', bk.id, { availableCopies: Number(bk.availableCopies || 0) + 1 }, true);
      showToast('কিতাব ফেরত নেওয়া হয়েছে', 'success');
      renderHostel(container);
    };
  });

  document.getElementById('hs-add-btn').onclick = () => {
    if (activeTab === 'rooms') {
      openModal({
        title: 'নতুন হোস্টেল রুম',
        bodyHtml: `
          <div class="form-grid">
            <div class="form-group"><label class="form-label">রুম নম্বর *</label><input id="rm-no" class="form-control" placeholder="যেমন: ২০১"></div>
            <div class="form-group"><label class="form-label">ভবন</label><input id="rm-bld" class="form-control" value="পূর্ব ভবন"></div>
            <div class="form-group"><label class="form-label">মোট আসন</label><input id="rm-cap" class="form-control" type="number" min="1" value="12"></div>
          </div>
        `,
        footerHtml: `<button type="button" class="btn btn-primary" id="rm-save">সংরক্ষণ</button>`
      });
      document.getElementById('rm-save').onclick = async () => {
        const roomNo = document.getElementById('rm-no').value.trim();
        if (!roomNo) return;
        await addDocItem('hostel_rooms', { branchId: 'main', roomNo, building: document.getElementById('rm-bld').value.trim(), capacity: Number(document.getElementById('rm-cap').value || 10), occupied: 0 });
        closeModal();
        renderHostel(container);
      };
    } else if (activeTab === 'stock') {
      openModal({
        title: 'রান্নাঘরের স্টক আইটেম যুক্ত করুন',
        bodyHtml: `
          <div class="form-grid">
            <div class="form-group"><label class="form-label">পণ্যের নাম *</label><input id="sk-name" class="form-control" placeholder="যেমন: চাল / মসুর ডাল / সয়াবিন তেল"></div>
            <div class="form-group"><label class="form-label">পরিমাণ ও একক</label><div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;"><input id="sk-qty" class="form-control" type="number" value="50"><input id="sk-unit" class="form-control" value="কেজি"></div></div>
            <div class="form-group"><label class="form-label">সতর্কতা সীমা</label><input id="sk-min" class="form-control" type="number" value="10"></div>
          </div>
        `,
        footerHtml: `<button type="button" class="btn btn-primary" id="sk-save">সংরক্ষণ</button>`
      });
      document.getElementById('sk-save').onclick = async () => {
        const nameBn = document.getElementById('sk-name').value.trim();
        if (!nameBn) return;
        await addDocItem('inventory', { branchId: 'main', nameBn, quantity: Number(document.getElementById('sk-qty').value || 0), unit: document.getElementById('sk-unit').value.trim(), minLevel: Number(document.getElementById('sk-min').value || 5) });
        closeModal();
        renderHostel(container);
      };
    } else if (activeTab === 'assets') {
      openModal({
        title: 'স্থায়ী সম্পদ যুক্ত করুন',
        bodyHtml: `
          <div class="form-grid">
            <div class="form-group"><label class="form-label">সম্পদের নাম *</label><input id="as-name" class="form-control" placeholder="যেমন: সিলিং ফ্যান / কাঠের আলমারি"></div>
            <div class="form-group"><label class="form-label">সংখ্যা ও মূল্য</label><div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;"><input id="as-qty" class="form-control" type="number" value="1"><input id="as-val" class="form-control" type="number" value="5000"></div></div>
            <div class="form-group"><label class="form-label">অবস্থান</label><input id="as-loc" class="form-control" value="অফিস কক্ষ"></div>
          </div>
        `,
        footerHtml: `<button type="button" class="btn btn-primary" id="as-save">সংরক্ষণ</button>`
      });
      document.getElementById('as-save').onclick = async () => {
        const nameBn = document.getElementById('as-name').value.trim();
        if (!nameBn) return;
        await addDocItem('assets', { branchId: 'main', nameBn, quantity: Number(document.getElementById('as-qty').value || 1), value: Number(document.getElementById('as-val').value || 0), location: document.getElementById('as-loc').value.trim(), condition: 'ভালো' });
        closeModal();
        renderHostel(container);
      };
    } else {
      openModal({
        title: 'নতুন কিতাব যুক্ত করুন',
        bodyHtml: `
          <div class="form-grid">
            <div class="form-group"><label class="form-label">কিতাবের নাম *</label><input id="bk-title" class="form-control" placeholder="যেমন: সহীহ বুখারী শরীফ"></div>
            <div class="form-group"><label class="form-label">লেখক / সংকলক</label><input id="bk-auth" class="form-control"></div>
            <div class="form-group"><label class="form-label">মোট কপি</label><input id="bk-cnt" class="form-control" type="number" min="1" value="5"></div>
          </div>
        `,
        footerHtml: `<button type="button" class="btn btn-primary" id="bk-save">সংরক্ষণ</button>`
      });
      document.getElementById('bk-save').onclick = async () => {
        const titleBn = document.getElementById('bk-title').value.trim();
        const cnt = Number(document.getElementById('bk-cnt').value || 1);
        if (!titleBn) return;
        await addDocItem('library_books', { branchId: 'main', titleBn, author: document.getElementById('bk-auth').value.trim(), totalCopies: cnt, availableCopies: cnt });
        closeModal();
        renderHostel(container);
      };
    }
  };
}
