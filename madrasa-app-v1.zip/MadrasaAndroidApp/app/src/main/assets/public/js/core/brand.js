import { getDocById } from './store.js';
import { setFormatPrefs, getDualDateLine } from './utils.js';
import { icon } from './icons.js';

let currentBrand = null;

export async function loadAndApplyBrand() {
  const inst = await getDocById('settings', 'institution');
  currentBrand = inst;
  applyBrandToDom(inst);
  return inst;
}

export function getBrand() {
  return currentBrand;
}

export function applyBrandToDom(inst) {
  const root = document.documentElement;
  const primary = inst?.primaryColor || '#0F6E56';
  const accent = inst?.accentColor || '#B47B2B';
  root.style.setProperty('--brand-primary', primary);
  root.style.setProperty('--brand-accent', accent);

  const metaTheme = document.querySelector('meta[name="theme-color"]');
  if (metaTheme) metaTheme.setAttribute('content', primary);

  setFormatPrefs({
    numberFormat: inst?.numberFormat || 'bn',
    currencySymbol: inst?.currencySymbol || '৳'
  });

  const savedTheme = localStorage.getItem('madrasa_theme') || 'light';
  root.setAttribute('data-theme', savedTheme);

  const name = inst?.nameBn || 'মাদ্রাসা ম্যানেজমেন্ট';
  document.title = name;

  const nameEl = document.getElementById('header-institution-name');
  if (nameEl) nameEl.textContent = name;

  const dateEl = document.getElementById('header-date-line');
  if (dateEl) dateEl.textContent = getDualDateLine(new Date());

  const logoWrap = document.getElementById('header-logo-wrap');
  if (logoWrap) {
    logoWrap.innerHTML = inst?.logoUrl
      ? `<img src="${inst.logoUrl}" alt="${name}">`
      : icon('book', 'md');
  }

  const demoBadge = document.getElementById('demo-badge');
  if (demoBadge) {
    demoBadge.hidden = !inst?.demoMode;
  }
}

export function toggleTheme() {
  const cur = document.documentElement.getAttribute('data-theme') || 'light';
  const next = cur === 'dark' ? 'light' : 'dark';
  document.documentElement.setAttribute('data-theme', next);
  localStorage.setItem('madrasa_theme', next);
  return next;
}
