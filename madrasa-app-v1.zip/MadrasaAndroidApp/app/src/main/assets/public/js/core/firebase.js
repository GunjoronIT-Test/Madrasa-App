/**
 * Firebase v10 ES Module সংযোগ ও অটো অফলাইন/ডেমো ফলব্যাক
 */
let firebaseState = {
  mode: 'local', // 'firebase' | 'local'
  app: null,
  auth: null,
  db: null,
  storage: null,
  sdk: null
};

export async function initFirebaseIfConfigured() {
  try {
    const cfgMod = await import('../../config/firebase-config.js');
    const cfg = cfgMod?.firebaseConfig;
    if (!cfg || !cfg.apiKey || String(cfg.apiKey).startsWith('PASTE_YOUR')) {
      firebaseState.mode = 'local';
      return firebaseState;
    }

    const [appMod, authMod, fsMod, stMod] = await Promise.all([
      import('https://www.gstatic.com/firebasejs/10.12.5/firebase-app.js'),
      import('https://www.gstatic.com/firebasejs/10.12.5/firebase-auth.js'),
      import('https://www.gstatic.com/firebasejs/10.12.5/firebase-firestore.js'),
      import('https://www.gstatic.com/firebasejs/10.12.5/firebase-storage.js')
    ]);

    const app = appMod.initializeApp(cfg);
    const auth = authMod.getAuth(app);
    const db = fsMod.initializeFirestore(app, {
      localCache: fsMod.persistentLocalCache({
        tabManager: fsMod.persistentMultipleTabManager()
      })
    });
    const storage = stMod.getStorage(app);

    if (cfgMod.USE_FIREBASE_EMULATOR) {
      authMod.connectAuthEmulator(auth, 'http://127.0.0.1:9099', { disableWarnings: true });
      fsMod.connectFirestoreEmulator(db, '127.0.0.1', 8080);
      stMod.connectStorageEmulator(storage, '127.0.0.1', 9199);
    }

    firebaseState = {
      mode: 'firebase',
      app,
      auth,
      db,
      storage,
      sdk: { authMod, fsMod, stMod }
    };
    return firebaseState;
  } catch {
    // firebase-config.js না থাকলে বা অফলাইনে থাকলে লোকাল/ডেমো স্টোরেজ ব্যবহার হবে
    firebaseState.mode = 'local';
    return firebaseState;
  }
}

export function getFirebaseState() {
  return firebaseState;
}
