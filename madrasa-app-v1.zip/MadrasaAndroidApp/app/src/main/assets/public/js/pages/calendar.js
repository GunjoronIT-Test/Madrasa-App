import { listCollection, addDocItem } from '../core/store.js';
import { icon } from '../core/icons.js';
import { todayISO, getHijriDateString, escapeHtml, openModal, closeModal, showToast } from '../core/utils.js';

const DAYS = ['শনিবার', 'রবিবার', 'সোমবার', 'মঙ্গলবার', 'বুধবার', 'বৃহস্পতিবার'];
let activeTab = 'routine'; // 'routine' | 'holidays'
let filterJamat = 'all';

export async function renderCalendar(container) {
  const [routines, holidays, jamats, staff] = await Promise.all([
    listCollection('routines'),
    listCollection('holidays'),
    listCollection('jamats', (j) => !j.isDeleted),
    listCollection('staff', (s) => !s.isDeleted)
  ]);

  const jamatMap = Object.fromEntries(jamats.map((j) => [j.id, j.nameBn]));
  const staffMap = Object.fromEntries(staff.map((s) => [s.id, s.nameBn]));

  const filteredRoutines = routines.filter((r) => filterJamat === 'all' || r.jamatId === filterJamat);

  container.innerHTML = `
    <div class="page-header">
      <div>
        <h1>ক্লাস রুটিন ও ছুটির ক্যালেন্ডার</h1>
        <p class="page-subtitle">ওস্তাদ কনফ্লিক্ট ডিটেকশন এবং হিজরি-ইংরেজি দ্বৈত ছুটির তালিকা</p>
      </div>
      <button type="button" class="btn btn-primary btn-sm" id="cal-add-btn">
        ${icon('plus', 'sm')} ${activeTab === 'routine' ? 'রুটিন যোগ' : 'ছুটি যোগ'}
      </button>
    </div>

    <div class="tabs">
      <button type="button" class="tab-btn ${activeTab === 'routine' ? 'active' : ''}" data-ctab="routine">ক্লাস রুটিন</button>
      <button type="button" class="tab-btn ${activeTab === 'holidays' ? 'active' : ''}" data-ctab="holidays">ছুটির ক্যালেন্ডার</button>
    </div>

    ${activeTab === 'routine' ? `
      <div class="toolbar">
        <select id="cal-jamat-filter" class="form-control">
          <option value="all">সকল জামাত</option>
          ${jamats.map((j) => `<option value="${j.id}" ${filterJamat === j.id ? 'selected' : ''}>${escapeHtml(j.nameBn)}</option>`).join('')}
        </select>
      </div>
      ${filteredRoutines.length === 0
        ? `<div class="card empty-state">${icon('calendar', 'lg')}<p>কোনো ক্লাস রুটিন যুক্ত করা হয়নি।</p></div>`
        : `<div class="table-wrap">
            <table class="data-table">
              <thead><tr><th>বার</th><th>সময়</th><th>জামাত</th><th>কিতাব / বিষয়</th><th>ওস্তাদ</th></tr></thead>
              <tbody>
                ${filteredRoutines.map((r) => `
                  <tr>
                    <td>${escapeHtml(r.day)}</td>
                    <td>${escapeHtml(r.timeSlot)}</td>
                    <td>${escapeHtml(jamatMap[r.jamatId] || '-')}</td>
                    <td><strong>${escapeHtml(r.subject)}</strong></td>
                    <td>${escapeHtml(staffMap[r.staffId] || '-')}</td>
                  </tr>
                `).join('')}
              </tbody>
            </table>
          </div>`}
    ` : `
      ${holidays.length === 0
        ? `<div class="card empty-state">${icon('calendar', 'lg')}<p>কোনো ছুটি তালিকাভুক্ত নেই।</p></div>`
        : `<div class="list-stack">
            ${holidays.map((h) => `
              <div class="list-item">
                <div class="list-item-main">
                  <div class="list-item-title">${escapeHtml(h.titleBn)}</div>
                  <div class="list-item-sub">ইংরেজি: ${escapeHtml(h.startDate)} ${h.endDate && h.endDate !== h.startDate ? `থেকে ${escapeHtml(h.endDate)}` : ''} | হিজরি: ${escapeHtml(h.hijriDate || '')}</div>
                </div>
                <span class="badge badge-info">${escapeHtml(h.category || 'ছুটি')}</span>
              </div>
            `).join('')}
          </div>`}
    `}
  `;

  container.querySelectorAll('[data-ctab]').forEach((b) => {
    b.onclick = () => {
      activeTab = b.dataset.ctab;
      renderCalendar(container);
    };
  });

  document.getElementById('cal-jamat-filter')?.addEventListener('change', (e) => {
    filterJamat = e.target.value;
    renderCalendar(container);
  });

  document.getElementById('cal-add-btn').onclick = () => {
    if (activeTab === 'routine') {
      openModal({
        title: 'ক্লাস রুটিনে পিরিয়ড যুক্ত করুন',
        bodyHtml: `
          <div class="form-grid">
            <div class="form-group">
              <label class="form-label">বার *</label>
              <select id="rt-day" class="form-control">${DAYS.map((d) => `<option value="${d}">${d}</option>`).join('')}</select>
            </div>
            <div class="form-group">
              <label class="form-label">সময় / পিরিয়ড *</label>
              <input id="rt-time" class="form-control" value="০৮:০০ - ০৯:০০">
            </div>
            <div class="form-group">
              <label class="form-label">জামাত *</label>
              <select id="rt-jamat" class="form-control">${jamats.map((j) => `<option value="${j.id}">${escapeHtml(j.nameBn)}</option>`).join('')}</select>
            </div>
            <div class="form-group">
              <label class="form-label">কিতাব / বিষয় *</label>
              <input id="rt-sub" class="form-control" placeholder="যেমন: হিফজ সবক / নাহুমীর">
            </div>
            <div class="form-group">
              <label class="form-label">ওস্তাদ *</label>
              <select id="rt-staff" class="form-control">${staff.map((s) => `<option value="${s.id}">${escapeHtml(s.nameBn)}</option>`).join('')}</select>
            </div>
          </div>
        `,
        footerHtml: `<button type="button" class="btn btn-primary" id="rt-save">সংরক্ষণ</button>`
      });
      document.getElementById('rt-save').onclick = async () => {
        const day = document.getElementById('rt-day').value;
        const timeSlot = document.getElementById('rt-time').value.trim();
        const staffId = document.getElementById('rt-staff').value;
        const subject = document.getElementById('rt-sub').value.trim();
        if (!subject || !timeSlot) return showToast('সময় ও বিষয় লিখুন', 'warning');

        // কনফ্লিক্ট ডিটেকশন: একই বার ও সময়ে একই ওস্তাদের অন্য ক্লাস আছে কি না
        const conflict = routines.find((r) => r.day === day && r.timeSlot === timeSlot && r.staffId === staffId);
        if (conflict) {
          showToast(`কনফ্লিক্ট সতর্কতা: এই ওস্তাদের ${day} (${timeSlot}) সময়ে ইতিমধ্যেই ক্লাস আছে!`, 'error');
          return;
        }

        await addDocItem('routines', {
          branchId: 'main',
          day,
          timeSlot,
          jamatId: document.getElementById('rt-jamat').value,
          subject,
          staffId
        });
        closeModal();
        showToast('ক্লাস রুটিন যুক্ত হয়েছে', 'success');
        renderCalendar(container);
      };
    } else {
      openModal({
        title: 'ছুটির ক্যালেন্ডারে যুক্ত করুন',
        bodyHtml: `
          <div class="form-grid">
            <div class="form-group">
              <label class="form-label">ছুটির নাম *</label>
              <input id="hl-title" class="form-control" placeholder="যেমন: রমযান ও ঈদুল ফিতরের ছুটি">
            </div>
            <div class="form-group">
              <label class="form-label">শুরুর তারিখ *</label>
              <input id="hl-start" class="form-control" type="date" value="${todayISO()}">
            </div>
            <div class="form-group">
              <label class="form-label">শেষ তারিখ</label>
              <input id="hl-end" class="form-control" type="date" value="${todayISO()}">
            </div>
          </div>
        `,
        footerHtml: `<button type="button" class="btn btn-primary" id="hl-save">সংরক্ষণ</button>`
      });
      document.getElementById('hl-save').onclick = async () => {
        const titleBn = document.getElementById('hl-title').value.trim();
        const startDate = document.getElementById('hl-start').value;
        if (!titleBn) return showToast('ছুটির নাম লিখুন', 'warning');
        await addDocItem('holidays', {
          branchId: 'main',
          titleBn,
          startDate,
          endDate: document.getElementById('hl-end').value || startDate,
          hijriDate: getHijriDateString(new Date(startDate)),
          category: 'বাৎসরিক ছুটি'
        });
        closeModal();
        showToast('ছুটি যুক্ত হয়েছে', 'success');
        renderCalendar(container);
      };
    }
  };
}
