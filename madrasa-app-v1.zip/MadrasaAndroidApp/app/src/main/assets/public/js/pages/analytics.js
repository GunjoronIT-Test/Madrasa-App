import { listCollection, addDocItem } from '../core/store.js';
import { logAudit } from '../core/audit.js';
import { icon } from '../core/icons.js';
import { formatCurrency, formatNum, escapeHtml, STUDENT_CATEGORIES, openModal, closeModal, showToast } from '../core/utils.js';

export async function renderAnalytics(container) {
  const [branches, students, attendance, invoices, txs, funds] = await Promise.all([
    listCollection('branches'),
    listCollection('students', (s) => !s.isDeleted && s.status === 'active'),
    listCollection('attendance', (a) => a.type === 'student'),
    listCollection('fee_invoices'),
    listCollection('transactions', (t) => t.status === 'posted'),
    listCollection('funds')
  ]);

  const totalAtt = attendance.length;
  const presentAtt = attendance.filter((a) => a.status === 'present').length;
  const attRate = totalAtt ? Math.round((presentAtt / totalAtt) * 100) : 0;

  const totalBilled = invoices.reduce((s, i) => s + Number(i.netAmount || 0), 0);
  const totalCollected = invoices.reduce((s, i) => s + Number(i.paidAmount || 0), 0);
  const feeRate = totalBilled ? Math.round((totalCollected / totalBilled) * 100) : 0;

  const totalInc = txs.filter((t) => t.type === 'income').reduce((s, t) => s + Number(t.amount || 0), 0);
  const totalExp = txs.filter((t) => t.type === 'expense').reduce((s, t) => s + Number(t.amount || 0), 0);
  const surplus = totalInc - totalExp;

  // ছাত্র ক্যাটাগরি বিশ্লেষণ
  const catCounts = Object.keys(STUDENT_CATEGORIES).map((k) => ({
    label: STUDENT_CATEGORIES[k],
    count: students.filter((s) => s.category === k).length
  }));
  const maxCat = Math.max(...catCounts.map((c) => c.count), 1);

  const totalFunds = funds.reduce((s, f) => s + Math.max(0, Number(f.currentBalance || 0)), 0) || 1;

  container.innerHTML = `
    <div class="page-header">
      <div>
        <h1>উন্নত বিশ্লেষণ ও মাল্টি-শাখা</h1>
        <p class="page-subtitle">প্রতিষ্ঠানের আর্থিক সক্ষমতা, আদায়ের হার ও শাখা ব্যবস্থাপনা</p>
      </div>
      <button type="button" class="btn btn-primary btn-sm" id="an-add-branch">${icon('plus', 'sm')} নতুন শাখা</button>
    </div>

    <div class="kpi-grid">
      <div class="card" style="padding:14px;">
        <div class="form-hint">গড় উপস্থিতির হার</div>
        <div class="kpi-value text-success">${formatNum(attRate)}%</div>
        <div class="kpi-meta">${formatNum(presentAtt)} / ${formatNum(totalAtt)} এন্ট্রি</div>
      </div>
      <div class="card" style="padding:14px;">
        <div class="form-hint">ফি আদায়ের হার</div>
        <div class="kpi-value">${formatNum(feeRate)}%</div>
        <div class="kpi-meta">${formatCurrency(totalCollected)} / ${formatCurrency(totalBilled)}</div>
      </div>
      <div class="card" style="padding:14px;">
        <div class="form-hint">নিট উদ্বৃত্ত (আয় - ব্যয়)</div>
        <div class="kpi-value ${surplus >= 0 ? 'text-success' : 'text-danger'}">${formatCurrency(surplus)}</div>
        <div class="kpi-meta">সর্বমোট পোস্টেড লেজার</div>
      </div>
      <div class="card" style="padding:14px;">
        <div class="form-hint">মোট শাখা</div>
        <div class="kpi-value">${formatNum(branches.length)}</div>
        <div class="kpi-meta">মাল্টি-শাখা সক্রিয়</div>
      </div>
    </div>

    <div class="card">
      <h2 style="margin-bottom:12px;">ছাত্র ধরনভিত্তিক বিশ্লেষণ</h2>
      <div class="list-stack" style="gap:10px;">
        ${catCounts.map((c) => {
          const pct = Math.round((c.count / maxCat) * 100);
          return `
            <div>
              <div style="display:flex;justify-content:space-between;font-size:0.875rem;margin-bottom:4px;">
                <span>${c.label}</span>
                <strong>${formatNum(c.count)} জন</strong>
              </div>
              <div style="height:10px;background:var(--bg-subtle);border-radius:99px;overflow:hidden;">
                <div style="height:100%;width:${pct}%;background:var(--brand-primary);"></div>
              </div>
            </div>
          `;
        }).join('')}
      </div>
    </div>

    <div class="card">
      <h2 style="margin-bottom:12px;">তহবিল বণ্টন (%)</h2>
      <div class="list-stack" style="gap:10px;">
        ${funds.map((f) => {
          const bal = Math.max(0, Number(f.currentBalance || 0));
          const pct = Math.round((bal / totalFunds) * 100);
          return `
            <div>
              <div style="display:flex;justify-content:space-between;font-size:0.875rem;margin-bottom:4px;">
                <span>${escapeHtml(f.nameBn)}</span>
                <strong>${formatCurrency(bal)} (${formatNum(pct)}%)</strong>
              </div>
              <div style="height:10px;background:var(--bg-subtle);border-radius:99px;overflow:hidden;">
                <div style="height:100%;width:${pct}%;background:${f.zakatRestricted ? 'var(--brand-accent)' : 'var(--color-success)'};"></div>
              </div>
            </div>
          `;
        }).join('')}
      </div>
    </div>

    <div class="card">
      <h2 style="margin-bottom:12px;">শাখা তালিকা (Multi-Branch)</h2>
      <div class="list-stack">
        ${branches.map((b) => `
          <div class="list-item">
            <div class="list-item-main">
              <div class="list-item-title">${escapeHtml(b.nameBn)} ${b.isDefault ? '<span class="badge badge-success">মূল শাখা</span>' : ''}</div>
              <div class="list-item-sub">আইডি: ${escapeHtml(b.branchId || b.id)} | ঠিকানা: ${escapeHtml(b.address || 'প্রধান ক্যাম্পাস')}</div>
            </div>
            <span class="badge badge-info">${b.status === 'active' ? 'সক্রিয়' : 'নিষ্ক্রিয়'}</span>
          </div>
        `).join('')}
      </div>
    </div>
  `;

  document.getElementById('an-add-branch').onclick = () => {
    openModal({
      title: 'নতুন শাখা যুক্ত করুন',
      bodyHtml: `
        <div class="form-grid">
          <div class="form-group"><label class="form-label">শাখার নাম *</label><input id="br-name" class="form-control" placeholder="যেমন: বালিকা শাখা / হিফজ ক্যাম্পাস-২"></div>
          <div class="form-group"><label class="form-label">ঠিকানা</label><input id="br-addr" class="form-control" placeholder="শাখার ঠিকানা"></div>
          <div class="form-group"><label class="form-label">ফোন নম্বর</label><input id="br-phone" class="form-control" placeholder="017XXXXXXXX"></div>
        </div>
      `,
      footerHtml: `<button type="button" class="btn btn-primary" id="br-save">শাখা যুক্ত করুন</button>`
    });
    document.getElementById('br-save').onclick = async () => {
      const nameBn = document.getElementById('br-name').value.trim();
      if (!nameBn) return showToast('শাখার নাম লিখুন', 'warning');
      const code = `branch_${Date.now().toString(36)}`;
      await addDocItem('branches', {
        branchId: code,
        nameBn,
        address: document.getElementById('br-addr').value.trim(),
        phone: document.getElementById('br-phone').value.trim(),
        isDefault: false,
        status: 'active'
      }, code);
      await logAudit({ action: 'ADD_BRANCH', collection: 'branches', docId: code, summary: `নতুন শাখা: ${nameBn}` });
      closeModal();
      showToast('নতুন শাখা যুক্ত হয়েছে', 'success');
      renderAnalytics(container);
    };
  };
}
