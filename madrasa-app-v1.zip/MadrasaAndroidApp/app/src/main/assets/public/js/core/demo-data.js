import { setDocById, addDocItem } from './store.js';
import { todayISO, currentMonthISO, getHijriDateString, sha256Hex } from './utils.js';

export async function seedDemoData(institutionOverride = {}) {
  const today = todayISO();
  const month = currentMonthISO();
  const hijri = getHijriDateString(new Date());

  await setDocById('branches', 'main', {
    branchId: 'main',
    nameBn: 'মূল শাখা',
    isDefault: true,
    status: 'active'
  });

  await setDocById('settings', 'institution', {
    nameBn: institutionOverride.nameBn || 'জামিয়া ইসলামিয়া দারুল উলূম (ডেমো)',
    nameEn: institutionOverride.nameEn || 'Jamia Islamia Darul Ulum (Demo)',
    slogan: institutionOverride.slogan || 'দ্বীনি ইলম ও আমলের সমন্বিত শিক্ষাকেন্দ্র',
    logoUrl: institutionOverride.logoUrl || '',
    address: institutionOverride.address || 'মাদ্রাসা রোড, ঢাকা',
    phone: institutionOverride.phone || '01700-000000',
    email: institutionOverride.email || 'admin@madrasa.demo',
    muhtamimName: institutionOverride.muhtamimName || 'মাওলানা আব্দুল করিম',
    primaryColor: institutionOverride.primaryColor || '#0F6E56',
    accentColor: institutionOverride.accentColor || '#B47B2B',
    currencySymbol: '৳',
    academicStartMonth: 1,
    defaultLanguage: 'bn',
    numberFormat: 'bn',
    expenseApprovalLimit: 10000,
    setupCompleted: true,
    demoMode: true
  });

  // ডেমো মুহতামিম ইউজার (পাসওয়ার্ড: 123456, PIN: 1234)
  const adminUid = 'user_muhtamim_demo';
  const passHash = await sha256Hex(`${adminUid}:123456`);
  const pinHash = await sha256Hex(`${adminUid}_pin_v1:1234`);
  await setDocById('users', adminUid, {
    uid: adminUid,
    name: institutionOverride.muhtamimName || 'মাওলানা আব্দুল করিম',
    email: 'admin@madrasa.demo',
    phone: '01700-000000',
    role: 'muhtamim',
    branchId: 'all',
    status: 'active',
    isDeleted: false,
    passwordHash: passHash,
    pinHash,
    pinSalt: `${adminUid}_pin_v1`
  });

  await setDocById('academic_years', 'ay_2026', {
    branchId: 'main',
    nameBn: '১৪৪৭-৪৮ হি. / ২০২৬-২৭',
    startDate: '2026-01-01',
    endDate: '2026-12-31',
    isCurrent: true
  });

  const depts = [
    { id: 'dept_maktab', nameBn: 'মক্তব ও নাজেরা', order: 1 },
    { id: 'dept_hifz', nameBn: 'হিফজুল কুরআন', order: 2 },
    { id: 'dept_kitab', nameBn: 'কিতাব বিভাগ', order: 3 }
  ];
  for (const d of depts) {
    await setDocById('departments', d.id, { branchId: 'main', ...d, isDeleted: false });
  }

  const jamats = [
    { id: 'jmt_nazera', departmentId: 'dept_maktab', nameBn: 'নাজেরা', monthlyFeeDefault: 800, order: 1 },
    { id: 'jmt_hifz', departmentId: 'dept_hifz', nameBn: 'হিফজ', monthlyFeeDefault: 1200, order: 2 },
    { id: 'jmt_mizan', departmentId: 'dept_kitab', nameBn: 'মিযান', monthlyFeeDefault: 1500, order: 3 },
    { id: 'jmt_hidaya', departmentId: 'dept_kitab', nameBn: 'হেদায়াতুন্নাহু', monthlyFeeDefault: 1500, order: 4 }
  ];
  for (const j of jamats) {
    await setDocById('jamats', j.id, { branchId: 'main', ...j, isDeleted: false });
  }

  // শরিয়াহ তহবিল ও অ্যাকাউন্ট
  const funds = [
    { id: 'fund_general', code: 'general', nameBn: 'সাধারণ তহবিল', zakatRestricted: false, currentBalance: 45000 },
    { id: 'fund_zakat', code: 'zakat', nameBn: 'যাকাত তহবিল', zakatRestricted: true, currentBalance: 32000 },
    { id: 'fund_sadaqah', code: 'sadaqah', nameBn: 'সদকা ও ফিতরা তহবিল', zakatRestricted: true, currentBalance: 14500 },
    { id: 'fund_lillah', code: 'lillah', nameBn: 'লিল্লাহ বোর্ডিং তহবিল', zakatRestricted: true, currentBalance: 22000 }
  ];
  for (const f of funds) {
    await setDocById('funds', f.id, { branchId: 'main', ...f });
  }

  const accounts = [
    { id: 'acc_cash', type: 'cash', nameBn: 'অফিস ক্যাশ', accountNo: '', currentBalance: 63500 },
    { id: 'acc_bank', type: 'bank', nameBn: 'ইসলামী ব্যাংক অ্যাকাউন্ট', accountNo: '২০৫০-১২৩৪৫৬', currentBalance: 38000 },
    { id: 'acc_bkash', type: 'bkash', nameBn: 'মাদ্রাসা বিকাশ', accountNo: '01700-112233', currentBalance: 12000 }
  ];
  for (const a of accounts) {
    await setDocById('accounts', a.id, { branchId: 'main', ...a });
  }

  // ডেমো ছাত্র
  const students = [
    { id: 'stu_1', studentCode: 'STD-0001', rollNumber: 1, departmentId: 'dept_hifz', jamatId: 'jmt_hifz', nameBn: 'মুহাম্মদ তানভীর আহমদ', fatherName: 'মোঃ রফিকুল ইসলাম', guardianName: 'মোঃ রফিকুল ইসলাম', guardianPhone: '01711-223344', category: 'residential', monthlyFee: 1200, feeWaiverAmount: 0, status: 'active' },
    { id: 'stu_2', studentCode: 'STD-0002', rollNumber: 2, departmentId: 'dept_hifz', jamatId: 'jmt_hifz', nameBn: 'আব্দুল্লাহ আল মামুন', fatherName: 'মরহুম জয়নাল আবেদীন', guardianName: 'রহিমা খাতুন', guardianPhone: '01812-334455', category: 'orphan', monthlyFee: 1200, feeWaiverAmount: 1200, feeWaiverReason: 'এতিম ছাত্র — সম্পূর্ণ মওকুফ', status: 'active' },
    { id: 'stu_3', studentCode: 'STD-0003', rollNumber: 1, departmentId: 'dept_kitab', jamatId: 'jmt_mizan', nameBn: 'সাইফুল ইসলাম', fatherName: 'হাফেজ নুরুল হক', guardianName: 'হাফেজ নুরুল হক', guardianPhone: '01913-445566', category: 'lillah_boarding', monthlyFee: 1500, feeWaiverAmount: 1000, feeWaiverReason: 'লিল্লাহ বোর্ডিং সহায়তা', status: 'active' },
    { id: 'stu_4', studentCode: 'STD-0004', rollNumber: 1, departmentId: 'dept_maktab', jamatId: 'jmt_nazera', nameBn: 'মাহমুদুল হাসান', fatherName: 'মোঃ কামাল উদ্দিন', guardianName: 'মোঃ কামাল উদ্দিন', guardianPhone: '01614-556677', category: 'non_residential', monthlyFee: 800, feeWaiverAmount: 0, status: 'active' }
  ];
  for (const s of students) {
    await setDocById('students', s.id, {
      branchId: 'main',
      academicYearId: 'ay_2026',
      presentAddress: 'ঢাকা',
      isDeleted: false,
      ...s
    });
  }

  // আজকের ডেমো হাজিরা
  await setDocById('attendance', `main_student_${today}_stu_1`, { branchId: 'main', type: 'student', date: today, hijriDate: hijri, targetId: 'stu_1', jamatId: 'jmt_hifz', status: 'present', markedBy: adminUid });
  await setDocById('attendance', `main_student_${today}_stu_2`, { branchId: 'main', type: 'student', date: today, hijriDate: hijri, targetId: 'stu_2', jamatId: 'jmt_hifz', status: 'present', markedBy: adminUid });
  await setDocById('attendance', `main_student_${today}_stu_3`, { branchId: 'main', type: 'student', date: today, hijriDate: hijri, targetId: 'stu_3', jamatId: 'jmt_mizan', status: 'absent', markedBy: adminUid });
  await setDocById('attendance', `main_student_${today}_stu_4`, { branchId: 'main', type: 'student', date: today, hijriDate: hijri, targetId: 'stu_4', jamatId: 'jmt_nazera', status: 'present', markedBy: adminUid });

  // ডেমো ফি ইনভয়েস
  await setDocById('fee_invoices', `inv_${month}_stu_1`, {
    branchId: 'main', studentId: 'stu_1', academicYearId: 'ay_2026', jamatId: 'jmt_hifz',
    billingMonth: month, feeType: 'monthly', grossAmount: 1200, waiverAmount: 0, netAmount: 1200,
    paidAmount: 1200, dueAmount: 0, status: 'paid', transactionIds: ['tx_demo_1']
  });
  await setDocById('fee_invoices', `inv_${month}_stu_3`, {
    branchId: 'main', studentId: 'stu_3', academicYearId: 'ay_2026', jamatId: 'jmt_mizan',
    billingMonth: month, feeType: 'monthly', grossAmount: 1500, waiverAmount: 1000, netAmount: 500,
    paidAmount: 0, dueAmount: 500, status: 'unpaid', transactionIds: []
  });
  await setDocById('fee_invoices', `inv_${month}_stu_4`, {
    branchId: 'main', studentId: 'stu_4', academicYearId: 'ay_2026', jamatId: 'jmt_nazera',
    billingMonth: month, feeType: 'monthly', grossAmount: 800, waiverAmount: 0, netAmount: 800,
    paidAmount: 400, dueAmount: 400, status: 'partial', transactionIds: []
  });

  // ডেমো দাতা ও লেনদেন
  await setDocById('donors', 'dnr_1', {
    branchId: 'main', nameBn: 'আলহাজ্ব মোহাম্মদ ইউসুফ', phone: '01715-889900',
    address: 'ধানমন্ডি, ঢাকা', donorType: 'regular', pledgedAmount: 5000, pledgeFrequency: 'monthly', isDeleted: false
  });

  await setDocById('transactions', 'tx_demo_1', {
    branchId: 'main', receiptNo: 'RCP-2026-0001', date: today, hijriDate: hijri,
    type: 'income', category: 'student_fee', fundId: 'fund_general', accountId: 'acc_cash',
    amount: 1200, description: 'মাসিক বেতন — মুহাম্মদ তানভীর আহমদ', studentId: 'stu_1',
    status: 'posted', approvalStatus: 'auto_approved', verifyCode: 'VRF-2026-0001', createdBy: adminUid
  });

  await setDocById('transactions', 'tx_demo_2', {
    branchId: 'main', receiptNo: 'RCP-2026-0002', date: today, hijriDate: hijri,
    type: 'income', category: 'zakat', fundId: 'fund_zakat', accountId: 'acc_bank',
    amount: 15000, description: 'যাকাত দান — আলহাজ্ব মোহাম্মদ ইউসুফ', donorId: 'dnr_1',
    status: 'posted', approvalStatus: 'auto_approved', verifyCode: 'VRF-2026-0002', createdBy: adminUid
  });

  await setDocById('transactions', 'tx_demo_3', {
    branchId: 'main', receiptNo: 'VCH-2026-0001', date: today, hijriDate: hijri,
    type: 'expense', category: 'food', fundId: 'fund_lillah', accountId: 'acc_cash',
    amount: 4200, description: 'লিল্লাহ বোর্ডিং বাজার খরচ',
    status: 'posted', approvalStatus: 'auto_approved', verifyCode: 'VRF-2026-0003', createdBy: adminUid
  });

  await setDocById('public_verifications', 'VRF-2026-0001', {
    docType: 'receipt', serialNo: 'RCP-2026-0001', holderName: 'মুহাম্মদ তানভীর আহমদ',
    amount: 1200, issuedDate: today, status: 'valid'
  });
  await setDocById('public_verifications', 'VRF-2026-0002', {
    docType: 'receipt', serialNo: 'RCP-2026-0002', holderName: 'আলহাজ্ব মোহাম্মদ ইউসুফ',
    amount: 15000, issuedDate: today, status: 'valid'
  });

  await setDocById('counters', 'receipt_2026', { branchId: 'main', prefix: 'RCP-2026-', lastNumber: 2 });
  await setDocById('counters', 'voucher_2026', { branchId: 'main', prefix: 'VCH-2026-', lastNumber: 1 });
  await setDocById('counters', 'student_code', { branchId: 'main', prefix: 'STD-', lastNumber: 4 });

  await addDocItem('audit_logs', {
    branchId: 'main', actorId: adminUid, actorName: 'সিস্টেম', actorRole: 'muhtamim',
    action: 'SEED_DEMO', collection: 'settings', docId: 'institution', summary: 'ডেমো ট্রেনিং ডেটা তৈরি করা হয়েছে'
  });


  // ফেজ ২ ডেমো ডেটা: ওস্তাদ, বেতন, ঋণ, পরীক্ষা ও নোটিশ
  await setDocById('staff', 'stf_demo_1', {
    branchId: 'main', staffCode: 'STF-0001', nameBn: 'হাফেজ মাওলানা ইউসুফ', designation: 'প্রধান হিফজ শিক্ষক',
    phone: '01720-112233', joiningDate: '2024-01-01', baseSalary: 15000, allowances: 1000, status: 'active', isDeleted: false
  });
  await setDocById('staff', 'stf_demo_2', {
    branchId: 'main', staffCode: 'STF-0002', nameBn: 'মাওলানা শফিকুল ইসলাম', designation: 'কিতাব বিভাগীয় ওস্তাদ',
    phone: '01821-445566', joiningDate: '2025-02-01', baseSalary: 13000, allowances: 500, status: 'active', isDeleted: false
  });
  await setDocById('payroll', `pay_${month}_stf_demo_1`, {
    branchId: 'main', staffId: 'stf_demo_1', month, baseSalary: 15000, bonus: 1000, advanceDeduction: 0, netAmount: 16000, paidAmount: 0, status: 'unpaid'
  });
  await setDocById('loans', 'ln_demo_1', {
    branchId: 'main', direction: 'payable', partyName: 'হাজী নুর মোহাম্মদ (করজে হাসানা)', partyPhone: '01755-667788',
    principalAmount: 50000, paidAmount: 20000, remainingAmount: 30000, dueDate: '2026-12-31', note: 'ভবন সংস্কার বাবদ', installments: [], status: 'active', createdBy: adminUid
  });
  await setDocById('exams', 'ex_demo_1', {
    branchId: 'main', titleBn: '১ম সাময়িক পরীক্ষা ২০২৬', jamatId: 'jmt_hifz', startDate: today,
    gradingSystem: 'qawmi_befaq', subjects: ['হিফজ তিলাওয়াত', 'তাজবীদ', 'মাসআলা ও আদব']
  });
  await setDocById('notices', 'nt_demo_1', {
    branchId: 'main', title: '১ম সাময়িক পরীক্ষার প্রবেশপত্র সংগ্রহ', body: 'আগামী সপ্তাহ থেকে সাময়িক পরীক্ষা শুরু হবে। সকল ছাত্রকে অফিস থেকে প্রবেশপত্র সংগ্রহের নির্দেশ দেওয়া হলো।',
    audience: 'all', priority: 'urgent', date: today, createdBy: adminUid
  });
  await setDocById('counters', 'staff_code', { branchId: 'main', prefix: 'STF-', lastNumber: 2 });


  // ফেজ ৩ ডেমো ডেটা: অনুষ্ঠান, হিফজ লগ, রুটিন, হোস্টেল, স্টক ও লাইব্রেরি
  await setDocById('events', 'ev_demo_1', {
    branchId: 'main', titleBn: 'বার্ষিক ওয়াজ মাহফিল ও দস্তারবন্দি ২০২৬', eventType: 'দস্তারবন্দি', eventDate: '2026-12-18',
    budget: 80000, collectedAmount: 45000, spentAmount: 18000, speakers: 'হযরত মাওলানা নুরুল ইসলাম, মুফতি আব্দুল্লাহ',
    committee: 'মাহফিল বাস্তবায়ন কমিটি', status: 'upcoming',
    tasks: [{ label: 'প্যান্ডেল বুকিং সম্পন্ন', done: true }, { label: 'পোস্টার ছাপানো', done: false }]
  });
  await setDocById('hifz_logs', 'hz_demo_1', {
    branchId: 'main', studentId: 'stu_1', date: today, paraNo: 12,
    sabaq: 'সূরা ইউসুফ ২ পৃষ্ঠা', sabqi: '১২ পৃষ্ঠা', amokhta: '১ পারা (পারা ১১)', quality: 'উত্তম', ustadNote: 'তাজবীদ সুন্দর'
  });
  await setDocById('routines', 'rt_demo_1', {
    branchId: 'main', day: 'শনিবার', timeSlot: '০৮:০০ - ০৯:৩০', jamatId: 'jmt_hifz', subject: 'সবক ও সবকি শুনানি', staffId: 'stf_demo_1'
  });
  await setDocById('holidays', 'hl_demo_1', {
    branchId: 'main', titleBn: 'বার্ষিক শবে বরাত ছুটি', startDate: '2026-02-15', endDate: '2026-02-15', hijriDate: '১৫ শাবান ১৪৪৭ হি.', category: 'ধর্মীয় ছুটি'
  });
  await setDocById('hostel_rooms', 'rm_demo_1', { branchId: 'main', roomNo: '১০১', building: 'মূল আবাসিক ভবন', capacity: 16, occupied: 14 });
  await setDocById('inventory', 'inv_rice', { branchId: 'main', nameBn: 'চাল (মিনিকেট)', quantity: 8, unit: 'বস্তা', minLevel: 10 });
  await setDocById('assets', 'as_gen', { branchId: 'main', nameBn: 'সোলার ইনভার্টার ও ব্যাটারি', quantity: 2, value: 65000, location: 'অফিস কক্ষ', condition: 'ভালো' });
  await setDocById('library_books', 'bk_bukhari', { branchId: 'main', titleBn: 'সহীহ বুখারী শরীফ (১ম খণ্ড)', author: 'ইমাম বুখারী (রহ.)', totalCopies: 6, availableCopies: 5 });

  return adminUid;
}
