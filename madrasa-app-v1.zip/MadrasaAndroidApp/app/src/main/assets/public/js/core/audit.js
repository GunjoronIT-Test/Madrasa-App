import { addDocItem } from './store.js';
import { getCurrentUser } from './auth.js';

export async function logAudit({ action, collection, docId, summary }) {
  const user = getCurrentUser();
  if (!user) return;
  await addDocItem('audit_logs', {
    branchId: user.branchId === 'all' ? 'main' : (user.branchId || 'main'),
    actorId: user.uid,
    actorName: user.name || user.email || 'অজানা',
    actorRole: user.role || 'unknown',
    action,
    collection,
    docId: docId || '',
    summary: summary || ''
  });
}
