import { listCollection, addDocItem, setDocById, nextSerial, getDocById } from '../core/store.js';
import { getBrand } from '../core/brand.js';
import { getCurrentUser, hasAnyRole, requirePinConfirmation } from '../core/auth.js';
import { logAudit } from '../core/audit.js';
import { navigate } from '../core/router.js';
import { icon } from '../core/icons.js';
import { todayISO, getHijriDateString, formatCurrency, escapeHtml, openModal, closeModal, showToast, readFileAsDataUrl } from '../core/utils.js';

const INCOME_CATEGORIES = [
  { code: 'student_fee', label: 'ছাত্র ফি' },
  { code: 'general_donation', label: 'সাধারণ দান' },
  { code: 'zakat', label: 'যাকাত' },
  { code: 'sadaqah', label: 'সদকা' },
  { code: 'fitra', label: 'ফিতরা' },
  { code: 'qurbani_skin', label: 'কুরবানীর চামড়া' },
  { code: 'mahfil', label: 'মাহফিল দান' },
  { code: 'other_income', label: 'অন্যান্য আয়' }
];

const EXPENSE_CATEGORIES = [
  { code: 'food', label: 'লিল্লাহ খাবার ও বাজার', zakatEligible: true },
  { code: 'orphan_support', label: 'এতিম/গরিব ছাত্র সহায়তা', zakatEligible: true },
  { code: 'salary', label: 'ওস্তাদ ও স্টাফ বেতন', zakatEligible: false },
  { code: 'electricity', label: 'বিদ্যুৎ ও গ্যাস বিল', zakatEligible: false },
  { code: 'rent', label: 'ভবন ভাড়া', zakatEligible: false },
  { code: 'maintenance', label: 'মেরামত ও নির্মাণ', zakatEligible: false },
  { code: 'event', label: 'অনুষ্ঠান / মাহফিল খরচ', zakatEligible: false },
  { code: 'other_expense', label: 'অন্যান্য ব্যয়', zakatEligible: false }
];

let txFilterType = 'all';

export async function renderFinance(container) {
  const [funds, accounts, transactions] = await Promise.all([
    listCollection('funds'),
    listCollection('accounts'),
    listCollection('transactions')
  ]);

  const fundMap = Object.fromEntries(funds.map((f) => [f.id, f]));
  const accMap = Object.fromEntries(accounts.map((a) => [a.id, a]));
  const sorted = transactions
    .filter((t) => txFilterType === 'all' || t.type === txFilterType)
    .sort((a, b) => String(b.createdAt || b.date).localeCompare(String(a.createdAt || a.date)));

  container.innerHTML = `
    <div class="page-header">
      <div>
        <h1>আয়-ব্যয় ও শরিয়াহ হিসাব</h1>
        <p class="page-subtitle">অপরিবর্তনীয় লেজার (ভুল হলে PIN দিয়ে বাতিল এন্ট্রি হবে)</p>
      </div>
      <div style="display:flex;gap:8px;">
        <button type="button" class="btn btn-primary btn-sm" id="fin-add-inc">${icon('plus', 'sm')} আয় এন্ট্রি</button>
        <button type="button" class="btn btn-secondary btn-sm" id="fin-add-exp">${icon('plus', 'sm')} ব্যয় এন্ট্রি</button>
      </div>
    </div>

    <div class="kpi-grid">
      ${accounts.map((a) => `
        <div class="card" style="padding:12px;">
          <div class="form-hint">${escapeHtml(a.nameBn)}</div>
          <div style="font-size:1.125rem;font-weight:700;margin-top:4px;">${formatCurrency(a.currentBalance)}</div>
        </div>
      `).join('')}
    </div>

    <div class="tabs">
      <button type="button" class="tab-btn ${txFilterType === 'all' ? 'active' : ''}" data-type="all">সকল লেনদেন</button>
      <button type="button" class="tab-btn ${txFilterType === 'income' ? 'active' : ''}" data-type="income">আয়</button>
      <button type="button" class="tab-btn ${txFilterType === 'expense' ? 'active' : ''}" data-type="expense">ব্যয়</button>
      <button type="button" class="tab-btn ${txFilterType === 'reversal' ? 'active' : ''}" data-type="reversal">বাতিল (Reversal)</button>
    </div>

    <div class="list-stack">
      ${sorted.length === 0 ? `<div class="card empty-state"><p>কোনো লেনদেন পাওয়া যায়নি।</p></div>` : sorted.map((t) => {
        const isInc = t.type === 'income';
        const isRev = t.type === 'reversal';
        const amountCls = isInc ? 'text-success' : isRev ? 'text-muted' : 'text-danger';
        return `
          <div class="list-item" style="flex-wrap:wrap;">
            <div class="list-item-main">
              <div class="list-item-title">
                ${escapeHtml(t.description || t.category)}
                ${t.status === 'reversed' ? `<span class="badge badge-danger">বাতিলকৃত</span>` : ''}
                ${t.approvalStatus === 'pending_approval' ? `<span class="badge badge-warning">অনুমোদন বাকি</span>` : ''}
              </div>
              <div class="list-item-sub">
                ${escapeHtml(t.receiptNo || '')} | ${escapeHtml(t.date)} |
                তহবিল: ${escapeHtml(fundMap[t.fundId]?.nameBn || '-')} |
                অ্যাকাউন্ট: ${escapeHtml(accMap[t.accountId]?.nameBn || '-')}
              </div>
            </div>
            <div class="list-item-actions">
              <strong class="${amountCls}">${isInc ? '+' : isRev ? '' : '-'}${formatCurrency(t.amount)}</strong>
              ${t.approvalStatus === 'pending_approval' && hasAnyRole(['muhtamim', 'nayeb_muhtamim'])
                ? `<button type="button" class="btn btn-primary btn-sm" data-approve="${t.id}">অনুমোদন</button>` : ''}
              ${isInc && t.status === 'posted'
                ? `<button type="button" class="btn btn-outline btn-sm" data-rcp="${t.id}">রিসিট</button>` : ''}
              ${t.status === 'posted' && !isRev
                ? `<button type="button" class="btn btn-secondary btn-sm" data-reverse="${t.id}">বাতিল</button>` : ''}
            </div>
          </div>
        `;
      }).join('')}
    </div>
  `;

  container.querySelectorAll('.tab-btn').forEach((b) => {
    b.onclick = () => {
      txFilterType = b.dataset.type;
      renderFinance(container);
    };
  });

  container.querySelectorAll('[data-rcp]').forEach((b) => {
    b.onclick = () => navigate(`/receipt/${b.dataset.rcp}`);
  });

  container.querySelectorAll('[data-approve]').forEach((b) => {
    b.onclick = async () => {
      const txId = b.dataset.approve;
      await setDocById('transactions', txId, {
        approvalStatus: 'approved',
        approvedBy: getCurrentUser()?.uid || 'admin',
        approvedAt: new Date().toISOString()
      }, true);
      await logAudit({ action: 'APPROVE_EXPENSE', collection: 'transactions', docId: txId, summary: 'সীমাতিরিক্ত ব্যয় অনুমোদন' });
      showToast('ব্যয় অনুমোদিত হয়েছে', 'success');
      renderFinance(container);
    };
  });

  container.querySelectorAll('[data-reverse]').forEach((b) => {
    b.onclick = async () => {
      const orig = transactions.find((x) => x.id === b.dataset.reverse);
      if (!orig) return;
      const ok = await requirePinConfirmation(`"${orig.description}" (${formatCurrency(orig.amount)}) বাতিল (Reversal) করতে PIN দিন।`);
      if (!ok) return;

      const revTx = await addDocItem('transactions', {
        branchId: 'main',
        receiptNo: `REV-${orig.receiptNo || orig.id.slice(-4)}`,
        date: todayISO(),
        hijriDate: getHijriDateString(new Date()),
        type: 'reversal',
        category: orig.category,
        fundId: orig.fundId,
        accountId: orig.accountId,
        amount: orig.amount,
        description: `বাতিল (Reversal): ${orig.description}`,
        reversalOfTxId: orig.id,
        status: 'posted',
        approvalStatus: 'auto_approved',
        createdBy: getCurrentUser()?.uid || 'system'
      });

      await setDocById('transactions', orig.id, { status: 'reversed', reversalTxId: revTx.id }, true);

      const delta = orig.type === 'income' ? -Number(orig.amount) : Number(orig.amount);
      const fund = await getDocById('funds', orig.fundId);
      if (fund) await setDocById('funds', orig.fundId, { currentBalance: Number(fund.currentBalance || 0) + delta }, true);
      const acc = await getDocById('accounts', orig.accountId);
      if (acc) await setDocById('accounts', orig.accountId, { currentBalance: Number(acc.currentBalance || 0) + delta }, true);

      if (orig.verifyCode) {
        await setDocById('public_verifications', orig.verifyCode, { status: 'revoked' }, true);
      }

      await logAudit({ action: 'REVERSE_TX', collection: 'transactions', docId: orig.id, summary: `লেনদেন বাতিল (Reversal): ${orig.receiptNo}` });
      showToast('লেনদেন বাতিল করে রিভার্সাল এন্ট্রি যুক্ত হয়েছে', 'warning');
      renderFinance(container);
    };
  });

  function openTxModal(type) {
    const isInc = type === 'income';
    const cats = isInc ? INCOME_CATEGORIES : EXPENSE_CATEGORIES;
    let voucherDataUrl = '';

    openModal({
      title: isInc ? 'নতুন আয় এন্ট্রি' : 'নতুন ব্যয় এন্ট্রি',
      bodyHtml: `
        <div class="form-grid">
          <div class="form-group">
            <label class="form-label">খাত *</label>
            <select id="tx-cat" class="form-control">
              ${cats.map((c) => `<option value="${c.code}" data-zakat="${c.zakatEligible ? '1' : '0'}">${c.label}</option>`).join('')}
            </select>
          </div>
          <div class="form-group">
            <label class="form-label">তহবিল *</label>
            <select id="tx-fund" class="form-control">
              ${funds.map((f) => `<option value="${f.id}" data-restricted="${f.zakatRestricted ? '1' : '0'}">${escapeHtml(f.nameBn)} (${formatCurrency(f.currentBalance)})</option>`).join('')}
            </select>
          </div>
          <div id="shariah-warn-box" class="alert-box alert-danger" hidden>
            ${icon('alert', 'sm')}
            <span>শরিয়াহ সতর্কতা: নির্বাচিত তহবিলটি যাকাত/সদকা-নির্ধারিত। এই খাতে ব্যয়ের আগে মুফতি সাহেবের সাথে নিশ্চিত হয়ে নিন।</span>
          </div>
          <div class="form-group">
            <label class="form-label">অ্যাকাউন্ট *</label>
            <select id="tx-acc" class="form-control">
              ${accounts.map((a) => `<option value="${a.id}">${escapeHtml(a.nameBn)}</option>`).join('')}
            </select>
          </div>
          <div class="form-group">
            <label class="form-label">টাকার পরিমাণ *</label>
            <input id="tx-amt" class="form-control" type="number" min="1" required placeholder="0">
          </div>
          <div class="form-group">
            <label class="form-label">বিবরণ *</label>
            <input id="tx-desc" class="form-control" required placeholder="সংক্ষিপ্ত বিবরণ লিখুন">
          </div>
          ${!isInc ? `
            <div class="form-group">
              <label class="form-label">ভাউচার / বিলের ছবি (ঐচ্ছিক)</label>
              <input id="tx-voucher" class="form-control" type="file" accept="image/*">
            </div>
          ` : ''}
        </div>
      `,
      footerHtml: `
        <button type="button" class="btn btn-secondary" id="tx-cancel">বাতিল</button>
        <button type="button" class="btn btn-primary" id="tx-save">সংরক্ষণ করুন</button>
      `
    });

    function checkShariahGuardrail() {
      if (isInc) return;
      const catOpt = document.getElementById('tx-cat').selectedOptions[0];
      const fundOpt = document.getElementById('tx-fund').selectedOptions[0];
      const isRestricted = fundOpt?.dataset.restricted === '1';
      const isEligible = catOpt?.dataset.zakat === '1';
      document.getElementById('shariah-warn-box').hidden = !(isRestricted && !isEligible);
    }

    document.getElementById('tx-cat').onchange = checkShariahGuardrail;
    document.getElementById('tx-fund').onchange = checkShariahGuardrail;
    checkShariahGuardrail();

    document.getElementById('tx-voucher')?.addEventListener('change', async (e) => {
      try {
        voucherDataUrl = await readFileAsDataUrl(e.target.files[0], 1024 * 1024);
      } catch (err) {
        showToast(err.message, 'error');
      }
    });

    document.getElementById('tx-cancel').onclick = closeModal;
    document.getElementById('tx-save').onclick = async () => {
      const amount = Number(document.getElementById('tx-amt').value || 0);
      const description = document.getElementById('tx-desc').value.trim();
      const category = document.getElementById('tx-cat').value;
      const fundId = document.getElementById('tx-fund').value;
      const accountId = document.getElementById('tx-acc').value;

      if (amount <= 0 || !description) {
        showToast('টাকার পরিমাণ ও বিবরণ সঠিকভাবে দিন', 'warning');
        return;
      }

      const year = new Date().getFullYear();
      const prefix = isInc ? `RCP-${year}-` : `VCH-${year}-`;
      const counterKey = isInc ? `receipt_${year}` : `voucher_${year}`;
      const receiptNo = await nextSerial(counterKey, prefix);
      const verifyCode = `VRF-${year}-${receiptNo.slice(-4)}`;

      const limit = Number(getBrand()?.expenseApprovalLimit || 10000);
      const needsApproval = !isInc && amount > limit && !hasAnyRole(['muhtamim']);

      const tx = await addDocItem('transactions', {
        branchId: 'main',
        receiptNo,
        date: todayISO(),
        hijriDate: getHijriDateString(new Date()),
        type,
        category,
        fundId,
        accountId,
        amount,
        description,
        voucherUrl: voucherDataUrl,
        status: 'posted',
        approvalStatus: needsApproval ? 'pending_approval' : 'auto_approved',
        verifyCode,
        createdBy: getCurrentUser()?.uid || 'system'
      });

      const delta = isInc ? amount : -amount;
      const fund = await getDocById('funds', fundId);
      if (fund) await setDocById('funds', fundId, { currentBalance: Number(fund.currentBalance || 0) + delta }, true);
      const acc = await getDocById('accounts', accountId);
      if (acc) await setDocById('accounts', accountId, { currentBalance: Number(acc.currentBalance || 0) + delta }, true);

      if (isInc) {
        await setDocById('public_verifications', verifyCode, {
          docType: 'receipt',
          serialNo: receiptNo,
          holderName: description,
          amount,
          issuedDate: todayISO(),
          status: 'valid'
        });
      }

      await logAudit({ action: isInc ? 'ADD_INCOME' : 'ADD_EXPENSE', collection: 'transactions', docId: tx.id, summary: `${description} (${amount} টাকা)` });
      closeModal();
      showToast(needsApproval ? 'ব্যয় সংরক্ষিত — মুহতামিমের অনুমোদনের অপেক্ষায়' : 'লেনদেন সংরক্ষিত হয়েছে', 'success');
      if (isInc) navigate(`/receipt/${tx.id}`);
      else renderFinance(container);
    };
  }

  document.getElementById('fin-add-inc').onclick = () => openTxModal('income');
  document.getElementById('fin-add-exp').onclick = () => openTxModal('expense');
}
