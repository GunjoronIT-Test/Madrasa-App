import { getBrand, loadAndApplyBrand } from '../core/brand.js';
import { loginWithCredentials } from '../core/auth.js';
import { seedDemoData } from '../core/demo-data.js';
import { icon } from '../core/icons.js';
import { showToast, escapeHtml } from '../core/utils.js';

export async function renderLogin(container, _route, onSuccess) {
  const brand = getBrand();
  const name = brand?.nameBn || 'মাদ্রাসা ম্যানেজমেন্ট সিস্টেম';
  const slogan = brand?.slogan || 'ডিজিটাল মাদ্রাসা ব্যবস্থাপনা';

  container.innerHTML = `
    <div class="auth-wrap">
      <div class="card">
        <div style="text-align:center;margin-bottom:20px;">
          <div class="header-logo-wrap" style="width:56px;height:56px;margin:0 auto 12px;">
            ${brand?.logoUrl ? `<img src="${brand.logoUrl}" alt="${escapeHtml(name)}">` : icon('book', 'lg')}
          </div>
          <h1>${escapeHtml(name)}</h1>
          <p class="page-subtitle">${escapeHtml(slogan)}</p>
        </div>

        <form id="login-form" class="form-grid">
          <div class="form-group">
            <label class="form-label" for="login-email">ইমেইল</label>
            <input id="login-email" class="form-control" type="email" required placeholder="admin@madrasa.demo" value="${brand?.demoMode ? 'admin@madrasa.demo' : ''}">
          </div>
          <div class="form-group">
            <label class="form-label" for="login-password">পাসওয়ার্ড</label>
            <input id="login-password" class="form-control" type="password" required placeholder="******" value="${brand?.demoMode ? '123456' : ''}">
          </div>
          <button type="submit" class="btn btn-primary btn-block">${icon('shield', 'sm')} লগইন করুন</button>
        </form>

        ${brand?.demoMode ? `
          <div class="alert-box alert-info" style="margin-top:16px;">
            ${icon('alert', 'sm')}
            <span>ডেমো লগইন: <strong>admin@madrasa.demo</strong> | পাসওয়ার্ড: <strong>123456</strong> | PIN: <strong>1234</strong></span>
          </div>
        ` : `
          <div style="margin-top:16px;text-align:center;">
            <button type="button" id="btn-start-demo" class="btn btn-outline btn-sm">ডেমো ডেটা দিয়ে পরীক্ষা করুন</button>
          </div>
        `}
      </div>
    </div>
  `;

  document.getElementById('login-form').onsubmit = async (e) => {
    e.preventDefault();
    const email = document.getElementById('login-email').value;
    const pass = document.getElementById('login-password').value;
    try {
      await loginWithCredentials(email, pass);
      showToast('সফলভাবে লগইন হয়েছে', 'success');
      if (onSuccess) onSuccess();
    } catch (err) {
      showToast(err.message || 'লগইন ব্যর্থ হয়েছে', 'error');
    }
  };

  document.getElementById('btn-start-demo')?.addEventListener('click', async () => {
    const uid = await seedDemoData();
    localStorage.setItem('madrasa_session_uid', uid);
    await loadAndApplyBrand();
    showToast('ডেমো মোড চালু হয়েছে', 'success');
    if (onSuccess) onSuccess();
  });
}
