import { getDocById } from '../core/store.js';
import { getBrand } from '../core/brand.js';
import { generateQrSvg } from '../core/qr.js';
import { navigate } from '../core/router.js';
import { icon } from '../core/icons.js';
import { formatCurrency, escapeHtml } from '../core/utils.js';

export async function renderReceipt(container, route) {
  const txId = route.param;
  const tx = txId ? await getDocById('transactions', txId) : null;
  if (!tx) {
    container.innerHTML = `<div class="card empty-state"><p>রিসিট পাওয়া যায়নি।</p></div>`;
    return;
  }

  const brand = getBrand() || {};
  const [fund, acc] = await Promise.all([
    tx.fundId ? getDocById('funds', tx.fundId) : null,
    tx.accountId ? getDocById('accounts', tx.accountId) : null
  ]);

  const verifyCode = tx.verifyCode || tx.receiptNo || tx.id;
  const verifyPayload = `${window.location.origin}${window.location.pathname}#/verify/${verifyCode}`;
  const qrSvg = generateQrSvg(verifyPayload, 108);

  container.innerHTML = `
    <div class="page-header no-print">
      <div>
        <h1>ডিজিটাল রিসিট</h1>
        <p class="page-subtitle">সিরিয়াল: ${escapeHtml(tx.receiptNo || tx.id)}</p>
      </div>
      <div style="display:flex;gap:8px;">
        <button type="button" class="btn btn-secondary btn-sm" id="rcp-verify-btn">${icon('qr', 'sm')} যাচাই দেখুন</button>
        <button type="button" class="btn btn-primary btn-sm" id="rcp-print-btn">${icon('print', 'sm')} প্রিন্ট / PDF</button>
      </div>
    </div>

    <article class="receipt-paper">
      <div class="receipt-head">
        <div style="display:flex;align-items:center;gap:12px;">
          <div class="header-logo-wrap" style="width:48px;height:48px;">
            ${brand.logoUrl ? `<img src="${brand.logoUrl}" alt="লোগো">` : icon('book', 'md')}
          </div>
          <div>
            <h2 style="font-size:1.2rem;">${escapeHtml(brand.nameBn || 'মাদ্রাসা')}</h2>
            <div style="font-size:0.8rem;color:#485B54;">${escapeHtml(brand.address || '')} | ফোন: ${escapeHtml(brand.phone || '')}</div>
          </div>
        </div>
        <span class="badge ${tx.status === 'reversed' ? 'badge-danger' : 'badge-success'}">
          ${tx.status === 'reversed' ? 'বাতিলকৃত' : 'আদায় রিসিট'}
        </span>
      </div>

      <div class="receipt-meta-grid">
        <div><strong>রিসিট নং:</strong> ${escapeHtml(tx.receiptNo || tx.id)}</div>
        <div><strong>তারিখ:</strong> ${escapeHtml(tx.date)} ${tx.hijriDate ? `(${escapeHtml(tx.hijriDate)})` : ''}</div>
        <div><strong>তহবিল:</strong> ${escapeHtml(fund?.nameBn || 'সাধারণ তহবিল')}</div>
        <div><strong>মাধ্যম:</strong> ${escapeHtml(acc?.nameBn || 'ক্যাশ')}</div>
      </div>

      <div style="margin-bottom:12px;">
        <strong>বিবরণ:</strong> ${escapeHtml(tx.description || '')}
      </div>

      <div class="receipt-amount-box">
        <span>গৃহীত মোট পরিমাণ</span>
        <strong style="font-size:1.35rem;">${formatCurrency(tx.amount)}</strong>
      </div>

      <div class="receipt-footer">
        <div style="display:flex;align-items:center;gap:10px;">
          <div>${qrSvg}</div>
          <div style="font-size:0.75rem;color:#485B54;">
            <div><strong>QR যাচাই কোড</strong></div>
            <div>${escapeHtml(verifyCode)}</div>
            <div>রিসিটটি ডিজিটালভাবে যাচাইযোগ্য</div>
          </div>
        </div>
        <div class="sig-line">
          ${escapeHtml(brand.muhtamimName || 'মুহতামিম / আদায়কারী')}
        </div>
      </div>
    </article>
  `;

  document.getElementById('rcp-print-btn').onclick = () => window.print();
  document.getElementById('rcp-verify-btn').onclick = () => navigate(`/verify/${verifyCode}`);
}
