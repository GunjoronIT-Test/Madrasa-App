import { initFirebaseIfConfigured } from './core/firebase.js';
import { loadIconSprite, icon } from './core/icons.js';
import { loadAndApplyBrand, getBrand } from './core/brand.js';
import { restoreSession, getCurrentUser } from './core/auth.js';
import { registerRoute, setRouteGuard, startRouter, navigate } from './core/router.js';
import { listCollection } from './core/store.js';
import { closeModal, openModal, escapeHtml, formatNum } from './core/utils.js';

import { renderSetupWizard } from './pages/setup-wizard.js';
import { renderLogin } from './pages/login.js';
import { renderDashboard } from './pages/dashboard.js';
import { renderStudents } from './pages/students.js';
import { renderAdmission } from './pages/admission.js';
import { renderAttendance } from './pages/attendance.js';
import { renderFees } from './pages/fees.js';
import { renderFinance } from './pages/finance.js';
import { renderDonations } from './pages/donations.js';
import { renderReceipt } from './pages/receipt.js';
import { renderVerify } from './pages/verify.js';
import { renderSettings } from './pages/settings.js';
import { renderStaff } from './pages/staff.js';
import { renderLoans } from './pages/loans.js';
import { renderExams } from './pages/exams.js';
import { renderNotices } from './pages/notices.js';
import { renderPosters } from './pages/posters.js';
import { renderReports } from './pages/reports.js';
import { renderEvents } from './pages/events.js';
import { renderHifz } from './pages/hifz.js';
import { renderCalendar } from './pages/calendar.js';
import { renderHostel } from './pages/hostel.js';
import { renderGuardianPortal } from './pages/guardian.js';
import { renderDocuments } from './pages/documents.js';
import { renderQrAttendance } from './pages/qr-attendance.js';
import { renderAnalytics } from './pages/analytics.js';
import { renderIntegrations } from './pages/integrations.js';

const BOTTOM_NAV_ITEMS = [
  { path: '/dashboard', label: 'ড্যাশবোর্ড', icon: 'dashboard' },
  { path: '/students', label: 'ছাত্র', icon: 'students' },
  { path: '/attendance', label: 'হাজিরা', icon: 'attendance' },
  { path: '/finance', label: 'হিসাব', icon: 'finance' },
  { path: '#more', label: 'আরও', icon: 'more' }
];

const MORE_ITEMS = [
  { path: '/admission', label: 'নতুন ভর্তি', icon: 'admission' },
  { path: '/qr-attendance', label: 'QR হাজিরা', icon: 'qr' },
  { path: '/fees', label: 'ছাত্র ফি ও বকেয়া', icon: 'receipt' },
  { path: '/donations', label: 'দান ও দাতা', icon: 'donation' },
  { path: '/staff', label: 'ওস্তাদ ও বেতন', icon: 'staff' },
  { path: '/loans', label: 'ঋণ ও পাওনা', icon: 'loan' },
  { path: '/exams', label: 'পরীক্ষা ও ফল', icon: 'exam' },
  { path: '/hifz', label: 'হিফজ অগ্রগতি', icon: 'book' },
  { path: '/events', label: 'মাহফিল ও অনুষ্ঠান', icon: 'calendar' },
  { path: '/calendar', label: 'রুটিন ও ছুটি', icon: 'calendar' },
  { path: '/hostel', label: 'হোস্টেল ও লাইব্রেরি', icon: 'book' },
  { path: '/documents', label: 'সনদ, TC ও আইডি', icon: 'qr' },
  { path: '/guardian', label: 'অভিভাবক পোর্টাল', icon: 'students' },
  { path: '/notices', label: 'নোটিশ বোর্ড', icon: 'bell' },
  { path: '/posters', label: 'পোস্টার মেকার', icon: 'poster' },
  { path: '/reports', label: 'রিপোর্ট ও এক্সপোর্ট', icon: 'report' },
  { path: '/analytics', label: 'বিশ্লেষণ ও শাখা', icon: 'report' },
  { path: '/integrations', label: 'SMS ও পেমেন্ট', icon: 'shield' },
  { path: '/settings', label: 'সেটিংস ও ব্যাকআপ', icon: 'settings' }
];

function renderBottomNav(activeBase) {
  const nav = document.getElementById('bottom-nav');
  if (!nav) return;
  nav.innerHTML = BOTTOM_NAV_ITEMS.map((item) => `
    <button type="button" class="nav-item ${activeBase === item.path ? 'active' : ''}" data-path="${item.path}">
      ${icon(item.icon, 'md')}
      <span>${item.label}</span>
    </button>
  `).join('');

  nav.querySelectorAll('.nav-item').forEach((btn) => {
    btn.onclick = () => {
      if (btn.dataset.path === '#more') openMoreDrawer();
      else navigate(btn.dataset.path);
    };
  });
}

function openMoreDrawer() {
  const drawer = document.getElementById('more-drawer');
  const grid = document.getElementById('more-drawer-grid');
  grid.innerHTML = MORE_ITEMS.map((item) => `
    <button type="button" class="more-tile" data-path="${item.path}">
      ${icon(item.icon, 'lg')}
      <span>${item.label}</span>
    </button>
  `).join('');
  grid.querySelectorAll('.more-tile').forEach((t) => {
    t.onclick = () => {
      drawer.hidden = true;
      navigate(t.dataset.path);
    };
  });
  drawer.hidden = false;
}

function updateChromeVisibility(basePath) {
  const isFullScreen = ['/setup', '/login', '/verify'].includes(basePath);
  document.getElementById('app-header').hidden = isFullScreen;
  document.getElementById('bottom-nav').hidden = isFullScreen;
  if (!isFullScreen) renderBottomNav(basePath);
}

async function openGlobalSearch() {
  const [students, staff, donors, txs] = await Promise.all([
    listCollection('students', (s) => !s.isDeleted),
    listCollection('staff', (s) => !s.isDeleted),
    listCollection('donors', (d) => !d.isDeleted),
    listCollection('transactions')
  ]);

  openModal({
    title: 'গ্লোবাল সার্চ',
    bodyHtml: `
      <input id="gs-input" class="form-control" type="search" placeholder="ছাত্র, ওস্তাদ, দাতা বা রিসিট নম্বর...">
      <div id="gs-results" class="list-stack" style="margin-top:12px;"></div>
    `
  });

  const input = document.getElementById('gs-input');
  const resultsEl = document.getElementById('gs-results');
  input.focus();

  input.oninput = () => {
    const q = input.value.trim().toLowerCase();
    if (!q) { resultsEl.innerHTML = ''; return; }
    const items = [];
    students.filter((s) => String(s.nameBn || '').toLowerCase().includes(q) || String(s.guardianPhone || '').includes(q))
      .slice(0, 4).forEach((s) => items.push({ title: s.nameBn, sub: `ছাত্র | রোল ${formatNum(s.rollNumber)}`, path: '/students' }));
    staff.filter((s) => String(s.nameBn || '').toLowerCase().includes(q))
      .slice(0, 3).forEach((s) => items.push({ title: s.nameBn, sub: `ওস্তাদ/স্টাফ | ${s.designation || ''}`, path: '/staff' }));
    donors.filter((d) => String(d.nameBn || '').toLowerCase().includes(q))
      .slice(0, 3).forEach((d) => items.push({ title: d.nameBn, sub: 'দাতা', path: '/donations' }));
    txs.filter((t) => String(t.receiptNo || '').toLowerCase().includes(q) || String(t.description || '').toLowerCase().includes(q))
      .slice(0, 3).forEach((t) => items.push({ title: t.receiptNo || t.description, sub: t.description, path: `/receipt/${t.id}` }));

    resultsEl.innerHTML = items.length === 0
      ? `<p class="text-muted">কোনো ফলাফল পাওয়া যায়নি।</p>`
      : items.map((it) => `
          <button type="button" class="list-item" style="width:100%;text-align:left;cursor:pointer;" data-go="${it.path}">
            <div class="list-item-main">
              <div class="list-item-title">${escapeHtml(it.title)}</div>
              <div class="list-item-sub">${escapeHtml(it.sub)}</div>
            </div>
          </button>
        `).join('');

    resultsEl.querySelectorAll('[data-go]').forEach((b) => {
      b.onclick = () => { closeModal(); navigate(b.dataset.go); };
    });
  };
}

async function bootstrap() {
  await loadIconSprite();
  await initFirebaseIfConfigured();
  await loadAndApplyBrand();
  await restoreSession();

  const offlineBanner = document.getElementById('offline-banner');
  const syncOnlineUi = () => { offlineBanner.hidden = navigator.onLine; };
  window.addEventListener('online', syncOnlineUi);
  window.addEventListener('offline', syncOnlineUi);
  syncOnlineUi();

  if ('serviceWorker' in navigator) {
    navigator.serviceWorker.register('./sw.js').catch(() => {});
  }

  document.getElementById('modal-close-btn').onclick = closeModal;
  document.getElementById('btn-close-drawer').onclick = () => { document.getElementById('more-drawer').hidden = true; };
  document.getElementById('more-drawer').onclick = (e) => { if (e.target.id === 'more-drawer') e.target.hidden = true; };
  document.getElementById('btn-user-menu').onclick = () => navigate('/settings');
  document.getElementById('btn-global-search').onclick = openGlobalSearch;

  registerRoute('/setup', renderSetupWizard);
  registerRoute('/login', (el, route) => renderLogin(el, route, () => navigate('/dashboard')));
  registerRoute('/dashboard', renderDashboard);
  registerRoute('/students', renderStudents);
  registerRoute('/admission', renderAdmission);
  registerRoute('/attendance', renderAttendance);
  registerRoute('/fees', renderFees);
  registerRoute('/finance', renderFinance);
  registerRoute('/donations', renderDonations);
  registerRoute('/receipt', renderReceipt);
  registerRoute('/verify', renderVerify);
  registerRoute('/settings', renderSettings);
  registerRoute('/staff', renderStaff);
  registerRoute('/loans', renderLoans);
  registerRoute('/exams', renderExams);
  registerRoute('/notices', renderNotices);
  registerRoute('/posters', renderPosters);
  registerRoute('/reports', renderReports);
  registerRoute('/events', renderEvents);
  registerRoute('/hifz', renderHifz);
  registerRoute('/calendar', renderCalendar);
  registerRoute('/hostel', renderHostel);
  registerRoute('/guardian', renderGuardianPortal);
  registerRoute('/documents', renderDocuments);
  registerRoute('/qr-attendance', renderQrAttendance);
  registerRoute('/analytics', renderAnalytics);
  registerRoute('/integrations', renderIntegrations);

  setRouteGuard(async (parsed) => {
    if (parsed.base === '/verify') { updateChromeVisibility('/verify'); return null; }
    const brand = getBrand();
    if (!brand?.setupCompleted) { updateChromeVisibility('/setup'); return parsed.base === '/setup' ? null : '/setup'; }
    const user = getCurrentUser();
    if (!user) { updateChromeVisibility('/login'); return parsed.base === '/login' ? null : '/login'; }
    if (parsed.base === '/login' || parsed.base === '/setup') { updateChromeVisibility('/dashboard'); return '/dashboard'; }
    updateChromeVisibility(parsed.base);
    return null;
  });

  startRouter();
}

bootstrap();
