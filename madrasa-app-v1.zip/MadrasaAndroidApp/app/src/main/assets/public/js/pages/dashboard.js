import { listCollection } from '../core/store.js';
import { navigate } from '../core/router.js';
import { icon } from '../core/icons.js';
import { formatNum, formatCurrency, todayISO, currentMonthISO, escapeHtml } from '../core/utils.js';

let activeRange = 'month';
let customFrom = todayISO();
let customTo = todayISO();

function inDateRange(isoDate) {
  if (!isoDate) return false;
  const today = todayISO();
  if (activeRange === 'today') return isoDate === today;
  if (activeRange === 'week') {
    const d = new Date();
    d.setDate(d.getDate() - 6);
    return isoDate >= d.toISOString().slice(0, 10) && isoDate <= today;
  }
  if (activeRange === 'month') return isoDate.slice(0, 7) === today.slice(0, 7);
  if (activeRange === 'year') return isoDate.slice(0, 4) === today.slice(0, 4);
  return isoDate >= customFrom && isoDate <= customTo;
}

export async function renderDashboard(container) {
  const [students, attendance, transactions, invoices, funds, payrolls, loans] = await Promise.all([
    listCollection('students', (s) => !s.isDeleted && s.status === 'active'),
    listCollection('attendance', (a) => a.type === 'student' && a.date === todayISO()),
    listCollection('transactions', (t) => t.status === 'posted'),
    listCollection('fee_invoices'),
    listCollection('funds'),
    listCollection('payroll', (p) => p.month === currentMonthISO()),
    listCollection('loans', (l) => l.direction === 'payable')
  ]);

  const presentToday = attendance.filter((a) => a.status === 'present').length;
  const absentToday = attendance.filter((a) => a.status === 'absent').length;

  const filteredTx = transactions.filter((t) => inDateRange(t.date));
  const totalIncome = filteredTx.filter((t) => t.type === 'income').reduce((s, t) => s + Number(t.amount || 0), 0);
  const totalExpense = filteredTx.filter((t) => t.type === 'expense').reduce((s, t) => s + Number(t.amount || 0), 0);
  const totalDonation = filteredTx
    .filter((t) => t.type === 'income' && ['general_donation', 'zakat', 'sadaqah', 'fitra', 'qurbani_skin', 'mahfil'].includes(t.category))
    .reduce((s, t) => s + Number(t.amount || 0), 0);

  const totalBalance = funds.reduce((s, f) => s + Number(f.currentBalance || 0), 0);
  const totalDueFees = invoices.reduce((s, inv) => s + Number(inv.dueAmount || 0), 0);
  const unpaidSalaryCount = payrolls.filter((p) => p.status !== 'paid').length;
  const totalLoanPayable = loans.reduce((s, l) => s + Number(l.remainingAmount || 0), 0);

  const maxBar = Math.max(totalIncome, totalExpense, totalDonation, 1);
  const incW = Math.round((totalIncome / maxBar) * 100);
  const expW = Math.round((totalExpense / maxBar) * 100);
  const donW = Math.round((totalDonation / maxBar) * 100);

  container.innerHTML = `
    <div class="page-header">
      <div>
        <h1>মুহতামিম ড্যাশবোর্ড</h1>
        <p class="page-subtitle">এক স্ক্রিনে মাদ্রাসার সার্বিক চিত্র</p>
      </div>
      <div style="display:flex;gap:8px;">
        <button type="button" class="btn btn-primary btn-sm" id="dash-quick-adm">${icon('admission', 'sm')} নতুন ভর্তি</button>
        <button type="button" class="btn btn-secondary btn-sm" id="dash-quick-att">${icon('attendance', 'sm')} হাজিরা</button>
      </div>
    </div>

    <div class="tabs" id="dash-range-tabs">
      <button type="button" class="tab-btn ${activeRange === 'today' ? 'active' : ''}" data-range="today">আজ</button>
      <button type="button" class="tab-btn ${activeRange === 'week' ? 'active' : ''}" data-range="week">সপ্তাহ</button>
      <button type="button" class="tab-btn ${activeRange === 'month' ? 'active' : ''}" data-range="month">মাস</button>
      <button type="button" class="tab-btn ${activeRange === 'year' ? 'active' : ''}" data-range="year">বছর</button>
      <button type="button" class="tab-btn ${activeRange === 'custom' ? 'active' : ''}" data-range="custom">কাস্টম</button>
    </div>

    ${activeRange === 'custom' ? `
      <div class="toolbar">
        <input type="date" id="dash-from" class="form-control" value="${customFrom}">
        <input type="date" id="dash-to" class="form-control" value="${customTo}">
        <button type="button" id="dash-apply-custom" class="btn btn-primary">প্রয়োগ</button>
      </div>
    ` : ''}

    <div class="kpi-grid">
      <button type="button" class="kpi-card" data-nav="/students">
        <div class="kpi-top"><span>মোট ছাত্র</span><span class="kpi-icon">${icon('students', 'sm')}</span></div>
        <div class="kpi-value">${formatNum(students.length)}</div>
        <div class="kpi-meta">সক্রিয় শিক্ষার্থী</div>
      </button>

      <button type="button" class="kpi-card" data-nav="/attendance">
        <div class="kpi-top"><span>আজকের হাজিরা</span><span class="kpi-icon">${icon('attendance', 'sm')}</span></div>
        <div class="kpi-value">${formatNum(presentToday)} / ${formatNum(absentToday)}</div>
        <div class="kpi-meta">উপস্থিত / অনুপস্থিত</div>
      </button>

      <button type="button" class="kpi-card" data-nav="/donations">
        <div class="kpi-top"><span>দান সংগ্রহ</span><span class="kpi-icon">${icon('donation', 'sm')}</span></div>
        <div class="kpi-value">${formatCurrency(totalDonation)}</div>
        <div class="kpi-meta">নির্বাচিত সময়ে</div>
      </button>

      <button type="button" class="kpi-card" data-nav="/finance">
        <div class="kpi-top"><span>মোট ব্যালেন্স</span><span class="kpi-icon">${icon('shield', 'sm')}</span></div>
        <div class="kpi-value">${formatCurrency(totalBalance)}</div>
        <div class="kpi-meta">সকল তহবিল মিলিয়ে</div>
      </button>

      <button type="button" class="kpi-card" data-nav="/staff">
        <div class="kpi-top"><span>বকেয়া বেতন</span><span class="kpi-icon">${icon('staff', 'sm')}</span></div>
        <div class="kpi-value text-warning">${formatNum(unpaidSalaryCount)} জন</div>
        <div class="kpi-meta">চলতি মাসে বাকি</div>
      </button>

      <button type="button" class="kpi-card" data-nav="/loans">
        <div class="kpi-top"><span>মোট ঋণ / দেনা</span><span class="kpi-icon">${icon('loan', 'sm')}</span></div>
        <div class="kpi-value text-danger">${formatCurrency(totalLoanPayable)}</div>
        <div class="kpi-meta">পরিশোধযোগ্য ঋণ</div>
      </button>

      <button type="button" class="kpi-card" data-nav="/fees">
        <div class="kpi-top"><span>বকেয়া ছাত্র ফি</span><span class="kpi-icon">${icon('receipt', 'sm')}</span></div>
        <div class="kpi-value text-warning">${formatCurrency(totalDueFees)}</div>
        <div class="kpi-meta">আদায়যোগ্য বকেয়া</div>
      </button>

      <button type="button" class="kpi-card" data-nav="/reports">
        <div class="kpi-top"><span>আয় / ব্যয়</span><span class="kpi-icon">${icon('report', 'sm')}</span></div>
        <div class="kpi-value text-success">${formatCurrency(totalIncome)}</div>
        <div class="kpi-meta">ব্যয়: ${formatCurrency(totalExpense)}</div>
      </button>
    </div>

    <div class="card">
      <h2 style="margin-bottom:12px;">আয় বনাম ব্যয় সারাংশ</h2>
      <svg viewBox="0 0 420 118" style="width:100%;height:auto;display:block;" role="img" aria-label="আয় বনাম ব্যয় চার্ট">
        <text x="0" y="18" font-size="12" fill="currentColor">মোট আয় (${formatCurrency(totalIncome)})</text>
        <rect x="0" y="25" width="420" height="12" rx="6" fill="var(--bg-subtle)"/>
        <rect x="0" y="25" width="${Math.max(incW * 4.2, 4)}" height="12" rx="6" fill="var(--color-success)"/>

        <text x="0" y="58" font-size="12" fill="currentColor">মোট ব্যয় (${formatCurrency(totalExpense)})</text>
        <rect x="0" y="65" width="420" height="12" rx="6" fill="var(--bg-subtle)"/>
        <rect x="0" y="65" width="${Math.max(expW * 4.2, 4)}" height="12" rx="6" fill="var(--color-danger)"/>

        <text x="0" y="98" font-size="12" fill="currentColor">দান সংগ্রহ (${formatCurrency(totalDonation)})</text>
        <rect x="0" y="105" width="420" height="12" rx="6" fill="var(--bg-subtle)"/>
        <rect x="0" y="105" width="${Math.max(donW * 4.2, 4)}" height="12" rx="6" fill="var(--brand-accent)"/>
      </svg>
    </div>

    <div class="card">
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:12px;">
        <h2>তহবিলভিত্তিক ব্যালেন্স (শরিয়াহ পৃথকীকরণ)</h2>
        <button type="button" class="btn btn-outline btn-sm" id="dash-go-finance">বিস্তারিত</button>
      </div>
      <div class="list-stack">
        ${funds.map((f) => `
          <div class="list-item">
            <div class="list-item-main">
              <div class="list-item-title">${escapeHtml(f.nameBn)}</div>
              <div class="list-item-sub">${f.zakatRestricted ? 'শরিয়াহ নির্ধারিত খাতে সীমাবদ্ধ' : 'সাধারণ ব্যবস্থাপনা ও পরিচালনা'}</div>
            </div>
            <strong>${formatCurrency(f.currentBalance)}</strong>
          </div>
        `).join('')}
      </div>
    </div>
  `;

  container.querySelectorAll('[data-nav]').forEach((btn) => {
    btn.onclick = () => navigate(btn.dataset.nav);
  });
  document.getElementById('dash-quick-adm').onclick = () => navigate('/admission');
  document.getElementById('dash-quick-att').onclick = () => navigate('/attendance');
  document.getElementById('dash-go-finance').onclick = () => navigate('/finance');

  container.querySelectorAll('#dash-range-tabs .tab-btn').forEach((btn) => {
    btn.onclick = () => {
      activeRange = btn.dataset.range;
      renderDashboard(container);
    };
  });
  document.getElementById('dash-apply-custom')?.addEventListener('click', () => {
    customFrom = document.getElementById('dash-from').value;
    customTo = document.getElementById('dash-to').value;
    renderDashboard(container);
  });
}
