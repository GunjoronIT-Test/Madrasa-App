/**
 * অফলাইন পিওর-জাভাস্ক্রিপ্ট ভেক্টর SVG QR কোড জেনারেটর (Version 3-L, Byte Mode)
 * কোনো বাহ্যিক API বা ইন্টারনেট ছাড়াই প্রতিটি রিসিটে স্ক্যানযোগ্য ভেক্টর QR তৈরি করে।
 */
const GF_EXP = new Uint8Array(512);
const GF_LOG = new Uint8Array(256);
(() => {
  let x = 1;
  for (let i = 0; i < 255; i++) {
    GF_EXP[i] = x;
    GF_LOG[x] = i;
    x <<= 1;
    if (x & 0x100) x ^= 0x11d;
  }
  for (let i = 255; i < 512; i++) GF_EXP[i] = GF_EXP[i - 255];
})();

function gfMul(a, b) {
  return a === 0 || b === 0 ? 0 : GF_EXP[GF_LOG[a] + GF_LOG[b]];
}

function rsGeneratorPoly(degree) {
  let poly = [1];
  for (let i = 0; i < degree; i++) {
    const next = new Array(poly.length + 1).fill(0);
    for (let j = 0; j < poly.length; j++) {
      next[j] ^= poly[j];
      next[j + 1] ^= gfMul(poly[j], GF_EXP[i]);
    }
    poly = next;
  }
  return poly;
}

function rsEncode(data, ecLen) {
  const gen = rsGeneratorPoly(ecLen);
  const res = new Uint8Array(data.length + ecLen);
  res.set(data);
  for (let i = 0; i < data.length; i++) {
    const factor = res[i];
    if (factor !== 0) {
      for (let j = 0; j < gen.length; j++) {
        res[i + j] ^= gfMul(gen[j], factor);
      }
    }
  }
  return res.slice(data.length);
}

// Version 3-L: size 29x29, 55 data codewords, 15 EC codewords (fits up to 53 bytes)
export function generateQrSvg(text, pixelSize = 112) {
  const bytes = new TextEncoder().encode(String(text).slice(0, 53));
  const totalData = 55;
  const ecLen = 15;
  const size = 29;

  // 1. Build bit stream
  const bits = [];
  const pushBits = (val, len) => {
    for (let i = len - 1; i >= 0; i--) bits.push((val >> i) & 1);
  };
  pushBits(0b0100, 4); // Byte mode
  pushBits(bytes.length, 8);
  for (const b of bytes) pushBits(b, 8);
  pushBits(0, Math.min(4, totalData * 8 - bits.length));
  while (bits.length % 8 !== 0) bits.push(0);

  const data = new Uint8Array(totalData);
  for (let i = 0; i < bits.length / 8; i++) {
    let val = 0;
    for (let j = 0; j < 8; j++) val = (val << 1) | bits[i * 8 + j];
    data[i] = val;
  }
  const padBytes = [0xec, 0x11];
  for (let i = bits.length / 8, p = 0; i < totalData; i++, p++) {
    data[i] = padBytes[p & 1];
  }

  const ec = rsEncode(data, ecLen);
  const allCodewords = new Uint8Array(totalData + ecLen);
  allCodewords.set(data);
  allCodewords.set(ec, totalData);

  // 2. Initialize matrix
  const mat = Array.from({ length: size }, () => new Int8Array(size).fill(-1));
  const reserved = Array.from({ length: size }, () => new Uint8Array(size));

  const setMod = (r, c, v, resv = true) => {
    if (r >= 0 && r < size && c >= 0 && c < size) {
      mat[r][c] = v ? 1 : 0;
      if (resv) reserved[r][c] = 1;
    }
  };

  const drawFinder = (r0, c0) => {
    for (let r = -1; r <= 7; r++) {
      for (let c = -1; c <= 7; c++) {
        const inside = r >= 0 && r <= 6 && c >= 0 && c <= 6;
        const border = r === 0 || r === 6 || c === 0 || c === 6;
        const center = r >= 2 && r <= 4 && c >= 2 && c <= 4;
        setMod(r0 + r, c0 + c, inside && (border || center));
      }
    }
  };
  drawFinder(0, 0);
  drawFinder(0, size - 7);
  drawFinder(size - 7, 0);

  // Alignment pattern for V3 at (22, 22)
  for (let r = -2; r <= 2; r++) {
    for (let c = -2; c <= 2; c++) {
      const dark = Math.max(Math.abs(r), Math.abs(c)) !== 1;
      setMod(22 + r, 22 + c, dark);
    }
  }

  // Timing patterns
  for (let i = 8; i < size - 8; i++) {
    setMod(6, i, i % 2 === 0);
    setMod(i, 6, i % 2 === 0);
  }
  setMod(size - 8, 8, 1); // Dark module

  // Reserve format info areas
  for (let i = 0; i < 9; i++) {
    reserved[8][i] = 1;
    reserved[i][8] = 1;
  }
  for (let i = 0; i < 8; i++) {
    reserved[8][size - 1 - i] = 1;
    reserved[size - 1 - i][8] = 1;
  }

  // 3. Place data bits with Mask 0 ((r + c) % 2 === 0)
  let bitIdx = 0;
  let upward = true;
  for (let col = size - 1; col > 0; col -= 2) {
    if (col === 6) col--;
    for (let step = 0; step < size; step++) {
      const row = upward ? size - 1 - step : step;
      for (let dc = 0; dc < 2; dc++) {
        const c = col - dc;
        if (!reserved[row][c]) {
          const byteIdx = bitIdx >> 3;
          const bit = byteIdx < allCodewords.length
            ? (allCodewords[byteIdx] >> (7 - (bitIdx & 7))) & 1
            : 0;
          const masked = ((row + c) % 2 === 0) ? (bit ^ 1) : bit;
          mat[row][c] = masked;
          bitIdx++;
        }
      }
    }
    upward = !upward;
  }

  // 4. Write format info for EC Level L (01) + Mask 0 (000) => precomputed 15-bit BCH: 0x77c4
  const fmt = 0x77c4;
  for (let i = 0; i < 6; i++) {
    const b = (fmt >> i) & 1;
    mat[i][8] = b;
    mat[8][size - 1 - i] = b;
  }
  mat[7][8] = (fmt >> 6) & 1;
  mat[8][8] = (fmt >> 7) & 1;
  mat[8][7] = (fmt >> 8) & 1;
  for (let i = 9; i < 15; i++) {
    mat[8][14 - i] = (fmt >> i) & 1;
  }
  mat[8][size - 7] = (fmt >> 6) & 1;
  mat[8][size - 8] = (fmt >> 7) & 1;
  for (let i = 8; i < 15; i++) {
    mat[size - 15 + i][8] = (fmt >> i) & 1;
  }

  // 5. Render crisp SVG
  const quiet = 2;
  const vb = size + quiet * 2;
  let paths = '';
  for (let r = 0; r < size; r++) {
    for (let c = 0; c < size; c++) {
      if (mat[r][c] === 1) {
        paths += `M${c + quiet},${r + quiet}h1v1h-1z`;
      }
    }
  }
  return `<svg xmlns="http://www.w3.org/2000/svg" width="${pixelSize}" height="${pixelSize}" viewBox="0 0 ${vb} ${vb}" shape-rendering="crispEdges" role="img" aria-label="QR যাচাই কোড"><rect width="${vb}" height="${vb}" fill="#FFFFFF"/><path d="${paths}" fill="#14221D"/></svg>`;
}
