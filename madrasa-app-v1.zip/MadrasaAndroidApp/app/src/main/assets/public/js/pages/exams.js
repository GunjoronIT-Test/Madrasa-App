import { listCollection, addDocItem, setDocById } from '../core/store.js';
import { getBrand } from '../core/brand.js';
import { generateQrSvg } from '../core/qr.js';
import { logAudit } from '../core/audit.js';
import { icon } from '../core/icons.js';
import { todayISO, formatNum, escapeHtml, openModal, closeModal, showToast } from '../core/utils.js';

let selectedExamId = '';
let activeSubTab = 'marks'; // 'marks' | 'merit' | 'admit'

function computeQawmiGrade(avg) {
  if (avg >= 80) return 'মুমতাজ (A+)';
  if (avg >= 65) return 'জায়্যিদ জিদ্দান (A)';
  if (avg >= 50) return 'জায়্যিদ (B)';
  if (avg >= 33) return 'মকবুল (C)';
  return 'রাসিব (অকৃতকার্য)';
}

export async function renderExams(container) {
  const [exams, jamats, students, results] = await Promise.all([
    listCollection('exams'),
    listCollection('jamats', (j) => !j.isDeleted),
    listCollection('students', (s) => !s.isDeleted && s.status === 'active'),
    listCollection('exam_results')
  ]);

  if (!selectedExamId && exams.length > 0) selectedExamId = exams[0].id;
  const exam = exams.find((e) => e.id === selectedExamId) || null;
  const jamatMap = Object.fromEntries(jamats.map((j) => [j.id, j.nameBn]));
  const examStudents = exam
    ? students.filter((s) => s.jamatId === exam.jamatId).sort((a, b) => Number(a.rollNumber) - Number(b.rollNumber))
    : [];

  const examResults = results.filter((r) => r.examId === selectedExamId);
  const resMap = Object.fromEntries(examResults.map((r) => [r.studentId, r]));

  // মেধাক্রম নির্ণয়
  const ranked = examStudents
    .map((s) => {
      const r = resMap[s.id];
      return { student: s, total: Number(r?.total || 0), average: Number(r?.average || 0), grade: r?.grade || '-', marks: r?.marks || {} };
    })
    .sort((a, b) => b.total - a.total);

  let bodyHtml = '';
  if (!exam) {
    bodyHtml = `<div class="card empty-state">${icon('exam', 'lg')}<p>এখনো কোনো পরীক্ষা তৈরি করা হয়নি। "নতুন পরীক্ষা" বাটনে ক্লিক করুন।</p></div>`;
  } else if (activeSubTab === 'marks') {
    const subjects = exam.subjects || ['কুরআন/হিফজ', 'ফিকহ', 'আরবি'];
    bodyHtml = `
      <div class="table-wrap">
        <table class="data-table">
          <thead>
            <tr>
              <th>রোল ও ছাত্র</th>
              ${subjects.map((sub) => `<th>${escapeHtml(sub)}</th>`).join('')}
              <th>মোট</th>
              <th>বিভাগ / গ্রেড</th>
              <th>অ্যাকশন</th>
            </tr>
          </thead>
          <tbody>
            ${examStudents.map((s) => {
              const r = resMap[s.id] || { marks: {}, total: 0, grade: '-' };
              return `
                <tr>
                  <td><strong>${formatNum(s.rollNumber)}. ${escapeHtml(s.nameBn)}</strong></td>
                  ${subjects.map((sub) => `
                    <td><input type="number" min="0" max="100" class="form-control" style="min-height:36px;width:74px;" data-mk-stu="${s.id}" data-mk-sub="${escapeHtml(sub)}" value="${r.marks?.[sub] ?? ''}"></td>
                  `).join('')}
                  <td><strong>${formatNum(r.total || 0)}</strong></td>
                  <td><span class="badge badge-info">${escapeHtml(r.grade || '-')}</span></td>
                  <td><button type="button" class="btn btn-primary btn-sm" data-save-mk="${s.id}">সেভ</button></td>
                </tr>
              `;
            }).join('')}
          </tbody>
        </table>
      </div>
    `;
  } else if (activeSubTab === 'merit') {
    bodyHtml = `
      <div class="list-stack">
        ${ranked.map((item, idx) => `
          <div class="list-item" style="flex-wrap:wrap;">
            <div class="list-item-main">
              <div class="list-item-title">মেধাক্রম ${formatNum(idx + 1)}: ${escapeHtml(item.student.nameBn)} <span class="badge badge-success">${escapeHtml(item.grade)}</span></div>
              <div class="list-item-sub">রোল: ${formatNum(item.student.rollNumber)} | মোট নম্বর: ${formatNum(item.total)} | গড়: ${formatNum(item.average.toFixed(1))}%</div>
            </div>
            <button type="button" class="btn btn-outline btn-sm" data-marksheet="${item.student.id}" data-rank="${idx + 1}">${icon('print', 'sm')} মার্কশিট</button>
          </div>
        `).join('')}
      </div>
    `;
  } else {
    // প্রবেশপত্র প্রিভিউ ও প্রিন্ট
    const brand = getBrand() || {};
    bodyHtml = `
      <div style="display:flex;justify-content:flex-end;margin-bottom:12px;" class="no-print">
        <button type="button" class="btn btn-primary btn-sm" onclick="window.print()">${icon('print', 'sm')} সকল প্রবেশপত্র প্রিন্ট / PDF</button>
      </div>
      <div class="list-stack">
        ${examStudents.map((s) => {
          const code = `ADM-${exam.id.slice(-4)}-${s.rollNumber}`;
          const qr = generateQrSvg(`${window.location.origin}${window.location.pathname}#/verify/${code}`, 72);
          return `
            <div class="receipt-paper" style="padding:16px;page-break-inside:avoid;">
              <div style="display:flex;justify-content:space-between;align-items:center;border-bottom:2px solid var(--brand-primary);padding-bottom:8px;margin-bottom:10px;">
                <div>
                  <h3>${escapeHtml(brand.nameBn || 'মাদ্রাসা')}</h3>
                  <div style="font-size:12px;color:#485B54;">প্রবেশপত্র — ${escapeHtml(exam.titleBn)}</div>
                </div>
                <div>${qr}</div>
              </div>
              <div class="receipt-meta-grid" style="margin-bottom:0;">
                <div><strong>ছাত্রের নাম:</strong> ${escapeHtml(s.nameBn)}</div>
                <div><strong>রোল নম্বর:</strong> ${formatNum(s.rollNumber)}</div>
                <div><strong>জামাত:</strong> ${escapeHtml(jamatMap[s.jamatId] || '')}</div>
                <div><strong>পরীক্ষার তারিখ:</strong> ${escapeHtml(exam.startDate || '')}</div>
              </div>
            </div>
          `;
        }).join('')}
      </div>
    `;
  }

  container.innerHTML = `
    <div class="page-header no-print">
      <div>
        <h1>পরীক্ষা, প্রবেশপত্র ও ফলাফল</h1>
        <p class="page-subtitle">কওমি (বেফাক) ও সাধারণ গ্রেডিং, অটো মেধাক্রম ও প্রবেশপত্র</p>
      </div>
      <button type="button" class="btn btn-primary btn-sm" id="btn-new-exam">${icon('plus', 'sm')} নতুন পরীক্ষা</button>
    </div>

    ${exams.length > 0 ? `
      <div class="toolbar no-print">
        <select id="exam-select" class="form-control">
          ${exams.map((e) => `<option value="${e.id}" ${e.id === selectedExamId ? 'selected' : ''}>${escapeHtml(e.titleBn)} (${escapeHtml(jamatMap[e.jamatId] || '')})</option>`).join('')}
        </select>
      </div>
      <div class="tabs no-print">
        <button type="button" class="tab-btn ${activeSubTab === 'marks' ? 'active' : ''}" data-sub="marks">নম্বর এন্ট্রি</button>
        <button type="button" class="tab-btn ${activeSubTab === 'merit' ? 'active' : ''}" data-sub="merit">মেধা তালিকা ও মার্কশিট</button>
        <button type="button" class="tab-btn ${activeSubTab === 'admit' ? 'active' : ''}" data-sub="admit">অটো প্রবেশপত্র</button>
      </div>
    ` : ''}

    ${bodyHtml}
  `;

  document.getElementById('exam-select')?.addEventListener('change', (e) => {
    selectedExamId = e.target.value;
    renderExams(container);
  });

  container.querySelectorAll('[data-sub]').forEach((b) => {
    b.onclick = () => {
      activeSubTab = b.dataset.sub;
      renderExams(container);
    };
  });

  document.getElementById('btn-new-exam').onclick = () => {
    openModal({
      title: 'নতুন পরীক্ষা তৈরি করুন',
      bodyHtml: `
        <div class="form-grid">
          <div class="form-group">
            <label class="form-label">পরীক্ষার নাম *</label>
            <input id="ex-title" class="form-control" placeholder="যেমন: ১ম সাময়িক পরীক্ষা ২০২৬">
          </div>
          <div class="form-group">
            <label class="form-label">জামাত *</label>
            <select id="ex-jamat" class="form-control">
              ${jamats.map((j) => `<option value="${j.id}">${escapeHtml(j.nameBn)}</option>`).join('')}
            </select>
          </div>
          <div class="form-group">
            <label class="form-label">শুরুর তারিখ</label>
            <input id="ex-date" class="form-control" type="date" value="${todayISO()}">
          </div>
          <div class="form-group">
            <label class="form-label">বিষয়সমূহ (কমা দিয়ে আলাদা করুন)</label>
            <input id="ex-subs" class="form-control" value="কুরআন মাজীদ, ফিকহ, আরবি, বাংলা ও গণিত">
          </div>
        </div>
      `,
      footerHtml: `
        <button type="button" class="btn btn-secondary" id="ex-cancel">বাতিল</button>
        <button type="button" class="btn btn-primary" id="ex-save">তৈরি করুন</button>
      `
    });
    document.getElementById('ex-cancel').onclick = closeModal;
    document.getElementById('ex-save').onclick = async () => {
      const titleBn = document.getElementById('ex-title').value.trim();
      if (!titleBn) return showToast('পরীক্ষার নাম দিন', 'warning');
      const subjects = document.getElementById('ex-subs').value.split(',').map((x) => x.trim()).filter(Boolean);
      const doc = await addDocItem('exams', {
        branchId: 'main',
        titleBn,
        jamatId: document.getElementById('ex-jamat').value,
        startDate: document.getElementById('ex-date').value,
        gradingSystem: 'qawmi_befaq',
        subjects: subjects.length ? subjects : ['কুরআন', 'ফিকহ']
      });
      selectedExamId = doc.id;
      await logAudit({ action: 'CREATE_EXAM', collection: 'exams', docId: doc.id, summary: `নতুন পরীক্ষা: ${titleBn}` });
      closeModal();
      showToast('পরীক্ষা তৈরি হয়েছে', 'success');
      renderExams(container);
    };
  };

  container.querySelectorAll('[data-save-mk]').forEach((b) => {
    b.onclick = async () => {
      const stuId = b.dataset.saveMk;
      const inputs = container.querySelectorAll(`[data-mk-stu="${stuId}"]`);
      const marks = {};
      let total = 0;
      let count = 0;
      inputs.forEach((inp) => {
        const val = Number(inp.value || 0);
        marks[inp.dataset.mkSub] = val;
        total += val;
        count++;
      });
      const avg = count ? total / count : 0;
      const grade = computeQawmiGrade(avg);
      await setDocById('exam_results', `res_${selectedExamId}_${stuId}`, {
        branchId: 'main',
        examId: selectedExamId,
        studentId: stuId,
        marks,
        total,
        average: avg,
        grade
      });
      showToast('নম্বর ও গ্রেড সংরক্ষিত হয়েছে', 'success');
      renderExams(container);
    };
  });

  container.querySelectorAll('[data-marksheet]').forEach((b) => {
    b.onclick = () => {
      const stuId = b.dataset.marksheet;
      const rank = b.dataset.rank;
      const stu = examStudents.find((s) => s.id === stuId);
      const res = resMap[stuId] || { marks: {}, total: 0, average: 0, grade: '-' };
      const brand = getBrand() || {};
      const qr = generateQrSvg(`${window.location.origin}${window.location.pathname}#/verify/RES-${selectedExamId.slice(-4)}-${stuId}`, 80);

      openModal({
        title: `মার্কশিট — ${stu?.nameBn || ''}`,
        bodyHtml: `
          <div class="receipt-paper" style="padding:16px;">
            <div style="text-align:center;border-bottom:2px solid var(--brand-primary);padding-bottom:8px;margin-bottom:12px;">
              <h3>${escapeHtml(brand.nameBn || 'মাদ্রাসা')}</h3>
              <div style="font-size:12px;">একাডেমিক মার্কশিট — ${escapeHtml(exam.titleBn)}</div>
            </div>
            <div class="receipt-meta-grid">
              <div><strong>ছাত্র:</strong> ${escapeHtml(stu?.nameBn || '')}</div>
              <div><strong>রোল:</strong> ${formatNum(stu?.rollNumber)}</div>
              <div><strong>জামাত:</strong> ${escapeHtml(jamatMap[stu?.jamatId] || '')}</div>
              <div><strong>মেধাক্রম:</strong> ${formatNum(rank)} তম</div>
            </div>
            <table class="data-table" style="margin-bottom:12px;">
              <thead><tr><th>বিষয়</th><th class="text-right">প্রাপ্ত নম্বর</th></tr></thead>
              <tbody>
                ${Object.entries(res.marks || {}).map(([sub, mk]) => `<tr><td>${escapeHtml(sub)}</td><td class="text-right">${formatNum(mk)}</td></tr>`).join('')}
                <tr><td><strong>মোট নম্বর ও গ্রেড</strong></td><td class="text-right"><strong>${formatNum(res.total)} (${escapeHtml(res.grade)})</strong></td></tr>
              </tbody>
            </table>
            <div style="display:flex;justify-content:space-between;align-items:flex-end;">
              <div>${qr}</div>
              <div class="sig-line">${escapeHtml(brand.muhtamimName || 'মুহতামিম')}</div>
            </div>
          </div>
        `,
        footerHtml: `<button type="button" class="btn btn-primary btn-sm" onclick="window.print()">প্রিন্ট / PDF</button>`
      });
    };
  });
}
