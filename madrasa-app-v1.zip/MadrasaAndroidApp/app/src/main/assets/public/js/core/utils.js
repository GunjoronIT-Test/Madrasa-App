/**
 * বাংলা/ইংরেজি সংখ্যা, হিজরি + ইংরেজি দ্বৈত তারিখ, মুদ্রা, হ্যাশিং ও টোস্ট
 */
const BN_DIGITS = ['০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯'];

let numberFormatPref = 'bn';
let currencySymbolPref = '৳';

export function setFormatPrefs({ numberFormat = 'bn', currencySymbol = '৳' } = {}) {
  numberFormatPref = numberFormat;
  currencySymbolPref = currencySymbol || '৳';
}

export function toBnDigits(input) {
  return String(input ?? '').replace(/\d/g, (d) => BN_DIGITS[Number(d)]);
}

export function formatNum(value) {
  const str = String(value ?? '0');
  return numberFormatPref === 'bn' ? toBnDigits(str) : str;
}

export function formatCurrency(amount) {
  const num = Number(amount || 0);
  const formatted = num.toLocaleString('en-IN', { maximumFractionDigits: 2 });
  return `${currencySymbolPref} ${formatNum(formatted)}`;
}

export function todayISO() {
  const d = new Date();
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${y}-${m}-${day}`;
}

export function currentMonthISO() {
  return todayISO().slice(0, 7);
}

export function getHijriDateString(dateObj = new Date()) {
  try {
    const fmt = new Intl.DateTimeFormat('bn-BD-u-ca-islamic-umalqura', {
      day: 'numeric',
      month: 'long',
      year: 'numeric'
    });
    return fmt.format(dateObj) + ' হি.';
  } catch {
    return '';
  }
}

export function getGregorianDateString(dateObj = new Date()) {
  try {
    return new Intl.DateTimeFormat('bn-BD', {
      day: 'numeric',
      month: 'long',
      year: 'numeric'
    }).format(dateObj);
  } catch {
    return todayISO();
  }
}

export function getDualDateLine(dateObj = new Date()) {
  const greg = getGregorianDateString(dateObj);
  const hijri = getHijriDateString(dateObj);
  return hijri ? `${greg} | ${hijri}` : greg;
}

export function escapeHtml(str) {
  return String(str ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

export function uid(prefix = 'id') {
  return `${prefix}_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 8)}`;
}

export async function sha256Hex(text) {
  const data = new TextEncoder().encode(text);
  const hashBuf = await crypto.subtle.digest('SHA-256', data);
  return Array.from(new Uint8Array(hashBuf))
    .map((b) => b.toString(16).padStart(2, '0'))
    .join('');
}

export function showToast(message, type = 'info') {
  const container = document.getElementById('toast-container');
  if (!container) return;
  const el = document.createElement('div');
  el.className = `toast toast-${type}`;
  el.textContent = message;
  container.appendChild(el);
  setTimeout(() => el.remove(), 3400);
}

export function openModal({ title, bodyHtml, footerHtml = '' }) {
  const root = document.getElementById('modal-root');
  document.getElementById('modal-title').textContent = title;
  document.getElementById('modal-body').innerHTML = bodyHtml;
  document.getElementById('modal-footer').innerHTML = footerHtml;
  root.hidden = false;
  return root;
}

export function closeModal() {
  const root = document.getElementById('modal-root');
  if (root) root.hidden = true;
}

export function readFileAsDataUrl(file, maxBytes = 1024 * 1024) {
  return new Promise((resolve, reject) => {
    if (!file) return resolve('');
    if (file.size > maxBytes) {
      return reject(new Error('ফাইলের সাইজ সীমার চেয়ে বেশি (সর্বোচ্চ ১ মেগাবাইট)'));
    }
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result || ''));
    reader.onerror = () => reject(new Error('ফাইল পড়া যায়নি'));
    reader.readAsDataURL(file);
  });
}

export const ROLE_LABELS = {
  muhtamim: 'মুহতামিম',
  nayeb_muhtamim: 'নায়েবে মুহতামিম',
  accountant: 'হিসাবরক্ষক',
  education_secretary: 'শিক্ষা সচিব',
  ustad: 'ওস্তাদ',
  office_staff: 'অফিস স্টাফ',
  guardian: 'অভিভাবক'
};

export const STUDENT_CATEGORIES = {
  residential: 'আবাসিক',
  non_residential: 'অনাবাসিক',
  lillah_boarding: 'লিল্লাহ বোর্ডিং',
  orphan: 'এতিম'
};
