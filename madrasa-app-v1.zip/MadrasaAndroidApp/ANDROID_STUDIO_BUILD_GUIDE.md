# অ্যান্ড্রয়েড স্টুডিও (Android Studio) থেকে APK বিল্ড গাইড

এই প্রজেক্টটি সরাসরি Android Studio-তে ওপেন করে APK বানানোর জন্য সম্পূর্ণ প্রস্তুত (Node.js বা npm লাগবে না)।

## প্রজেক্টের তথ্য
- **অ্যাপের নাম:** মাদ্রাসা ম্যানেজমেন্ট
- **প্যাকেজ নেম (Application ID):** `com.madrasa.darululum.app`
- **ন্যূনতম অ্যান্ড্রয়েড ভার্সন:** Android 7.0 (API 24) বা তার উপরে
- **সম্পূর্ণ অফলাইন ও ডেমো সাপোর্ট:** অ্যাপটি ইনস্টল করেই প্রথম স্ক্রিনে **"ডেমো ডেটা দিয়ে ট্রেনিং মোড"** ক্লিক করে ফোনে সব মডিউল (ফেজ ১–৪) টেস্ট করতে পারবেন।

## ৪ ধাপে APK বানান
1. জিপ ফাইলটি এক্সট্র্যাক্ট করে `MadrasaAndroidApp` ফোল্ডারটি কম্পিউটারে রাখুন।
2. **Android Studio** ওপেন করে **File > Open** ক্লিক করুন এবং `MadrasaAndroidApp` ফোল্ডারটি সিলেক্ট করুন।
3. নিচে **Gradle Sync** শেষ হওয়া পর্যন্ত ১–২ মিনিট অপেক্ষা করুন (প্রথমবার ইন্টারনেট সংযোগ থাকতে হবে যাতে AndroidX ও Gradle ডাউনলোড হয়)।
4. Sync শেষ হলে:
   - সরাসরি ফোনে চালাতে: USB কেবল দিয়ে ফোন যুক্ত করে উপরের **Run (সবুজ প্লে বাটন)** ক্লিক করুন।
   - APK ফাইল বানাতে: মেনু থেকে **Build > Build Bundle(s) / APK(s) > Build APK(s)** ক্লিক করুন।
   - বিল্ড শেষ হলে `app/build/outputs/apk/debug/app-debug.apk` ফাইলটি ফোনে নিয়ে ইনস্টল করুন।

## পরে নিজের মাদ্রাসার জন্য নাম ও Firebase যুক্ত করতে চাইলে
- **অ্যাপের নাম বদলাতে:** `app/src/main/res/values/strings.xml`
- **প্যাকেজ নেম বদলাতে:** `app/build.gradle`-এর `applicationId`
- **Firebase যুক্ত করতে:** `app/src/main/assets/public/config/firebase-config.example.js` কপি করে একই ফোল্ডারে `firebase-config.js` নামে সেভ করে আপনার Firebase কনফিগ বসান।
