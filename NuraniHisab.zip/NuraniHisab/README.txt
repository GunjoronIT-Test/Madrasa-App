নূরানী হিসাব - Android Studio প্রজেক্ট

১) Android Studio -> File > Open -> এই NuraniHisab ফোল্ডারটি সিলেক্ট করুন
২) Gradle Sync শেষ হওয়া পর্যন্ত অপেক্ষা করুন (প্রথমবার ইন্টারনেট লাগবে, SDK/Gradle নামাতে)
৩) APK: Build > Build Bundle(s) / APK(s) > Build APK(s)
   ফাইল: app/build/outputs/apk/debug/app-debug.apk

* অ্যাপ সম্পূর্ণ অফলাইন, কোনো পারমিশন লাগে না
* HTML ফাইল: app/src/main/assets/index.html
* আইকন: app/src/main/res/drawable/ic_launcher_*.xml (ভেক্টর)
