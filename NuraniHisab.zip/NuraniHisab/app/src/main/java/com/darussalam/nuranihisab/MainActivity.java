package com.darussalam.nuranihisab;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintManager;
import android.text.InputType;
import android.webkit.JavascriptInterface;
import android.webkit.JsPromptResult;
import android.webkit.JsResult;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity {

    private static final int REQ_SAVE = 101;
    private static final int REQ_OPEN = 102;

    private WebView web;
    private String pendingBackup;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        web = new WebView(this);
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(false);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        s.setTextZoom(100);

        web.addJavascriptInterface(new Bridge(), "Android");
        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onJsAlert(WebView view, String url, String message, final JsResult result) {
                new AlertDialog.Builder(MainActivity.this)
                        .setMessage(message)
                        .setPositiveButton("ঠিক আছে", (d, w) -> result.confirm())
                        .setOnCancelListener(d -> result.cancel())
                        .show();
                return true;
            }

            @Override
            public boolean onJsConfirm(WebView view, String url, String message, final JsResult result) {
                new AlertDialog.Builder(MainActivity.this)
                        .setMessage(message)
                        .setPositiveButton("হ্যাঁ", (d, w) -> result.confirm())
                        .setNegativeButton("না", (d, w) -> result.cancel())
                        .setOnCancelListener(d -> result.cancel())
                        .show();
                return true;
            }

            @Override
            public boolean onJsPrompt(WebView view, String url, String message, String defaultValue, final JsPromptResult result) {
                final EditText input = new EditText(MainActivity.this);
                input.setInputType(InputType.TYPE_CLASS_NUMBER);
                if (defaultValue != null) {
                    input.setText(defaultValue);
                    input.setSelection(input.getText().length());
                }
                new AlertDialog.Builder(MainActivity.this)
                        .setMessage(message)
                        .setView(input)
                        .setPositiveButton("ঠিক আছে", (d, w) -> result.confirm(input.getText().toString()))
                        .setNegativeButton("বাতিল", (d, w) -> result.cancel())
                        .setOnCancelListener(d -> result.cancel())
                        .show();
                return true;
            }
        });

        web.loadUrl("file:///android_asset/index.html");
    }

    @Override
    protected void onPause() {
        super.onPause();
        web.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        web.onResume();
    }

    @Override
    protected void onDestroy() {
        if (web != null) {
            web.destroy();
        }
        super.onDestroy();
    }

    /** JavaScript থেকে ডাকা যায় এমন ফাংশনগুলো (window.Android.xxx) */
    private class Bridge {

        // ডাটার দ্বিতীয় নিরাপদ কপি (localStorage হারালেও যেন ডাটা থাকে)
        @JavascriptInterface
        public void nativeSave(String key, String value) {
            getSharedPreferences("nurani_hisab", Context.MODE_PRIVATE)
                    .edit().putString(key, value).apply();
        }

        @JavascriptInterface
        public String nativeLoad(String key) {
            return getSharedPreferences("nurani_hisab", Context.MODE_PRIVATE)
                    .getString(key, null);
        }

        @JavascriptInterface
        public void printPage() {
            runOnUiThread(() -> {
                try {
                    PrintManager pm = (PrintManager) getSystemService(Context.PRINT_SERVICE);
                    String job = "Nurani_Hisab";
                    PrintDocumentAdapter adapter = web.createPrintDocumentAdapter(job);
                    PrintAttributes attrs = new PrintAttributes.Builder()
                            .setMediaSize(PrintAttributes.MediaSize.ISO_A4.asLandscape())
                            .build();
                    pm.print(job, adapter, attrs);
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "প্রিন্ট চালু করা যায়নি", Toast.LENGTH_LONG).show();
                }
            });
        }

        @JavascriptInterface
        public void saveBackup(String json) {
            pendingBackup = json;
            runOnUiThread(() -> {
                try {
                    String date = new SimpleDateFormat("yyyy-MM-dd_HH-mm", Locale.US).format(new Date());
                    Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                    i.addCategory(Intent.CATEGORY_OPENABLE);
                    i.setType("application/json");
                    i.putExtra(Intent.EXTRA_TITLE, "nurani-hisab-backup-" + date + ".json");
                    startActivityForResult(i, REQ_SAVE);
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "ব্যাকআপ শুরু করা যায়নি", Toast.LENGTH_LONG).show();
                }
            });
        }

        @JavascriptInterface
        public void restoreBackup() {
            runOnUiThread(() -> {
                try {
                    Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                    i.addCategory(Intent.CATEGORY_OPENABLE);
                    i.setType("*/*");
                    startActivityForResult(i, REQ_OPEN);
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "ফাইল সিলেক্ট করা যায়নি", Toast.LENGTH_LONG).show();
                }
            });
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();

        if (requestCode == REQ_SAVE) {
            try (OutputStream os = getContentResolver().openOutputStream(uri, "wt")) {
                if (os == null || pendingBackup == null) throw new Exception("empty");
                os.write(pendingBackup.getBytes("UTF-8"));
                os.flush();
                Toast.makeText(this, "ব্যাকআপ সেভ হয়েছে ✅", Toast.LENGTH_LONG).show();
            } catch (Exception e) {
                Toast.makeText(this, "ব্যাকআপ সেভ হয়নি ❌", Toast.LENGTH_LONG).show();
            }
            pendingBackup = null;

        } else if (requestCode == REQ_OPEN) {
            try (InputStream is = getContentResolver().openInputStream(uri)) {
                if (is == null) throw new Exception("empty");
                ByteArrayOutputStream bos = new ByteArrayOutputStream();
                byte[] buf = new byte[8192];
                int n;
                while ((n = is.read(buf)) > 0) bos.write(buf, 0, n);
                String text = bos.toString("UTF-8");
                web.evaluateJavascript("window.onRestore(" + JSONObject.quote(text) + ")", null);
            } catch (Exception e) {
                Toast.makeText(this, "ফাইল পড়া যায়নি ❌", Toast.LENGTH_LONG).show();
            }
        }
    }
}
