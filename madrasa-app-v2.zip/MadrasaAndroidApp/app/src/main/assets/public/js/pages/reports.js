import { listCollection } from '../core/store.js';
import { getBrand } from '../core/brand.js';
import { icon } from '../core/icons.js';
import { formatCurrency, formatNum, escapeHtml, showToast, todayISO, downloadFile } from '../core/utils.js';

let reportType = 'finance'; // 'finance' | 'students' | 'payroll' | 'loans'

function downloadCsv(filename, headers, rows) {
  const esc = (v) => `"${String(v ?? '').replace(/"/g, '""')}"`;
  const csv = '\uFEFF' + [headers.map(esc).join(','), ...rows.map((r) => r.map(esc).join(','))].join('\n');
  downloadFile(filename, csv, 'text/csv;charset=utf-8');
}

export async function renderReports(container) {
  const brand = getBrand() || {};
  const [students, txs, funds, payrolls, staffList, loans, jamats] = await Promise.all([
    listCollection('students', (s) => !s.isDeleted),
    listCollection('transactions', (t) => t.status === 'posted'),
    listCollection('funds'),
    listCollection('payroll'),
    listCollection('staff', (s) => !s.isDeleted),
    listCollection('loans'),
    listCollection('jamats', (j) => !j.isDeleted)
  ]);

  const jamatMap = Object.fromEntries(jamats.map((j) => [j.id, j.nameBn]));
  const staffMap = Object.fromEntries(staffList.map((s) => [s.id, s.nameBn]));

  const totalInc = txs.filter((t) => t.type === 'income').reduce((s, t) => s + Number(t.amount || 0), 0);
  const totalExp = txs.filter((t) => t.type === 'expense').reduce((s, t) => s + Number(t.amount || 0), 0);
  const totalBal = funds.reduce((s, f) => s + Number(f.currentBalance || 0), 0);

  let headers = [];
  let rows = [];
  let summaryLine = '';

  if (reportType === 'finance') {
    headers = ['তারিখ', 'রিসিট নং', 'ধরন', 'বিবরণ', 'পরিমাণ'];
    rows = txs.map((t) => [t.date, t.receiptNo || '', t.type === 'income' ? 'আয়' : 'ব্যয়', t.description || '', t.amount]);
    summaryLine = `মোট আয়: ${formatCurrency(totalInc)} | মোট ব্যয়: ${formatCurrency(totalExp)} | বর্তমান ব্যালেন্স: ${formatCurrency(totalBal)}`;
  } else if (reportType === 'students') {
    headers = ['আইডি', 'রোল', 'ছাত্রের নাম', 'জামাত', 'অভিভাবকের ফোন', 'মাসিক ফি'];
    rows = students.map((s) => [s.studentCode || '', s.rollNumber, s.nameBn, jamatMap[s.jamatId] || '', s.guardianPhone || '', s.monthlyFee || 0]);
    summaryLine = `মোট সক্রিয় ছাত্র: ${formatNum(students.length)} জন`;
  } else if (reportType === 'payroll') {
    headers = ['মাস', 'ওস্তাদ/স্টাফ', 'মূল বেতন', 'বোনাস', 'কর্তন', 'নিট বেতন', 'অবস্থা'];
    rows = payrolls.map((p) => [p.month, staffMap[p.staffId] || p.staffId, p.baseSalary, p.bonus || 0, p.advanceDeduction || 0, p.netAmount, p.status === 'paid' ? 'পরিশোধিত' : 'বাকি']);
    summaryLine = `মোট বেতন রেকর্ড: ${formatNum(payrolls.length)} টি`;
  } else {
    headers = ['ধরন', 'ব্যক্তি/প্রতিষ্ঠান', 'মূল টাকা', 'পরিশোধ', 'বাকি', 'মেয়াদ'];
    rows = loans.map((l) => [l.direction === 'payable' ? 'মাদ্রাসার ঋণ' : 'পাওনা', l.partyName, l.principalAmount, l.paidAmount || 0, l.remainingAmount, l.dueDate || '-']);
    summaryLine = `মোট ঋণ/পাওনা এন্ট্রি: ${formatNum(loans.length)} টি`;
  }

  container.innerHTML = `
    <div class="page-header no-print">
      <div>
        <h1>রিপোর্ট ও এক্সপোর্ট (PDF / Excel)</h1>
        <p class="page-subtitle">দাতা ও কমিটির জন্য প্রিন্টযোগ্য রিপোর্ট এবং বাংলা Excel (CSV) এক্সপোর্ট</p>
      </div>
      <div style="display:flex;gap:8px;">
        <button type="button" class="btn btn-secondary btn-sm" id="rep-csv">${icon('download', 'sm')} Excel (CSV)</button>
        <button type="button" class="btn btn-primary btn-sm" onclick="window.print()">${icon('print', 'sm')} PDF / প্রিন্ট</button>
      </div>
    </div>

    <div class="tabs no-print">
      <button type="button" class="tab-btn ${reportType === 'finance' ? 'active' : ''}" data-rt="finance">আর্থিক রিপোর্ট</button>
      <button type="button" class="tab-btn ${reportType === 'students' ? 'active' : ''}" data-rt="students">ছাত্র তালিকা</button>
      <button type="button" class="tab-btn ${reportType === 'payroll' ? 'active' : ''}" data-rt="payroll">বেতন রিপোর্ট</button>
      <button type="button" class="tab-btn ${reportType === 'loans' ? 'active' : ''}" data-rt="loans">ঋণ ও পাওনা</button>
    </div>

    <div class="card">
      <div style="margin-bottom:12px;border-bottom:1px solid var(--border-color);padding-bottom:10px;">
        <h2>${escapeHtml(brand.nameBn || 'মাদ্রাসা')} — সার্ভিস রিপোর্ট</h2>
        <div class="page-subtitle">তারিখ: ${todayISO()} | ${summaryLine}</div>
      </div>

      ${rows.length === 0 ? `<p class="text-muted">এই রিপোর্টে কোনো ডেটা নেই।</p>` : `
        <div class="table-wrap">
          <table class="data-table">
            <thead><tr>${headers.map((h) => `<th>${escapeHtml(h)}</th>`).join('')}</tr></thead>
            <tbody>
              ${rows.map((r) => `<tr>${r.map((c) => `<td>${escapeHtml(c)}</td>`).join('')}</tr>`).join('')}
            </tbody>
          </table>
        </div>
      `}
    </div>
  `;

  container.querySelectorAll('[data-rt]').forEach((b) => {
    b.onclick = () => {
      reportType = b.dataset.rt;
      renderReports(container);
    };
  });

  document.getElementById('rep-csv').onclick = () => {
    downloadCsv(`madrasa-${reportType}-report-${todayISO()}.csv`, headers, rows);
    showToast('Excel-উপযোগী বাংলা CSV ডাউনলোড হয়েছে', 'success');
  };
}
