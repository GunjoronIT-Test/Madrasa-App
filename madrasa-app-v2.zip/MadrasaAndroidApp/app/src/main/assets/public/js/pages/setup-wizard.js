import { setDocById } from '../core/store.js';
import { loadAndApplyBrand } from '../core/brand.js';
import { seedDemoData } from '../core/demo-data.js';
import { navigate } from '../core/router.js';
import { icon } from '../core/icons.js';
import { sha256Hex, showToast, readFileAsDataUrl, escapeHtml, formatNum } from '../core/utils.js';
import { restoreSession } from '../core/auth.js';

const state = {
  step: 1,
  nameBn: '',
  nameEn: '',
  slogan: '',
  address: '',
  phone: '',
  muhtamimName: '',
  primaryColor: '#0F6E56',
  accentColor: '#B47B2B',
  logoUrl: '',
  adminEmail: '',
  adminPassword: '',
  adminPin: '1234',
  jamatsText: 'নাজেরা:800\nহিফজ:1200\nমিযান:1500\nহেদায়াতুন্নাহু:1500',
  academicYearName: '১৪৪৭-৪৮ হি. / ২০২৬-২৭',
  expenseApprovalLimit: 10000
};

export async function renderSetupWizard(container) {
  function draw() {
    const stepsHtml = [1, 2, 3, 4, 5]
      .map((s) => `<div class="step-dot ${s <= state.step ? 'active' : ''}"></div>`)
      .join('');

    let stepBody = '';
    if (state.step === 1) {
      stepBody = `
        <h2>ধাপ ১: প্রতিষ্ঠানের তথ্য ও ব্র্যান্ডিং</h2>
        <p class="page-subtitle" style="margin-bottom:16px;">এই তথ্য অ্যাপের হেডার, রিসিট, প্রবেশপত্র ও সব রিপোর্টে স্বয়ংক্রিয়ভাবে বসবে।</p>
        <div class="form-grid cols-2">
          <div class="form-group">
            <label class="form-label">মাদ্রাসার নাম (বাংলা) *</label>
            <input id="wiz-nameBn" class="form-control" value="${escapeHtml(state.nameBn)}" placeholder="যেমন: জামিয়া ইসলামিয়া দারুল উলূম">
          </div>
          <div class="form-group">
            <label class="form-label">মাদ্রাসার নাম (ইংরেজি)</label>
            <input id="wiz-nameEn" class="form-control" value="${escapeHtml(state.nameEn)}" placeholder="Jamia Islamia Darul Ulum">
          </div>
          <div class="form-group">
            <label class="form-label">স্লোগান / মূলনীতি</label>
            <input id="wiz-slogan" class="form-control" value="${escapeHtml(state.slogan)}" placeholder="দ্বীনি ইলম ও আমলের শিক্ষাকেন্দ্র">
          </div>
          <div class="form-group">
            <label class="form-label">মুহতামিমের নাম *</label>
            <input id="wiz-muhtamim" class="form-control" value="${escapeHtml(state.muhtamimName)}" placeholder="মাওলানা ...">
          </div>
          <div class="form-group">
            <label class="form-label">ঠিকানা *</label>
            <input id="wiz-address" class="form-control" value="${escapeHtml(state.address)}" placeholder="গ্রাম/রোড, থানা, জেলা">
          </div>
          <div class="form-group">
            <label class="form-label">ফোন নম্বর *</label>
            <input id="wiz-phone" class="form-control" value="${escapeHtml(state.phone)}" placeholder="017XXXXXXXX">
          </div>
          <div class="form-group">
            <label class="form-label">প্রধান রঙ</label>
            <input id="wiz-primary" class="form-control" type="color" value="${escapeHtml(state.primaryColor)}">
          </div>
          <div class="form-group">
            <label class="form-label">অ্যাকসেন্ট রঙ</label>
            <input id="wiz-accent" class="form-control" type="color" value="${escapeHtml(state.accentColor)}">
          </div>
          <div class="form-group" style="grid-column: 1 / -1;">
            <label class="form-label">মাদ্রাসার লোগো (ঐচ্ছিক, PNG/JPG)</label>
            <input id="wiz-logo" class="form-control" type="file" accept="image/*">
          </div>
        </div>
      `;
    } else if (state.step === 2) {
      stepBody = `
        <h2>ধাপ ২: মুহতামিম অ্যাকাউন্ট ও নিরাপত্তা PIN</h2>
        <p class="page-subtitle" style="margin-bottom:16px;">লগইন ইমেইল এবং সংবেদনশীল কাজের (বেতন, রিভার্সাল, রিস্টোর) জন্য ৪ সংখ্যার PIN দিন।</p>
        <div class="form-grid">
          <div class="form-group">
            <label class="form-label">মুহতামিম ইমেইল *</label>
            <input id="wiz-email" class="form-control" type="email" value="${escapeHtml(state.adminEmail)}" placeholder="muhtamim@madrasa.org">
          </div>
          <div class="form-group">
            <label class="form-label">পাসওয়ার্ড (কমপক্ষে ৬ অক্ষর) *</label>
            <input id="wiz-pass" class="form-control" type="password" value="${escapeHtml(state.adminPassword)}" placeholder="******">
          </div>
          <div class="form-group">
            <label class="form-label">নিরাপত্তা PIN (৪ সংখ্যা) *</label>
            <input id="wiz-pin" class="form-control" type="password" inputmode="numeric" maxlength="6" value="${escapeHtml(state.adminPin)}">
          </div>
        </div>
      `;
    } else if (state.step === 3) {
      stepBody = `
        <h2>ধাপ ৩: বিভাগ ও জামাত কাঠামো</h2>
        <p class="page-subtitle" style="margin-bottom:16px;">প্রতি লাইনে "জামাতের নাম:মাসিক ফি" ফরম্যাটে লিখুন। পরে সেটিংস থেকে বদলানো যাবে।</p>
        <div class="form-group">
          <label class="form-label">জামাত ও মাসিক ফি তালিকা</label>
          <textarea id="wiz-jamats" class="form-control" rows="6">${escapeHtml(state.jamatsText)}</textarea>
        </div>
      `;
    } else if (state.step === 4) {
      stepBody = `
        <h2>ধাপ ৪: তহবিল ও অনুমোদন সীমা</h2>
        <p class="page-subtitle" style="margin-bottom:16px;">শরিয়াহ অনুযায়ী সাধারণ, যাকাত, সদকা ও লিল্লাহ তহবিল স্বয়ংক্রিয়ভাবে আলাদা তৈরি হবে।</p>
        <div class="form-group">
          <label class="form-label">মুহতামিমের অনুমোদন সীমা (টাকা)</label>
          <input id="wiz-limit" class="form-control" type="number" min="0" value="${state.expenseApprovalLimit}">
          <span class="form-hint">এই অঙ্কের বেশি যেকোনো খরচে মুহতামিমের অনুমোদন প্রয়োজন হবে।</span>
        </div>
      `;
    } else {
      stepBody = `
        <h2>ধাপ ৫: শিক্ষাবর্ষ ও চূড়ান্ত শুরু</h2>
        <p class="page-subtitle" style="margin-bottom:16px;">বর্তমান শিক্ষাবর্ষের নাম নিশ্চিত করে সেটআপ সম্পন্ন করুন।</p>
        <div class="form-group" style="margin-bottom:16px;">
          <label class="form-label">শিক্ষাবর্ষ</label>
          <input id="wiz-ay" class="form-control" value="${escapeHtml(state.academicYearName)}">
        </div>
        <div class="alert-box alert-info">
          ${icon('shield', 'sm')}
          <span>আপনি চাইলে নিজের তথ্য দিয়ে শুরু করতে পারেন, অথবা প্রশিক্ষণের জন্য "ডেমো ডেটা দিয়ে শুরু করুন" বাটনে ক্লিক করতে পারেন।</span>
        </div>
      `;
    }

    container.innerHTML = `
      <div class="auth-wrap">
        <div class="card">
          <div style="display:flex;align-items:center;gap:10px;margin-bottom:12px;">
            ${icon('book', 'lg')}
            <div>
              <h1>প্রথমবার সেটআপ উইজার্ড</h1>
              <div class="page-subtitle">ধাপ ${formatNum(state.step)} / ৫</div>
            </div>
          </div>
          <div class="stepper">${stepsHtml}</div>
          ${stepBody}
          <div style="display:flex;justify-content:space-between;gap:8px;margin-top:20px;flex-wrap:wrap;">
            ${state.step > 1
              ? `<button type="button" id="wiz-prev" class="btn btn-secondary">পূর্ববর্তী</button>`
              : `<button type="button" id="wiz-demo-quick" class="btn btn-outline">ডেমো ডেটা দিয়ে ট্রেনিং মোড</button>`}
            ${state.step < 5
              ? `<button type="button" id="wiz-next" class="btn btn-primary">পরবর্তী ধাপ</button>`
              : `<button type="button" id="wiz-finish" class="btn btn-primary">${icon('check', 'sm')} সেটআপ সম্পন্ন করুন</button>`}
          </div>
        </div>
      </div>
    `;

    const logoInput = document.getElementById('wiz-logo');
    if (logoInput) {
      logoInput.onchange = async (e) => {
        try {
          state.logoUrl = await readFileAsDataUrl(e.target.files[0], 800 * 1024);
          showToast('লোগো সংযুক্ত হয়েছে', 'success');
        } catch (err) {
          showToast(err.message, 'error');
        }
      };
    }

    document.getElementById('wiz-prev')?.addEventListener('click', () => {
      captureStep();
      state.step -= 1;
      draw();
    });

    document.getElementById('wiz-next')?.addEventListener('click', () => {
      if (!captureStep()) return;
      state.step += 1;
      draw();
    });

    document.getElementById('wiz-demo-quick')?.addEventListener('click', async () => {
      const uid = await seedDemoData();
      localStorage.setItem('madrasa_session_uid', uid);
      await loadAndApplyBrand();
      showToast('ডেমো ট্রেনিং মোড চালু হয়েছে', 'success');
      await restoreSession();
      navigate('/dashboard');
    });

    document.getElementById('wiz-finish')?.addEventListener('click', async () => {
      if (!captureStep()) return;
      await saveFreshSetup();
      await loadAndApplyBrand();
      showToast('মাদ্রাসা সেটআপ সম্পন্ন হয়েছে! এখন লগইন করুন।', 'success');
      navigate('/login');
    });
  }

  function captureStep() {
    if (state.step === 1) {
      state.nameBn = document.getElementById('wiz-nameBn').value.trim();
      state.nameEn = document.getElementById('wiz-nameEn').value.trim();
      state.slogan = document.getElementById('wiz-slogan').value.trim();
      state.muhtamimName = document.getElementById('wiz-muhtamim').value.trim();
      state.address = document.getElementById('wiz-address').value.trim();
      state.phone = document.getElementById('wiz-phone').value.trim();
      state.primaryColor = document.getElementById('wiz-primary').value;
      state.accentColor = document.getElementById('wiz-accent').value;
      if (!state.nameBn || !state.muhtamimName || !state.address || !state.phone) {
        showToast('তারকা চিহ্নিত (*) ঘরগুলো পূরণ করুন', 'warning');
        return false;
      }
    } else if (state.step === 2) {
      state.adminEmail = document.getElementById('wiz-email').value.trim().toLowerCase();
      state.adminPassword = document.getElementById('wiz-pass').value;
      state.adminPin = document.getElementById('wiz-pin').value.trim();
      if (!state.adminEmail || state.adminPassword.length < 6 || state.adminPin.length < 4) {
        showToast('সঠিক ইমেইল, কমপক্ষে ৬ অক্ষরের পাসওয়ার্ড এবং ৪ সংখ্যার PIN দিন', 'warning');
        return false;
      }
    } else if (state.step === 3) {
      state.jamatsText = document.getElementById('wiz-jamats').value.trim();
    } else if (state.step === 4) {
      state.expenseApprovalLimit = Number(document.getElementById('wiz-limit').value || 10000);
    } else if (state.step === 5) {
      state.academicYearName = document.getElementById('wiz-ay').value.trim() || '২০২৬-২৭';
    }
    return true;
  }

  async function saveFreshSetup() {
    await setDocById('branches', 'main', { branchId: 'main', nameBn: 'মূল শাখা', isDefault: true, status: 'active' });
    await setDocById('settings', 'institution', {
      nameBn: state.nameBn,
      nameEn: state.nameEn,
      slogan: state.slogan,
      logoUrl: state.logoUrl,
      address: state.address,
      phone: state.phone,
      email: state.adminEmail,
      muhtamimName: state.muhtamimName,
      primaryColor: state.primaryColor,
      accentColor: state.accentColor,
      currencySymbol: '৳',
      academicStartMonth: 1,
      defaultLanguage: 'bn',
      numberFormat: 'bn',
      expenseApprovalLimit: state.expenseApprovalLimit,
      setupCompleted: true,
      demoMode: false
    });

    const uid = 'user_muhtamim_main';
    const passHash = await sha256Hex(`${uid}:${state.adminPassword}`);
    const pinHash = await sha256Hex(`${uid}_pin_v1:${state.adminPin}`);
    await setDocById('users', uid, {
      uid,
      name: state.muhtamimName,
      email: state.adminEmail,
      phone: state.phone,
      role: 'muhtamim',
      branchId: 'all',
      status: 'active',
      isDeleted: false,
      passwordHash: passHash,
      pinHash,
      pinSalt: `${uid}_pin_v1`
    });

    await setDocById('academic_years', 'ay_current', {
      branchId: 'main',
      nameBn: state.academicYearName,
      isCurrent: true
    });

    await setDocById('departments', 'dept_main', { branchId: 'main', nameBn: 'সাধারণ বিভাগ', order: 1, isDeleted: false });
    const lines = state.jamatsText.split('\n').map((l) => l.trim()).filter(Boolean);
    let idx = 1;
    for (const line of lines) {
      const [name, feeStr] = line.split(':');
      await setDocById('jamats', `jmt_${idx}`, {
        branchId: 'main',
        departmentId: 'dept_main',
        nameBn: (name || `জামাত ${idx}`).trim(),
        monthlyFeeDefault: Number(feeStr || 1000),
        order: idx,
        isDeleted: false
      });
      idx++;
    }

    const defaultFunds = [
      { id: 'fund_general', code: 'general', nameBn: 'সাধারণ তহবিল', zakatRestricted: false, currentBalance: 0 },
      { id: 'fund_zakat', code: 'zakat', nameBn: 'যাকাত তহবিল', zakatRestricted: true, currentBalance: 0 },
      { id: 'fund_sadaqah', code: 'sadaqah', nameBn: 'সদকা ও ফিতরা তহবিল', zakatRestricted: true, currentBalance: 0 },
      { id: 'fund_lillah', code: 'lillah', nameBn: 'লিল্লাহ বোর্ডিং তহবিল', zakatRestricted: true, currentBalance: 0 }
    ];
    for (const f of defaultFunds) await setDocById('funds', f.id, { branchId: 'main', ...f });

    const defaultAccounts = [
      { id: 'acc_cash', type: 'cash', nameBn: 'অফিস ক্যাশ', accountNo: '', currentBalance: 0 },
      { id: 'acc_bank', type: 'bank', nameBn: 'ব্যাংক অ্যাকাউন্ট', accountNo: '', currentBalance: 0 },
      { id: 'acc_bkash', type: 'bkash', nameBn: 'বিকাশ', accountNo: '', currentBalance: 0 },
      { id: 'acc_nagad', type: 'nagad', nameBn: 'নগদ', accountNo: '', currentBalance: 0 }
    ];
    for (const a of defaultAccounts) await setDocById('accounts', a.id, { branchId: 'main', ...a });
  }

  draw();
}
